# FusionBridge PC 0.6.5 — Minecraft dentro do GTA San Andreas (e do Skyrim)

O Minecraft Java e o GTA San Andreas rodam **ao mesmo tempo** no seu PC, e o **FusionBridge** fica no meio juntando os dois:

- a **câmera do GTA comanda a câmera do Minecraft**: o Minecraft desenha o mundo dele exatamente do ponto de vista do GTA;
- o **chão do GTA vira chão invisível no Minecraft**: blocos, mobs e itens ficam em cima das ruas de Los Santos;
- a **imagem do Minecraft é desenhada dentro do GTA** pela profundidade: um poste do GTA tapa a sua casa de blocos, e a casa tapa o carro atrás dela;
- o **Steve fica no lugar do CJ** a pé, e o mouse e as teclas 1–9 jogam o Minecraft;
- **TNT e creeper explodem nos dois jogos**, a pérola do Ender teleporta o CJ e os blocos que você constrói viram parede para os carros do GTA.

E na página **Mods fusion** fica o **SkyCraft** (Minecraft dentro do Skyrim), outro mod que junta dois jogos de verdade e que o app instala e abre.

## O que mudou na 0.6.5

- **A interface nova voltou, junto com tudo da 0.6.4:** barra lateral com as páginas **Ponte, Caos, Controles, Instalar, Mods fusion, Desempenho, Segurança, Diagnóstico e Log**, a logo do F na ponte ao pôr do sol (janela, barra de tarefas e atalho), fontes próprias e o visual de blocos.
- **SkyCraft (Minecraft dentro do Skyrim), de chasmlol (MIT):** cartão na página **Mods fusion**. O app acha o Skyrim, lê a versão do `SkyrimSE.exe`, confere se o SKSE e a Address Library são os da mesma versão, baixa o SkyCraft 0.1.2 oficial do GitHub (SHA-256 conferido), instala **sem sobrescrever nada** e faz **backup dos saves** antes. Também prepara o Minecraft do SkyCraft para você **entrar na conta Microsoft antes de jogar**, abre o Skyrim pelo SKSE (abrindo a Steam antes, se precisar), mostra os logs em palavras simples, liga e desliga as opções do `SkyCraft.ini` e avisa dos mods de câmera que brigam com ele.
- **Minecraft automático na fusão do GTA** (aprendido com o SkyCraft): o app usa um **Prism Launcher portátil** (baixado do GitHub oficial, SHA-256 conferido) com uma instância pronta: Minecraft 26.3 + Fabric 0.19.5 + os mods da fusão. **Não precisa mais do Minecraft Launcher nem do instalador do Fabric**, e as versões sempre batem. O Prism baixa o Minecraft e o Java sozinho.
  - **Abre o Minecraft sozinho quando o GTA abre**, e nunca abre um segundo.
  - **Fecha o Minecraft quando o GTA fecha**, mas só o que o app abriu (ele salva o mundo antes).
  - Opção de deixar a **janela do Minecraft fora da tela, sem minimizar** (minimizado ele quase para de desenhar).
  - O modo antigo (Minecraft Launcher oficial) continua: escolha na página **Instalar**.
- **Backup dos saves do GTA** antes de instalar, em `%LOCALAPPDATA%\FusionBridge\backups`.
- **Ponte integrada aos mods:** escolhendo o Skyrim como Host, a Ponte avisa que quem faz essa fusão é o SkyCraft e leva para a página dele.
- **Resident Doom removido:** ele era só uma referência de ideias e nunca devia ter entrado no app. Saíram o mod, o cartão e o reconhecimento do Doom e do Resident Evil no seletor de jogos. Parte do código dele vem de engenharia reversa do Resident Evil 1, então ficar fora evita qualquer problema. Se você usou o **Preparar** dele na 0.6.4, pode apagar a pasta `%LOCALAPPDATA%\FusionBridge\ResidentDoom`.
- **Licença:** o código do FusionBridge agora é MIT (`LICENSE`), e os textos completos das licenças de terceiros estão em `THIRD-PARTY-NOTICES.md` (também no zip só do mod do GTA).
- **Pesquisa de mods parecidos:** publicados e com licença aberta, só o SkyCraft roda um jogo de verdade dentro de outro. O Minecraft no Elden Ring é só vídeo, sem download, e o mashup de MW2 do autor do SkyCraft é uma recriação em Rust que precisa de arquivos do Xbox 360. Os dois ficaram de fora.

### Antes (0.6.1 a 0.6.4)

- **0.6.4:** Upscale em qualquer jogo (FSR 1.0 pelo Magpie), hoje no último cartão da página **Desempenho**.
- **0.6.3:** FSR 1.0 de verdade na imagem do Minecraft dentro do GTA; DLSS e Frame Generation explicados sem enganação.
- **0.6.2:** inventário do Minecraft dentro do GTA (**I**), o GTA não trava mais esperando o app.
- **0.6.1:** app próprio (`FusionBridge.exe`, nada no navegador), compatível com o Controle inteligente de aplicativo, escolha de Host e Secundário com o mouse.

## Antes de começar

- **Windows 10 ou 11, 64 bits.**
- **GTA San Andreas de PC na versão 1.0 US** com o **MoonLoader** instalado (ele traz o carregador de ASI). A versão da Steam/Rockstar Launcher precisa de downgrade para a 1.0.
- **Minecraft Java comprado numa conta Microsoft.** No modo **automático** (padrão) é só isso. No modo **Minecraft Launcher**, também: o Minecraft Launcher aberto uma vez e o **Fabric Loader 0.19.5 para a 26.3** pelo [instalador oficial do Fabric](https://fabricmc.net/use/installer/).

## Instalação

1. Extraia este ZIP numa pasta sua, por exemplo `Documentos\FusionBridge` (em *Arquivos de Programas* o Windows pede administrador para algumas coisas).
2. Abra o **`FusionBridge.exe`**. Na primeira vez, o app oferece criar o atalho com a logo na Área de Trabalho.
3. Vá na página **Instalar**. O app procura o GTA sozinho; se não achar, clique em **Escolher gta_sa.exe…**. As bolinhas mostram o que está pronto e o que falta.
4. No cartão **Minecraft Java**, deixe **Automático (Prism)** (ou escolha **Minecraft Launcher**).
5. Feche o GTA e clique em **Instalar**. O app:
   - faz uma **cópia dos saves do GTA**;
   - baixa dos sites oficiais, conferindo o SHA-256 de cada um, o **ReShade 6.8.0 com add-on**, o **Fabric API**, dois arquivos de shader e, no modo automático, o **Prism Launcher 11.1.1 portátil**;
   - coloca no GTA o `d3d9.dll` (ReShade 32-bit), o `FusionBridgeSA.asi`, o efeito `FusionBridgeSA.fx`, o `ReShade.ini`, o `ReShadePreset.ini` e o `moonloader\FusionBridgeGTA.lua` 0.2.4 (um antigo vira backup);
   - no modo automático, prepara a instância **FusionBridge** do Prism (em `%LOCALAPPDATA%\FusionBridge\Prism`) com os mods `passthrough`, `FusionBridgeMC` e Fabric API; no modo Minecraft Launcher, cria o perfil **FusionBridge - Minecraft no GTA SA** com pasta própria.
6. Modo automático: clique em **Entrar na conta** (uma vez só). No Prism: **Contas** (canto de cima) → **Adicionar Microsoft**, entre com a conta que tem o Minecraft Java e feche o Prism.
7. Já tem um `d3d9.dll`/ReShade de outro mod? A instalação **para sem apagar nada**. Para trocar, marque **Substituir d3d9.dll/ReShade de outro mod**: o antigo vira backup e o Remover devolve.
8. Pasta protegida? Aparece **Reabrir como administrador**. O Windows mostra "Python Software Foundation" como editor verificado (é o Python oficial; veja `SEGURANCA-WINDOWS.md`).

Se um download falhar, o app mostra o endereço oficial. Baixe pelo navegador, coloque o arquivo na pasta que **Pasta de downloads** abre e clique em **Instalar** de novo.

## Escolher os jogos (Host e Secundário)

Na **Ponte** há dois cartões: **Host** (o jogo que fica na tela) e **Secundário** (o jogo desenhado dentro do Host).

1. Clique no cartão. Abre a lista dos **jogos instalados no seu PC**, achados pelos próprios launchers: Steam, Epic Games, GOG, Ubisoft Connect, Rockstar Games Launcher, EA app, Battle.net, Riot, app Xbox, Minecraft e o GTA SA clássico. Digite para procurar.
2. Clique num jogo. **À direita aparece se ele tem mod fusion** para aquele lado, se o mod já está instalado e se faz par com o jogo do outro cartão (bolinha verde: tem para esse lado; amarela: só para o outro lado; cinza: não tem).
3. **Selecionar como Host/Secundário** (ou Enter). Esc fecha sem mudar nada.

Escolher um GTA SA 1.0 como Host preenche a pasta da página **Instalar**; escolher o **Skyrim** como Host leva o SkyCraft junto (página **Mods fusion**). Jogo que não apareceu: **Outro jogo… (escolher o .exe)**.

**Mods fusion de outros jogos:** cada jogo suportado tem um arquivo `.json` na pasta `fusion-mods`. Quando sair um mod fusion novo, copie o arquivo dele para essa pasta (ou para a que o botão **Pasta de mods fusion** abre): o app reconhece na hora. Detalhes em `fusion-mods\COMO-ADICIONAR-MOD.md`.

## Como jogar (GTA + Minecraft)

1. Abra o **`FusionBridge.exe`** (ou o atalho).
2. Abra o **GTA San Andreas** e carregue um save.
   - **Modo automático:** o FusionBridge abre o Minecraft sozinho (ou clique em **Abrir o Minecraft** na Ponte). Na primeira vez o Prism baixa o Minecraft, o Fabric e o Java: alguns minutos.
   - **Modo Minecraft Launcher:** no launcher, escolha **FusionBridge - Minecraft no GTA SA** e clique em **JOGAR**. Deixe a janela do Minecraft aberta, sem minimizar.
3. O mod cria e abre sozinho um mundo vazio. Em alguns segundos aparece "FusionBridge: fusao ligada" no GTA e o chão é nivelado.
4. Quando a fusão começa, as teclas dos dois jogos são **fundidas** sozinhas. Com o CJ a pé e o mouse no Minecraft:

| Tecla | Minecraft | GTA SA |
|---|---|---|
| botão esquerdo | quebrar bloco, golpe de espada | (tiro do CJ bloqueado) |
| botão direito | colocar bloco, acender TNT, atirar com besta/arco, jogar pérola | (mira do CJ bloqueada) |
| **1 – 9** | barra de itens | — |
| rodinha, **Q / E** | item anterior / próximo | arma anterior / próxima (o mesmo gesto nos dois) |
| **I** | abre o inventário **dentro do GTA**: aparece o cursor, e clique, Shift+clique, 1–9 e Q funcionam ali mesmo; **I** ou **E** fecha | — (o CJ e a câmera param enquanto ele está aberto) |
| **Z** | soltar o item da mão | — |
| **X** | trocar o item de mão | — |
| **F7** | liga / desliga a fusão | |
| **F8** | nivela o chão do Minecraft onde o CJ está (blocos flutuando ou enterrados) | |
| **F6** | mouse e teclas do Minecraft ↔ do GTA (para usar as armas do CJ) | |

A barra já vem montada: pérolas, espada, besta, arco, **TNT (5)**, **isqueiro (6)**, ovos de creeper, **grama (8)** e fogos. Na Ponte, "Itens para o Steve" dá mais TNT, blocos de construção, obsidiana para portal etc. Dentro de um carro o CJ volta a aparecer e todas as teclas voltam a ser do GTA. A fusão das teclas pode ser desligada em **Controles**.

## SkyCraft (Minecraft dentro do Skyrim)

Mod de chasmlol (MIT): o Skyrim desenha tudo e um Minecraft Java de verdade roda escondido ao lado, os dois conversando por memória compartilhada (blocos, física, inventário e mobs do Minecraft dentro do mundo do Skyrim).

Precisa: **Skyrim Special Edition no runtime da Anniversary Edition (1.6 ou 1.7**; a 1.5.97, o Skyrim VR e o do Xbox/Game Pass não servem), o **SKSE64** da mesma versão ([skse.silverlock.org](https://skse.silverlock.org/)) e a **Address Library** "All in one (Anniversary Edition)" ([Nexus](https://www.nexusmods.com/skyrimspecialedition/mods/32444)). Recomendado: **Alternate Start** ([Nexus](https://www.nexusmods.com/skyrimspecialedition/mods/272)), porque o começo do Skyrim pode travar com o SkyCraft. Sem ele, jogue de um save feito depois de Helgen.

1. Página **Mods fusion**, cartão **SkyCraft**. O app acha o Skyrim (ou **Escolher SkyrimSE.exe…**) e mostra a versão.
2. Faltando o SKSE ou a Address Library, baixe pelos botões e clique em **Escolher SKSE…** / **Escolher Address Library…**. Serve o arquivo baixado (`.7z`/`.zip`) ou o arquivo de dentro (`skse64_loader.exe`, `versionlib-….bin`). Um SKSE de outra versão já na pasta pode ser trocado com backup (o Remover devolve).
3. **Instalar SkyCraft**: backup dos saves, download oficial conferido e instalação sem sobrescrever nada. Depois o app já prepara o Minecraft do SkyCraft.
4. **Entrar na conta Microsoft** (uma vez): Contas → Adicionar Microsoft no Prism do SkyCraft, entrar e fechar.
5. **Jogar**: abre o Skyrim pelo SKSE (e a Steam antes, se estiver fechada). O Minecraft abre escondido sozinho e fecha junto com o Skyrim.

Teclas que continuam do Skyrim: **G** ativar (portas, conversar, baús), **Esc** menu, **J/M** diário e mapa, **H** esperar, **F9** carregar o save rápido, **~** console, **O** pausa do Minecraft. O resto é do Minecraft (**E** inventário, **F5** câmera…). Limites do SkyCraft: com o Minecraft no controle, o inventário e as magias do Skyrim não abrem; os golpes do Minecraft só acertam pessoas e bichos; os interiores dividem um mundo; reserve uns 3 GB de RAM a mais. **Improved Camera SE, SmoothCam e True Directional Movement** brigam com ele (o app avisa).

O cartão mostra o que o `SkyCraft.log` e o `latest.log` do Minecraft dizem, liga o **Diagnóstico detalhado** e desliga **Abrir o Minecraft junto com o Skyrim**, se você quiser abrir por conta. **Remover** tira só o que o app colocou; a conta e o mundo do SkyCraft ficam em `%LOCALAPPDATA%\SkyCraft`.

## Desempenho (FSR 1.0, DLSS, Frame Generation)

- **Ritmo e peso da fusão:** modo da ponte, raio do chão e o tamanho máximo do Minecraft. Lento? Raio 24 e Minecraft 720p.
- **FSR 1.0** (ligado por padrão): em **Modo**, *Qualidade* ou *Equilibrado* deixam o Minecraft bem mais leve e quase tão nítido.
- **DLSS:** indisponível nestes dois jogos (o motivo está na página). Para ampliar o GTA inteiro: Upscale em qualquer jogo (GTA em janela), NIS da NVIDIA, RSR da AMD ou Lossless Scaling.
- **Frame Generation:** Lossless Scaling com o GTA em janela (o app acha e abre); Smooth Motion nas RTX 40/50; AFMF na AMD. Ligue só no GTA.
- **Upscale em qualquer jogo** (último cartão): **Baixar e preparar** uma vez; depois, jogo **em janela** numa resolução menor, **Abrir upscaler (FSR)** e **Alt+Shift+A** no jogo.

## Se algo não funcionar

A **Ponte** diz qual peça falta:

- **"aguardando o Minecraft em 127.0.0.1:25599"**: o Minecraft não está aberto pela instância/perfil do FusionBridge, ou o mundo ainda está carregando. No modo automático, a faixa **Minecraft automático** da Ponte diz o que falta (instalar, entrar na conta) e tem o botão **Abrir o Minecraft**.
- **O Minecraft automático não abre:** confira em **Instalar** se a conta Microsoft está conectada. Se o Prism mostrar um erro, ele fica na janela dele. Com o Controle inteligente de aplicativo ligado, o Windows pode bloquear o Prism (sem assinatura digital; veja `SEGURANCA-WINDOWS.md`).
- **A imagem do Minecraft sumiu com "fora da tela" ligado:** desligue a opção em **Instalar → Minecraft automático** (a janela volta) e conte o que aconteceu: ela não foi testada em todas as placas.
- **"FusionBridgeSA.asi não carregou"**: o ASI não está na pasta do GTA, o carregador de ASI do MoonLoader não está instalado, ou o Windows bloqueou o arquivo (**Segurança** → **Procurar bloqueios do Windows**).
- **"ASI carregado, mas o ReShade não"**: falta o `d3d9.dll` do ReShade **com add-on** (Instalar de novo).
- **"efeito FusionBridgeSA.fx não carregou"**: aperte **Home** no GTA para abrir o ReShade e ver o erro; o log fica em `ReShade.log` na pasta do GTA.
- **O GTA travou:** o `FusionBridgeSA.asi` anota no `FusionBridgeSA.log` (pasta do GTA) onde o jogo parou, e o script anota no `moonloader\moonloader.log`. Mande esses arquivos, o `ReShade.log` e a página **Log** do app.
- **SkyCraft parado em "starting Minecraft…":** o cartão do SkyCraft mostra o que o `SkyCraft.log` diz. Quase sempre é o Prism esperando a conta Microsoft (use **Entrar na conta Microsoft** com o Skyrim fechado) ou baixando o Minecraft na primeira vez.
- **`libFusionBridgeGTA.so`:** é o mod de **Android**. No Windows não é carregado e pode ser apagado da pasta do GTA.
- Erros do app ficam em `%LOCALAPPDATA%\FusionBridge\FusionBridge-erro.log`; a página **Log** tem o resto (botão Copiar log).

## Remover

- **Fusão do GTA:** página **Instalar** → **Remover**. Tira só o que o Instalar colocou (e só arquivos que você não mexeu depois), devolve os backups, e no modo Minecraft Launcher apaga o perfil. O backup dos saves do GTA fica em `%LOCALAPPDATA%\FusionBridge\backups`.
- **Minecraft automático:** **Instalar → Minecraft automático → Remover o Prism** (o mundo da fusão é copiado para os backups antes).
- **SkyCraft:** **Mods fusion → SkyCraft → Remover** (um SKSE antigo trocado volta para o lugar).

## Segurança

- Use no **modo single player**. Não leve o GTA com esses mods para servidores online (SA-MP/MTA).
- O FusionBridge só escuta em `127.0.0.1` (o próprio PC). O firewall não pergunta nada.
- Controle inteligente de aplicativo, assinaturas e o que fazer se o Windows bloquear os mods: **`SEGURANCA-WINDOWS.md`** e a página **Segurança**.

## Créditos

- Fusão visual: o mod `passthrough`, o shader e o compositor adaptados para o GTA SA vêm do [Minecraft x GTA V Passthrough](https://github.com/rehan-remade/universal-modder/tree/main/examples/minecraft-gta5-passthrough), de Rehan e contribuidores (MIT, `mod/LICENSE-passthrough-MIT.txt`).
- [SkyCraft](https://github.com/chasmlol/SkyCraft), de chasmlol (MIT): baixado do GitHub oficial pelo app, não vem no pacote. A ideia do Minecraft automático (Prism portátil que abre e fecha junto com o jogo) também é dele.
- [Prism Launcher](https://prismlauncher.org) (GPL-3.0): baixado do GitHub oficial pelo app, não vem no pacote.
- [SKSE64](https://skse.silverlock.org/) (equipe do SKSE) e [Address Library](https://www.nexusmods.com/skyrimspecialedition/mods/32444) (meh321): não vêm no FusionBridge; você baixa dos sites deles.
- [Magpie](https://github.com/Blinue/Magpie), de Blinue (GPL-3.0), baixado pelo app.
- O `FusionBridge.exe` e o `runtime\` são o Python oficial (python.org, Python Software Foundation), sem modificação; licença em `runtime\LICENSE-Python.txt`.
- [ReShade](https://reshade.me) e a API de add-ons por crosire (BSD-3, `src/third_party/reshade`), [MoonLoader](https://www.blast.hk/moonloader/), [Fabric](https://fabricmc.net).
- Fontes Jersey 15 e IBM Plex Mono (SIL Open Font License, `app/assets/fonts`).
- Minecraft é da Mojang/Microsoft, GTA San Andreas da Rockstar Games/Take-Two e Skyrim da Bethesda. Projeto de fã.
