"""Tests for app/fb_upscale.py (FSR 1.0 for any game's window, through Magpie): config, safe extraction, install,
launch and removal. Run: python3 -I tests/test_upscale.py   (fake Magpie zip in a temp dir; nothing is downloaded or run)"""
import json, os, sys, tempfile, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "app"))
import fb_installer as FI  # noqa: E402
import fb_upscale as UP  # noqa: E402

results = []

# the effects Magpie 0.12.1 ships (effects/<name>.hlsl in Magpie-v0.12.1-x64.zip)
SHIPPED = {"FSR\\FSR_EASU", "FSR\\FSR_RCAS", "Lanczos", "FSRCNNX\\FSRCNNX", "CuNNy2\\CuNNy-4x12-NVL",
           "Anime4K\\Anime4K_Upscale_Denoise_L", "CRT\\CRT_Geom", "Nearest"}


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> %s" % (detail,)))


def fake_zip(path, members):
    with zipfile.ZipFile(path, "w") as z:
        for name, data in members:
            z.writestr(name, data)
    return path


def read_cfg(folder):
    with open(os.path.join(folder, "config", "config.json"), encoding="utf-8") as f:
        return json.load(f)


def write(path, text, encoding="utf-8"):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding=encoding) as f:
        f.write(text)


def main():
    name, url, sha, _ = FI.DEPS["magpie"]
    check("the Magpie download is the official 0.12.1 release", name == "Magpie-v0.12.1-x64.zip" and
          url == "https://github.com/Blinue/Magpie/releases/download/v0.12.1/Magpie-v0.12.1-x64.zip", (name, url))
    check("the Magpie download is pinned by SHA-256", len(sha) == 64 and sha == sha.upper()
          and all(c in "0123456789ABCDEF" for c in sha), sha)
    fsr = UP.DEFAULT_MODES[0]
    check("FSR is the first scaling mode: EASU (fit to screen) then RCAS",
          fsr["name"] == "FSR" and [e["name"] for e in fsr["effects"]] == ["FSR\\FSR_EASU", "FSR\\FSR_RCAS"]
          and fsr["effects"][0]["scalingType"] == 1 and fsr["effects"][1]["parameters"]["sharpness"] == 0.87, fsr)
    used = {e["name"] for m in UP.DEFAULT_MODES for e in m["effects"]}
    check("every default mode uses an effect Magpie ships", used <= SHIPPED, used - SHIPPED)
    check("the default modes are Magpie's own seven", len(UP.DEFAULT_MODES) == 7 and
          len({m["name"] for m in UP.DEFAULT_MODES}) == 7, [m["name"] for m in UP.DEFAULT_MODES])

    with tempfile.TemporaryDirectory() as t:
        # ---- prepare_config
        d = os.path.join(t, "new")
        check("a new folder gets a config", UP.prepare_config(d) is True)
        c = read_cfg(d)
        check("the new config makes FSR the default (global profile)", c["scalingModes"] == UP.DEFAULT_MODES
              and c["profiles"][0]["scalingMode"] == 0 and len(c["profiles"]) == 1, c.get("profiles"))
        check("the new config is in Portuguese", c.get("language") == "pt-br", c.get("language"))
        check("no temporary file is left", not os.path.exists(os.path.join(d, "config", "config.json.tmp")))

        d = os.path.join(t, "mine")
        mine = json.dumps({"scalingModes": [{"name": "Meu", "effects": [{"name": "Lanczos"}]}],
                           "profiles": [{"scalingMode": 0}], "language": "en-us"})
        write(os.path.join(d, "config", "config.json"), mine)
        check("a config with the player's modes is left alone", UP.prepare_config(d) is False and
              open(os.path.join(d, "config", "config.json"), encoding="utf-8").read() == mine)

        d = os.path.join(t, "broken")
        write(os.path.join(d, "config", "config.json"), "{not json")
        check("a broken config is never overwritten", UP.prepare_config(d) is False and
              open(os.path.join(d, "config", "config.json"), encoding="utf-8").read() == "{not json")

        d = os.path.join(t, "empty")
        write(os.path.join(d, "config", "config.json"), "  \n")
        check("an empty config is filled in", UP.prepare_config(d) is True and read_cfg(d)["profiles"][0]["scalingMode"] == 0)

        d = os.path.join(t, "partial")
        write(os.path.join(d, "config", "config.json"), json.dumps(
            {"language": "en-us", "theme": 2, "profiles": [{"captureMethod": 1}, {"name": "GTA", "scalingMode": -1}]}),
            encoding="utf-8-sig")
        check("a config without scaling modes gets them (BOM read too)", UP.prepare_config(d) is True)
        c = read_cfg(d)
        check("the player's other settings and profiles stay", c["theme"] == 2 and c["language"] == "en-us" and
              c["profiles"][0] == {"captureMethod": 1, "scalingMode": 0} and c["profiles"][1]["name"] == "GTA", c)

        # ---- safe extraction
        for bad in ("../evil.dll", "/abs.dll", "C:/x.dll", "effects/../../evil.dll"):
            z = fake_zip(os.path.join(t, "bad.zip"), [("Magpie.exe", b"MZ"), (bad, b"x")])
            dest = os.path.join(t, "bad-dest")
            try:
                UP._extract(z, dest)
                check("zip member %s refused" % bad, False)
            except UP.UpscaleError:
                check("zip member %s refused, nothing extracted" % bad,
                      not os.path.exists(os.path.join(dest, "Magpie.exe")) and not os.path.exists(os.path.join(t, "evil.dll")))

        # ---- install
        paths = FI.Paths(local=os.path.join(t, "local"), appdata=os.path.join(t, "roaming"), app_root=ROOT)
        z = fake_zip(os.path.join(t, "Magpie-v0.12.1-x64.zip"), [
            ("Magpie.exe", b"MZ magpie"), ("effects/", b""), ("effects/FSR/FSR_EASU.hlsl", b"// easu"),
            ("effects/FSR/FSR_RCAS.hlsl", b"// rcas"), ("Updater.exe", b"MZ updater")])
        asked, log = [], []

        def get_dep(key, p, lg):
            asked.append((key, p))
            return z
        try:
            UP.install(paths, log=log.append, get_dependency=get_dep, is_running=lambda n: True)
            check("install refused while Magpie runs", False)
        except UP.UpscaleError:
            check("install refused while Magpie runs, nothing downloaded", not asked)
        exe = UP.install(paths, log=log.append, get_dependency=get_dep, is_running=lambda n: False)
        md = UP.magpie_dir(paths.local)
        check("install asks for the pinned magpie download", asked == [("magpie", paths)], asked)
        check("Magpie lands in %LOCALAPPDATA%\\FusionBridge\\Magpie", exe == os.path.join(paths.local, "FusionBridge", "Magpie",
              "Magpie.exe") and os.path.isfile(exe) and os.path.isfile(os.path.join(md, "effects", "FSR", "FSR_RCAS.hlsl")))
        check("install makes FSR the default and runs portable", UP.installed(paths.local) and
              read_cfg(md)["profiles"][0]["scalingMode"] == 0 and read_cfg(md)["scalingModes"][0]["name"] == "FSR")
        check("install tells what it did", any("Magpie 0.12.1" in s for s in log) and any("FSR" in s for s in log), log)
        check("no .part file is left", not any(f.endswith(".part") for _, _, fs in os.walk(md) for f in fs))

        cfg_path = os.path.join(md, "config", "config.json")
        write(cfg_path, json.dumps({"scalingModes": UP.DEFAULT_MODES, "profiles": [{"scalingMode": 3}]}))
        z2 = fake_zip(os.path.join(t, "z2.zip"), [("Magpie.exe", b"MZ new"), ("config/config.json", b"{}")])
        UP.install(paths, log=log.append, get_dependency=lambda *a: z2, is_running=lambda n: False)
        check("reinstalling keeps the player's Magpie settings", read_cfg(md)["profiles"][0]["scalingMode"] == 3 and
              open(os.path.join(md, "Magpie.exe"), "rb").read() == b"MZ new")

        def fails(*a):
            raise FI.InstallError("sem internet")
        try:
            UP.install(paths, log=log.append, get_dependency=fails, is_running=lambda n: False)
            check("a failed download becomes a message for the player", False)
        except UP.UpscaleError as e:
            check("a failed download becomes a message for the player", "sem internet" in str(e), e)
        z3 = fake_zip(os.path.join(t, "z3.zip"), [("readme.txt", b"no exe")])
        paths2 = FI.Paths(local=os.path.join(t, "local2"), appdata=os.path.join(t, "roaming"), app_root=ROOT)
        try:
            UP.install(paths2, log=log.append, get_dependency=lambda *a: z3, is_running=lambda n: False)
            check("a zip without Magpie.exe refused", False)
        except UP.UpscaleError:
            check("a zip without Magpie.exe refused", not UP.installed(paths2.local))

        # ---- launch
        started = []
        try:
            UP.launch(os.path.join(t, "nowhere"), popen=lambda *a, **kw: started.append(1), is_running=lambda n: False)
            check("opening before Baixar e preparar refused", False)
        except UP.UpscaleError:
            check("opening before Baixar e preparar refused", not started)
        os.remove(cfg_path)
        r = UP.launch(paths.local, popen=lambda *a, **kw: started.append((a, kw)) or "proc", is_running=lambda n: False)
        check("opening starts Magpie.exe in its own folder (portable)", r == "proc" and started and
              started[0][0][0] == [exe] and started[0][1].get("cwd") == md, started)
        check("opening puts the FSR config back if it was deleted", os.path.isfile(cfg_path) and
              read_cfg(md)["profiles"][0]["scalingMode"] == 0)
        started.clear()
        check("opening while Magpie already runs does nothing", UP.launch(
            paths.local, popen=lambda *a, **kw: started.append(1), is_running=lambda n: n == "Magpie.exe") is None and not started)

        # ---- remove
        try:
            UP.remove(paths.local, is_running=lambda n: True)
            check("removing refused while Magpie runs", False)
        except UP.UpscaleError:
            check("removing refused while Magpie runs", os.path.isdir(md))
        check("removing deletes only the Magpie folder", UP.remove(paths.local, is_running=lambda n: False) is True and
              not os.path.exists(md) and os.path.isdir(os.path.join(paths.local, "FusionBridge")))
        check("removing twice is fine", UP.remove(paths.local, is_running=lambda n: False) is False)

    src = open(os.path.join(ROOT, "app", "fb_app.py"), encoding="utf-8").read()
    perf = src[src.index("    def tab_perf("):src.index("    def card_upscale(")]
    check("the Desempenho page shows the upscale card (any game on the PC)", "return self.card_upscale(ui, x, y, w, gpus)" in perf)

    bad = [n for n, ok in results if not ok]
    print("\n%d/%d passaram" % (len(results) - len(bad), len(results)))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
