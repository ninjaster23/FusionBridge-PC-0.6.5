"""FusionBridge PC 0.6.5 - the logo as pixel art, drawn in code (pure Python, no image files or libraries).

A big green pixel "F" standing on a suspension bridge, at sunset: sky bands from night purple to amber, the sun
going down behind a city skyline, the bridge towers and cables in silhouette and the sun's reflection on the bay.
The same art is the app icon (tools/make_icon.py) and the logo in the sidebar (fb_app.py).

art(32) and art(16) return (rows, palette): rows of characters, each a palette key ('.' = transparent).
"""

SKY = ["#20172f", "#2f1f45", "#4a2858", "#76335f", "#ad4459", "#dd6a43", "#f29a46", "#f7bf5e"]
P = {
    "sun": "#ffd681", "sun2": "#fff1bf", "city": "#3a2547", "city2": "#2a1b36",
    "sea": "#13283a", "sea2": "#1b3a4f", "glint": "#f6b45a", "glint2": "#ffe3a1",
    "steel": "#150f1e", "cable": "#120c19", "deck": "#0e0a15",
    "F": "#6cc04a", "Fhi": "#a6e57f", "Fsh": "#3f7a2a", "Fo": "#0b1608",
}


def _canvas(n):
    return [[None] * n for _ in range(n)]


def _set(c, x, y, col):
    n = len(c)
    if 0 <= x < n and 0 <= y < n and col:
        c[y][x] = col


def _rect(c, x0, y0, x1, y1, col):          # inclusive
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            _set(c, x, y, col)


def _round_corners(c, r):
    n = len(c)
    cut = {1: [(0, 0)], 2: [(0, 0), (1, 0), (0, 1)], 3: [(0, 0), (1, 0), (2, 0), (0, 1), (0, 2), (1, 1)]}[r]
    for dx, dy in cut:
        for x, y in ((dx, dy), (n - 1 - dx, dy), (dx, n - 1 - dy), (n - 1 - dx, n - 1 - dy)):
            c[y][x] = None


def _letter_f(c, x0, y0, s):
    """The F: s = pixel size of one 'brick' of the letter. Outline, fill, top light, right/bottom shade."""
    bricks = [(0, 0), (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (1, 2), (2, 2), (0, 3), (0, 4)]
    cells = set()
    for bx, by in bricks:
        for yy in range(s):
            for xx in range(s):
                cells.add((x0 + bx * s + xx, y0 + by * s + yy))
    for (x, y) in cells:                                    # outline ring around the letter
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1), (-1, 1), (1, -1)):
            if (x + dx, y + dy) not in cells:
                _set(c, x + dx, y + dy, P["Fo"])
    for (x, y) in cells:
        col = P["F"]
        if (x, y - 1) not in cells:
            col = P["Fhi"]                                  # lit top edge
        elif (x + 1, y) not in cells or (x, y + 1) not in cells:
            col = P["Fsh"]                                  # shaded right/bottom edge
        _set(c, x, y, col)
    # a few darker "block" pixels so the letter reads as built from blocks
    if s >= 3:
        for bx, by in bricks:
            _set(c, x0 + bx * s + s // 2, y0 + by * s + s - 2, P["Fsh"])


def _letter_f_px(c, x0, y0, stem=5, arm=5, mid=4, width=13, mid_w=10, height=17):
    """A clean pixel F: stem, top arm and middle arm, with a 1 px outline, lit top/left edges and shaded
    bottom/right edges (like a raised block)."""
    cells = set()
    for y in range(y0, y0 + height):
        for x in range(x0, x0 + stem):
            cells.add((x, y))
    for y in range(y0, y0 + arm):
        for x in range(x0, x0 + width):
            cells.add((x, y))
    my = y0 + arm + 2
    for y in range(my, my + mid):
        for x in range(x0, x0 + mid_w):
            cells.add((x, y))
    for (x, y) in cells:
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if (x + dx, y + dy) not in cells:
                    _set(c, x + dx, y + dy, P["Fo"])
    for (x, y) in cells:
        if (x, y - 1) not in cells or (x - 1, y) not in cells:
            col = P["Fhi"]
        elif (x, y + 1) not in cells or (x + 1, y) not in cells:
            col = P["Fsh"]
        else:
            col = P["F"]
        _set(c, x, y, col)


def _draw32():
    n = 32
    c = _canvas(n)
    horizon = 19
    bands = [(0, 3), (4, 6), (7, 9), (10, 12), (13, 14), (15, 16), (17, 17), (18, 18)]
    for (a, b), col in zip(bands, SKY):
        _rect(c, 0, a, n - 1, b, col)
    # the sun going down on the right
    cx, cy, r = 24, horizon, 6
    for y in range(cy - r, cy + 1):
        for x in range(cx - r, cx + r + 1):
            d = (x - cx) ** 2 + (y - cy) ** 2
            if d <= r * r:
                _set(c, x, y, P["sun2"] if d <= (r - 3) ** 2 else P["sun"])
    # low city skyline
    for x0, x1, top, col in ((0, 1, 15, "city"), (2, 3, 13, "city2"), (4, 5, 16, "city"), (29, 31, 16, "city"),
                             (30, 30, 14, "city2")):
        _rect(c, x0, top, x1, horizon - 1, P[col])
    for x, y in ((1, 17), (2, 15), (30, 17)):
        _set(c, x, y, P["glint"])
    # the bay, with the sun's reflection
    _rect(c, 0, horizon, n - 1, n - 1, P["sea"])
    for y in range(horizon + 4, n, 2):
        _rect(c, 0, y, n - 1, y, P["sea2"])
    for y, x0, x1 in ((horizon + 5, 20, 28), (horizon + 7, 21, 27), (horizon + 9, 22, 26), (horizon + 11, 23, 25)):
        _rect(c, x0, y, x1, y, P["glint"])
        _set(c, (x0 + x1) // 2, y, P["glint2"])
    # suspension bridge in silhouette: two towers, one main cable, a few hangers, the deck
    deck = 21
    for tx in (3, 28):
        _rect(c, tx, 7, tx + 1, deck + 4, P["steel"])
        _rect(c, tx - 1, 10, tx + 2, 10, P["steel"])
    for x in range(5, 28):
        t = (x - 16.0) / 11.0
        y = int(round(17 - 10 * t * t))
        _set(c, x, y, P["cable"])
        if x % 4 == 1 and x > 5:
            for yy in range(y + 1, deck):
                _set(c, x, yy, P["cable"])
    for x in range(0, 3):
        _set(c, x, 9 + (3 - x) * 2, P["cable"])
    for x in range(30, 32):
        _set(c, x, 9 + (x - 29) * 2, P["cable"])
    _rect(c, 0, deck, n - 1, deck + 1, P["deck"])
    _rect(c, 0, deck + 2, n - 1, deck + 2, P["steel"])
    # the F, standing on the deck
    _letter_f_px(c, 9, 4)
    _round_corners(c, 3)
    return c


def _draw16():
    n = 16
    c = _canvas(n)
    horizon = 10
    for (a, b), col in zip(((0, 1), (2, 3), (4, 5), (6, 7), (8, 8), (9, 9)), SKY[1:7]):
        _rect(c, 0, a, n - 1, b, col)
    for y in range(horizon - 3, horizon):
        for x in range(9, 15):
            if (x - 11.5) ** 2 + (y - horizon) ** 2 <= 9.5:
                _set(c, x, y, P["sun"])
    _rect(c, 0, 7, 1, horizon - 1, P["city"])
    _rect(c, 14, 8, 15, horizon - 1, P["city"])
    _rect(c, 0, horizon, n - 1, n - 1, P["sea"])
    _rect(c, 10, 13, 13, 13, P["glint"])
    _rect(c, 11, 15, 12, 15, P["glint"])
    _rect(c, 1, 3, 1, 13, P["steel"])
    _rect(c, 14, 3, 14, 13, P["steel"])
    for x in range(2, 14):
        t = (x - 7.5) / 5.5
        _set(c, x, int(round(9 - 5 * t * t)), P["cable"])
    _rect(c, 0, 11, n - 1, 12, P["deck"])
    # the F (2-px bricks)
    _letter_f(c, 5, 2, 2)                                    # 8 px wide, 10 tall: y 2..11
    _round_corners(c, 1)
    return c


def art(size=32):
    c = _draw32() if size >= 32 else _draw16()
    keys, pal, rows = {}, {}, []
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    for row in c:
        s = []
        for col in row:
            if col is None:
                s.append(".")
                continue
            k = keys.get(col)
            if k is None:
                k = keys[col] = alphabet[len(keys)]
                pal[k] = col
            s.append(k)
        rows.append("".join(s))
    return rows, pal
