"""FusionBridge PC 0.6.5 - the app: one native window with everything inside (no browser).

The hub and the fusion engine run inside this process (fusionbridge.start_hub); the screens call its Controller
directly. Pages (sidebar): Ponte, Caos, Controles, Instalar, Mods fusion, Desempenho, Seguranca, Diagnostico, Log.
Clicking the Host or Secundario card opens the game picker: the games installed on the PC, and whether each one has a
fusion mod (fb_games.py). Mods fusion holds the fusion mods of other authors the app installs and opens: SkyCraft
(Minecraft inside Skyrim, fb_skycraft.py). The GTA SA fusion's Minecraft can be the
automatic one (a portable Prism, fb_prism.py): the app opens it when GTA opens and closes it when GTA closes.
"""
import json
import os
import queue
import sys
import threading
import time

import fb_art
import fb_games as G
import fb_installer as FI
import fb_perf as PF
import fb_prism as PR
import fb_skycraft as SK
import fb_upscale as UP
import fb_winui as W
import fusionbridge as FB
from fb_winui import FW_BOLD, FW_NORMAL, FW_SEMIBOLD

# one palette for the whole app (the same names as fb_winui.T): dark obsidian ground, grass green for Minecraft,
# sunset amber for GTA San Andreas, block-style bevels
C = {"night": "#101215", "side": "#0b0d10", "dusk": "#191c21", "dusk2": "#23282f", "inset": "#0e1013",
     "line": "#2a2f37", "line2": "#3a414b", "paper": "#ece9e2", "head": "#f4f1ea", "haze": "#9aa1ab", "soft": "#c3c8cf",
     "sunset": "#e9a23b", "grass": "#6cc04a", "red": "#d8442a", "blue": "#8fb8f2", "ok": "#8fd46a", "wait": "#f2c77a",
     "bad": "#f08a70", "off": "#5a616b", "shadow": "#08090b", "host": "#1f1a14", "sec": "#16201a"}
BLOCK = {"grass": ("#6cc24a", "#8a5a36", "#5e3c22"), "tnt": ("#e8e2d6", "#c8322f", "#7e1d1b"),
         "wither": ("#5c5c66", "#2c2a33", "#141318"), "creep": ("#9fe08a", "#4e9a3a", "#2d5e21"),
         "sky": ("#cfe6ff", "#3f6fb0", "#24467a"), "calm": ("#cfd6e6", "#4a5168", "#2c3142"),
         "road": ("#f2c14e", "#3b3b46", "#22222a"), "fire": ("#ffd08a", "#d9542b", "#8a2d12"),
         "cash": ("#c6f2a8", "#2f7a46", "#1c4e2c")}
MODE_HINT = {"eco": "O mundo do Minecraft congela sozinho quando nada acontece; estado 5x/s. O mais leve.",
             "live": "O Minecraft roda o tempo todo; estado 20x/s.",
             "visual": "Os dois jogos na tela, sem economia. O mais pesado."}
MC_BLOCKS = [("wither", "Wither", "invoca o chefe", "wither"), ("tnt", "TNT", "1 bloco aceso", "tnt"),
             ("tnt_rain", "Chuva de TNT", "8 caindo", "tnt"), ("creeper", "Creeper", "do lado", "creep"),
             ("charged_creeper", "Creeper carregado", "maior", "creep"), ("lightning", "Raio", "na posição", "sky"),
             ("boom", "Explosão já", "sem pavio", "tnt"), ("heal", "Curar", "vida cheia", "calm"),
             ("clear", "Limpar", "remove tudo", "calm"), ("day", "Dia limpo", "hora e clima", "sky"),
             ("freeze", "Congelar", "tick freeze", "calm"), ("unfreeze", "Descongelar", "tick unfreeze", "calm")]
GTA_BLOCKS = [("block", "Bloco", "na frente do CJ", "road"), ("boom", "Explosão", "9 m à frente", "fire"),
              ("boom_rain", "Chuva de explosões", "em volta", "fire"), ("heal", "Curar CJ", "vida cheia", "cash"),
              ("shake", "Tremer câmera", "1,2 s", "road")]
KITS = [("tnt", "TNT x64", "+ isqueiro", "tnt"), ("build", "Construção", "grama, pedra, madeira, vidro", "grass"),
        ("portal", "Portal do Nether", "obsidiana + isqueiro", "wither"), ("creeper", "Ovos de creeper", "x16", "creep"),
        ("pearls", "Pérolas do Ender", "x16", "calm")]
FUSION_OPTS = [("hide_cj", "Steve no lugar do CJ"), ("cj_safe", "CJ à prova de explosão e fogo"),
               ("props", "Blocos do Minecraft viram parede no GTA"), ("explosions", "Explosões do Minecraft → GTA"),
               ("pearls", "Pérola do Ender teleporta o CJ"), ("auto_level", "Nivelar o chão sozinho"),
               ("keys_fused", "Fundir as teclas dos dois jogos (Q/E, I, Z, X)")]
# the keys while CJ walks with the mouse playing Minecraft: (key, Minecraft, GTA SA, only with the fused keys)
KEY_TABLE = [("Botão esq.", "quebrar bloco, golpe de espada", "tiro do CJ bloqueado", False),
             ("Botão dir.", "colocar bloco, acender TNT, atirar, pérola", "mira do CJ bloqueada", False),
             ("1 – 9", "barra de itens", "—", False),
             ("Rodinha", "item anterior / próximo", "arma anterior / próxima", False),
             ("Q / E", "item anterior / próximo", "arma anterior / próxima (o mesmo gesto)", True),
             ("I", "abre o inventário dentro do GTA, com cursor (I ou E fecha)", "— (CJ e câmera param)", True),
             ("Z", "soltar o item da mão", "—", True),
             ("X", "trocar o item de mão", "—", True)]
GTA_KEYS = [("F7", "liga / desliga a fusão"), ("F8", "nivela o chão do Minecraft onde o CJ está"),
            ("F6", "mouse e teclas do Minecraft ↔ do GTA (para usar as armas do CJ)")]
# sidebar: (tab, label, icon)
NAV = [("fusion", "Ponte", "ponte"), ("chaos", "Caos", "caos"), ("controls", "Controles", "controles"),
       ("install", "Instalar", "instalar"), ("mods", "Mods fusion", "blocos"), ("perf", "Desempenho", "desempenho"),
       ("security", "Segurança", "seguranca"), ("diag", "Diagnóstico", "diag"), ("log", "Log", "log")]
TABS = [(k, lbl) for k, lbl, _ in NAV]
# page header: (kicker, title, subtitle)
PAGES = {"fusion": ("Ponte", "Minecraft dentro do GTA San Andreas",
                    "O GTA manda a câmera e o chão, o Minecraft desenha o mundo dele com essa câmera e o FusionBridgeSA.asi "
                    "junta as duas imagens pela profundidade."),
         "chaos": ("Caos", "Caos nos dois jogos", "Cada bloco manda o comando na hora para o jogo conectado."),
         "controls": ("Controles", "Mouse, teclas e o que vai para cada jogo",
                      "Valem com o CJ a pé e o mouse no Minecraft. No carro, ou depois do F6, tudo volta a ser do GTA."),
         "install": ("Instalar", "Preparar os dois jogos",
                     "Tudo que o Instalar coloca fica registrado; o Remover tira exatamente isso e devolve os backups. "
                     "Os downloads vêm dos sites oficiais e são conferidos pelo SHA-256, e os saves do GTA ganham uma cópia antes."),
         "mods": ("Mods fusion", "Outras fusões de jogos",
                  "Mods de outros autores que juntam dois jogos de verdade. O FusionBridge confere as versões, instala sem "
                  "sobrescrever nada, abre o jogo e mostra os logs. Nada dos jogos vem junto."),
         "perf": ("Desempenho", "Dois jogos, uma placa",
                  "Os dois jogos dividem a mesma placa de vídeo. Aqui só entra o que funciona de verdade; o último cartão "
                  "vale para qualquer jogo do PC."),
         "security": ("Segurança", "Segurança do Windows",
                      "O FusionBridge.exe é o programa oficial do Python, assinado pela Python Software Foundation, e o código "
                      "do FusionBridge roda dentro dele. Por isso o Controle inteligente de aplicativo deixa o app abrir."),
         "diag": ("Diagnóstico", "Conexões e módulos", "Quem está ligado na ponte agora e como está o módulo do GTA."),
         "log": ("Log", "Tudo que a ponte registrou", None)}
SAC_TEXT = {"on": ("ok", "Ligado"), "eval": ("wait", "Em avaliação"), "off": ("", "Desligado"),
            "unknown": ("", "Não deu para ler (no Windows 10 ele não existe)")}
FSR_MODES = [(100, "Nativo"), (130, "Ultra qualidade"), (150, "Qualidade"), (170, "Equilibrado"), (200, "Desempenho")]
# SkyCraft's keys while Minecraft drives the player in Skyrim (from SkyCraft's README)
SKY_KEYS = [("G", "ativar do Skyrim: portas, conversar, baús"), ("Esc", "menu do Skyrim (ou fecha a tela do Minecraft)"),
            ("J / M", "diário / mapa do Skyrim"), ("H", "esperar (Skyrim)"), ("F9", "carregar o save rápido"),
            ("~", "console do Skyrim"), ("O", "pausa / opções do Minecraft"), ("E", "inventário do Minecraft")]
PREFS_DEFAULT = {"mc_mode": None, "auto_start": True, "auto_close": True, "hide_mc": False}
SB = 232          # sidebar width (logical px)

# pixel art (original). The logo (fb_art.py): a green pixel F on a suspension bridge at sunset
LOGO, LOGO_PAL = fb_art.art(32)
ART_MC = ["............",
          ".GGGGGGGGGG.",
          ".GgGGGGgGGG.",
          ".GGGGgGGGGG.",
          ".GGdddGddGG.",
          ".dddGddddGd.",
          ".dDdddddDdd.",
          ".ddddDdddDd.",
          ".dddDddddDd.",
          ".dDddddDddd.",
          ".ddddDddddd.",
          "............"]
ART_GTA = ["PPPPPPPPPPPP",
           "PPPPPPPPPPPP",
           "PPPPPPPPPPPP",
           "PPPPSSSSPPPP",
           "PPPPSSSSPKKP",
           "PKKPSSSSPKKP",
           "AKKASSSSAKKA",
           "AKKAAKKAAKKA",
           "AKKAAKKAAKKA",
           "AKKAAKKAAKKA",
           "KKKKKKKKKKKK",
           "KKKKKKKKKKKK"]
ART_GAME = ["............",
            "............",
            "............",
            "..LLLLLLLL..",
            ".LLLLLLLLLL.",
            ".LwLLLLLaLL.",
            ".wwwLLLLLbL.",
            ".LwLLLLaLLL.",
            ".LLLLLLLLLL.",
            ".LLL....LLL.",
            "............",
            "............"]
ART_SKY = ["............",
           ".....ww.....",
           "....wwww....",
           "...wLwwLw...",
           "..LLLLLLLL..",
           ".LLLLLLLLLL.",
           "LLLLGGGGLLLL",
           "LLLLGgGGLLLL",
           "LLLLddddLLLL",
           "LLLLdDddLLLL",
           "KKKKddDdKKKK",
           "KKKKKKKKKKKK"]
ART_PAL = {"G": "#6cc04a", "g": "#4e9a3a", "d": "#7a5230", "D": "#5b3c22", "P": "#3b2a4a", "S": "#f6d06b",
           "A": "#e9a23b", "K": "#1a1420", "L": "#5a616b", "w": "#ece9e2", "a": "#e9a23b", "b": "#6cc04a"}

def read_hardware():
    """GPU and CPU names from the registry (read-only), for the Desempenho page. {} when not on Windows."""
    out = {}
    try:
        import re
        import winreg
    except ImportError:
        return out
    hk = winreg.HKEY_LOCAL_MACHINE
    try:
        with winreg.OpenKey(hk, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as k:
            cpu = winreg.QueryValueEx(k, "ProcessorNameString")[0]
        cpu = re.sub(r"\((R|TM)\)", "", cpu)
        cpu = re.sub(r"\s+\d+-Core Processor\s*$|\s+Processor\s*$|\s+CPU.*$", "", cpu).strip()
        out["cpu"] = re.sub(r"\s+", " ", cpu)
    except OSError:
        pass
    try:
        names = []
        base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        with winreg.OpenKey(hk, base) as k:
            for i in range(64):
                try:
                    sub = winreg.EnumKey(k, i)
                except OSError:
                    break
                if not sub.isdigit():
                    continue
                try:
                    with winreg.OpenKey(k, sub) as d:
                        names.append(winreg.QueryValueEx(d, "DriverDesc")[0])
                except OSError:
                    continue
        rank = lambda n: (0 if ("NVIDIA" in n or "Radeon" in n or "Arc" in n) else (2 if "Basic" in n or "Microsoft" in n else 1))
        if names:
            gpu = sorted(names, key=rank)[0]
            out["gpu"] = gpu.replace("NVIDIA GeForce ", "").replace("AMD Radeon ", "Radeon ").strip()
    except OSError:
        pass
    return out


def ago(s):
    s = int(s or 0)
    return "%d s" % s if s < 60 else ("%d min" % (s // 60) if s < 3600 else "%d h" % (s // 3600))


class App:
    def __init__(self):
        self.hub, self.ctl = FB.start_hub()
        self.tab = "fusion"
        self.at = "player"
        self.gta_hud_want = True
        self.rules = {"tnt": True, "wither": True, "lightning": True, "creeper": True}
        self.toast_text, self.toast_until = "", 0.0
        self.S, self.S_time = None, 0.0
        self.heights = {}          # measured heights of boxes (drawn with last frame's size)
        self.content_h = {}
        self.follow_log = True
        self.errors_seen = set()
        self.paths = FI.Paths()
        self.inst = {"gta_path": None, "gta": None, "mc": None, "manifest": None, "busy": False, "log": [],
                     "replace_d3d9": False, "error": None, "done": None, "checked": 0.0, "needs_admin": False}
        self.sec = {"sac": None, "sigs": [], "app_sigs": [], "blocks": None, "blocks_err": None, "busy": False,
                    "checked": 0.0}
        # SkyCraft (Minecraft inside Skyrim): the Skyrim folder and the SKSE / Address Library files picked
        self.sky_file = os.path.join(self.paths.local, "FusionBridge", "skycraft.json")
        self.sky = {"game": None, "skse": None, "addrlib": None, "replace_skse": False, "c": None, "busy": False,
                    "log": [], "error": None, "done": None, "checked": 0.0, "checking": False}
        self.sky_load()
        # Desempenho: the graphics cards and Lossless Scaling, found in the background; Magpie (upscale for any game)
        self.perf = {"gpus": None, "lossless": None, "checked": 0.0, "checking": False}
        self.up = {"installed": None, "running": False, "busy": False, "log": [], "error": None, "done": None}
        # Minecraft for the GTA fusion: automatic (portable Prism) or the official launcher, and what the app does by itself
        self.prefs_file = os.path.join(self.paths.local, "FusionBridge", "preferencias.json")
        self.prefs = dict(PREFS_DEFAULT)
        self.prefs_load()
        self.pr = {"st": None, "busy": False, "error": None, "done": None, "at": 0.0, "checking": False}
        self.auto = PR.AutoMC(self.paths.local, log=FB.log)
        self.closing = False
        self.hud = None
        self.hw = {}
        self.shortcut_dismissed = os.path.exists(os.path.join(self.paths.local, "FusionBridge", "atalho-oferecido"))
        self.win = None
        self._checking = False
        # game picker (Host / Secundario cards)
        self.reg = G.ModRegistry(G.default_dirs(self.paths.app_root, self.paths.local), log=FB.log)
        self.reg.refresh()
        self.reg_checked = time.time()
        self.choices = G.Choices(os.path.join(self.paths.local, "FusionBridge", "jogos.json"))
        self.games = {"list": None, "errors": [], "scanning": False, "at": 0.0}
        self.picker = None          # {"role": "host"|"secondary", "sel": game key, "filter": text} while it is open
        self._gta_ver = {}
        # file checks for the picker run on one worker thread, never on the window's (a game on a sleeping
        # network drive must not freeze the app): results by key, None until ready
        self._bg_done, self._bg_wanted, self._bg_lock = {}, set(), threading.Lock()
        self._bg_q = queue.Queue()
        self._last_verdict = {}
        threading.Thread(target=self._bg_worker, name="FusionBridge-Checks2", daemon=True).start()
        W.Window.error_handler = self.on_error

    # ---------------------------------------------------------------- plumbing
    def on_close(self):
        if self.inst.get("busy") or self.sky.get("busy") or self.pr.get("busy"):
            # never cut an install/removal in half (its rollback would not run)
            self.toast("Espere a instalação/remoção terminar para fechar o app")
            self.win.invalidate()
            return False
        self.closing = True
        if self.hud is not None:
            self.hud.close()
        return True

    def on_error(self, e):
        key = repr(e)[:200]
        if key not in self.errors_seen:
            self.errors_seen.add(key)
            FB.log("[App] erro na interface: %s" % key)
            import traceback
            for line in traceback.format_exception(type(e), e, e.__traceback__)[-4:]:
                FB.log("[App]   " + line.rstrip().replace("\n", " | "))

    def toast(self, text):
        self.toast_text, self.toast_until = text, time.time() + 2.4

    def status(self):
        now = time.time()
        if self.S is None or now - self.S_time > 0.2:
            self.S = self.ctl.status(with_log=self.tab == "log")
            self.S_time = now
        return self.S

    def act(self, result, ok_text, fail_text="Recusado"):
        r = result or {}
        self.toast(ok_text if r.get("ok") else (r.get("error") or fail_text))

    def start_checks(self, force=False):
        """Filesystem/registry checks for Instalacao/Seguranca, off the UI thread."""
        if self._checking or (not force and time.time() - self.inst["checked"] < 3.0):
            return
        self._checking = True

        def work():
            try:
                if not self.inst["gta_path"]:
                    saved = self.choices.gta_path
                    self.inst["gta_path"] = saved if saved and os.path.isfile(os.path.join(saved, "gta_sa.exe")) \
                        else FI.find_gta_sa()
                gp = self.inst["gta_path"]
                self.inst["gta"] = FI.check_gta(gp, self.paths)
                self.inst["mc"] = FI.check_minecraft(self.paths)
                self.inst["manifest"] = FI.load_manifest(self.paths)
                self.pr["st"] = PR.state(self.paths.local)
                if self.prefs.get("mc_mode") not in ("prism", "launcher"):
                    man = self.inst["manifest"] or {}
                    # an install of 0.6.4 or older used the official launcher: keep it; otherwise the automatic one
                    self.prefs_set(mc_mode="launcher" if (man and man.get("McMode", "launcher") == "launcher"
                                                          and man.get("LauncherProfile")) else "prism")
                self.sec["sac"] = FI.sac_state()
                if not self.hw:
                    self.hw = read_hardware()
                self.inst["shortcut"] = FI.app_shortcut_exists()
                self.sec["app_sigs"] = FI.app_code_signatures(self.paths.app_root)
                if gp:
                    files = [("gta_sa.exe", "o jogo"), ("d3d9.dll", "ReShade (add-on)"), ("FusionBridgeSA.asi", "FusionBridge"),
                             ("MoonLoader.asi", "MoonLoader"), ("vorbisFile.dll", "carregador de ASI"),
                             ("dinput8.dll", "carregador de ASI")]
                    self.sec["sigs"] = [(n, what, FI.signature(os.path.join(gp, n))) for n, what in files
                                        if os.path.exists(os.path.join(gp, n))]
                else:
                    self.sec["sigs"] = []
            except Exception as e:
                self.on_error(e)
            finally:
                self.inst["checked"] = time.time()
                self._checking = False
        threading.Thread(target=work, name="FusionBridge-Checks", daemon=True).start()

    def run(self):
        here = os.path.dirname(os.path.abspath(__file__))
        icon = os.path.join(here, "assets", "FusionBridge.ico")
        self.icon = icon
        W.load_fonts(os.path.join(here, "assets", "fonts"))
        self.win = W.Window("FusionBridge PC %s" % FB.VERSION, 1240, 820, self.build, class_name="FusionBridgeMain",
                            icon=icon, min_size=(980, 660), timer_ms=400, on_close=self.on_close, bg=C["night"])
        self.win.is_main = True
        self.win.show()
        self.start_checks()
        threading.Thread(target=self._auto_loop, name="FusionBridge-AutoMC", daemon=True).start()
        W.run_loop()

    # ---------------------------------------------------------------- preferences + the automatic Minecraft
    def prefs_load(self):
        try:
            with open(self.prefs_file, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict):
                for k, v in PREFS_DEFAULT.items():
                    if k in d and (isinstance(d[k], bool) if isinstance(v, bool) else d[k] in ("prism", "launcher")):
                        self.prefs[k] = d[k]
        except (OSError, ValueError):
            pass

    def prefs_set(self, **kw):
        self.prefs.update(kw)
        try:
            os.makedirs(os.path.dirname(self.prefs_file), exist_ok=True)
            tmp = self.prefs_file + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.prefs, f, indent=1)
            os.replace(tmp, self.prefs_file)
        except OSError as e:
            FB.log("[App] não deu para salvar as preferências: %s" % e)

    def _auto_loop(self):
        """Every 2 s, off the window's thread: the automatic Minecraft (open with GTA, close with GTA, window off
        the screen). Only in the automatic mode; reads the hub's published status (safe from any thread)."""
        last = ""
        while not self.closing:
            time.sleep(2.0)
            try:
                p = self.prefs
                if p.get("mc_mode") != "prism" or not (p.get("auto_start") or p.get("auto_close") or p.get("hide_mc")
                                                       or self.auto.hidden):
                    continue
                F = self.ctl.status().get("fusion") or {}
                self.auto.tick(p, FI.is_running("gta_sa.exe"), F.get("mc"))
                if self.auto.note != last:
                    last = self.auto.note
                    if self.win:
                        self.win.invalidate()
            except Exception as e:
                self.on_error(e)

    # ---------------------------------------------------------------- small drawing helpers
    def box(self, ui, key, x, y, w, color=None, radius=6):
        ui.panel(x, y, w, self.heights.get(key, 80), bg=color or C["dusk"], radius=radius)

    def box_end(self, ui, key, y, bottom):
        h = bottom - y
        if abs(self.heights.get(key, -1) - h) > 0.5:
            self.heights[key] = h
            ui.fired = True          # draw again with the right size

    def gate(self, ui, x, y, w, state, text):
        ui.dot(x + 7, y + 10, state, 4.5)
        return max(20, ui.text(x + 22, y, w - 22, text, C["paper"], 14)) + 8

    def h2(self, ui, x, y, w, text, sub=None, icon=None, color=None):
        tx = x
        if icon:
            ui.icon(icon, x, y + 1, 20, color or C["grass"])
            tx = x + 30
        h = ui.text(tx, y, w - (tx - x), text, C["head"], 16, FW_BOLD) + 4
        if sub:
            h += ui.text(x, y + h, w, sub, C["haze"], 13) + 12
        else:
            h += 8
        return h

    def blocks_grid(self, ui, x, y, w, items, enabled, on_click, minw=132, h=78, gap=12):
        cols = max(1, int((w + gap) // (minw + gap)))
        bw = (w - gap * (cols - 1)) / cols
        for i, (key, title, sub, style) in enumerate(items):
            cx = x + (i % cols) * (bw + gap)
            cy = y + (i // cols) * (h + gap)
            top, body, shade = BLOCK[style]
            if ui.block("blk-" + key, cx, cy, bw, h, title, sub, top, body, shade, enabled):
                on_click(key, title)
        rows = (len(items) + cols - 1) // cols
        return rows * (h + gap) - gap

    def action_tile(self, ui, key, x, y, w, h, icon, icon_color, title, sub, kind="normal", active=False):
        """A big clickable tile (quick actions): icon, title, one line under it."""
        hv, ck = ui.interactive(x, y, w, h)
        bg, border = {"danger": ("#1f1513", "#4a2620"), "active": ("#14202f", "#4d7bc4")}.get(
            "active" if active else kind, (C["dusk"], C["line"]))
        oy = 2 if ui.pressing(hv) else 0
        ui.panel(x, y + oy, w, h, bg=bg, border=icon_color if hv else border, shadow=oy == 0)
        if hv:
            ui.rect(x, y + oy, w, h, "#ffffff", 6, 10)
        ui.icon(icon, x + 16, y + oy + 18, 24, icon_color)
        th = ui.text(x + 52, y + oy + 15, w - 66, title, C["head"], 15, FW_BOLD)
        ui.text(x + 52, y + oy + 19 + th, w - 66, sub, "#e3b6aa" if kind == "danger" else C["haze"], 12)
        return ck

    # ---------------------------------------------------------------- frame
    def build(self, ui):
        S = self.status()
        if time.time() - self.reg_checked > 1.5:
            self.reg_checked = time.time()
            n = len(self.reg.mods)
            if self.reg.refresh():
                self.bg_clear()
                self.toast("Mods fusion atualizados: %d%s" % (len(self.reg.mods), " (novo reconhecido)" if len(self.reg.mods) > n else ""))
        blocked = None
        if self.picker is not None:              # the picker is modal: nothing under it reacts to the mouse
            blocked, ui.mouse, ui.click = (ui.mouse, ui.click), None, None
        self.sidebar(ui, S)
        pad = 32
        x = SB + pad
        w = ui.w - SB - 2 * pad
        top = self.page_header(ui, x, 22, w, S) + 16
        ui.rect(SB, top - 1, ui.w - SB, 1, C["line"])
        view_h = ui.h - top
        key = "tab-" + self.tab
        ui.begin_scroll(key, SB, top, ui.w - SB, view_h, self.content_h.get(key, view_h))
        fn = {"fusion": self.tab_fusion, "chaos": self.tab_chaos, "controls": self.tab_controls, "install": self.tab_install,
              "mods": self.tab_mods, "perf": self.tab_perf, "security": self.tab_security, "diag": self.tab_diag,
              "log": self.tab_log}[self.tab]
        bottom = fn(ui, x, top + 22, w, S)
        ch = bottom - top + 30
        if abs(self.content_h.get(key, -1) - ch) > 0.5:
            self.content_h[key] = ch
        ui.end_scroll(SB, top, ui.w - SB, view_h)
        if self.tab in ("install", "security", "perf", "mods"):
            self.start_checks()
        if blocked is not None:
            ui.mouse, ui.click = blocked
            self.draw_picker(ui)
        self.draw_toast(ui)

    def go(self, tab):
        if tab != self.tab:
            self.tab = tab
            self.S = None
            if tab in ("install", "security", "perf", "mods"):
                self.start_checks(force=True)
            if tab == "mods":
                self.sky["checked"] = 0.0

    def draw_toast(self, ui):
        if time.time() > self.toast_until or not self.toast_text:
            return
        tw = min(ui.w - SB - 40, ui.measure(self.toast_text, 560, 14, FW_SEMIBOLD)[0] + 70)
        th = ui.measure(self.toast_text, tw - 70, 14, FW_SEMIBOLD)[1] + 26
        x, y = SB + (ui.w - SB - tw) / 2, ui.h - th - 26
        ui.panel(x, y, tw, th, bg=C["dusk2"], border=C["line2"])
        ui.rect(x + 14, y + (th - 22) / 2, 22, 22, "#3f7a2a", 3)
        ui.rect(x + 14, y + (th - 22) / 2, 22, 19, C["grass"], 3)
        ui.icon("check", x + 17, y + (th - 22) / 2 + 2, 16, "#0f1e08", 2.6)
        ui.text(x + 48, y + 13, tw - 64, self.toast_text, C["head"], 14, FW_SEMIBOLD)

    # ---------------------------------------------------------------- sidebar and page header
    def nav_badge(self, key, S):
        F = S.get("fusion") or {}
        if key == "fusion":
            if not F.get("on"):
                return None
            mc = (F.get("mc") or {}).get("state") == "open"
            return "ok" if mc and (F.get("gta") or {}).get("connected") else "wait"
        if key == "install" and self.inst.get("checked") and not self.inst.get("manifest"):
            return "wait"
        if key == "security" and self.sec.get("blocks"):
            return "bad"
        if key == "mods" and self.sky.get("busy"):
            return "wait"
        return None

    def sidebar(self, ui, S):
        ui.rect(0, 0, SB, ui.h, C["side"])
        ui.rect(SB - 1, 0, 1, ui.h, C["line"])
        ui.rect(19, 19, 48, 48, "#000000", 6, 90)
        ui.pixels(18, 16, 1.5, LOGO, LOGO_PAL)
        ui.text(78, 16, SB - 86, "FusionBridge", C["head"], 26, FW_BOLD, wrap=False, pixel=True)
        ui.text(78, 46, SB - 86, "PC %s · Windows" % S.get("version", FB.VERSION), C["haze"], 12, wrap=False)
        y = 92
        for key, label, icon in NAV:
            if ui.nav_item("nav-" + key, 12, y, SB - 24, 42, icon, label, key == self.tab, self.nav_badge(key, S)):
                self.go(key)
            y += 44
        # the bridge server (the hub inside this app)
        hub = S.get("hub", {})
        mode = hub.get("mode")
        n = len([c for c in self.clients(S) if not (c.get("name") or "").startswith("panel")]) + \
            (1 if ((S.get("fusion") or {}).get("mc") or {}).get("state") == "open" else 0)
        bh = 142
        by = max(y + 14, ui.h - bh - 18)
        bx, bw = 12, SB - 24
        ui.panel(bx, by, bw, bh, bg="#13161a", shadow=False)
        ui.text(bx + 14, by + 12, bw - 28, "Servidor da ponte", C["haze"], 12, wrap=False)
        st, txt = {"hub": ("ok", "ativo"), "off": ("", "desligado"), "retry": ("wait", "abrindo a porta…")}.get(mode, ("", "—"))
        tw = ui.measure(txt, 200, 12, FW_SEMIBOLD, wrap=False)[0]
        ui.text(bx + bw - 14 - tw, by + 12, tw + 2, txt, {"ok": C["ok"], "wait": C["wait"]}.get(st, C["soft"]), 12,
                FW_SEMIBOLD, wrap=False)
        ui.text(bx + 14, by + 34, bw - 28, "127.0.0.1:28765", C["head"], 13, mono=True, wrap=False)
        ui.text(bx + 14, by + 56, bw - 28, ("%d jogo%s conectado%s" % (n, "" if n == 1 else "s", "" if n == 1 else "s")) if n
                else "nenhum jogo conectado", C["soft"], 12, wrap=False)
        want = hub.get("want")
        if ui.button("bridge", bx + 12, by + bh - 50, bw - 24, 36, "Desligar ponte" if want else "Ligar ponte",
                     kind="secondary" if want else "primary", size=13):
            self.act(self.ctl.set_bridge(not want), "Ponte " + ("desligada" if want else "ligada"))

    def page_header(self, ui, x, y, w, S):
        kicker, title, sub = PAGES[self.tab]
        right = self.header_right(ui, x, y, w, S, draw=False)
        tw = w - (right + 24 if right else 0)
        ui.text(x, y, tw, kicker.upper(), C["haze"], 12, FW_SEMIBOLD, wrap=False)
        th = ui.text(x, y + 18, tw, title, C["head"], 36, FW_BOLD, pixel=True)
        bottom = y + 20 + th
        if self.tab == "chaos":
            F = S.get("fusion") or {}
            mc, pt = self.has(S, "minecraft"), (F.get("mc") or {}).get("state") == "open"
            sub = ("Os comandos vão para o Minecraft Java conectado." if mc else
                   ("Os comandos vão pelo mod passthrough (perfil FusionBridge)." if pt else
                    ("Nenhum Minecraft conectado: abra o GTA (o FusionBridge abre o Minecraft sozinho) ou use Abrir o "
                     "Minecraft na Ponte." if self.prefs.get("mc_mode") == "prism" else
                     "Nenhum Minecraft conectado: abra o perfil FusionBridge no Minecraft Launcher.")))
        if sub:
            bottom += 6 + ui.text(x, bottom + 6, min(tw, 760), sub, C["soft"], 14)
        if right:
            self.header_right(ui, x, y, w, S, draw=True, bottom=bottom)
        return bottom

    def header_right(self, ui, x, y, w, S, draw=True, bottom=0):
        """The page's own controls on the right of the title. With draw=False only returns the width they take."""
        if self.tab == "fusion":
            F = S.get("fusion") or {}
            bw = 236
            if draw and F.get("mc"):
                on = bool(F.get("on"))
                if ui.toggle_button("fon", x + w - bw, y + 14, bw, 54, on, "Fusão ligada", "Fusão desligada"):
                    self.act(self.ctl.fusion("on", "0" if on else "1"), "Fusão " + ("desligada" if on else "ligada"))
            return bw
        if self.tab == "perf":
            chips = [c for c in (self.hw.get("gpu"), self.hw.get("cpu")) if c]
            if not chips:
                return 0
            widths = [ui.measure(c, 400, 13, mono=True, wrap=False)[0] + 24 for c in chips]
            total = sum(widths) + 8 * (len(chips) - 1)
            if draw:
                cx = x + w - total
                for c, cw in zip(chips, widths):
                    ui.inset(cx, y + 22, cw, 34, C["dusk"])
                    ui.text(cx, y + 22, cw, c, C["head"], 13, mono=True, align="center", wrap=False, h=34)
                    cx += cw + 8
            return total
        if self.tab == "log":
            if draw:
                if ui.button("copy", x + w - 330, y + 18, 150, 38, "Copiar log", icon="copiar", size=13):
                    text = "\n".join(S.get("log") or [])
                    self.win.post(lambda: self.toast("Log copiado" if W.set_clipboard_text(self.win.hwnd, text) else "Não deu para copiar"))
                ck, _ = ui.checkbox("follow", x + w - 166, y + 26, 166, "Acompanhar o fim", self.follow_log)
                if ck:
                    self.follow_log = not self.follow_log
            return 330
        if self.tab == "chaos":
            if draw:
                v, _ = ui.segmented("at", x + w - 236, y + 18, [("player", "No jogador"), ("spawn", "No spawn")], self.at)
                if v:
                    self.at = v
                ui.text(x + w - 236 - 54, y + 18, 50, "Onde:", C["haze"], 13, wrap=False, h=38)
            return 290
        if self.tab == "install":
            if draw:
                busy = self._checking
                if ui.button("recheck", x + w - 190, y + 18, 190, 38, "Verificando…" if busy else "Verificar de novo",
                             icon="recarregar", size=13, enabled=not busy):
                    self.start_checks(force=True)
            return 190
        if self.tab == "mods":
            if draw:
                busy = self.sky["checking"]
                if ui.button("recheck-mods", x + w - 190, y + 18, 190, 38, "Verificando…" if busy else "Verificar de novo",
                             icon="recarregar", size=13, enabled=not busy):
                    self.sky["checked"] = 0.0
                    self.scan_games()
            return 190
        return 0

    def clients(self, S):
        return S.get("hub", {}).get("clients", []) or []

    def has(self, S, prefix):
        return any((c.get("name") or "").startswith(prefix) for c in self.clients(S))

    def snap(self, S, of):
        import json
        for s in S.get("hub", {}).get("snapshots", []) or []:
            if s.get("of") == of:
                try:
                    return json.loads(s.get("state") or "{}")
                except ValueError:
                    return None
        return None

    # ---------------------------------------------------------------- the desktop shortcut (the app's icon)
    def _offer_flag(self):
        return os.path.join(self.paths.local, "FusionBridge", "atalho-oferecido")

    def shortcut_banner(self, ui, x, y, w):
        """Offers the Desktop shortcut once: FusionBridge.exe itself must keep python.org's signed icon (changing the
        file would break the signature Smart App Control checks), so the logo goes on the shortcut, the window and
        the taskbar."""
        if self.inst.get("shortcut") is not False or self.shortcut_dismissed:
            return y
        h = 92
        ui.panel(x, y, w, h, bg="#15191f", border=C["line2"])
        ui.rect(x + 18, y + 18, 56, 56, "#000000", 6, 90)
        ui.pixels(x + 14, y + 14, 1.75, LOGO, LOGO_PAL)
        bw1, bw2 = 170, 120
        tw = w - 96 - bw1 - bw2 - 40
        th = ui.text(x + 92, y + 18, tw, "Coloque o FusionBridge na Área de Trabalho", C["head"], 22, FW_BOLD, pixel=True)
        ui.text(x + 92, y + 20 + th, tw, "O atalho mostra o ícone do app: o F na ponte, ao pôr do sol.", C["haze"], 13)
        if ui.button("sc-make", x + w - 18 - bw2 - 10 - bw1, y + (h - 42) / 2, bw1, 42, "Criar atalho", kind="primary",
                     icon="atalho", size=14):
            self.win.post(self.make_shortcuts_from_banner)
        if ui.button("sc-skip", x + w - 18 - bw2, y + (h - 42) / 2, bw2, 42, "Agora não", kind="ghost", size=13):
            self.dismiss_shortcut()
        return y + h + 20

    def dismiss_shortcut(self):
        self.shortcut_dismissed = True
        try:
            os.makedirs(os.path.dirname(self._offer_flag()), exist_ok=True)
            open(self._offer_flag(), "w").close()
        except OSError:
            pass

    def make_shortcuts_from_banner(self):
        self.make_shortcuts()
        self.inst["shortcut"] = FI.app_shortcut_exists()
        if self.inst["shortcut"]:
            self.dismiss_shortcut()


    # ---------------------------------------------------------------- Ponte: the two games and the bridge between them
    def bridge_row(self, ui, x, y, w, S, F):
        gta, mc = self.has(S, "gta"), self.has(S, "minecraft")
        pt = (F.get("mc") or {}).get("state") == "open"
        gst = self.snap(S, "gta")
        gcap = ("módulo conectado" + (", CJ com vida %s" % gst.get("health") if gst and gst.get("health") is not None else "")
                if gta else "módulo não conectado: abra o GTA com o FusionBridgeGTA.lua")
        mcap = (("passthrough conectado" if pt else "mod conectado") + (" + FusionBridgeMC" if mc and pt else "")) \
            if (mc or pt) else "mod não conectado: abra o perfil FusionBridge no Minecraft"
        g, fr, a = F.get("gta") or {}, F.get("frames") or {}, (F.get("gta") or {}).get("asi") or {}
        gdet = [("Câmera", ("%.0f/s" % g.get("cam_hz", 0)) if g.get("connected") else "—"),
                ("Composição", "desenhando" if a.get("effect") and a.get("frame") else ("pronta" if a.get("effect") else "—"))]
        mdet = [("Link", ":%s %s" % ((F.get("mc") or {}).get("port", 25599), "aberto" if pt else "fechado")),
                ("Imagem", ("%s×%s · %.0f fps" % (fr.get("w"), fr.get("h"), fr.get("fps", 0))) if fr.get("present") else "—")]
        h = 140
        live = (S.get("hub", {}).get("mode") == "hub") and F.get("on") and pt and g.get("connected")
        if w >= 860:
            rail = 210
            cw = (w - rail) / 2
            self.game_card(ui, "host", x, y, cw, h, gcap, gta, gdet)
            self.rail(ui, x + cw, y, rail, h, S, F, live)
            self.game_card(ui, "secondary", x + cw + rail, y, cw, h, mcap, mc or pt, mdet)
            return y + h
        self.game_card(ui, "host", x, y, w, h, gcap, gta, gdet)
        self.rail(ui, x, y + h + 6, w, 124, S, F, live)
        self.game_card(ui, "secondary", x, y + h + 136, w, h, mcap, mc or pt, mdet)
        return y + 2 * h + 136

    def rail(self, ui, x, y, w, h, S, F, live):
        cx = x + w / 2
        ly = y + 30
        phase = (time.time() * 24) % 16 if live else 0
        for side, col in ((-1, C["grass"]), (1, C["sunset"])):
            a0, a1 = (x + 14, cx - 52) if side < 0 else (cx + 52, x + w - 14)
            sx = a0 - 16 + (phase if side > 0 else -phase) % 16
            while sx < a1:
                s0, s1 = max(sx, a0), min(sx + 10, a1)
                if s1 > s0:
                    ui.rect(s0, ly - 2, s1 - s0, 4, col if live else C["line2"], 1)
                sx += 16
        bw = 96
        ui.rect(cx - bw / 2, ly - 17 + 3, bw, 34, C["shadow"] if "shadow" in C else "#08090b", 4)
        ui.rect(cx - bw / 2, ly - 17, bw, 34, C["dusk2"], 4)
        ui.outline(cx - bw / 2, ly - 17, bw, 34, C["grass"] if live else C["line2"], 4)
        ui.text(cx - bw / 2, ly - 17, bw, "FUSÃO", C["head"] if live else C["soft"], 19, FW_BOLD, align="center",
                wrap=False, h=33, pixel=True)
        F = F or {}
        lv = F.get("level") or {}
        n = len([c for c in self.clients(S) if not (c.get("name") or "").startswith("panel")]) + \
            (1 if (F.get("mc") or {}).get("state") == "open" else 0)
        chips = [("Conectados", str(n)), ("Câmera → MC", "%.0f/s" % (F.get("gta") or {}).get("cam_hz", 0)),
                 ("Chão", "%s col." % lv.get("ground_cols", 0)), ("Explosões", str(F.get("booms", 0)))]
        gap = 6
        chw = (w - 8 - gap) / 2
        chh = (h - 58 - gap) / 2
        for i, (k, v) in enumerate(chips):
            qx = x + 4 + (i % 2) * (chw + gap)
            qy = y + 56 + (i // 2) * (chh + gap)
            ui.inset(qx, qy, chw, chh, "#14171b")
            ui.text(qx + 10, qy + 4, chw - 16, k, C["haze"], 11, wrap=False)
            ui.text(qx + 10, qy + chh - 22, chw - 16, v, C["head"], 13, mono=True, wrap=False)

    def game_card(self, ui, role, x, y, w, h, live_caption, live_ok, details=None):
        """The Host / Secundario card: the chosen game; a click opens the picker."""
        host = role == "host"
        game = self.chosen(role)
        v = self.verdict_for(game, role)
        accent = C["sunset"] if host else C["grass"]
        hv, ck = ui.interactive(x, y, w, h)
        ui.panel(x, y, w, h, bg=C["dusk"], border=accent if hv else C["line"])
        if hv:
            ui.rect(x, y, w, h, "#ffffff", 6, 8)
        special = (game.get("ids") or {}).get("special") or ""
        art = ART_GTA if "gta" in special else (ART_MC if "minecraft" in special else ART_GAME)
        ui.pixels(x + 18, y + 18, 4, art, ART_PAL)
        mod = v.get("mod")
        builtin = mod is not None and mod.id == self.BUILTIN_MOD[role]
        if v is self.CHECKING:
            pill = ("Verificando…", "off")
        elif builtin:
            pill = ("Conectado", "ok") if live_ok else ("Aguardando", "wait")
        elif mod is not None:
            pill = ("Mod fusion", "info")
        else:
            pill = ("Sem mod fusion", "bad")
        pw = ui.pill(x + w - 16, y + 16, pill[0], pill[1], align="right")
        tx = x + 18 + 48 + 16
        tw = x + w - tx - pw - 26
        ui.text(tx, y + 16, tw, "HOST · NA TELA" if host else "SECUNDÁRIO · DENTRO", accent, 11, FW_SEMIBOLD, wrap=False)
        ui.text(tx, y + 33, x + w - tx - 18, game["name"], C["head"], 17, FW_BOLD, wrap=False)
        if builtin:
            cap, col = live_caption, C["soft"] if live_ok else C["haze"]
        elif mod is not None:
            cap, col = "mod fusion: %s" % mod.name, C["soft"]
        else:
            cap, col = v["title"], C["wait"]
        ui.text(tx, y + 57, x + w - tx - 18, cap, col, 12, h=32)
        if details and builtin:
            dx = x + 18
            dw = (w - 36) / len(details)
            for i, (k, val) in enumerate(details):
                ui.text(dx + i * dw, y + h - 44, dw - 10, k, C["haze"], 11, wrap=False)
                ui.text(dx + i * dw, y + h - 27, dw - 10, val, C["head"], 13, mono=True, wrap=False)
        hint = "trocar jogo"
        hw = ui.measure(hint, 200, 12, FW_SEMIBOLD, wrap=False)[0] + 2
        hc = accent if hv else C["haze"]
        if hv or not (details and builtin):
            ui.text(x + w - 34 - hw, y + h - 30, hw, hint, hc, 12, FW_SEMIBOLD, wrap=False)
            ui.icon("seta_d", x + w - 30, y + h - 31, 16, hc)
        if ck:
            self.open_picker(role)

    # ---------------------------------------------------------------- Host / Secundario: the chosen games
    DEFAULT_GAME = {"host": {"key": "default:gta-sa", "name": "GTA: San Andreas", "source": "", "path": "",
                             "ids": {"special": "gta-sa"}},
                    "secondary": {"key": "default:minecraft-java", "name": "Minecraft: Java Edition", "source": "", "path": "",
                                  "ids": {"special": "minecraft-java"}}}
    BUILTIN_MOD = {"host": "fusionbridge-gta-sa", "secondary": "fusionbridge-minecraft-java"}

    def chosen(self, role):
        return self.choices.get(role) or self.DEFAULT_GAME[role]

    def _bg_worker(self):
        while True:
            key, fn = self._bg_q.get()
            try:
                val = fn()
            except Exception as e:
                self.on_error(e)
                val = False
            with self._bg_lock:
                self._bg_done[key] = val
                self._bg_wanted.discard(key)

    def bg(self, key, fn):
        """fn() worked out on the checks thread, cached by key; None while it isn't ready."""
        with self._bg_lock:
            if key in self._bg_done:
                return self._bg_done[key]
            if key not in self._bg_wanted:
                if len(self._bg_done) > 3000:
                    self._bg_done.clear()
                self._bg_wanted.add(key)
                self._bg_q.put((key, fn))
        return None

    def bg_clear(self):
        with self._bg_lock:
            self._bg_done.clear()

    CHECKING = {"state": "wait", "title": "Verificando…", "lines": [], "mod": None}

    def verdict_for(self, game, role):
        other = self.chosen("secondary" if role == "host" else "host")
        base = (game.get("key"), role, other.get("key"))
        v = self.bg(("v",) + base + (self.reg.loaded_at, int(time.time() / 3)),
                    lambda: G.verdict(game, role, self.reg, other=other, fb_data=os.path.join(self.paths.local, "FusionBridge"),
                                      checks={"gta_sa_1_0_us": self.check_gta_version,
                                              "skyrim_skycraft": self.check_skyrim}))
        if v:
            self._last_verdict[base] = v
            return v
        return self._last_verdict.get(base) or self.CHECKING

    def _compat_of(self, game):
        mods = self.reg.for_game(game)
        return {"host": any("host" in m.roles for m in mods), "secondary": any("secondary" in m.roles for m in mods),
                "any": bool(mods)}

    def compat(self, game, role):
        """Dot for the picker list: 'ok' fusion mod for this side, 'wait' only for the other side, '' none."""
        c = self.bg(("c", game["key"], self.reg.loaded_at), lambda: self._compat_of(game))
        if not c:
            return ""
        return "ok" if c[role] else ("wait" if c["any"] else "")

    def check_gta_version(self, game):
        exe = os.path.join(game.get("path") or "", "gta_sa.exe")
        try:
            st = os.stat(exe)
        except OSError:
            return ("wait", "Não achei o gta_sa.exe nesta pasta. O FusionBridge precisa do GTA SA 1.0 US (as versões da "
                            "Steam e do Rockstar Launcher precisam de downgrade para a 1.0).") if game.get("path") else ("", "")
        k = (exe, st.st_mtime_ns, st.st_size)
        if k not in self._gta_ver:
            self._gta_ver[k] = FI.gta_version(exe)
        ver = self._gta_ver[k]
        if ver == "1.0 US":
            return "ok", "gta_sa.exe versão 1.0 US: pronto."
        return "wait", "gta_sa.exe versão %s: precisa ser a 1.0 US (faça o downgrade)." % (ver or "não reconhecida")

    def check_skyrim(self, game):
        """The SkyCraft line in the picker: Skyrim's build, SKSE, Address Library, SkyCraft (read from the files)."""
        return SK.summary(SK.check(game.get("path"), self.paths.local))

    def open_picker(self, role):
        cur = self.choices.get(role)
        self.picker = {"role": role, "sel": cur["key"] if cur else None, "filter": "", "reveal": True}
        self.win.scroll["picker-list"] = 0.0
        if self.games["list"] is None or time.time() - self.games["at"] > 60:
            self.scan_games()

    def scan_games(self):
        if self.games["scanning"]:
            return
        self.games["scanning"] = True
        extra = list(self.choices.custom)
        gta_dirs = [self.inst.get("gta_path")]

        def work():
            try:
                found, errors = G.scan(extra=extra, gta_sa_dirs=gta_dirs + [FI.find_gta_sa()])
                for c in list(self.choices.custom):     # added with "Outro jogo..." while this ran
                    if not any(G.norm_path(g.get("path")) == G.norm_path(c.get("path")) for g in found):
                        found.append(dict(c, source="manual"))
                found.sort(key=lambda g: (G.norm_name(g["name"]), g["source"]))
                at = self.reg.loaded_at
                for g in found:                          # the list dots, worked out here and not while drawing
                    with self._bg_lock:
                        self._bg_done[("c", g["key"], at)] = self._compat_of(g)
                self.games.update(list=found, errors=errors, at=time.time())
                FB.log("[Jogos] %d jogos instalados encontrados%s" % (len(found), ("; problemas: " + "; ".join(errors)) if errors else ""))
            except Exception as e:
                self.games.update(list=self.games["list"] or [], errors=[str(e)], at=time.time())
                self.on_error(e)
            finally:
                self.games["scanning"] = False
        threading.Thread(target=work, name="FusionBridge-Games", daemon=True).start()

    def picker_games(self):
        role = self.picker["role"]
        games = self.games["list"] or []
        f = G.norm_name(self.picker["filter"])
        if f:
            games = [g for g in games if f in G.norm_name(g["name"])]
        rank = {"ok": 0, "wait": 1, "": 2}
        return sorted(games, key=lambda g: (rank[self.compat(g, role)], G.norm_name(g["name"])))

    def user_mods_dir(self):
        return G.default_dirs(self.paths.app_root, self.paths.local)[-1]

    def draw_picker(self, ui):
        P = self.picker
        role = P["role"]
        host = role == "host"
        accent = C["sunset"] if host else C["grass"]
        games = self.picker_games()
        keys = [g["key"] for g in games]
        for k in ui.keys:                                     # keyboard: Esc, arrows, Enter, Backspace
            if k == W.VK_ESCAPE:
                self.picker = None
                ui.fired = True
                return
            if k in (W.VK_UP, W.VK_DOWN) and keys:
                i = keys.index(P["sel"]) if P["sel"] in keys else -1
                P["sel"] = keys[max(0, min(len(keys) - 1, i + (1 if k == W.VK_DOWN else -1)))]
                P["reveal"] = True
            elif k == W.VK_BACK and P["filter"]:
                P["filter"] = P["filter"][:-1]
                self.win.scroll["picker-list"] = 0.0
                games = self.picker_games()
                keys = [g["key"] for g in games]
            elif k == W.VK_RETURN and P["sel"] in keys:
                self.choose(role, games[keys.index(P["sel"])])
                ui.fired = True
                return
        if ui.chars:
            P["filter"] = (P["filter"] + ui.chars)[:40]
            self.win.scroll["picker-list"] = 0.0
            games = self.picker_games()
            keys = [g["key"] for g in games]
        if P["filter"] and keys and P["sel"] not in keys:     # the search moves the selection to the first match
            P["sel"] = keys[0]
        ui.rect(0, 0, ui.w, ui.h, "#000000", 0, 170)
        pw, ph = min(ui.w - 32, 1060), min(ui.h - 32, 720)
        px, py = (ui.w - pw) / 2, (ui.h - ph) / 2
        if ui.click is not None:                              # a click outside the panel closes it
            (dx, dy), (ux, uy) = ui.click
            if not (px <= dx < px + pw and py <= dy < py + ph) and not (px <= ux < px + pw and py <= uy < py + ph):
                self.picker = None
                ui.click = None
                ui.fired = True
                return
        ui.panel(px, py, pw, ph, bg=C["night"], border=accent, radius=8)
        ui.rect(px + 8, py, pw - 16, 3, accent, 1)
        ui.text(px + 24, py + 18, pw - 100, "Escolher o jogo Host" if host else "Escolher o jogo Secundário", C["head"], 28,
                FW_BOLD, wrap=False, pixel=True)
        ui.text(px + 24, py + 48, pw - 100, "O Host é o jogo que fica na tela; o Secundário é desenhado dentro dele. "
                "Clique num jogo para ver se ele tem mod fusion.", C["haze"], 13, wrap=False)
        if ui.button("pk-x", px + pw - 56, py + 16, 38, 36, "", kind="ghost", icon="x"):
            self.picker = None
            return
        top = py + 80
        lw = max(300.0, (pw - 72) * 0.52)
        lx = px + 24
        bar = py + ph - 64
        # search field: typing anywhere goes here
        ui.inset(lx, top, lw, 38, C["inset"])
        ui.icon("busca", lx + 12, top + 10, 18, C["haze"])
        caret = "|" if int(time.time() * 2.5) % 2 == 0 else " "
        ui.text(lx + 40, top, lw - 52, (P["filter"] + caret) if P["filter"] else "Digite para procurar…",
                C["paper"] if P["filter"] else C["haze"], 13, wrap=False, h=38)
        # the list
        lt, lh, row = top + 46, bar - top - 46 - 8, 56
        if P.get("reveal") and P["sel"] in keys:
            P.pop("reveal")
            rt, off = keys.index(P["sel"]) * row, self.win.scroll.get("picker-list", 0.0)
            if rt + off < 0:
                self.win.scroll["picker-list"] = -rt
            elif rt + row + off > lh:
                self.win.scroll["picker-list"] = lh - rt - row
        ui.panel(lx, lt, lw, lh, bg=C["dusk"], shadow=False)
        ui.begin_scroll("picker-list", lx, lt, lw, lh, max(lh, len(games) * row + 8))
        if self.games["list"] is None or (self.games["scanning"] and not games):
            ui.text(lx + 16, lt + 16, lw - 32, "Procurando os jogos instalados…", C["haze"], 14)
        elif not games:
            ui.text(lx + 16, lt + 16, lw - 32, "Nenhum jogo com esse nome." if P["filter"] else
                    "Nenhum jogo encontrado. Use \"Outro jogo…\" aqui embaixo.", C["haze"], 14)
        for i, g in enumerate(games):
            ry = lt + 4 + i * row
            hv, ck = ui.interactive(lx + 4, ry, lw - 16, row)
            if g["key"] == P["sel"]:
                ui.rect(lx + 4, ry + 2, lw - 16, row - 4, C["dusk2"], 4)
                ui.outline(lx + 4, ry + 2, lw - 16, row - 4, accent, 4, 1.0, 160)
            elif hv:
                ui.rect(lx + 4, ry + 2, lw - 16, row - 4, "#ffffff", 4, 10)
            ui.dot(lx + 22, ry + row / 2, self.compat(g, role))
            ui.text(lx + 36, ry + 8, lw - 62, g["name"], C["paper"], 14, FW_SEMIBOLD, wrap=False)
            ui.text(lx + 36, ry + 29, lw - 62, "%s · %s" % (G.SOURCE_LABEL.get(g["source"], g["source"]), g["path"] or "—"),
                    C["haze"], 12, wrap=False)
            if ck:
                P["sel"] = g["key"]
        ui.end_scroll(lx, lt, lw, lh)
        # right side: the sentence about the selected game (scrolls; the Selecionar button stays at the bottom)
        rx = lx + lw + 24
        rw = px + pw - 24 - rx
        rb = bar - 8
        ui.panel(rx, top, rw, rb - top, bg=C["dusk"], shadow=False)
        sel = next((g for g in games if g["key"] == P["sel"]), None) or \
            next((g for g in (self.games["list"] or []) if g["key"] == P["sel"]), None)
        if P.get("shown") != P["sel"]:
            P["shown"] = P["sel"]
            self.win.scroll["picker-right"] = 0.0
        area_h = rb - top - (64 if sel else 0)
        ui.begin_scroll("picker-right", rx, top, rw, area_h, self.content_h.get("picker-right", area_h))
        yy = top + 16
        if sel is None:
            yy += ui.text(rx + 18, yy, rw - 36, "Clique em um jogo da lista: aqui aparece se ele tem mod fusion para funcionar "
                          "como %s." % G.ROLE_LABEL[role], C["haze"], 14) + 12
        else:
            yy += ui.text(rx + 18, yy, rw - 36, sel["name"], C["head"], 18, FW_BOLD) + 2
            yy += ui.text(rx + 18, yy, rw - 36, G.SOURCE_LABEL.get(sel["source"], sel["source"]) +
                          ((" · " + sel["path"]) if sel.get("path") else ""), C["haze"], 12) + 12
            v = self.verdict_for(sel, role)
            box = yy
            ui.rect(rx + 12, yy, rw - 24, self.heights.get("pk-verdict", 90),
                    {"ok": "#1b2a16", "wait": "#2e2414", "bad": "#2e1814"}[v["state"]], 4)
            yy += 12
            yy += ui.text(rx + 26, yy, rw - 52, v["title"], {"ok": C["ok"], "wait": C["wait"], "bad": C["bad"]}[v["state"]],
                          16, FW_BOLD) + 6
            for st, txt in v["lines"]:
                yy += self.gate(ui, rx + 26, yy, rw - 52, st, txt)
            yy += 6
            self.box_end(ui, "pk-verdict", box, yy)
            yy += 16
        for st, txt in (("ok", "tem mod fusion como %s" % G.ROLE_LABEL[role]),      # what the dots mean
                        ("wait", "tem mod fusion, mas para o outro lado"), ("", "sem mod fusion")):
            ui.dot(rx + 24, yy + 10, st)
            ui.text(rx + 38, yy, rw - 56, txt, C["haze"], 12, wrap=False, h=20)
            yy += 24
        ch = yy - top + 8
        if abs(self.content_h.get("picker-right", -1) - ch) > 0.5:
            self.content_h["picker-right"] = ch
            ui.fired = True
        ui.end_scroll(rx, top, rw, area_h)
        if sel is not None:
            cur = self.choices.get(role)
            is_cur = cur is not None and cur["key"] == sel["key"]
            if ui.button("pk-choose", rx + 12, rb - 56, rw - 24, 44, ("Escolhido como " if is_cur else "Selecionar como ") +
                         G.ROLE_LABEL[role], kind="amber" if host else "primary", size=15, weight=FW_BOLD, enabled=not is_cur):
                self.choose(role, sel)
                return
        # bottom bar
        by = bar + 12
        scanning = self.games["scanning"]
        if ui.button("pk-other", lx, by, 250, 38, "Outro jogo… (escolher o .exe)", icon="pasta", size=13):
            self.win.post(self.add_custom_game)
        if ui.button("pk-rescan", lx + 260, by, 170, 38, "Procurando…" if scanning else "Atualizar lista", icon="recarregar",
                     size=13, enabled=not scanning):
            self.scan_games()
        mw = min(rw, 250)
        if ui.button("pk-mods", rx, by, mw, 38, "Pasta de mods fusion", icon="pasta", size=13):
            self.win.post(lambda: self.open_path(self.user_mods_dir(), make=True))
        n = len(self.reg.mods)
        if rw - mw > 90:
            ui.text(rx + mw + 12, by, rw - mw - 12, "%d mod%s fusion" % (n, "" if n == 1 else "s"), C["haze"], 12, wrap=False, h=38)

    def choose(self, role, game):
        other = self.chosen("secondary" if role == "host" else "host")
        v = G.verdict(game, role, self.reg, other=other, fb_data=os.path.join(self.paths.local, "FusionBridge"))
        self.choices.set(role, game)
        self.bg_clear()
        mod = v.get("mod")
        FB.log("[Jogos] %s: %s (%s)" % (G.ROLE_LABEL[role], game["name"], ("mod fusion: " + mod.name) if mod else v["title"].lower()))
        path = game.get("path")
        if role == "host" and mod is not None and mod.id == self.BUILTIN_MOD["host"] and path and \
                os.path.isfile(os.path.join(path, "gta_sa.exe")) and G.norm_path(path) != G.norm_path(self.inst.get("gta_path")):
            self.set_gta_path(path)                      # the Instalacao tab uses the GTA chosen here
        if role == "host" and mod is not None and mod.id == "skycraft-skyrim" and SK.is_skyrim_dir(path):
            self.sky_set_game(path)                      # the SkyCraft card uses the Skyrim chosen here
        self.picker = None
        self.toast("%s: %s%s" % (G.ROLE_LABEL[role], game["name"], "" if mod else " (sem mod fusion)"))

    def add_custom_game(self):
        p = W.open_file_dialog(self.win.hwnd, "Escolha o .exe do jogo", [("Jogos (*.exe)", "*.exe")], None)
        if not p:
            return
        if not p.lower().endswith(".exe"):
            self.toast("Escolha o arquivo .exe do jogo")
            return
        games = list(self.games["list"] or [])
        exe_dir = G.norm_path(os.path.dirname(p))
        # an .exe inside a game that is already listed (bin\x64, Binaries\Win64...) is that game
        same = next((x for x in games if x.get("path") and (exe_dir == G.norm_path(x["path"]) or
                                                             exe_dir.startswith(G.norm_path(x["path"]) + os.sep))), None)
        if same is None:
            same = self.choices.add_custom(p)
            games.append(same)
            games.sort(key=lambda x: (G.norm_name(x["name"]), x["source"]))
            self.games["list"] = games
        if self.picker is not None:
            self.picker.update(sel=same["key"], filter="", reveal=True)
        FB.log("[Jogos] jogo adicionado à mão: %s (%s)" % (same["name"], same["path"]))

    # ---------------------------------------------------------------- tab: Ponte
    def tab_fusion(self, ui, x, y, w, S):
        F = S.get("fusion") or {}
        if not F.get("mc"):
            return y + ui.text(x, y, w, "Iniciando o motor de fusão…", C["haze"], 14)
        y = self.shortcut_banner(ui, x, y, w)
        hv = self._last_verdict.get((self.chosen("host").get("key"), "host", self.chosen("secondary").get("key")))
        if hv and hv.get("mod") is not None and hv["mod"].id == "skycraft-skyrim":
            y = self.skycraft_banner(ui, x, y, w)
        y = self.bridge_row(ui, x, y, w, S, F) + 22
        if self.prefs.get("mc_mode") == "prism" and (F.get("mc") or {}).get("state") != "open":
            y = self.mc_auto_strip(ui, x, y, w) + 18
        y = self.status_cards(ui, x, y, w, F) + 18

        # quick actions
        cols = 3 if w >= 760 else 1
        gap = 12
        tw = (w - gap * (cols - 1)) / cols
        th = 84
        mouse_mc = F.get("mouse") != "gta"
        tiles = [("relevel", "nivelar", C["grass"], "Nivelar o chão aqui", "Alinha os blocos ao chão do GTA · F8", "normal", False),
                 ("mouse", "mouse", C["blue"], "Mouse no Minecraft" if mouse_mc else "Mouse no GTA",
                  ("Cliques e 1–9 vão para o Minecraft · F6" if mouse_mc else "O CJ usa as armas dele · F6"), "normal", not mouse_mc),
                 ("clear", "lixo", C["bad"], "Limpar o Minecraft", "Tira as construções; pede confirmação antes", "danger", False)]
        for i, (k, icon, col, title, sub, kind, active) in enumerate(tiles):
            cx = x + (i % cols) * (tw + gap)
            cy = y + (i // cols) * (th + gap)
            if self.action_tile(ui, "qa-" + k, cx, cy, tw, th, icon, col, title, sub, kind, active):
                if k == "relevel":
                    self.act(self.ctl.fusion("relevel"), "Nivelando o chão")
                elif k == "mouse":
                    v = "gta" if mouse_mc else "mc"
                    self.act(self.ctl.fusion("mouse", v), "Mouse: " + ("Minecraft" if v == "mc" else "GTA"))
                else:
                    self.win.post(self.confirm_clear)
        y += ((len(tiles) + cols - 1) // cols) * (th + gap) - gap + 18

        # kits
        mc_open = F["mc"].get("state") == "open"
        top = y
        self.box(ui, "b-kits", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Itens para o Steve", "Vão direto para o inventário do Minecraft (pelo mod passthrough).",
                     icon="pacote")
        y += self.blocks_grid(ui, x + 18, y, w - 36, KITS, mc_open,
                              lambda k, t: self.act(self.ctl.fusion("give", k), t + " no inventário", "Minecraft não conectado"))
        y += 18
        self.box_end(ui, "b-kits", top, y)
        y += 18

        # engine notes
        top = y
        self.box(ui, "b-notes", x, y, w, color=C["inset"])
        y += 16
        y += self.h2(ui, x + 18, y, w - 36, "Eventos da ponte", icon="diag", color=C["sunset"])
        notes = F.get("notes") or []
        if not notes:
            y += ui.text(x + 18, y, w - 36, "Nada ainda.", C["haze"], 13) + 6
        for n in notes[:12]:
            ui.text(x + 18, y, 64, ago(n.get("age_s")), "#7e8691", 12, mono=True, wrap=False)
            y += max(20, ui.text(x + 86, y, w - 104, n.get("text", ""), C["soft"], 12, mono=True)) + 5
        y += 10
        self.box_end(ui, "b-notes", top, y)
        return y

    def skycraft_banner(self, ui, x, y, w):
        """Host = Skyrim with SkyCraft: that fusion runs on its own (shared memory between the two games), not over
        this bridge; its install and play buttons are on Mods fusion."""
        h = 96
        ui.panel(x, y, w, h, bg="#15191f", border=C["line2"])
        ui.pixels(x + 18, y + 18, 5, ART_SKY, ART_PAL)
        bw = 200
        tw = w - 100 - bw - 36
        th = ui.text(x + 92, y + 16, tw, "Skyrim + Minecraft: quem faz esta fusão é o SkyCraft", C["head"], 22, FW_BOLD, pixel=True)
        ui.text(x + 92, y + 20 + th, tw, "O Skyrim e o Minecraft conversam direto por memória compartilhada, sem a ponte "
                "abaixo (ela é da fusão GTA). Instalar, entrar na conta e jogar ficam em Mods fusion.", C["haze"], 13)
        if ui.button("go-mods", x + w - 18 - bw, y + (h - 42) / 2, bw, 42, "Abrir Mods fusion", kind="primary", icon="blocos",
                     size=14):
            self.go("mods")
        return y + h + 20

    def pr_refresh(self):
        """The automatic Minecraft's state (installed, signed in...), re-read in the background every few seconds
        while a page shows it (the player signs in on Prism's own window)."""
        pr = self.pr
        if pr["checking"] or time.time() - pr["at"] < 4.0:
            return
        pr["checking"] = True

        def work():
            try:
                pr["st"] = PR.state(self.paths.local)
            except Exception as e:
                self.on_error(e)
            finally:
                pr["at"], pr["checking"] = time.time(), False
                if self.win:
                    self.win.invalidate()
        threading.Thread(target=work, name="FusionBridge-PrismState", daemon=True).start()

    def mc_auto_strip(self, ui, x, y, w):
        """Automatic Minecraft and not linked yet: what the app will do, and a button to open it now."""
        self.pr_refresh()
        st = self.pr.get("st") or {}
        h = 76
        ui.panel(x, y, w, h, bg=C["dusk"], border=C["line"])
        ui.icon("jogar", x + 18, y + (h - 24) / 2, 24, C["grass"])
        bw = 190
        if not st.get("installed"):
            msg, btn = "Minecraft automático ainda não instalado: use Instalar (ele baixa o Prism e prepara tudo).", ("go-inst", "Ir para Instalar")
        elif not st.get("signed_in"):
            msg, btn = "Falta entrar na sua conta Microsoft no Prism (uma vez só).", ("pr-signin", "Entrar na conta")
        else:
            note = self.auto.note or ("Abra o GTA: o FusionBridge abre o Minecraft sozinho." if self.prefs.get("auto_start")
                                      else "Abrir sozinho com o GTA está desligado (Instalar → Minecraft automático).")
            msg, btn = note, ("pr-launch", "Abrir o Minecraft")
        th = ui.text(x + 56, y + 14, w - 56 - bw - 36, "Minecraft automático", C["head"], 15, FW_BOLD)
        ui.text(x + 56, y + 16 + th, w - 56 - bw - 36, msg, C["haze"], 13)
        if ui.button(btn[0], x + w - 18 - bw, y + (h - 42) / 2, bw, 42, btn[1], kind="primary", size=14,
                     icon="conta" if btn[0] == "pr-signin" else ("instalar" if btn[0] == "go-inst" else "jogar"),
                     enabled=not self.pr["busy"]):
            if btn[0] == "go-inst":
                self.go("install")
            elif btn[0] == "pr-signin":
                self.win.post(self.pr_sign_in)
            else:
                self.win.post(self.pr_launch)
        return y + h

    def status_cards(self, ui, x, y, w, F):
        mc_open = F["mc"].get("state") == "open"
        fr, g, lv = F.get("frames") or {}, F.get("gta") or {}, F.get("level") or {}
        a = g.get("asi") or {}
        mc_lines = [("ok" if mc_open else ("wait" if F["mc"].get("state") == "handshake" else ""),
                     ("link aberto (pid %s), %s msgs enviadas" % ((F["mc"].get("hello") or {}).get("pid", "?"), F["mc"].get("tx")))
                     if mc_open else ("aguardando o Minecraft em 127.0.0.1:%s" % F["mc"].get("port")) +
                     (" — " + F["mc"]["error"] if F["mc"].get("error") else ""))]
        if not fr.get("supported"):
            mc_lines.append(("", "frames: só aparece no Windows"))
        else:
            mc_lines.append(("ok" if fr.get("present") and fr.get("fps", 0) > 1 else ("wait" if fr.get("present") else ""),
                             "frames do Minecraft: %.0f/s, %s×%s" % (fr.get("fps", 0), fr.get("w"), fr.get("h"))
                             if fr.get("present") else "frames do Minecraft: ainda nenhum (mundo abrindo?)"))
        gc = g.get("connected")
        asi_loaded = a.get("loaded") == 1
        gta_lines = [("ok" if gc and g.get("cam_hz", 0) > 5 else ("wait" if gc else ""),
                      ("câmera chegando %.0fx/s" % g.get("cam_hz", 0) + (" (no carro)" if g.get("veh") else ""))
                      if gc else "script do GTA não conectado")]
        if not gc:
            gta_lines.append(("", "FusionBridgeSA.asi: —"))
        elif not asi_loaded:
            gta_lines.append(("bad", a.get("note") or "FusionBridgeSA.asi não carregou"))
        elif not a.get("sa_ok"):
            gta_lines.append(("bad", "ASI: gta_sa.exe não é 1.0 US (fusão visual desligada)"))
        elif not a.get("reshade"):
            gta_lines.append(("bad", "ASI carregado, mas o ReShade (d3d9.dll com add-on) não"))
        else:
            gta_lines.append(("ok", "ASI + ReShade prontos" + (" (%s×%s)" % (a.get("bb_w"), a.get("bb_h")) if a.get("bb_w") else "")))
        if asi_loaded:
            gta_lines.append(("ok" if a.get("effect") and a.get("frame") else ("wait" if a.get("effect") else "bad"),
                              ("Minecraft sendo desenhado no GTA (%s frames)" % a.get("uploads")) if a.get("effect") and a.get("frame")
                              else ("efeito pronto, esperando frames do Minecraft" if a.get("effect")
                                    else "efeito FusionBridgeSA.fx não carregou (aperte Home no GTA para ver o erro)")))
            gta_lines.append(("ok" if a.get("pad_hook") and a.get("hud_hook") else "wait",
                              "bloqueio do tiro: %s · HUD do GTA por cima: %s" % ("sim" if a.get("pad_hook") else "não",
                                                                                 "sim" if a.get("hud_hook") else "não")))
        booms, tps = F.get("booms", 0), F.get("teleports", 0)
        lv_lines = [("ok" if lv.get("have") else "wait",
                     ("chão nivelado (deslocamento %+.2f%s)" % (lv.get("yoff", 0), (", %s blocos" % lv.get("shift")) if lv.get("shift") else ""))
                     if lv.get("have") else "chão ainda não nivelado"),
                    ("ok" if lv.get("ground_cols") else "", "%s colunas de chão enviadas · %s blocos construídos perto" % (lv.get("ground_cols", 0), lv.get("blocks", 0))),
                    ("ok" if booms or tps else "", "%d %s e %d %s levados para o GTA" % (booms, "explosão" if booms == 1 else "explosões",
                                                                                       tps, "teleporte" if tps == 1 else "teleportes"))]
        cards = [("c-mc", "Minecraft (passthrough)", "pacote", C["grass"], mc_lines),
                 ("c-gta", "GTA San Andreas", "raio", C["sunset"], gta_lines),
                 ("c-lv", "Chão e mundo", "nivelar", C["blue"], lv_lines)]
        cols = 3 if w >= 900 else 1
        gap = 12
        cw = (w - gap * (cols - 1)) / cols
        hmax = max(self.heights.get(k, 120) for k, _, _, _, _ in cards)
        cy = y
        for i, (key, title, icon, col, lines) in enumerate(cards):
            cx = x + i * (cw + gap) if cols == 3 else x
            ch = hmax if cols == 3 else self.heights.get(key, 120)
            ui.panel(cx, cy, cw, ch)
            yy = cy + 16
            ui.icon(icon, cx + 16, yy, 18, col)
            yy += ui.text(cx + 42, yy, cw - 58, title, C["head"], 15, FW_BOLD) + 10
            for st, txt in lines:
                yy += self.gate(ui, cx + 16, yy, cw - 32, st, txt)
            h = yy - cy + 8
            if abs(self.heights.get(key, -1) - h) > 0.5:
                self.heights[key] = h
                ui.fired = True
            if cols != 3:
                cy += ch + gap
        return y + hmax if cols == 3 else cy - gap

    def confirm_clear(self):
        if W.message_box("Limpar o mundo do Minecraft?\n\nTira as construções, a TNT e os mobs do mundo da fusão. "
                         "Seus mundos normais do Minecraft não são tocados.", "FusionBridge",
                         W.MB_YESNO | W.MB_ICONWARN, self.win.hwnd) != W.IDYES:
            return
        self.act(self.ctl.mc_action("clear", self.at), "Limpando o Minecraft")

    # ---------------------------------------------------------------- tab: Controles
    def tab_controls(self, ui, x, y, w, S):
        F = S.get("fusion") or {}
        top = y
        self.box(ui, "b-mouse", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Mouse com o CJ a pé", "Quem recebe os cliques, a rodinha e as teclas 1–9.", icon="mouse",
                     color=C["blue"])
        v, _ = ui.segmented("mouse", x + 18, y, [("mc", "Minecraft (blocos, itens)"), ("gta", "GTA (armas do CJ)")], F.get("mouse"))
        if v:
            self.act(self.ctl.fusion("mouse", v), "Mouse: " + ("Minecraft" if v == "mc" else "GTA"))
        y += 56
        self.box_end(ui, "b-mouse", top, y)
        y += 18

        top = y
        self.box(ui, "b-opts", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Opções da fusão", icon="controles")
        opts = F.get("opts") or {}
        ocols = 2 if w >= 640 else 1
        ow = (w - 36) / ocols
        rows_h = 0
        for i, (k, label) in enumerate(FUSION_OPTS):
            ox = x + 18 + (i % ocols) * ow
            oy = y + (i // ocols) * 36
            ck, _ = ui.checkbox("opt-" + k, ox, oy, ow - 16, label, bool(opts.get(k)))
            if ck:
                self.act(self.ctl.fusion("opt", "0" if opts.get(k) else "1", k), label + (": não" if opts.get(k) else ": sim"))
            rows_h = (i // ocols + 1) * 36
        y += rows_h + 12
        self.box_end(ui, "b-opts", top, y)
        y += 18

        top = y
        self.box(ui, "b-keys", x, y, w)
        y += 18
        fused = bool((F.get("opts") or {}).get("keys_fused", True))
        y += self.h2(ui, x + 18, y, w - 36, "Teclas no GTA",
                     "Ligam sozinhas quando a fusão começa." + ("" if fused else " Teclas fundidas desligadas (Opções da fusão)."),
                     icon="caos", color=C["sunset"])
        kc = 132
        c1, c2 = x + 18 + kc, x + 18 + kc + (w - 36 - kc) * 0.5
        ui.text(c1, y, c2 - c1 - 10, "Minecraft", C["grass"], 13, FW_SEMIBOLD, wrap=False)
        ui.text(c2, y, x + w - 18 - c2, "GTA San Andreas", C["sunset"], 13, FW_SEMIBOLD, wrap=False)
        y += 26
        for key, mc_does, gta_does, needs_fused in KEY_TABLE:
            if needs_fused and not fused:
                continue
            ui.keycap(x + 18, y, key, min_w=96)
            h1 = ui.text(c1, y + 4, c2 - c1 - 12, mc_does, C["paper"], 14)
            h2 = ui.text(c2, y + 4, x + w - 18 - c2, gta_does, C["haze"], 14)
            ui.rect(x + 18, y + max(34, max(h1, h2) + 12) - 5, w - 36, 1, C["line"])
            y += max(34, max(h1, h2) + 12) + 4
        y += 8
        for key, what in GTA_KEYS:
            ui.keycap(x + 18, y, key, min_w=96)
            y += max(36, ui.text(c1, y + 4, x + w - 18 - c1, what, C["paper"], 14) + 14)
        y += 8
        self.box_end(ui, "b-keys", top, y)
        return y

    # ---------------------------------------------------------------- tab: Desempenho
    def seg_row(self, ui, key, x, y, w, label, hint, options, cur):
        """A label + hint on the left and a segmented control on the right (under it when narrow).
        Returns (picked value or None, height used)."""
        segw = sum(ui.measure(l, 1000, 13, FW_SEMIBOLD, wrap=False)[0] + 28 for _, l in options) + 8 + 4 * (len(options) - 1)
        wide = w - segw > 300
        lw = (w - segw - 24) if wide else w
        lh = ui.text(x, y, lw, label, C["head"], 14, FW_SEMIBOLD) + 2
        if hint:
            lh += ui.text(x, y + lh, lw, hint, C["haze"], 12)
        sy = y + (max(0, (lh - 38) / 2) if wide else lh + 8)
        v, _ = ui.segmented(key, (x + w - segw) if wide else x, sy, options, cur)
        return v, (max(lh, 38) if wide else lh + 50)

    def bullets(self, ui, x, y, w, lines, size=14):
        for line in lines:
            ui.rect(x + 2, y + 8, 6, 6, C["grass"])
            y += ui.text(x + 18, y, w - 18, line, C["paper"], size) + 7
        return y

    def note_box(self, ui, x, y, w, text, kind):
        """A coloured message line (error / done / waiting) with its icon; returns the new y."""
        bg, border, icon, col = {"error": ("#3a1d18", "#5a2a22", "x", C["bad"]), "done": ("#213318", "#2f4a22", "check", C["ok"]),
                                 "wait": ("#352712", "#4a3818", "info", C["wait"])}[kind]
        eh = ui.measure(text, w - 56, 13)[1] + 24
        ui.rect(x, y, w, eh, bg, 4)
        ui.outline(x, y, w, eh, border, 4)
        ui.icon(icon, x + 12, y + 12, 16, col, 2.4)
        ui.text(x + 38, y + 12, w - 50, text, C["paper"], 13)
        return y + eh + 10

    def perf_check(self):
        pf = self.perf
        pf["checking"] = True
        games = list(self.games["list"] or [])

        def work():
            try:
                self.up["installed"] = UP.installed(self.paths.local)
                self.up["running"] = UP.running()
                self.sec["sac"] = FI.sac_state()
                pf["gpus"] = PF.gpu_names()
                pf["lossless"] = PF.find_lossless_scaling(games)
            except Exception as e:
                self.on_error(e)
            finally:
                pf["checked"], pf["checking"] = time.time(), False
                if self.win:
                    self.win.invalidate()
        if self.games["list"] is None:
            self.scan_games()
        threading.Thread(target=work, name="FusionBridge-Perf", daemon=True).start()

    def tab_perf(self, ui, x, y, w, S):
        cfg = S.get("cfg", {})
        F = S.get("fusion") or {}
        opts = F.get("opts") or {}
        pf = self.perf
        if not pf["checking"] and time.time() - pf["checked"] > 30:
            self.perf_check()
        gpus = pf.get("gpus") or []
        main = gpus[0] if gpus else (self.hw.get("gpu") or "")
        vend = PF.vendor(main)
        # 1. rhythm and weight of the fusion
        top = y
        self.box(ui, "b-rhythm", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Ritmo e peso da fusão", icon="desempenho")
        rows = [("mode", "Modo da ponte", MODE_HINT.get(cfg.get("mode"), ""),
                 [("eco", "Eco híbrido"), ("live", "Ao vivo"), ("visual", "Visual")], cfg.get("mode")),
                ("radius", "Raio do chão", "Quantos blocos de chão do GTA o Minecraft recebe em volta do CJ.",
                 [(24, "24 (leve)"), (40, "40"), (56, "56 (pesado)")], opts.get("radius")),
                ("pix", "Minecraft no máximo", "Copiar a imagem custa banda; acima disso o FSR 1.0 (abaixo) amplia.",
                 [(921600, "720p"), (2073600, "1080p"), (3686400, "1440p")], opts.get("max_pixels"))]
        for i, (k, label, hint, options, cur) in enumerate(rows):
            v, h = self.seg_row(ui, "perf-" + k, x + 18, y, w - 36, label, hint, options, cur)
            if v is not None:
                if k == "mode":
                    self.act(self.ctl.set_cfg(mode=v), "Modo: " + dict(options)[v])
                elif k == "radius":
                    self.act(self.ctl.fusion("opt", str(v), "radius"), "Raio do chão: %d blocos" % v)
                else:
                    self.act(self.ctl.fusion("opt", str(v), "max_pixels"), "Minecraft no máximo: " + dict(options)[v])
            y += h + 14
            if i < len(rows) - 1:
                ui.rect(x + 18, y - 7, w - 36, 1, C["line"])
                y += 6
        y += 6
        self.box_end(ui, "b-rhythm", top, y)
        y += 18

        # 2. FSR 1.0: real, on any card, for Minecraft's picture inside GTA
        top = y
        self.box(ui, "b-fsr", x, y, w)
        y += 18
        fsr_on = bool(opts.get("fsr", True))
        ui.text(x + 18, y - 2, w - 240, "FSR 1.0", C["head"], 28, FW_BOLD, wrap=False, pixel=True)
        ui.pill(x + w - 18, y + 2, "Funciona em qualquer placa" if fsr_on else "Desligado", "ok" if fsr_on else "off", align="right")
        y += 40
        y += ui.text(x + 18, y, w - 36, "A imagem do Minecraft dentro do GTA: o Minecraft desenha menor (alivia a placa) e o "
                     "FSR 1.0 da AMD amplia até a resolução do GTA com bordas definidas (EASU) e nitidez (RCAS), dentro do "
                     "próprio GTA. Também melhora a imagem quando o Minecraft no máximo (acima) fica menor que o GTA.",
                     C["soft"], 14) + 14
        ck, h = ui.checkbox("fsr", x + 18, y, w - 36, "FSR 1.0 ligado", fsr_on)
        if ck:
            self.act(self.ctl.fusion("opt", "0" if fsr_on else "1", "fsr"), "FSR 1.0 " + ("desligado" if fsr_on else "ligado"))
        y += h + 14
        v, h = self.seg_row(ui, "fsr-mode", x + 18, y, w - 36, "Modo", "Como na AMD: quanto menor o Minecraft, mais leve.",
                            FSR_MODES, opts.get("fsr_scale", 100))
        if v is not None:
            self.act(self.ctl.fusion("opt", str(v), "fsr_scale"), "FSR 1.0: " + dict(FSR_MODES)[v])
        y += h + 14
        v, h = self.seg_row(ui, "fsr-sharp", x + 18, y, w - 36, "Nitidez", None, [(0, "Forte"), (20, "Padrão"), (50, "Suave")],
                            opts.get("fsr_sharp", 20))
        if v is not None:
            self.act(self.ctl.fusion("opt", str(v), "fsr_sharp"), "Nitidez do FSR ajustada")
        y += h + 14
        mc, gv = F.get("view"), F.get("gta_view")
        if mc and gv:
            up = fsr_on and mc[0] < gv[0] * 0.98
            now = "Agora: o Minecraft desenha em %d×%d e o GTA está em %d×%d — %s" % (
                mc[0], mc[1], gv[0], gv[1], "o FSR 1.0 está ampliando a imagem do Minecraft." if up else
                ("sem ampliação: o Minecraft já está no tamanho do GTA." if mc[0] >= gv[0] * 0.98 else "ampliação simples (FSR desligado)."))
        else:
            now = "Os tamanhos aparecem aqui quando o GTA e o Minecraft estiverem conectados (FusionBridgeSA.asi 0.6.3 em diante)."
        ui.inset(x + 18, y, w - 36, 10 + ui.measure(now, w - 64, 13)[1] + 10, C["inset"])
        y += ui.text(x + 32, y + 10, w - 64, now, C["haze"], 13) + 30
        self.box_end(ui, "b-fsr", top, y)
        y += 18

        # 3. DLSS (not possible in these two games, and why) | Frame Generation (from outside the game)
        cols = 2 if w >= 820 else 1
        gap = 16
        cw = (w - gap) * 0.42 if cols == 2 else w
        fw = (w - gap - cw) if cols == 2 else w
        hmax = max(self.heights.get("c-dlss", 200), self.heights.get("c-fg", 200)) if cols == 2 else None
        cy = y
        ui.panel(x, cy, cw, hmax or self.heights.get("c-dlss", 200))
        yy = cy + 18
        ui.text(x + 18, yy - 2, cw - 160, "DLSS", C["head"], 28, FW_BOLD, wrap=False, pixel=True)
        ui.pill(x + cw - 18, yy + 2, "Indisponível nestes jogos", "off", align="right")
        yy += 40
        yy += ui.text(x + 18, yy, cw - 36, "O DLSS precisa vir de dentro do jogo (vetores de movimento) e só existe em DirectX "
                      "11/12 e Vulkan. O GTA SA é Direct3D 9 e o Minecraft Java é OpenGL: nenhum programa liga DLSS de verdade "
                      "neles, então aqui não tem botão que não faria nada. No lugar:", C["soft"], 14) + 12
        lines = ["No Minecraft dentro do GTA: o FSR 1.0 acima."]
        if vend == "nvidia":
            lines.append("No GTA inteiro: app da NVIDIA → Gráficos → Escala de imagem (NIS) ligada, e uma resolução menor no GTA "
                         "(tela cheia).")
        elif vend == "amd":
            lines.append("No GTA inteiro: AMD Software → Jogos → Gráficos → Radeon Super Resolution (RSR), e uma resolução "
                         "menor no GTA (tela cheia).")
        lines.append("GTA em janela: o Upscale em qualquer jogo (último cartão) amplia a janela dele com FSR 1.0.")
        yy = self.bullets(ui, x + 18, yy, cw - 36, lines, 13) + 8
        self.box_end(ui, "c-dlss", cy, yy)
        fx, fy = (x + cw + gap, y) if cols == 2 else (x, cy + self.heights.get("c-dlss", 200) + gap)
        ui.panel(fx, fy, fw, hmax or self.heights.get("c-fg", 200))
        yy = fy + 18
        ls = pf.get("lossless")
        ui.text(fx + 18, yy - 2, fw - 240, "Frame Generation", C["head"], 28, FW_BOLD, wrap=False, pixel=True)
        ui.pill(fx + fw - 18, yy + 2, "Lossless Scaling encontrado" if ls else "Por fora do jogo", "ok" if ls else "info",
                align="right")
        yy += 40
        yy += ui.text(fx + 18, yy, fw - 36, "Gera quadros entre os do jogo. Nestes jogos antigos ele só vem de fora, aplicado "
                      "na janela do GTA (que já mostra o Minecraft dentro dela). Ligue só no GTA.", C["soft"], 14) + 12
        lines = []
        if ls:
            lines.append("Lossless Scaling: deixe o GTA em janela sem bordas, abra e clique em Scale; LSFG (Frame Generation) "
                         "em X2 e, se quiser ampliar também, o tipo de escala FSR.")
        else:
            lines.append("Lossless Scaling (Steam, pago): gera quadros em qualquer jogo em janela, inclusive o GTA SA. Depois de "
                         "instalado ele aparece aqui com um botão para abrir.")
        if vend == "nvidia" and PF.is_rtx_40_50(main):
            lines.append("NVIDIA Smooth Motion (RTX 40/50): app da NVIDIA → Gráficos → gta_sa.exe → Smooth Motion. O driver só "
                         "liga nos jogos que ele aceita; se não pegar no GTA SA, use o Lossless Scaling.")
        elif vend == "amd":
            lines.append("AMD Fluid Motion Frames (AFMF): AMD Software → Jogos → gta_sa.exe → Fluid Motion Frames.")
        yy = self.bullets(ui, fx + 18, yy, fw - 36, lines, 13) + 4
        if ls:
            if ui.button("open-ls", fx + 18, yy, 240, 42, "Abrir Lossless Scaling", kind="primary", icon="atalho", size=14):
                self.win.post(lambda: self.open_path(ls))
            yy += 54
        self.box_end(ui, "c-fg", fy, yy + 6)
        y = (y + max(self.heights.get("c-dlss", 200), self.heights.get("c-fg", 200))) if cols == 2 else \
            (fy + self.heights.get("c-fg", 200))
        y += 26

        # 4. any game on the PC: Magpie (FSR 1.0 over the game's window)
        y += self.h2(ui, x, y, w, "Qualquer jogo do PC", icon="desempenho", color=C["sunset"])
        return self.card_upscale(ui, x, y, w, gpus)

    # ---------------------------------------------------------------- Desempenho: upscale for any game (Magpie)
    def card_upscale(self, ui, x, y, w, gpus):
        up = self.up
        ok, run = bool(up.get("installed")), bool(up.get("running"))
        top = y
        self.box(ui, "b-perf-up", x, y, w)
        y += 18
        ui.text(x + 18, y - 2, w - 260, "Upscale em qualquer jogo", C["head"], 28, FW_BOLD, wrap=False, pixel=True)
        ui.pill(x + w - 18, y + 2, "Magpie aberto" if run else ("Pronto" if ok else "Grátis · qualquer placa"),
                "ok" if (run or ok) else "off", align="right")
        y += 40
        y += ui.text(x + 18, y, w - 36, "FSR 1.0 na janela do jogo, para todos os jogos do PC (DirectX 9 a 12, OpenGL, Vulkan, "
                     "emuladores): o jogo roda numa resolução menor e o FSR 1.0 da AMD amplia a janela dele até a tela inteira%s. "
                     "Usa o Magpie (grátis, código aberto, GPL-3.0), baixado do GitHub oficial com SHA-256 conferido e guardado "
                     "só na pasta do FusionBridge: nada é instalado no Windows." % ((" na sua %s" % gpus[0]) if gpus else ""),
                     C["soft"], 14) + 12
        y = self.bullets(ui, x + 18, y, w - 36, [
            "No jogo: modo janela ou janela sem bordas, numa resolução menor que a da tela. Metade da tela = modo Desempenho "
            "(ex.: 1720×720 num monitor 3440×1440); dois terços = Qualidade (ex.: 2293×960).",
            "Clique em Abrir upscaler, volte para o jogo e aperte Alt+Shift+A: a janela vai para a tela inteira com FSR 1.0. "
            "Alt+Shift+A de novo volta ao normal; Alt+Shift+D mostra a barra do Magpie (efeito, FPS).",
            "Não pega: tela cheia exclusiva (use janela), jogo aberto como administrador (abra o Magpie como administrador "
            "também) e jogos online cujo anti-cheat bloqueia a captura da janela.",
            "FSR 2/3 e DLSS só existem dentro dos jogos que já trazem a opção (menu de gráficos deles).",
        ], 13) + 6
        if self.sec.get("sac") in ("on", "eval"):
            y += self.gate(ui, x + 18, y, w - 36, "wait",
                           "O Controle inteligente de aplicativo está %s: o Magpie não tem assinatura digital e o Windows pode "
                           "bloquear quando você clicar em Abrir. O FusionBridge não mexe nessa configuração (veja Segurança)."
                           % ("ligado" if self.sec["sac"] == "on" else "em avaliação")) + 4
        bx = x + 18
        if ok:
            if ui.button("up-open", bx, y, 220, 44, "Abrir upscaler (FSR)", kind="primary", icon="atalho", size=14,
                         weight=FW_BOLD, enabled=not up["busy"]):
                self.win.post(self.up_launch)
            bx += 232
        if ui.button("up-get", bx, y, 200 if not ok else 150, 44,
                     "Baixando…" if up["busy"] else ("Baixar e preparar" if not ok else "Reinstalar"),
                     kind="primary" if not ok else "secondary", icon="instalar" if not ok else "recarregar",
                     size=14 if not ok else 13, enabled=not up["busy"]):
            self.up_install()
        bx += (212 if not ok else 162)
        if ui.button("up-dir", bx, y, 150, 44, "Abrir pasta", icon="pasta", size=13, enabled=ok and not up["busy"]):
            self.win.post(lambda: self.open_path(UP.magpie_dir(self.paths.local)))
        bx += 162
        if ok and bx + 130 <= x + w - 18 and ui.button("up-del", bx, y, 130, 44, "Remover", kind="danger", icon="lixo", size=13,
                                                        enabled=not up["busy"]):
            self.win.post(self.up_remove)
        y += 58
        if up.get("error"):
            y = self.note_box(ui, x + 18, y, w - 36, up["error"], "error")
        if up.get("done"):
            y = self.note_box(ui, x + 18, y, w - 36, up["done"], "done")
        for line in up["log"][-6:]:
            y += ui.text(x + 18, y, w - 36, line, C["soft"], 12, mono=True) + 2
        y += 8
        self.box_end(ui, "b-perf-up", top, y)
        return y

    def up_install(self):
        up = self.up
        if up["busy"]:
            return
        up.update(busy=True, error=None, done=None, log=[])

        def work():
            try:
                UP.install(self.paths, log=up["log"].append)
                up["installed"] = True
                up["done"] = ("Pronto. Clique em Abrir upscaler (FSR), deixe o jogo em janela na frente e aperte Alt+Shift+A. "
                              "Se o Windows avisar sobre o Magpie, é o aviso normal de programa baixado da internet.")
                FB.log("[Upscale] Magpie %s preparado em %s" % (UP.MAGPIE_VERSION, UP.magpie_dir(self.paths.local)))
            except UP.UpscaleError as e:
                up["error"] = str(e)
            except OSError as e:
                up["error"] = "Não deu para extrair o Magpie: %s" % (e.strerror or e)
            except Exception as e:
                up["error"] = "Erro inesperado: %s" % e
                self.on_error(e)
            finally:
                up["busy"] = False
                self.perf["checked"] = 0.0
                if self.win:
                    self.win.invalidate()
        threading.Thread(target=work, name="FusionBridge-Upscale", daemon=True).start()

    def up_launch(self):
        up = self.up
        try:
            p = UP.launch(self.paths.local)
            up["error"] = None
            up["done"] = ("Magpie aberto. Volte para o jogo (em janela) e aperte Alt+Shift+A." if p is not None else
                          "O Magpie já está aberto (ícone perto do relógio). No jogo, aperte Alt+Shift+A.")
            up["running"] = True
            FB.log("[Upscale] Magpie aberto" if p is not None else "[Upscale] Magpie já estava aberto")
        except UP.UpscaleError as e:
            up["error"] = str(e)
        except OSError as e:
            up["error"] = ("Não deu para abrir o Magpie: %s. Se o Controle inteligente de aplicativo do Windows bloqueou, veja "
                           "a página Segurança." % (e.strerror or e))
        self.perf["checked"] = 0.0

    def up_remove(self):
        up = self.up
        if W.message_box("Apagar a pasta do Magpie (e as configurações dele)?\n%s" % UP.magpie_dir(self.paths.local),
                         "FusionBridge", W.MB_YESNO | W.MB_ICONWARN, self.win.hwnd) != W.IDYES:
            return
        try:
            UP.remove(self.paths.local)
            up.update(installed=False, running=False, error=None, done="Magpie removido.", log=[])
            FB.log("[Upscale] Magpie removido")
        except UP.UpscaleError as e:
            up["error"] = str(e)
        except OSError as e:
            up["error"] = "Não deu para apagar a pasta (algum arquivo aberto?): %s" % (e.strerror or e)
        self.perf["checked"] = 0.0

    # ---------------------------------------------------------------- tab: Caos
    def tab_chaos(self, ui, x, y, w, S):
        F = S.get("fusion") or {}
        gta, mc = self.has(S, "gta"), self.has(S, "minecraft")
        pt = (F.get("mc") or {}).get("state") == "open"
        y += self.h2(ui, x, y, w, "No Minecraft", icon="pacote")
        y += self.blocks_grid(ui, x, y, w, MC_BLOCKS, mc or pt,
                              lambda k, t: self.act(self.ctl.mc_action(k, self.at), t + " enviado")) + 28
        gst = self.snap(S, "gta")
        y += self.h2(ui, x, y, w, "No GTA San Andreas",
                     ("módulo conectado" + (", CJ em x %.0f y %.0f" % (gst.get("x", 0), gst.get("y", 0)) if gst and gst.get("x") is not None else ""))
                     if gta else "módulo do GTA não conectado", icon="raio", color=C["sunset"])
        y += self.blocks_grid(ui, x, y, w, GTA_BLOCKS, gta,
                              lambda k, t: self.act(self.ctl.gta_action(k), t + " no GTA")) + 24
        top = y
        self.box(ui, "b-rules", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Fusão automática Minecraft → GTA",
                     "Quando algo acontece no Minecraft, o módulo repete no GTA perto do CJ (com a fusão visual ligada, as "
                     "explosões vão para o ponto exato).", icon="fusao")
        cols = 2 if w >= 700 else 1
        cw = (w - 36) / cols
        labels = [("tnt", "TNT → explosão"), ("wither", "Wither → 2 explosões + tremor"), ("lightning", "Raio → explosão"),
                  ("creeper", "Creeper → explosão")]
        for i, (k, label) in enumerate(labels):
            ck, _ = ui.checkbox("rule-" + k, x + 18 + (i % cols) * cw, y + (i // cols) * 36, cw - 16, label, self.rules[k])
            if ck:
                self.rules[k] = not self.rules[k]
                self.ctl.gta_action("rules", **{r: 1 if self.rules[r] else 0 for r in self.rules})
                self.toast("Regras enviadas")
        y += ((len(labels) + cols - 1) // cols) * 36 + 8
        ui.rect(x + 18, y, w - 36, 1, C["line"])
        y += 14
        ck, _ = ui.checkbox("gtahud", x + 18, y + 6, 300, "Corações do Minecraft no GTA", self.gta_hud_want)
        if ck:
            self.gta_hud_want = not self.gta_hud_want
            self.ctl.gta_action("hud", on=1 if self.gta_hud_want else 0)
        if ui.button("hudwin", x + 330, y, 250, 38, "Abrir HUD flutuante", icon="atalho", size=13):
            self.win.post(self.open_hud)
        y += 56
        self.box_end(ui, "b-rules", top, y)
        y += 18
        top = y
        self.box(ui, "b-feed", x, y, w, color=C["inset"])
        y += 16
        y += self.h2(ui, x + 18, y, w - 36, "O que está acontecendo", icon="diag", color=C["sunset"])
        events = S.get("hub", {}).get("events", []) or []
        if not events:
            y += ui.text(x + 18, y, w - 36, "Nada ainda.", C["haze"], 13) + 6
        for e in events[:16]:
            ui.text(x + 18, y, 64, ago(e.get("age_s")), "#7e8691", 12, mono=True, wrap=False)
            ui.text(x + 86, y, 140, e.get("from", ""), C["wait"], 12, mono=True, wrap=False)
            y += max(20, ui.text(x + 232, y, w - 250, e.get("text", ""), C["soft"], 12, mono=True)) + 5
        y += 10
        self.box_end(ui, "b-feed", top, y)
        return y

    # ---------------------------------------------------------------- tab: Instalar
    def check_row(self, ui, x, y, w, st, title, detail=None):
        """One install check: a block-style chip (✓ / ! / ×), the name and what was found."""
        chip = {"ok": ("#213318", "#a8dd86", "check"), "wait": ("#352712", "#f2c77a", "info"),
                "bad": ("#3a1d18", "#f4a08a", "x")}.get(st, ("#23282f", "#c3c8cf", None))
        ui.rect(x, y + 4, 26, 26, chip[0], 3)
        if chip[2]:
            ui.icon(chip[2], x + 5, y + 9, 16, chip[1], 2.4)
        th = ui.text(x + 40, y + 2, w - 40, title, C["paper"], 14, FW_SEMIBOLD)
        if detail:
            th += ui.text(x + 40, y + 4 + th, w - 40, detail, C["haze"], 12)
        h = max(34, th + 10)
        ui.rect(x, y + h + 4, w, 1, C["line"])
        return h + 10

    def mc_mode(self):
        """'prism' or 'launcher': what is installed (the record says), else what the player picked."""
        man = self.inst.get("manifest")
        if man:
            return man.get("McMode") or ("launcher" if man.get("LauncherProfile") else "prism")
        return self.prefs.get("mc_mode") or "prism"

    def tab_install(self, ui, x, y, w, S):
        inst = self.inst
        g, mc, man = inst.get("gta") or {}, inst.get("mc") or {}, inst.get("manifest")
        mode = self.mc_mode()
        pst = self.pr.get("st") or {}
        # where GTA is
        top = y
        self.box(ui, "b-path", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Pasta do GTA San Andreas", icon="pasta", color=C["sunset"])
        path = inst.get("gta_path") or "não encontrada: escolha o gta_sa.exe"
        ui.inset(x + 18, y, w - 250, 40, C["inset"])
        ui.text(x + 30, y, w - 274, path, C["head"] if inst.get("gta_path") else C["haze"], 13, mono=True, wrap=False, h=40)
        if ui.button("pick", x + w - 218, y, 200, 40, "Escolher gta_sa.exe…", icon="pasta", size=13):
            self.win.post(self.pick_gta)
        y += 58
        self.box_end(ui, "b-path", top, y)
        y += 18

        # the checks, one card per game
        gta_rows, mc_rows = [], []
        if inst.get("gta_path"):
            ver = g.get("version")
            gta_rows.append(("ok" if g.get("exe") else "bad", "gta_sa.exe", "encontrado" if g.get("exe") else "não está nessa pasta"))
            gta_rows.append(("ok" if ver == "1.0 US" else "wait", "Versão 1.0 US",
                             "é a 1.0 US" if ver == "1.0 US" else ("versão %s: o MoonLoader e o ASI só funcionam na 1.0 US" % ver
                                                                   if ver else "versão não reconhecida (precisa ser a 1.0 US)")))
            gta_rows.append(("ok" if g.get("moonloader") else "bad", "MoonLoader", "instalado (traz o carregador de ASI)" if g.get("moonloader")
                             else "não encontrado: instale antes, ele traz o carregador de ASI"))
            d3 = g.get("d3d9")
            gta_rows.append(("ok" if d3 in ("none", "ours") else "wait", "d3d9.dll (ReShade)",
                             {"none": "sem d3d9.dll de outro mod", "ours": "é o ReShade do FusionBridge",
                              "other": "já existe um d3d9.dll de outro mod (ENB/ReShade): marque Substituir abaixo"}.get(d3, "—")))
            if g.get("running"):
                gta_rows.append(("bad", "GTA aberto", "feche o jogo antes de instalar ou remover"))
        else:
            gta_rows.append(("", "Pasta do GTA", "escolha o gta_sa.exe acima"))
        if mode == "prism":
            inst_ok, signed = bool(pst.get("installed")), bool(pst.get("signed_in"))
            mods_ok = bool(man) and bool(pst.get("mods")) and all(pst["mods"].values())
            mc_rows.append(("ok" if inst_ok else "", "Prism Launcher %s (portátil)" % PR.PRISM_VERSION,
                            ("pronto em %s" % PR.root(self.paths.local)) if inst_ok else
                            "o Instalar baixa do GitHub oficial (SHA-256 conferido); nada é instalado no Windows"))
            mc_rows.append(("ok" if signed else ("wait" if inst_ok else ""), "Conta Microsoft com o Minecraft Java",
                            "conectada no Prism" if signed else ("clique em Entrar na conta (uma vez só)" if inst_ok else
                                                                 "depois de instalar, entre uma vez")))
            mc_rows.append(("ok" if mods_ok else "", "Minecraft 26.3 + Fabric 0.19.5 + mods da fusão",
                            "instância FusionBridge com passthrough, FusionBridgeMC e Fabric API" if mods_ok else
                            "o Instalar prepara; o Prism baixa o Minecraft, o Fabric e o Java na primeira vez"))
        else:
            mc_rows.append(("ok" if mc.get("launcher") else "bad", "Minecraft Launcher",
                            "já foi aberto" if mc.get("launcher") else "abra o launcher uma vez (falta o launcher_profiles.json)"))
            mc_rows.append(("ok" if mc.get("fabric") else "bad", "Fabric Loader 0.19.5 · 26.3",
                            "instalado" if mc.get("fabric") else "instale pelo instalador oficial (fabricmc.net)"))
            mc_rows.append(("ok" if man else "", "Mod passthrough + Fabric API + perfil",
                            ("instalados (registro de %s)" % (man.get("Version") or "?")) if man else "o Instalar coloca"))
        cols = 2 if w >= 860 else 1
        gap = 16
        cw = (w - gap) / 2 if cols == 2 else w
        hmax = max(self.heights.get("c-gta", 200), self.heights.get("c-mcin", 200))
        cy = y
        for i, (key, title, rows, art) in enumerate((("c-gta", "GTA San Andreas", gta_rows, ART_GTA),
                                                     ("c-mcin", "Minecraft Java", mc_rows, ART_MC))):
            cx = x + (i * (cw + gap) if cols == 2 else 0)
            yy0 = cy if cols == 2 else (y if i == 0 else y + self.heights.get("c-gta", 200) + gap)
            ui.panel(cx, yy0, cw, hmax if cols == 2 else self.heights.get(key, 200))
            ui.pixels(cx + 18, yy0 + 18, 2.5, art, ART_PAL)
            ui.text(cx + 58, yy0 + 14, cw - 160, title, C["head"], 26, FW_BOLD, wrap=False, pixel=True)
            ok = len([r for r in rows if r[0] == "ok"])
            ui.text(cx + cw - 128, yy0 + 22, 110, "%d de %d prontos" % (ok, len(rows)), C["haze"], 12, align="right", wrap=False)
            yy = yy0 + 62
            if key == "c-mcin":                      # how Minecraft is opened: automatic (Prism) or the official launcher
                v, _ = ui.segmented("mc-mode", cx + 18, yy - 4, [("prism", "Automático (Prism)"), ("launcher", "Minecraft Launcher")],
                                    mode)
                if v is not None:
                    if man:
                        self.toast("Para trocar, use Remover e depois Instalar de novo")
                    else:
                        self.prefs_set(mc_mode=v)
                        self.toast("Minecraft: " + ("automático (Prism)" if v == "prism" else "Minecraft Launcher oficial"))
                yy += 48
            for st, t, d in rows:
                yy += self.check_row(ui, cx + 18, yy, cw - 36, st, t, d)
            self.box_end(ui, key, yy0, yy + 6)
        y = (cy + hmax) if cols == 2 else (y + self.heights.get("c-gta", 200) + gap + self.heights.get("c-mcin", 200))
        y += 18

        # actions
        top = y
        self.box(ui, "b-act", x, y, w)
        y += 18
        ck, h = ui.checkbox("repl", x + 18, y, w - 36, "Substituir d3d9.dll/ReShade de outro mod (faz backup, e o Remover devolve)",
                            inst["replace_d3d9"])
        if ck:
            inst["replace_d3d9"] = not inst["replace_d3d9"]
        y += h + 16
        busy = inst["busy"]
        bx = x + 18
        if ui.button("install", bx, y, 200, 46, "Instalando…" if busy else ("Instalado" if man else "Instalar"), kind="primary",
                     icon="instalar", enabled=not busy and not man and bool(inst.get("gta_path")), size=15, weight=FW_BOLD):
            self.start_install()
        bx += 212
        if ui.button("remove", bx, y, 150, 46, "Remover", kind="danger", icon="lixo", enabled=not busy and bool(man), size=14):
            self.win.post(self.confirm_remove)
        bx += 162
        if mode == "prism":
            if ui.button("pr-signin2", bx, y, 190, 46, "Entrar na conta", icon="conta", size=13,
                         enabled=bool(pst.get("installed")) and not self.pr["busy"]):
                self.win.post(self.pr_sign_in)
            bx += 202
        row2 = bx + 210 + 12 + 240 > x + w - 18
        if ui.button("dl", bx, y, 210, 46, "Pasta de downloads", icon="pasta", size=13):
            self.win.post(lambda: self.open_path(self.paths.cache, make=True))
        lx, ly = (x + 18, y + 58) if row2 else (bx + 222, y)
        if ui.button("lnk", lx, ly, 240, 46, "Atalho na Área de Trabalho", icon="atalho", size=13):
            self.win.post(self.make_shortcuts)
        y = ly + 64
        if self.pr.get("error"):
            y = self.note_box(ui, x + 18, y, w - 36, self.pr["error"], "error")
        if self.pr.get("done"):
            y = self.note_box(ui, x + 18, y, w - 36, self.pr["done"], "done")
        if inst.get("error"):
            eh = ui.measure(inst["error"], w - 76, 13)[1] + 24
            ui.rect(x + 18, y, w - 36, eh, "#3a1d18", 4)
            ui.outline(x + 18, y, w - 36, eh, "#5a2a22", 4)
            ui.icon("x", x + 30, y + 12, 16, C["bad"], 2.4)
            ui.text(x + 56, y + 12, w - 86, inst["error"], C["paper"], 13)
            y += eh + 12
            if inst.get("needs_admin") and not FI.is_admin():
                if ui.button("admin", x + 18, y, 280, 42, "Reabrir como administrador", kind="amber", icon="escudo", size=14):
                    self.win.post(self.reopen_admin)
                y += 56
        if inst.get("done"):
            ui.rect(x + 18, y, w - 36, 40, "#213318", 4)
            ui.icon("check", x + 30, y + 12, 16, C["ok"], 2.4)
            ui.text(x + 56, y, w - 86, inst["done"], C["paper"], 13, wrap=False, h=40)
            y += 52
        if inst["log"]:
            y += ui.text(x + 18, y, w - 36, "O que foi feito", C["haze"], 13, FW_SEMIBOLD) + 6
            lt = y
            ui.rect(x + 18, y, w - 36, self.heights.get("inst-log", 40), C["inset"], 4)
            y += 10
            for line in inst["log"][-40:]:
                y += ui.text(x + 30, y, w - 60, line, C["soft"], 12, mono=True) + 2
            y += 10
            self.box_end(ui, "inst-log", lt, y)
            y += 8
        y += 6
        self.box_end(ui, "b-act", top, y)
        y += 18
        if mode == "prism":
            y = self.card_mc_auto(ui, x, y, w) + 18
        top = y
        self.box(ui, "b-need", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Antes de instalar", icon="info", color=C["blue"])
        steps = (("GTA San Andreas de PC na versão 1.0 US com o MoonLoader instalado.",
                  "Uma conta Microsoft que tenha o Minecraft Java. O Prism baixa o Minecraft 26.3, o Fabric e o Java sozinho "
                  "(não precisa do Minecraft Launcher nem do instalador do Fabric).",
                  "Feche o GTA antes de clicar em Instalar (os saves do GTA ganham uma cópia antes).",
                  "Depois: Entrar na conta (uma vez) e abra o GTA. O FusionBridge abre o Minecraft sozinho.")
                 if mode == "prism" else
                 ("GTA San Andreas de PC na versão 1.0 US com o MoonLoader instalado.",
                  "Minecraft Java 26.3 aberto pelo menos uma vez, e o Fabric Loader 0.19.5 para 26.3 (instalador oficial do Fabric).",
                  "Feche o GTA e o Minecraft Launcher antes de clicar em Instalar (os saves do GTA ganham uma cópia antes).",
                  "Depois: escolha o perfil 'FusionBridge - Minecraft no GTA SA' no launcher, clique em JOGAR e abra o GTA."))
        for i, line in enumerate(steps):
            ui.rect(x + 18, y + 1, 22, 22, C["dusk2"], 3)
            ui.text(x + 18, y + 1, 22, str(i + 1), C["head"], 12, FW_BOLD, align="center", wrap=False, h=22, pixel=True)
            y += max(26, ui.text(x + 52, y + 2, w - 70, line, C["paper"], 14) + 10)
        y += 8
        self.box_end(ui, "b-need", top, y)
        return y

    # ---------------------------------------------------------------- Instalar: the automatic Minecraft (Prism)
    def card_mc_auto(self, ui, x, y, w):
        self.pr_refresh()
        pst = self.pr.get("st") or {}
        top = y
        self.box(ui, "b-mcauto", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Minecraft automático",
                     "Como o SkyCraft faz no Skyrim: o FusionBridge cuida do Minecraft da fusão para você não precisar abrir, "
                     "fechar nem arrumar a janela dele.", icon="jogar")
        opts = (("auto_start", "Abrir o Minecraft sozinho quando o GTA abrir (nunca abre um segundo)"),
                ("auto_close", "Fechar o Minecraft quando o GTA fechar (só o que o FusionBridge abriu; ele salva o mundo antes)"),
                ("hide_mc", "Deixar a janela do Minecraft fora da tela, sem minimizar (minimizado ele quase para de desenhar)"))
        for k, label in opts:
            ck, h = ui.checkbox("pa-" + k, x + 18, y, w - 36, label, bool(self.prefs.get(k)))
            if ck:
                self.prefs_set(**{k: not self.prefs.get(k)})
            y += h + 10
        if self.auto.note:
            y += 4
            y += self.gate(ui, x + 18, y, w - 36, "ok", self.auto.note)
        y += 6
        bx = x + 18
        if ui.button("pr-launch2", bx, y, 210, 42, "Abrir o Minecraft agora", kind="primary", icon="jogar", size=13,
                     enabled=bool(pst.get("installed") and pst.get("signed_in")) and not self.pr["busy"]):
            self.win.post(self.pr_launch)
        bx += 222
        if ui.button("pr-dir", bx, y, 170, 42, "Pasta do Prism", icon="pasta", size=13, enabled=bool(pst.get("installed"))):
            self.win.post(lambda: self.open_path(PR.root(self.paths.local)))
        bx += 182
        if bx + 230 <= x + w - 18 and ui.button("pr-remove", bx, y, 230, 42, "Remover o Prism", kind="danger", icon="lixo", size=13,
                                                 enabled=bool(pst.get("installed")) and not self.pr["busy"] and not self.inst["busy"]):
            self.win.post(self.pr_remove)
        y += 56
        self.box_end(ui, "b-mcauto", top, y)
        return y

    def pr_sign_in(self):
        try:
            PR.sign_in(self.paths.local)
            self.pr.update(error=None, done="Prism aberto: clique em Contas (canto de cima) → Adicionar Microsoft, entre com a "
                           "conta que tem o Minecraft Java e feche o Prism. Isso é só uma vez.")
            FB.log("[Prism] aberto para entrar na conta Microsoft")
        except PR.PrismError as e:
            self.pr["error"] = str(e)
        except OSError as e:
            self.pr["error"] = "Não deu para abrir o Prism: %s" % (e.strerror or e)
        self.pr["st"] = None
        self.start_checks(force=True)

    def pr_launch(self):
        F = (self.status().get("fusion") or {}).get("mc") or {}
        if F.get("state") == "open":
            self.toast("O Minecraft já está conectado")
            return
        if FI.is_running("prismlauncher.exe"):
            self.toast("O Prism já está abrindo o Minecraft")
            return
        try:
            PR.launch(self.paths.local)
            self.auto.launched_by_hand()
            self.pr.update(error=None, done=None)
            self.toast("Abrindo o Minecraft (na primeira vez o Prism baixa o jogo: alguns minutos)")
            FB.log("[Prism] Minecraft aberto pelo botão (instância %s)" % PR.INSTANCE)
        except PR.PrismError as e:
            self.pr["error"] = str(e)
            self.toast(str(e))
        except OSError as e:
            self.pr["error"] = "Não deu para abrir o Prism: %s" % (e.strerror or e)

    def pr_remove(self):
        if W.message_box("Remover o Minecraft automático?\n\nApaga a pasta do Prism (o programa, a sua conta conectada nele e os "
                         "arquivos do Minecraft que ele baixou). O mundo da fusão é copiado para a pasta backups do "
                         "FusionBridge antes. A fusão do GTA precisa do Minecraft: depois use Remover e Instalar de novo.",
                         "FusionBridge", W.MB_YESNO | W.MB_ICONWARN, self.win.hwnd) != W.IDYES:
            return
        pr = self.pr
        pr.update(busy=True, error=None, done=None)

        def work():
            try:
                PR.remove(self.paths.local, log=self.inst["log"].append)
                pr["done"] = "Minecraft automático removido."
            except PR.PrismError as e:
                pr["error"] = str(e)
            except OSError as e:
                pr["error"] = "Não deu para remover: %s" % (e.strerror or e)
            finally:
                pr["busy"] = False
                pr["st"] = None
                self.start_checks(force=True)
        threading.Thread(target=work, name="FusionBridge-PrismRemove", daemon=True).start()

    # ---------------------------------------------------------------- page: Mods fusion
    def tab_mods(self, ui, x, y, w, S):
        y = self.card_skycraft(ui, x, y, w) + 18
        top = y
        self.box(ui, "b-moremods", x, y, w, color=C["inset"])
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Outros mods fusion",
                     "Procuramos mods que rodam um jogo de verdade dentro de outro. Publicados e com licença aberta, por "
                     "enquanto só o SkyCraft (o Minecraft no Elden Ring é só vídeo, sem download). Quando sair outro, coloque "
                     "o .json dele (fusion-mods/COMO-ADICIONAR-MOD.md) na pasta de mods fusion: ele aparece no seletor de jogos "
                     "da Ponte na hora.", icon="blocos", color=C["blue"])
        if ui.button("mods-dir", x + 18, y, 250, 40, "Pasta de mods fusion", icon="pasta", size=13):
            self.win.post(lambda: self.open_path(self.user_mods_dir(), make=True))
        n = len(self.reg.mods)
        ui.text(x + 282, y, w - 300, "%d mod%s fusion reconhecido%s" % (n, "" if n == 1 else "s", "" if n == 1 else "s"),
                C["haze"], 12, wrap=False, h=40)
        y += 56
        self.box_end(ui, "b-moremods", top, y)
        return y

    # ---------------------------------------------------------------- Mods fusion: SkyCraft (Minecraft inside Skyrim)
    def sky_rows(self, c):
        sky, game = self.sky, self.sky.get("game")
        if not c.get("exe"):
            return [("bad" if game else "", "SkyrimSE.exe", "não está nesta pasta" if game else "escolha a pasta do Skyrim acima")]
        ver, rt = c.get("version") or "?", c.get("runtime")
        rows = [("ok" if rt == "ae" else "bad", "Skyrim %s · %s" % (ver, SK.STORE_LABEL.get(c.get("store"), "")),
                 "runtime da Anniversary Edition: o que o SkyCraft precisa" if rt == "ae" else
                 ("a 1.5.97 não serve: o SkyCraft precisa da 1.6 ou 1.7 (a Steam atualiza sozinha)" if rt == "se"
                  else "versão não reconhecida")),]
        if c.get("store") == "gamepass":
            rows.append(("bad", "Skyrim do Xbox / Game Pass", "o SKSE não funciona nessa versão, então o SkyCraft também não"))
        other = ", ".join(c.get("skse_other") or [])
        rows.append(("ok" if c.get("skse") else ("wait" if sky.get("skse") else "bad"), "SKSE64 (%s)" % (c.get("skse_dll") or "skse64"),
                     "instalado" if c.get("skse") else ("escolhido abaixo: vai junto no Instalar" if sky.get("skse") else
                                                        ("tem um SKSE de outra versão (%s): baixe o da %s" % (other, ver) if other
                                                         else "falta: baixe no site do SKSE e escolha o arquivo abaixo"))))
        rows.append(("ok" if c.get("addrlib") else ("wait" if sky.get("addrlib") else "bad"),
                     "Address Library (%s)" % (c.get("addrlib_name") or "versionlib"),
                     "instalada" if c.get("addrlib") else ("escolhida abaixo: vai junto no Instalar" if sky.get("addrlib") else
                                                          "falta: baixe o \"All in one (Anniversary Edition)\" no Nexus e escolha abaixo")))
        rows.append(("ok" if c.get("skycraft") else "", "SkyCraft %s" % SK.VERSION,
                     ("instalado pelo FusionBridge" if c.get("ours") else "instalado (por outro caminho, ex.: gerenciador de mods)")
                     if c.get("skycraft") else "o Instalar baixa do GitHub oficial (SHA-256 conferido)"))
        rows.append(("ok" if c.get("prism") and c.get("signed_in") else ("wait" if c.get("prism") else ""),
                     "Minecraft do SkyCraft (Prism + conta Microsoft)",
                     "pronto, com a conta conectada" if c.get("prism") and c.get("signed_in") else
                     ("falta entrar na conta Microsoft (botão abaixo), senão a janela do Prism aparece por cima do Skyrim"
                      if c.get("prism") else "preparado logo depois do Instalar (o SkyCraft traz o próprio Prism)")))
        rows.append(("bad" if c.get("conflicts") else "ok", "Mods de câmera",
                     ("%s mexe na câmera e briga com o SkyCraft: desative" % " e ".join(c["conflicts"])) if c.get("conflicts")
                     else "nenhum dos que brigam (Improved Camera SE, SmoothCam, True Directional Movement)"))
        rows.append(("ok" if c.get("alt_start") else "wait", "Alternate Start (recomendado)",
                     "instalado" if c.get("alt_start") else
                     "sem ele, jogue de um save feito depois de Helgen: o começo do Skyrim pode travar com o SkyCraft"))
        if c.get("running"):
            rows.append(("wait", "Skyrim aberto", "feche o jogo para instalar ou remover"))
        return rows

    def sky_pick_row(self, ui, x, y, w, key, label, cur, btn, url, url_label):
        y += ui.text(x + 18, y, w - 36, label, C["paper"], 14, FW_SEMIBOLD) + 6
        bw, uw = 230, 150
        fw = w - 36 - bw - uw - 24
        ui.inset(x + 18, y, fw, 40, C["inset"])
        ui.text(x + 30, y, fw - 24, cur or "nenhum arquivo escolhido (.7z / .zip, ou o arquivo de dentro)",
                C["head"] if cur else C["haze"], 12, mono=bool(cur), wrap=False, h=40)
        if ui.button("sky-" + key, x + 18 + fw + 12, y, bw, 40, btn, icon="pasta", size=13, enabled=not self.sky["busy"]):
            self.win.post(lambda: self.sky_pick(key))
        if ui.button("sky-url-" + key, x + w - 18 - uw, y, uw, 40, url_label, kind="ghost", icon="atalho", size=13):
            self.win.post(lambda: self.open_path(url))
        return y + 54

    def card_skycraft(self, ui, x, y, w):
        sky = self.sky
        if not sky["checking"] and not sky["busy"] and time.time() - sky["checked"] > 15:
            self.sky_check()
        c = sky.get("c") or {}
        game, busy = sky.get("game"), sky["busy"]
        ready = bool(c.get("skse") and c.get("addrlib") and c.get("skycraft"))
        top = y
        self.box(ui, "b-sky", x, y, w)
        y += 18
        ui.pixels(x + 18, y, 4, ART_SKY, ART_PAL)
        ui.text(x + 82, y - 4, w - 360, "SkyCraft", C["head"], 30, FW_BOLD, wrap=False, pixel=True)
        ui.text(x + 82, y + 28, w - 360, "Minecraft Java dentro do Skyrim · chasmlol · MIT · v%s" % SK.VERSION, C["haze"], 12, wrap=False)
        if sky["checking"] and not c:
            pill = ("Verificando…", "off")
        elif not c.get("exe"):
            pill = ("Skyrim não encontrado", "wait")
        elif c.get("runtime") != "ae" or c.get("store") == "gamepass":
            pill = ("Esta versão não serve", "bad")
        elif ready:
            pill = ("Pronto para jogar", "ok") if c.get("signed_in") else ("Falta entrar na conta", "wait")
        else:
            pill = ("Pronto para instalar", "info") if (c.get("skse") or sky.get("skse")) and (c.get("addrlib") or sky.get("addrlib")) \
                else ("Falta SKSE / Address Library", "wait")
        ui.pill(x + w - 18, y + 4, pill[0], pill[1], align="right")
        y += 64
        y += ui.text(x + 18, y, w - 36, "O Skyrim desenha tudo; um Minecraft Java de verdade roda escondido ao lado e os dois "
                     "conversam por memória compartilhada: blocos, física, inventário e mobs do Minecraft dentro do mundo do "
                     "Skyrim. O FusionBridge confere as versões, instala sem sobrescrever nada (com backup dos saves), prepara "
                     "o Minecraft dele para você entrar na conta antes e abre o jogo pelo SKSE.", C["soft"], 14) + 16
        ui.inset(x + 18, y, w - 268, 40, C["inset"])
        ui.text(x + 30, y, w - 292, game or "Skyrim Special Edition não encontrado: escolha o SkyrimSE.exe", C["head"] if game else C["haze"],
                13, mono=bool(game), wrap=False, h=40)
        if ui.button("sky-pick", x + w - 238, y, 220, 40, "Escolher SkyrimSE.exe…", icon="pasta", size=13, enabled=not busy):
            self.win.post(self.sky_pick_game)
        y += 56
        for st, t, d in self.sky_rows(c):
            y += self.check_row(ui, x + 18, y, w - 36, st, t, d)
        y += 8
        ver = c.get("version") or "?"
        if c.get("exe") and c.get("runtime") == "ae" and c.get("store") != "gamepass":
            if not c.get("skse"):
                y = self.sky_pick_row(ui, x, y, w, "skse", "SKSE64 para o Skyrim %s (o arquivo baixado, ou o skse64_loader.exe "
                                      "extraído)" % ver, sky.get("skse"), "Escolher SKSE…", SK.SKSE_SITE, "Site do SKSE")
            if not c.get("addrlib"):
                y = self.sky_pick_row(ui, x, y, w, "addrlib", "Address Library: All in one (Anniversary Edition) — precisa ter o %s"
                                      % (c.get("addrlib_name") or "versionlib"), sky.get("addrlib"), "Escolher Address Library…",
                                      SK.ADDRLIB_PAGE, "Nexus")
            if c.get("skse_other") and sky.get("skse"):
                ck, h = ui.checkbox("sky-repl", x + 18, y, w - 36, "Trocar o SKSE antigo (%s) pelo escolhido: faz backup e o "
                                    "Remover devolve" % ", ".join(c["skse_other"]), sky["replace_skse"], enabled=not busy)
                if ck:
                    sky["replace_skse"] = not sky["replace_skse"]
                y += h + 12
        if self.sec.get("sac") in ("on", "eval") and c.get("exe"):
            y += self.gate(ui, x + 18, y, w - 36, "wait", "Controle inteligente de aplicativo %s: o SKSE e o SkyCraft não têm "
                           "assinatura digital, e o Windows pode bloquear o Skyrim com eles (veja Segurança)."
                           % ("ligado" if self.sec["sac"] == "on" else "em avaliação")) + 4
        if c.get("managers") and not c.get("ours"):
            y += self.gate(ui, x + 18, y, w - 36, "", "Você usa %s: dá para instalar o SkyCraft por ele (o mesmo %s) e abrir o "
                           "Skyrim por ele. Instalando por aqui, os arquivos vão direto na pasta Data do jogo, e o %s continua "
                           "vendo tudo." % (" e ".join(c["managers"]), SK.ZIP_NAME, c["managers"][0])) + 4
        # actions
        y += 4
        bx = x + 18
        ours, have = bool(c.get("ours")), bool(c.get("skycraft"))
        can_install = bool(c.get("exe")) and c.get("runtime") == "ae" and c.get("store") != "gamepass" and not have \
            and not busy and not c.get("running") and bool(c.get("skse") or sky.get("skse")) and bool(c.get("addrlib") or sky.get("addrlib"))
        if not have:
            if ui.button("sky-install", bx, y, 200, 46, "Instalando…" if busy else "Instalar SkyCraft", kind="primary",
                         icon="instalar", enabled=can_install, size=15, weight=FW_BOLD):
                self.sky_install()
            bx += 212
        if ui.button("sky-play", bx, y, 150, 46, "Jogar", kind="amber", icon="jogar", size=15, weight=FW_BOLD,
                     enabled=ready and not busy and not c.get("running")):
            self.sky_play()
        bx += 162
        if c.get("bundle") and not (c.get("prism") and c.get("stamp_ok")):
            if ui.button("sky-prep", bx, y, 210, 46, "Preparar o Minecraft", icon="pacote", size=13,
                         enabled=not busy and not c.get("mc_running")):
                self.sky_prepare()
            bx += 222
        elif c.get("prism") and not c.get("signed_in"):
            if ui.button("sky-signin", bx, y, 220, 46, "Entrar na conta Microsoft", kind="primary", icon="conta", size=13,
                         enabled=not busy):
                self.win.post(self.sky_signin)
            bx += 232
        if ours and bx + 140 <= x + w - 18:
            if ui.button("sky-remove", bx, y, 140, 46, "Remover", kind="danger", icon="lixo", size=13,
                         enabled=not busy and not c.get("running")):
                self.win.post(self.sky_remove)
            bx += 152
        if bx + 120 <= x + w - 18 and ui.button("sky-logs", bx, y, 120, 46, "Logs", icon="log", size=13,
                                                 enabled=bool(c.get("skse_log"))):
            self.win.post(lambda: self.open_path(c.get("skse_log")))
        y += 60
        ini = c.get("ini") or {}
        if have and ini.get("found"):
            ck, h = ui.checkbox("sky-start", x + 18, y, w - 36, "Abrir o Minecraft junto com o Skyrim (escondido, sem som; fecha "
                                "junto) — SkyCraft.ini", bool(ini.get("start")), enabled=not busy)
            if ck:
                self.sky_ini("bStartWithSkyrim", not ini.get("start"))
            y += h + 10
            ck, h = ui.checkbox("sky-diag", x + 18, y, w - 36, "Diagnóstico detalhado no SkyCraft.log (para relatar problemas; "
                                "várias linhas por segundo)", bool(ini.get("diag")), enabled=not busy)
            if ck:
                self.sky_ini("bDiagnostics", not ini.get("diag"))
            y += h + 14
        if sky.get("error"):
            y = self.note_box(ui, x + 18, y, w - 36, sky["error"], "error")
        if sky.get("done"):
            y = self.note_box(ui, x + 18, y, w - 36, sky["done"], "done")
        if sky["log"]:
            lt = y
            ui.rect(x + 18, y, w - 36, self.heights.get("sky-log", 40), C["inset"], 4)
            y += 10
            for line in sky["log"][-14:]:
                y += ui.text(x + 30, y, w - 60, line, C["soft"], 12, mono=True) + 2
            y += 10
            self.box_end(ui, "sky-log", lt, y)
            y += 12
        # what the logs say
        if c.get("hints") or c.get("skse_tail") or c.get("mc_tail"):
            y += ui.text(x + 18, y, w - 36, "O que os logs dizem", C["haze"], 13, FW_SEMIBOLD) + 6
            for st, txt in c.get("hints") or []:
                y += self.gate(ui, x + 18, y, w - 36, st, txt)
            for title, lines in (("SkyCraft.log", c.get("skse_tail")), ("latest.log do Minecraft", c.get("mc_tail"))):
                if not lines:
                    continue
                lt = y
                ui.rect(x + 18, y, w - 36, self.heights.get("sky-t-" + title, 40), C["inset"], 4)
                y += 8
                y += ui.text(x + 30, y, w - 60, title, C["haze"], 11, FW_SEMIBOLD) + 4
                for line in lines[-6:]:
                    y += ui.text(x + 30, y, w - 60, line, C["soft"], 11, mono=True) + 1
                y += 8
                self.box_end(ui, "sky-t-" + title, lt, y)
                y += 10
        # keys and limits
        y += 6
        y += ui.text(x + 18, y, w - 36, "Teclas no Skyrim com o SkyCraft (o resto é do Minecraft)", C["haze"], 13, FW_SEMIBOLD) + 8
        cols = 2 if w >= 820 else 1
        colw = (w - 36) / cols
        for i, (k, what) in enumerate(SKY_KEYS):
            kx = x + 18 + (i % cols) * colw
            ky = y + (i // cols) * 38
            ui.keycap(kx, ky, k, min_w=70)
            ui.text(kx + 82, ky + 4, colw - 92, what, C["paper"], 13, wrap=False)
        y += ((len(SKY_KEYS) + cols - 1) // cols) * 38 + 8
        y = self.bullets(ui, x + 18, y, w - 36, [
            "Com o Minecraft no controle, o inventário, as magias e as perícias do Skyrim não abrem.",
            "Os golpes do Minecraft só acertam pessoas e bichos do Skyrim, não objetos. Fechar o Minecraft devolve o "
            "controle ao Skyrim.",
            "Todos os interiores do Skyrim dividem um mundo do Minecraft. Reserve uns 3 GB de RAM a mais.",
        ], 13) + 4
        self.box_end(ui, "b-sky", top, y)
        return y

    def sky_load(self):
        try:
            with open(self.sky_file, encoding="utf-8") as f:
                data = json.load(f)
            for k in ("game", "skse", "addrlib"):
                v = data.get(k) if isinstance(data, dict) else None
                if isinstance(v, str) and len(v) < 600 and os.path.exists(v):
                    self.sky[k] = v
        except (OSError, ValueError):
            pass

    def sky_save(self):
        try:
            os.makedirs(os.path.dirname(self.sky_file), exist_ok=True)
            tmp = self.sky_file + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({k: self.sky.get(k) for k in ("game", "skse", "addrlib")}, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.sky_file)
        except OSError as e:
            FB.log("[SkyCraft] não deu para salvar as escolhas: %s" % e)

    def sky_set_game(self, path):
        sky = self.sky
        if SK._same(path, sky.get("game")):
            return
        sky.update(game=path, c=None, error=None, done=None, checked=0.0)
        self.sky_save()

    def sky_check(self):
        sky = self.sky
        sky["checking"] = True
        games = list(self.games["list"] or [])

        def work():
            try:
                if not sky.get("game"):
                    found = SK.find_skyrim(games)
                    if found:
                        sky["game"] = found
                        self.sky_save()
                sky["c"] = SK.check(sky.get("game"), self.paths.local)
                if self.sec.get("sac") is None:
                    self.sec["sac"] = FI.sac_state()
            except Exception as e:
                self.on_error(e)
            finally:
                sky["checked"], sky["checking"] = time.time(), False
                if self.win:
                    self.win.invalidate()
        if self.games["list"] is None:
            self.scan_games()
        threading.Thread(target=work, name="FusionBridge-SkyCraft", daemon=True).start()

    def sky_pick_game(self):
        p = W.open_file_dialog(self.win.hwnd, "Escolha o SkyrimSE.exe do Skyrim Special Edition",
                               [("SkyrimSE.exe", "SkyrimSE.exe;SkyrimVR.exe;TESV.exe"), ("Programas (*.exe)", "*.exe")],
                               self.sky.get("game"))
        if not p:
            return
        name = os.path.basename(p).lower()
        if name != "skyrimse.exe":
            W.message_box("O SkyCraft só funciona no Skyrim Special Edition / Anniversary Edition (SkyrimSE.exe). O Skyrim VR e o "
                          "Skyrim de 2011 (TESV.exe) não servem.", "FusionBridge", W.MB_OK | W.MB_ICONWARN, self.win.hwnd)
            return
        self.sky_set_game(os.path.dirname(p))

    def sky_pick(self, key):
        sky = self.sky
        cur = sky.get(key)
        start = os.path.dirname(cur) if cur else os.path.join(os.path.expanduser("~"), "Downloads")
        if key == "skse":
            p = W.open_file_dialog(self.win.hwnd, "Escolha o SKSE64 baixado (.7z/.zip) ou o skse64_loader.exe extraído",
                                   [("SKSE64 (.7z, .zip, skse64_loader.exe)", "*.7z;*.zip;*.rar;skse64_loader.exe")], start)
        else:
            p = W.open_file_dialog(self.win.hwnd, "Escolha a Address Library baixada (.zip/.7z) ou o versionlib .bin",
                                   [("Address Library (.zip, .7z, .bin)", "*.zip;*.7z;*.rar;versionlib-*.bin")], start)
        if p:
            sky[key] = p
            sky["error"] = sky["done"] = None
            self.sky_save()

    def sky_work(self, name, fn):
        """Runs fn(log) on a worker thread with the card busy; fn returns the 'done' text."""
        sky = self.sky
        if sky["busy"]:
            return
        sky.update(busy=True, error=None, done=None, log=[])

        def work():
            try:
                sky["done"] = fn(sky["log"].append)
            except (SK.SkyError, FI.InstallError) as e:
                sky["error"] = str(e)
            except OSError as e:
                sky["error"] = "Erro do Windows: %s" % (e.strerror or e)
            except Exception as e:
                sky["error"] = "Erro inesperado: %s" % e
                self.on_error(e)
            finally:
                sky["busy"] = False
                sky["checked"] = 0.0
                if self.win:
                    self.win.invalidate()
        threading.Thread(target=work, name="FusionBridge-SkyCraft-" + name, daemon=True).start()

    def sky_install(self):
        sky = self.sky
        game, skse, addrlib, repl = sky.get("game"), sky.get("skse"), sky.get("addrlib"), sky["replace_skse"]
        c = sky.get("c") or {}
        skse = None if c.get("skse") else skse
        addrlib = None if c.get("addrlib") else addrlib

        def fn(log):
            zpath = FI.get_dependency("skycraft", self.paths, log)
            SK.install(game, self.paths.local, skycraft_zip=zpath, skse=skse, addrlib=addrlib, log=log, replace_skse=repl)
            try:
                SK.prepare_minecraft(game, self.paths.local, log)
            except SK.SkyError as e:
                log("Minecraft do SkyCraft: %s (o próprio SkyCraft prepara quando o Skyrim abrir)" % e)
            sky["skse"] = sky["addrlib"] = None
            self.sky_save()
            FB.log("[SkyCraft] instalado em %s" % game)
            if SK.signed_in(self.paths.local):
                return "SkyCraft instalado. Clique em Jogar (o Minecraft abre escondido junto com o Skyrim)."
            return "SkyCraft instalado. Agora clique em Entrar na conta Microsoft (uma vez) e depois em Jogar."
        self.sky_work("Install", fn)

    def sky_play(self):
        game = self.sky.get("game")
        c = self.sky.get("c") or {}

        def fn(log):
            SK.launch(game, log=log)
            FB.log("[SkyCraft] Skyrim aberto pelo SKSE")
            tip = "" if c.get("alt_start") else " Sem o Alternate Start, carregue um save feito depois de Helgen."
            if (c.get("ini") or {}).get("start") and not c.get("signed_in"):
                tip += " Na primeira vez o Prism pede a conta Microsoft: Alt+Tab até ele, entre e volte."
            return "Skyrim abrindo pelo SKSE. O Minecraft abre escondido sozinho e avisa no canto da tela quando estiver pronto." + tip
        self.sky_work("Play", fn)

    def sky_prepare(self):
        game = self.sky.get("game")

        def fn(log):
            r = SK.prepare_minecraft(game, self.paths.local, log)
            return ("Minecraft do SkyCraft já estava pronto." if r == "já preparado" else
                    "Minecraft do SkyCraft pronto. Agora clique em Entrar na conta Microsoft (uma vez).")
        self.sky_work("Prepare", fn)

    def sky_signin(self):
        sky = self.sky
        try:
            SK.sign_in(self.paths.local)
            sky.update(error=None, done="Prism do SkyCraft aberto: Contas (canto de cima) → Adicionar Microsoft, entre com a "
                       "conta que tem o Minecraft Java e feche o Prism. Isso é só uma vez.")
            FB.log("[SkyCraft] Prism aberto para entrar na conta")
        except SK.SkyError as e:
            sky["error"] = str(e)
        except OSError as e:
            sky["error"] = "Não deu para abrir o Prism do SkyCraft: %s" % (e.strerror or e)
        sky["checked"] = 0.0

    def sky_remove(self):
        if W.message_box("Remover o SkyCraft deste Skyrim?\n\nSai só o que o FusionBridge colocou (e só arquivos que não "
                         "mudaram); um SKSE antigo trocado volta para o lugar. A sua conta Microsoft e o mundo do SkyCraft "
                         "ficam em %s, e o backup dos saves continua guardado." % SK.mc_dir(self.paths.local), "FusionBridge",
                         W.MB_YESNO | W.MB_ICONWARN, self.win.hwnd) != W.IDYES:
            return

        def fn(log):
            r = SK.remove(self.paths.local, log=log)
            FB.log("[SkyCraft] removido")
            return "SkyCraft removido." if not r["kept"] else "Removido, menos os arquivos que você alterou (veja acima)."
        self.sky_work("Remove", fn)

    def sky_ini(self, key, on):
        sky = self.sky
        try:
            SK.set_ini(sky.get("game"), "Debug" if key == "bDiagnostics" else "Minecraft", key, "1" if on else "0",
                       self.paths.local)
            self.toast("SkyCraft.ini: %s %s" % (key, "ligado" if on else "desligado"))
        except (SK.SkyError, OSError) as e:
            sky["error"] = "Não deu para mudar o SkyCraft.ini: %s" % e
        sky["checked"] = 0.0

    # ---------------------------------------------------------------- tab: Seguranca
    def tab_security(self, ui, x, y, w, S):
        sec = self.sec
        top = y
        self.box(ui, "b-sac", x, y, w)
        y += 18
        st, label = SAC_TEXT.get(sec.get("sac") or "unknown", ("", "—"))
        y += self.h2(ui, x + 18, y, w - 36, "Controle inteligente de aplicativo (Smart App Control)", icon="escudo")
        y += self.gate(ui, x + 18, y, w - 36, st, "Estado: " + label)
        y += 6
        y += ui.text(x + 18, y, w - 36, "Este app", C["haze"], 13, FW_SEMIBOLD) + 6
        sigs = sec.get("app_sigs") or []
        if sigs:
            good = [n for n, sig in sigs if sig == "assinado"]
            unknown = [n for n, sig in sigs if sig == "desconhecido"]
            y += self.gate(ui, x + 18, y, w - 36, "ok" if len(good) == len(sigs) else ("wait" if len(good) + len(unknown) == len(sigs) else "bad"),
                           "%d de %d arquivos de código do app assinados (Python Software Foundation / Microsoft), "
                           "verificados agora pelo Windows" % (len(good), len(sigs)))
            for name, sig in sigs:
                if sig != "assinado":
                    y += self.gate(ui, x + 18, y, w - 36, "wait" if sig == "desconhecido" else "bad",
                                   "%s: %s" % (name, {"sem assinatura": "SEM assinatura", "nao confiavel": "assinatura não confiável",
                                                      "ausente": "não encontrado", "desconhecido": "não deu para verificar"}.get(sig, sig)))
        else:
            y += ui.text(x + 18, y, w - 36, "verificando…", C["haze"], 13) + 6
        y += 10
        self.box_end(ui, "b-sac", top, y)
        y += 18
        top = y
        self.box(ui, "b-mods", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Arquivos do GTA",
                     "Os mods do GTA (MoonLoader, carregador de ASI, ReShade e o FusionBridgeSA.asi) são DLLs que entram dentro do "
                     "gta_sa.exe. Com o Controle inteligente LIGADO, o Windows pode impedir que DLLs sem assinatura reconhecida "
                     "carreguem no jogo. Se for o d3d9.dll (ReShade) ou o carregador de ASI, o GTA nem abre; se for um .asi, o "
                     "jogo abre sem aquele mod. Isso vale para quase todo mod de GTA SA e não dá para resolver de dentro do app.",
                     icon="pasta", color=C["sunset"])
        sigs = sec.get("sigs") or []
        if not self.inst.get("gta_path"):
            y += ui.text(x + 18, y, w - 36, "Escolha a pasta do GTA em Instalar para conferir os arquivos.", C["haze"], 13) + 6
        for name, what, sig in sigs:
            y += self.gate(ui, x + 18, y, w - 36, "ok" if sig == "assinado" else ("wait" if sig == "desconhecido" else "bad"),
                           "%s (%s): %s" % (name, what, {"assinado": "assinado", "sem assinatura": "sem assinatura",
                                                         "nao confiavel": "assinatura não confiável",
                                                         "desconhecido": "não deu para verificar"}.get(sig, sig)))
        y += 8
        busy = sec.get("busy")
        if ui.button("scan", x + 18, y, 290, 42, "Procurando…" if busy else "Procurar bloqueios do Windows", icon="busca",
                     enabled=not busy, size=13):
            self.start_scan()
        if ui.button("wsec", x + 320, y, 260, 42, "Abrir Segurança do Windows", icon="escudo", size=13):
            self.win.post(lambda: self.open_path("windowsdefender://appbrowser"))
        y += 58
        if sec.get("blocks_err"):
            y += ui.text(x + 18, y, w - 36, sec["blocks_err"] + ". Você também pode olhar no Visualizador de Eventos: "
                         "Logs de Aplicativos e Serviços > Microsoft > Windows > CodeIntegrity > Operational.", C["wait"], 13) + 6
        elif sec.get("blocks") is not None:
            if not sec["blocks"]:
                y += self.gate(ui, x + 18, y, w - 36, "ok", "Nenhum bloqueio recente ligado ao GTA, ao ReShade ou ao FusionBridge no log do Windows.")
            for b in sec["blocks"][:20]:
                audit = str(b.get("event")) in ("3034", "3076")      # audit/evaluation: it would be blocked, it loaded
                y += self.gate(ui, x + 18, y, w - 36, "wait" if audit else "bad", "%s — %s: %s (processo %s, evento %s)" % (
                    b.get("time"), "seria bloqueado (só avaliação, o arquivo carregou)" if audit else "bloqueado",
                    os.path.basename(b.get("file") or "?"), os.path.basename(b.get("process") or "?"), b.get("event")))
        y += 10
        self.box_end(ui, "b-mods", top, y)
        y += 18
        top = y
        self.box(ui, "b-what", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Se o Windows bloquear os mods do GTA", icon="info", color=C["blue"])
        for line in ("O app FusionBridge não precisa de nada: ele já é aceito pelo Controle inteligente.",
                     "Para os mods do GTA, só há dois caminhos que a Microsoft documenta: os arquivos serem assinados por um "
                     "certificado reconhecido (depende de quem fez cada mod), ou desligar o Controle inteligente em Segurança do "
                     "Windows > Controle de aplicativos e do navegador. A escolha é sua; o FusionBridge não mexe nessa configuração.",
                     "Com o Controle inteligente em 'Em avaliação', nada é bloqueado ainda: o Windows só observa."):
            ui.rect(x + 22, y + 8, 6, 6, C["grass"])
            y += ui.text(x + 40, y, w - 58, line, C["paper"], 14) + 8
        y += 8
        self.box_end(ui, "b-what", top, y)
        return y

    # ---------------------------------------------------------------- tab: Diagnostico
    def tab_diag(self, ui, x, y, w, S):
        top = y
        self.box(ui, "b-cli", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Conexões", icon="ponte")
        cols = [("Cliente", 0.30), ("Lado", 0.22), ("Tempo", 0.16), ("Msgs", 0.16), ("Perdidas", 0.16)]
        ui.rect(x + 18, y - 4, w - 36, 30, C["inset"], 3)
        cx = x + 30
        for name, frac in cols:
            ui.text(cx, y - 4, (w - 60) * frac, name, C["haze"], 12, FW_SEMIBOLD, wrap=False, h=30)
            cx += (w - 60) * frac
        y += 32
        clients = self.clients(S)
        if not clients:
            y += ui.text(x + 30, y + 4, w - 60, "Ninguém conectado.", C["haze"], 13) + 12
        for c in clients:
            vals = [c.get("name", ""), c.get("side") or c.get("role") or "", ago(c.get("secs")), str(c.get("rx", "-")), str(c.get("dropped", "-"))]
            cx = x + 30
            for i, ((name, frac), v) in enumerate(zip(cols, vals)):
                ui.text(cx, y, (w - 60) * frac - 6, v, C["paper"], 13, mono=i > 1, wrap=False, h=30)
                cx += (w - 60) * frac
            ui.rect(x + 18, y + 30, w - 36, 1, C["line"])
            y += 32
        y += 10
        self.box_end(ui, "b-cli", top, y)
        y += 18
        top = y
        self.box(ui, "b-gmod", x, y, w)
        y += 18
        y += self.h2(ui, x + 18, y, w - 36, "Módulo do GTA SA", icon="raio", color=C["sunset"])
        import json
        diag = None
        for d in S.get("hub", {}).get("diags", []) or []:
            if d.get("of") == "gta":
                try:
                    diag = json.loads(d.get("diag") or "{}")
                except ValueError:
                    pass
        gta = self.has(S, "gta")
        gst = self.snap(S, "gta")
        y += self.gate(ui, x + 18, y, w - 36, "ok" if gta else ("bad" if diag else ""),
                       ("módulo conectado" + (" (v%s)" % diag.get("mod") if diag and diag.get("mod") else "")) if gta
                       else ("módulo já conectou antes, agora desconectado" if diag else "módulo ainda não conectou"))
        y += self.gate(ui, x + 18, y, w - 36, "ok" if gst else "wait", "posição e vida do CJ chegando" if gst else "esperando você entrar no jogo")
        if diag and diag.get("note"):
            y += ui.text(x + 18, y, w - 36, diag["note"], C["haze"], 13) + 6
        if ui.button("gdiag", x + 18, y + 6, 220, 40, "Pedir diagnóstico", icon="diag", size=13):
            self.act(self.ctl.gta_action("diag"), "Pedido enviado")
        y += 62
        self.box_end(ui, "b-gmod", top, y)
        return y

    # ---------------------------------------------------------------- tab: Log
    def tab_log(self, ui, x, y, w, S):
        lines = S.get("log") or []
        top = y
        self.box(ui, "b-log", x, y, w, color=C["inset"], radius=4)
        y += 14
        if not lines:
            y += ui.text(x + 16, y, w - 32, "Nada registrado ainda.", C["haze"], 12, mono=True) + 2
        for line in lines:
            col = C["bad"] if ("erro" in line.lower() or "falh" in line.lower()) else C["soft"]
            y += ui.text(x + 16, y, w - 32, line, col, 12, mono=True) + 1
        y += 14
        self.box_end(ui, "b-log", top, y)
        if self.follow_log:
            key = "tab-log"
            view = ui.clip[3] if ui.clip else 400
            ui.win.scroll[key] = min(0.0, view - self.content_h.get(key, 0))
        return y

    # ---------------------------------------------------------------- actions (run from the message loop)
    def pick_gta(self):
        start = self.inst.get("gta_path") or os.environ.get("ProgramFiles(x86)") or None
        p = W.open_file_dialog(self.win.hwnd, "Escolha o gta_sa.exe do GTA San Andreas",
                               [("gta_sa.exe", "gta_sa.exe"), ("Programas (*.exe)", "*.exe")], start)
        if p:
            if os.path.basename(p).lower() != "gta_sa.exe":
                W.message_box("Escolha o arquivo gta_sa.exe (o executável do GTA San Andreas).", "FusionBridge",
                              W.MB_OK | W.MB_ICONWARN, self.win.hwnd)
                return
            self.set_gta_path(os.path.dirname(p))

    def set_gta_path(self, path):
        self.inst["gta_path"] = path
        self.inst["error"] = self.inst["done"] = None
        self.choices.gta_path = path                     # kept for the next start (and the elevated copy)
        self.choices.save()
        self.start_checks(force=True)

    def start_install(self):
        inst = self.inst
        if inst["busy"]:
            return
        inst.update(busy=True, error=None, done=None, log=[], needs_admin=False)
        gp, repl = inst.get("gta_path"), inst["replace_d3d9"]
        mode = self.mc_mode()

        def work():
            try:
                if mode == "prism":
                    g = FI.check_gta(gp, self.paths)         # the GTA side first: no Prism download for nothing
                    if not g.get("exe"):
                        raise FI.InstallError("gta_sa.exe nao foi encontrado em %s" % gp)
                    if not g.get("moonloader"):
                        raise FI.InstallError("MoonLoader nao encontrado nesta pasta do GTA (falta a pasta moonloader ou o "
                                              "MoonLoader.asi). Instale o MoonLoader primeiro e clique em Instalar de novo.")
                    PR.install(self.paths, log=inst["log"].append)
                    FI.install(gp, repl, log=inst["log"].append, paths=self.paths, mc_mode="prism",
                               mc_game=PR.game_dir(self.paths.local))
                    inst["done"] = ("Instalado. Clique em Entrar na conta (uma vez) e abra o GTA: o FusionBridge abre o "
                                    "Minecraft sozinho." if not PR.signed_in(self.paths.local) else
                                    "Instalado. Abra o GTA: o FusionBridge abre o Minecraft sozinho.")
                else:
                    FI.install(gp, repl, log=inst["log"].append, paths=self.paths)
                    inst["done"] = "Instalado. Abra o Minecraft pelo perfil FusionBridge e depois o GTA."
                FB.log("[App] instalacao concluida em %s (Minecraft: %s)" % (gp, "automático" if mode == "prism" else "launcher"))
            except PR.PrismError as e:
                inst["error"] = str(e)
            except FI.InstallError as e:
                inst["error"] = str(e)
                inst["needs_admin"] = e.needs_admin
            except Exception as e:
                inst["error"] = "Erro inesperado: %s" % e
                self.on_error(e)
            finally:
                inst["busy"] = False
                self.pr["st"] = None
                self.start_checks(force=True)
        threading.Thread(target=work, name="FusionBridge-Install", daemon=True).start()

    def confirm_remove(self):
        what = "os mods do Minecraft automático" if self.mc_mode() == "prism" else "o perfil do Minecraft"
        if W.message_box("Remover a fusão do GTA e %s?\n\nSó sai o que o FusionBridge colocou; os backups "
                         "voltam para o lugar. Seus saves e mundos normais não são tocados." % what, "FusionBridge",
                         W.MB_YESNO | W.MB_ICONWARN, self.win.hwnd) != W.IDYES:
            return
        inst = self.inst
        inst.update(busy=True, error=None, done=None, log=[], needs_admin=False)

        def work():
            try:
                FI.remove(log=inst["log"].append, paths=self.paths)
                inst["done"] = "Removido."
            except FI.InstallError as e:
                inst["error"] = str(e)
                inst["needs_admin"] = e.needs_admin
            except Exception as e:
                inst["error"] = "Erro inesperado: %s" % e
                self.on_error(e)
            finally:
                inst["busy"] = False
                self.start_checks(force=True)
        threading.Thread(target=work, name="FusionBridge-Remove", daemon=True).start()

    def reopen_admin(self):
        exe = os.path.join(self.paths.app_root, "FusionBridge.exe")
        if FI.relaunch_as_admin(exe, self.paths.app_root, self.paths):
            self.win.close()          # the elevated copy waits for this window to close, then opens
        else:
            self.toast("O Windows não abriu como administrador (pedido cancelado?)")

    def make_shortcuts(self):
        try:
            made = FI.create_app_shortcuts(self.paths)
            self.toast("Atalho criado: Área de Trabalho e menu Iniciar" if made else "Não achei a Área de Trabalho")
        except FI.InstallError as e:
            self.toast(str(e))
        except Exception as e:
            self.on_error(e)
            self.toast("Não deu para criar o atalho")

    def start_scan(self):
        sec = self.sec
        if sec.get("busy"):
            return
        sec.update(busy=True, blocks=None, blocks_err=None)

        def work():
            try:
                blocks, err = FI.code_integrity_blocks(self.inst.get("gta_path"))
                sec["blocks"], sec["blocks_err"] = blocks, err
            except Exception as e:
                sec["blocks_err"] = "não consegui ler o log (%s)" % e
            finally:
                sec["busy"] = False
        threading.Thread(target=work, name="FusionBridge-CI", daemon=True).start()

    def open_path(self, target, make=False):
        try:
            if make:
                os.makedirs(target, exist_ok=True)
            os.startfile(target)
        except Exception as e:
            self.toast("Não deu para abrir: %s" % e)

    # ---------------------------------------------------------------- floating hearts
    HEART = (".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X...")

    def open_hud(self):
        if self.hud is not None and not self.hud.closed:
            W.user32.SetForegroundWindow(self.hud.hwnd)
            return

        def closed():
            self.hud = None
            return True
        sw = W.user32.GetSystemMetrics(0)
        self.hud = W.Window("FusionBridge - corações", 380, 92, self.build_hud, class_name="FusionBridgeHud", icon=self.icon,
                            min_size=(300, 80), timer_ms=500, ex_style=W.WS_EX_TOPMOST | W.WS_EX_TOOLWINDOW,
                            style=W.WS_POPUP | W.WS_CLIPCHILDREN, on_close=closed, drag_anywhere=True,
                            x=max(0, sw - 420), y=60)
        self.hud.show()

    def build_hud(self, ui):
        S = self.status()
        gst = self.snap(S, "gta") or {}
        hp = gst.get("health")
        half = max(0, min(20, int((hp if hp is not None else 100) / 5.0 + 0.5)))
        ui.rect(0, 0, ui.w, ui.h, C["night"])
        ui.outline(0, 0, ui.w, ui.h, C["line2"], 6)
        ui.rect(6, 0, ui.w - 12, 2, C["grass"], 1)
        ui.text(12, 6, ui.w - 60, "CJ  %s" % (hp if hp is not None else "—"), C["soft"], 17, FW_SEMIBOLD, wrap=False, pixel=True)
        if ui.button("x", ui.w - 36, 6, 28, 26, "", kind="ghost", icon="x"):
            self.hud.post(self.hud.close)
        cell = 3
        hw = 7 * cell + 2 * cell
        x0 = (ui.w - 10 * (hw + cell)) / 2
        for i in range(10):
            st = 2 if half >= (i + 1) * 2 else (1 if half == i * 2 + 1 else 0)
            hx, hy = x0 + i * (hw + cell), 40
            ui.rect(hx - cell, hy - cell, 9 * cell, 8 * cell, "#000000", 2, 160)
            for r, row in enumerate(self.HEART):
                for c, ch in enumerate(row):
                    if ch == "X":
                        col = "#e81818" if st == 2 or (st == 1 and c <= 2) else "#3a1414"
                        ui.rect(hx + c * cell, hy + r * cell, cell, cell, col)
        ui.dot(ui.w - 16, 62, "ok" if self.has(S, "gta") else "wait", 4)


def main():
    W.init_process()
    elevated = sys._xoptions.get("fb") == "elevated"     # FusionBridge.exe -X fb=elevated (see fb_installer.relaunch_as_admin)
    if elevated:
        # the user's own folders (the administrator who approved the UAC prompt may be another account)
        for opt, env in (("fblocal", "LOCALAPPDATA"), ("fbappdata", "APPDATA")):
            v = sys._xoptions.get(opt)
            if isinstance(v, str) and os.path.isabs(v) and os.path.isdir(v):
                os.environ[env] = v
    if not W.single_instance("Local\\FusionBridgePC", "FusionBridgeMain", wait_s=15.0 if elevated else 0.0):
        return
    App().run()


if __name__ == "__main__":
    main()
