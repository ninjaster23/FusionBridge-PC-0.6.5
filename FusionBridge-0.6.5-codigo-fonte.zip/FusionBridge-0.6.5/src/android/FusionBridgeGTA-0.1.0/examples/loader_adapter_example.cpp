// Example only: wire these callbacks to the GTA SA Android loader/SDK you choose.
// This file deliberately contains NO hard-coded GTA addresses and NO copyrighted game code.
#include "fusionbridge_gta.h"
#include <cstdio>

static void log_line(const char* s) { std::printf("[FBGTA] %s\n", s ? s : ""); }

static int get_player(float* x,float* y,float* z,float* yaw,float* hp,int* in_car,float* car_hp) {
    // TODO: read CJ state through your loader SDK on the GTA main thread.
    (void)x;(void)y;(void)z;(void)yaw;(void)hp;(void)in_car;(void)car_hp;
    return 0;
}

static int spawn_entity(const char* kind, long long id, float x,float y,float z) {
    // TODO examples:
    //   minecraft:wither  -> custom model/actor proxy + boss behavior
    //   minecraft:creeper -> custom model/actor proxy + timed explosion
    (void)kind;(void)id;(void)x;(void)y;(void)z;
    return 0;
}
static void move_entity(long long,float,float,float) {}
static void remove_entity(long long) {}
static void explode(float,float,float,float,float) {}
static int place_block(const char*,long long,float,float,float) { return 0; }
static void remove_block(long long) {}

void install_fusionbridge() {
    FusionBridgeGtaApi api{};
    api.abi_version = 1;
    api.log = log_line;
    api.get_player_state = get_player;
    api.spawn_proxy_entity = reinterpret_cast<int(*)(const char*,int64_t,float,float,float)>(spawn_entity);
    api.move_proxy_entity = reinterpret_cast<void(*)(int64_t,float,float,float)>(move_entity);
    api.remove_proxy_entity = reinterpret_cast<void(*)(int64_t)>(remove_entity);
    api.create_explosion = explode;
    api.place_proxy_block = reinterpret_cast<int(*)(const char*,int64_t,float,float,float)>(place_block);
    api.remove_proxy_block = reinterpret_cast<void(*)(int64_t)>(remove_block);
    FusionBridgeGTA_SetApi(&api);
    FusionBridgeGTA_Init();
}

// Call FusionBridgeGTA_Tick() from the loader's per-frame/main-thread callback.
// Call FusionBridgeGTA_Shutdown() during unload.
