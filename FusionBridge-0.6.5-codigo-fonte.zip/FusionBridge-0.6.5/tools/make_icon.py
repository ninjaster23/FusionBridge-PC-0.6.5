#!/usr/bin/env python3
"""Generates app/assets/FusionBridge.ico (16/24/32/48/64/128/256 px, PNG entries) and FusionBridge-256.png: the logo
from app/fb_art.py (a green pixel F on a suspension bridge at sunset; the same art as the sidebar). Pure Python (zlib),
no image libraries."""
import os, struct, sys, zlib

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app"))
import fb_art  # noqa: E402  (the logo, drawn in code)


def _rgba(h):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)


ARTS = {n: fb_art.art(n) for n in (16, 32)}


def png(size):
    base = 16 if size in (16, 24, 48) else 32
    art, pal = ARTS[base]
    rows = []
    for y in range(size):
        sy = y * base // size
        row = bytearray([0])
        for x in range(size):
            ch = art[sy][x * base // size]
            row += bytes(_rgba(pal[ch]) if ch != "." else (0, 0, 0, 0))
        rows.append(bytes(row))
    raw = zlib.compress(b"".join(rows), 9)

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)) + chunk(b"IDAT", raw) + chunk(b"IEND", b"")


def main():
    sizes = [16, 24, 32, 48, 64, 128, 256]
    images = [png(s) for s in sizes]
    head = struct.pack("<HHH", 0, 1, len(sizes))
    offset = 6 + 16 * len(sizes)
    entries, data = b"", b""
    for s, img in zip(sizes, images):
        entries += struct.pack("<BBBBHHII", s % 256, s % 256, 0, 0, 1, 32, len(img), offset + len(data))
        data += img
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "assets", "FusionBridge.ico")
    with open(out, "wb") as f:
        f.write(head + entries + data)
    with open(os.path.join(os.path.dirname(out), "FusionBridge-256.png"), "wb") as f:
        f.write(images[-1])
    print("icone:", os.path.abspath(out))


if __name__ == "__main__":
    main()
