// Native test of the hang watchdog (Windows or Wine, 32-bit): the main thread beats, then "hangs" in Sleep for 11 s;
// the watchdog must report the stall with the stage, where the thread is and its stack, then see it come back.
// Build: i686-w64-mingw32-g++ -std=c++17 -O2 -static -I.. test_watchdog.cpp ../watchdog.cpp ../sa.cpp -o test_watchdog.exe
#include "../watchdog.h"
#include <windows.h>
#include <cstdio>
#include <cstring>
#include <string>

static CRITICAL_SECTION g_cs;
static std::string g_out;

static void log_line(const char *line)
{
	EnterCriticalSection(&g_cs);
	g_out += line;
	g_out += '\n';
	LeaveCriticalSection(&g_cs);
	printf("  | %s\n", line);
	fflush(stdout);
}

__attribute__((noinline)) static void stuck_frame()
{
	Sleep(11000);
}

static int g_pass = 0, g_fail = 0;
static void check(const char *name, bool ok)
{
	printf("%s %s\n", ok ? "PASS" : "FAIL", name);
	(ok ? g_pass : g_fail)++;
}

int main()
{
	InitializeCriticalSection(&g_cs);
	watchdog::start(GetModuleHandleW(nullptr), &log_line);
	for (int i = 0; i < 30; ++i)
	{
		watchdog::beat();
		Sleep(50);
	}
	check("no report while frames keep coming", g_out.empty());
	watchdog::stage(watchdog::kUpload);
	stuck_frame();
	watchdog::stage(watchdog::kIdle);
	watchdog::beat();
	Sleep(2500);
	EnterCriticalSection(&g_cs);
	const std::string out = g_out;
	LeaveCriticalSection(&g_cs);
	check("the stall is reported", out.find("VIGIA: o GTA esta ha") != std::string::npos);
	check("... with what the ASI was doing", out.find("copiando a imagem do Minecraft") != std::string::npos);
	check("... where the thread is", out.find("parado em ") != std::string::npos);
	check("... and the stack, with the stuck function's caller in this exe", out.find("pilha +") != std::string::npos &&
		out.find("gta_sa.exe+0x") != std::string::npos);
	check("... reported once (no second look before 30 s)", out.find("2a olhada") == std::string::npos);
	check("the recovery is logged", out.find("voltou a rodar") != std::string::npos);
	watchdog::stop();
	printf("\n%d/%d passed\n", g_pass, g_pass + g_fail);
	return g_fail == 0 ? 0 : 1;
}
