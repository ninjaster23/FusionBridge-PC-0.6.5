# Avisos de terceiros (third-party notices)

O código do FusionBridge é MIT (veja `LICENSE`). Estas são as partes de outros autores que vão neste repositório e nos
zips, com o texto completo da licença de cada uma, como as licenças pedem. Os textos das licenças ficam no original
(inglês).

| Parte | Onde está | Licença |
|---|---|---|
| Mod `passthrough` 0.1.0 (Minecraft, fusão visual) | `mod/passthrough-0.1.0.jar` | MIT, Rehan e contribuidores do universal-modder |
| Compositor e efeito adaptados do passthrough | `src/asi/compositor.cpp` → `gta/FusionBridgeSA.asi`, `gta/shaders/FusionBridgeSA.fx` | MIT, Rehan e contribuidores do universal-modder |
| AMD FidelityFX Super Resolution 1.0 (EASU + RCAS), portado para o efeito | `gta/shaders/FusionBridgeSA.fx` | MIT, Advanced Micro Devices, Inc. |
| Cabeçalhos da API de add-ons do ReShade | `src/third_party/reshade/` (compilados dentro do `gta/FusionBridgeSA.asi`) | BSD-3-Clause, Patrick Mours |
| Fonte Jersey 15 | `app/assets/fonts/Jersey15-Regular.ttf` | SIL Open Font License 1.1 (`app/assets/fonts/OFL-Jersey15.txt`) |
| Fonte IBM Plex Mono | `app/assets/fonts/IBMPlexMono-*.ttf` | SIL Open Font License 1.1 (`app/assets/fonts/OFL-IBMPlexMono.txt`) |
| Python 3.13 (só no zip para jogar: `FusionBridge.exe`, `python313.dll`, `runtime\`) | não fica no repositório | PSF License (`runtime\LICENSE-Python.txt`, no zip) |

**Não vêm no FusionBridge** (o app baixa do site oficial, conferindo o SHA-256, ou você instala por conta): ReShade
(BSD-3), Fabric API (Apache-2.0), Prism Launcher (GPL-3.0), SkyCraft (MIT, chasmlol), Magpie (GPL-3.0), MoonLoader,
SKSE64 e Address Library. Nenhum arquivo do Minecraft, do GTA San Andreas ou do Skyrim vem junto. Minecraft é marca da
Mojang/Microsoft, GTA San Andreas da Rockstar Games/Take-Two e Skyrim da Bethesda; este é um projeto de fã, sem ligação
com essas empresas.

---

## passthrough (Minecraft x GTA V Passthrough) — MIT

Origem: https://github.com/rehan-remade/universal-modder/tree/main/examples/minecraft-gta5-passthrough
(o mod `passthrough-0.1.0.jar` sem alteração; o compositor do `FusionBridgeSA.asi` e o `FusionBridgeSA.fx` foram
adaptados do compositor e do efeito desse projeto para o GTA San Andreas)

```
MIT License

Copyright (c) 2026 Rehan and universal-modder contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.
```

## AMD FidelityFX Super Resolution 1.0 — MIT

Origem: https://github.com/GPUOpen-Effects/FidelityFX-FSR (portado para ReShade FX / shader model 3 dentro do
`FusionBridgeSA.fx`)

```
Copyright (c) 2021 Advanced Micro Devices, Inc. All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

## ReShade (API de add-ons) — BSD-3-Clause

Origem: https://github.com/crosire/reshade (só os cabeçalhos da API de add-ons, em `src/third_party/reshade/`)

```
Copyright 2014 Patrick Mours. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
  * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
  * Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
```

## Fontes — SIL Open Font License 1.1

- Jersey 15: Copyright 2023 The Soft Type Project Authors (https://github.com/scfried/soft-type-jersey). Texto completo
  em `app/assets/fonts/OFL-Jersey15.txt`.
- IBM Plex Mono: Copyright © 2017 IBM Corp. with Reserved Font Name "Plex". Texto completo em
  `app/assets/fonts/OFL-IBMPlexMono.txt`.

As fontes vão sem alteração, junto com o app; elas não são vendidas separadas.
