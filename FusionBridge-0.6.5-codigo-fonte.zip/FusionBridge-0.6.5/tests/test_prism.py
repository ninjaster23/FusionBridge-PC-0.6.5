"""Tests for app/fb_prism.py ("Minecraft automático": portable Prism + the FusionBridge instance, and AutoMC).
usage: python3 -I tests/test_prism.py"""
import hashlib, io, json, os, sys, tempfile, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "app"))
import fb_installer as FI  # noqa: E402
import fb_prism as PR  # noqa: E402

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(detail)[:400]), flush=True)


def zbytes(entries):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for name, data in entries:
            z.writestr(name, data)
    return buf.getvalue()


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data if isinstance(data, bytes) else data.encode("utf-8"))
    return path


class FakePlacer:
    def __init__(self):
        self.calls = []

    def hide(self, pid):
        self.calls.append(("hide", pid))
        return True

    def show(self, pid):
        self.calls.append(("show", pid))
        return True

    def close(self, pid):
        self.calls.append(("close", pid))
        return True


def main():
    logs = []
    not_running = lambda n: False                                            # noqa: E731
    with tempfile.TemporaryDirectory() as t:
        paths = FI.Paths(local=os.path.join(t, "local"), appdata=os.path.join(t, "appdata"), app_root=ROOT)
        zdata = zbytes([("prismlauncher.exe", b"MZ prism 11.1.1"), ("portable.txt", ""), ("jars/NewLaunch.jar", b"jar"),
                        ("platforms/qwindows.dll", b"dll")])
        zpath = write(os.path.join(t, "dl", "PrismLauncher-Windows-MSVC-Portable-11.1.1.zip"), zdata)
        asked = []

        def get_dep(key, p, log):
            asked.append(key)
            return zpath
        check("before installing: nothing", not PR.state(paths.local, not_running)["installed"])
        PR.install(paths, log=logs.append, get_dependency=get_dep, running=not_running)
        r = PR.root(paths.local)
        check("install uses the pinned Prism download", asked == ["prism"])
        check("Prism unpacked (portable) in %LOCALAPPDATA%\\FusionBridge\\Prism",
              os.path.isfile(os.path.join(r, "prismlauncher.exe")) and os.path.isfile(os.path.join(r, "portable.txt")) and
              os.path.isfile(os.path.join(r, "platforms", "qwindows.dll")))
        pack = json.load(open(os.path.join(PR.instance_dir(paths.local), "mmc-pack.json"), encoding="utf-8"))
        comp = {c["uid"]: c["version"] for c in pack["components"]}
        check("the FusionBridge instance: Minecraft 26.3, Fabric Loader 0.19.5, intermediary 26.3, LWJGL 3.4.3",
              comp == {"net.minecraft": "26.3", "net.fabricmc.fabric-loader": "0.19.5", "net.fabricmc.intermediary": "26.3",
                       "org.lwjgl3": "3.4.3"} and pack["formatVersion"] == 1, comp)
        cfg = open(os.path.join(PR.instance_dir(paths.local), "instance.cfg"), encoding="utf-8").read()
        check("... OneSix instance named FusionBridge, 4 GB max, no console", "InstanceType=OneSix" in cfg and "name=FusionBridge" in cfg
              and "MaxMemAlloc=4096" in cfg and "ShowConsole=false" in cfg and "startHidden" not in cfg, cfg)
        pcfg = open(os.path.join(r, "prismlauncher.cfg"), encoding="utf-8").read()
        check("Prism's settings: Java downloaded by itself, quits after the game, no low-memory question",
              "AutomaticJavaDownload=true" in pcfg and "QuitAfterGameStop=true" in pcfg and "LowMemWarning=false" in pcfg, pcfg)
        st = PR.state(paths.local, not_running)
        check("state: installed, not signed in, mods not there yet", st["installed"] and not st["signed_in"] and
              not any(st["mods"].values()) and st["version"] == "11.1.1", st)
        write(os.path.join(r, "prismlauncher.cfg"), "[General]\nLanguage=en_US\n")
        PR.install(paths, log=logs.append, get_dependency=get_dep, running=not_running)
        check("installing again keeps the player's Prism settings",
              open(os.path.join(r, "prismlauncher.cfg"), encoding="utf-8").read() == "[General]\nLanguage=en_US\n")
        try:
            PR.install(paths, log=logs.append, get_dependency=get_dep, running=lambda n: n == "prismlauncher.exe")
            check("installing with Prism open: refused", False)
        except PR.PrismError:
            check("installing with Prism open: refused", True)
        evil = write(os.path.join(t, "dl", "evil.zip"), zbytes([("../outside.exe", b"x")]))
        try:
            PR.install(paths, log=logs.append, get_dependency=lambda k, p, l: evil, running=not_running)
            check("a Prism zip with ../ paths is refused", False)
        except PR.PrismError:
            check("a Prism zip with ../ paths is refused", not os.path.exists(os.path.join(paths.local, "FusionBridge", "outside.exe")))

        # launching needs the Microsoft sign-in first
        calls = []
        popen = lambda args, **kw: calls.append((args, kw.get("cwd")))                                  # noqa: E731
        try:
            PR.launch(paths.local, popen=popen)
            check("launch before signing in: refused (asks to sign in)", False)
        except PR.PrismError as e:
            check("launch before signing in: refused (asks to sign in)", "conta" in str(e) and not calls, e)
        PR.sign_in(paths.local, popen=popen)
        check("sign in opens Prism's own window", calls == [([PR.exe(paths.local)], r)], calls)
        write(os.path.join(r, "accounts.json"), json.dumps({"accounts": [{"type": "MSA", "profile": {"name": "Steve"}}]}))
        calls.clear()
        PR.launch(paths.local, popen=popen)
        check("launch starts the FusionBridge instance (prismlauncher.exe --launch FusionBridge)",
              calls == [([PR.exe(paths.local), "--launch", "FusionBridge"], r)], calls)
        for n in PR.MODS:
            write(os.path.join(PR.mods_dir(paths.local), n), b"jar")
        st = PR.state(paths.local, not_running)
        check("state: signed in, the three mods there", st["signed_in"] and all(st["mods"].values()), st)

        # AutoMC: open with GTA, never twice, close only its own, window off the screen
        now = [1000.0]
        launched = []
        placer = FakePlacer()
        auto = PR.AutoMC(paths.local, launcher=lambda: launched.append(now[0]), placer=placer, running=not_running,
                         clock=lambda: now[0], log=logs.append)
        prefs = {"auto_start": True, "auto_close": True, "hide_mc": True}
        closed = {"state": "connecting"}
        auto.tick(prefs, False, closed)
        check("GTA closed: Minecraft is not opened", not launched)
        auto.tick(prefs, True, closed)
        check("GTA opens: Minecraft opened once", launched == [1000.0], launched)
        now[0] += 30
        auto.tick(prefs, True, closed)
        check("... not again while it is still starting", len(launched) == 1)
        now[0] += 30
        linked = {"state": "open", "hello": {"pid": 4242}}
        auto.tick(prefs, True, linked)
        check("linked: its window goes off the screen (not minimized)", ("hide", 4242) in placer.calls, placer.calls)
        auto.tick(prefs, True, linked)
        check("... once (the player can bring it back)", placer.calls.count(("hide", 4242)) == 1, placer.calls)
        now[0] += 2
        auto.tick(prefs, False, linked)
        check("GTA just closed: Minecraft kept for a few seconds", ("close", 4242) not in placer.calls)
        now[0] += PR.AutoMC.CLOSE_AFTER + 1
        auto.tick(prefs, False, linked)
        check("GTA closed for a while: the Minecraft the app opened is closed", ("close", 4242) in placer.calls, placer.calls)

        placer2 = FakePlacer()
        auto2 = PR.AutoMC(paths.local, launcher=lambda: launched.append("x"), placer=placer2, running=not_running,
                          clock=lambda: now[0], log=logs.append)
        theirs = {"state": "open", "hello": {"pid": 777}}
        auto2.tick(prefs, True, theirs)
        now[0] += 60
        auto2.tick(prefs, False, theirs)
        now[0] += 60
        auto2.tick(prefs, False, theirs)
        check("a Minecraft the player opened is never closed by the app", ("close", 777) not in placer2.calls and "x" not in launched,
              placer2.calls)
        auto2.tick(dict(prefs, hide_mc=False), False, theirs)
        check("turning 'off the screen' off brings the window back", ("show", 777) in placer2.calls, placer2.calls)

        launched.clear()
        auto3 = PR.AutoMC(paths.local, launcher=lambda: launched.append(1), placer=FakePlacer(),
                          running=lambda n: n == "prismlauncher.exe", clock=lambda: now[0], log=logs.append)
        auto3.tick(prefs, True, closed)
        check("Prism already starting one: no second Minecraft", not launched and "Prism" in auto3.note, auto3.note)
        os.remove(os.path.join(r, "accounts.json"))
        auto4 = PR.AutoMC(paths.local, launcher=lambda: launched.append(1), placer=FakePlacer(), running=not_running,
                          clock=lambda: now[0], log=logs.append)
        auto4.tick(prefs, True, closed)
        check("not signed in: nothing opened, the note says to sign in", not launched and "conta" in auto4.note, auto4.note)
        auto4.tick(dict(prefs, auto_start=False), True, closed)
        check("auto start off: nothing opened", not launched)
        auto5 = PR.AutoMC(paths.local, launcher=lambda: (_ for _ in ()).throw(OSError("bloqueado")), placer=FakePlacer(),
                          running=not_running, clock=lambda: now[0], log=logs.append)
        write(os.path.join(r, "accounts.json"), json.dumps({"accounts": [{"type": "MSA"}]}))
        auto5.tick(prefs, True, closed)
        check("a launch that fails is reported, not retried at once", "bloqueado" in auto5.note and auto5.launched_at == now[0], auto5.note)
        auto6 = PR.AutoMC(paths.local, launcher=lambda: None, placer=FakePlacer(), running=not_running, clock=lambda: now[0])
        auto6.launched_by_hand()
        auto6.tick(prefs, True, {"state": "open", "hello": {"pid": 99}})
        check("a Minecraft opened with the button counts as the app's (closed with GTA)", auto6.ours_pid == 99)

        # remove: the world is copied first, then the whole Prism folder goes
        write(os.path.join(PR.game_dir(paths.local), "saves", "FusionBridge", "level.dat"), b"world")
        try:
            PR.remove(paths.local, log=logs.append, running=lambda n: n == "prismlauncher.exe")
            check("removing with Prism open: refused", False)
        except PR.PrismError:
            check("removing with Prism open: refused", os.path.isdir(r))
        PR.remove(paths.local, log=logs.append, running=not_running)
        bdir = os.path.join(paths.local, "FusionBridge", "backups")
        worlds = os.listdir(bdir) if os.path.isdir(bdir) else []
        check("remove: the fusion world copied to backups, the Prism folder gone",
              not os.path.exists(r) and len(worlds) == 1 and
              os.path.isfile(os.path.join(bdir, worlds[0], "FusionBridge", "level.dat")), worlds)
        try:
            PR.remove(paths.local, log=logs.append, running=not_running)
            check("removing when not installed: refused", False)
        except PR.PrismError:
            check("removing when not installed: refused", True)
    check("the Placer does nothing off Windows", PR.Placer().window(1) is None and PR.Placer().hide(1) is False)

    bad = [n for n, ok in results if not ok]
    print("\n%d/%d passaram" % (len(results) - len(bad), len(results)))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
