#pragma once
#include <cstdint>
#include <string>

namespace fbgta {

struct Event {
    enum class Type {
        Unknown,
        TntExplosion,
        Explosion,
        EntitySpawn,
        EntityMove,
        EntityRemove,
        BlockPlace,
        BlockBreak,
        Heal
    } type = Type::Unknown;

    std::string kind;      // e.g. minecraft:wither, minecraft:creeper
    std::string block_id;  // e.g. minecraft:tnt
    std::int64_t id = 0;
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
    float radius = 0.0f;
    float damage = 0.0f;
    float amount = 0.0f;
};

// Tiny JSON-lines parser for FusionBridge protocol messages. It intentionally
// extracts only whitelisted scalar fields; it is not a general JSON library.
bool parse_event_line(const std::string& line, Event& out);
std::string make_hello();
std::string make_ping();
std::string make_player_state(float x, float y, float z, float yaw, float health,
                              int in_vehicle, float vehicle_health);

} // namespace fbgta
