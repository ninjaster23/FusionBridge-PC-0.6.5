// FusionBridge PC 0.6.3 - composites Minecraft Java into GTA: San Andreas (Direct3D 9, ReShade 6.8 add-on).
// FusionBridgeSA.asi uploads Minecraft's latest frame (passthrough mod, shared memory) into the MCWORLD /
// MCDEPTH / MCOVERLAY textures and sets the camera/plane uniforms every frame.
//
// Adapted from MCPassthrough.fx of the MIT "Minecraft x GTA V passthrough" (rehan-remade/universal-modder):
//   * GTA SA's depth is standard Z (not reversed like GTA V's) and its planes come from RenderWare;
//   * GTA SA without a widescreen fix projects 4:3 stretched over the screen: HostAspect is the real one;
//   * Direct3D 9 / shader model 3: both composite targets have the same bit depth (MRT rule) and every
//     texture read is an explicit-LOD read, so nothing needs gradients inside branches.
//
// world: premultiplied RGBA, drawn where Minecraft is nearer than GTA's depth buffer (both in metres).
// overlay: Minecraft's hand, HUD and screens, always on top.
//
// 0.6.3 - AMD FidelityFX Super Resolution 1.0 (FSR 1.0, MIT, (c) Advanced Micro Devices): Minecraft can render below
// GTA's resolution (it is the heavy one of the two games) and is brought up to GTA's resolution with EASU (edge-adaptive
// spatial upscaling) and sharpened with RCAS (robust contrast-adaptive sharpening), each in its own pass. Ported here
// as plain texture taps (shader model 3 has no gather); the app picks the AMD preset (Minecraft's render size) and the
// add-on sets FsrEnable / FsrSharpness / McSize.
//
// ---------------------------------------------------------------- licenses
// FusionBridge code: MIT, Copyright (c) 2026 FusionBridge contributors (LICENSE). Parts of other authors, with their
// notices as their licenses require (also in THIRD-PARTY-NOTICES.md):
//
// The compositing is adapted from MCPassthrough.fx of "Minecraft x GTA V passthrough":
//
// MIT License
//
// Copyright (c) 2026 Rehan and universal-modder contributors
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
// OR OTHER DEALINGS IN THE SOFTWARE.
//
// The EASU and RCAS passes are ported from AMD FidelityFX Super Resolution 1.0 (ffx_fsr1.h):
//
// Copyright (c) 2021 Advanced Micro Devices, Inc. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
#include "ReShade.fxh"

texture MCWorldTex : MCWORLD;
texture MCDepthTex : MCDEPTH;
texture MCOverlayTex : MCOVERLAY;
sampler sWorld { Texture = MCWorldTex; AddressU = CLAMP; AddressV = CLAMP; };
sampler sDepth { Texture = MCDepthTex; MinFilter = POINT; MagFilter = POINT; AddressU = CLAMP; AddressV = CLAMP; };
sampler sOverlay { Texture = MCOverlayTex; AddressU = CLAMP; AddressV = CLAMP; };

// x = near, y = far, z = flags (1: [0,1] depth, 2: rows bottom-up, 4: reversed Z). Set by the add-on.
uniform float3 McPlanes = float3(0.05, 2048.0, 7.0);
// GTA's camera near/far clip (RenderWare camera). Set by the add-on.
uniform float2 HostPlanes = float2(0.3, 800.0);
// GTA's projection aspect (tan of half the horizontal fov / tan of half the vertical fov). 0: the screen's.
uniform float HostAspect = 0.0;

// Set true by the add-on only while it has uploaded a Minecraft frame; until then GTA passes through untouched.
uniform bool McActive = false;

uniform bool HostReversedZ < ui_label = "GTA depth is reversed"; > = false;
uniform float DepthBias < ui_type = "drag"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.005; ui_label = "Depth bias (m)";
	ui_tooltip = "How far behind GTA's surface Minecraft may still show (blocks resting on the ground)."; > = 0.04;
uniform float SlopeBias < ui_type = "drag"; ui_min = 0.0; ui_max = 40.0; ui_step = 0.1; ui_label = "Depth bias per grazing slope";
	ui_tooltip = "Extra depth bias where GTA's surface is seen at a grazing angle (its depth changes fast down the screen): Minecraft ground laid into GTA's (lava, netherrack) still shows far away."; > = 0.0;
uniform float MaxBias < ui_type = "drag"; ui_min = 0.1; ui_max = 10.0; ui_step = 0.1; ui_label = "Largest depth bias (m)"; > = 3.0;
uniform float HostDepthScale < ui_type = "drag"; ui_min = 0.5; ui_max = 2.0; ui_step = 0.001; ui_label = "GTA depth scale";
	ui_tooltip = "Calibration: multiplies GTA's linearised depth."; > = 1.0;
uniform float LightMatch < ui_type = "drag"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; ui_label = "Match GTA lighting";
	ui_tooltip = "Relight Minecraft by the (blurred) GTA picture around it: darker in shade, tinted by nearby light."; > = 0.8;
uniform float LightReference < ui_type = "drag"; ui_min = 0.1; ui_max = 1.0; ui_step = 0.01; ui_label = "Neutral brightness";
	ui_tooltip = "GTA brightness at which Minecraft keeps its own colours."; > = 0.42;
uniform float LightTint < ui_type = "drag"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; ui_label = "Light colour"; > = 0.55;
uniform float LightBlur < ui_type = "drag"; ui_min = 1.0; ui_max = 6.0; ui_step = 0.1; ui_label = "Light blur (mip)"; > = 3.2;
uniform float GradeMatch < ui_type = "drag"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; ui_label = "Match GTA colour grade";
	ui_tooltip = "Give Minecraft the colour of GTA's whole picture (a red Nether night, an orange sunset), as GTA's own grading does to its world."; > = 0.55;
uniform float HazeStart < ui_type = "drag"; ui_min = 0.0; ui_max = 200.0; ui_step = 1.0; ui_label = "Haze start (m)"; > = 15.0;
uniform float HazeDistance < ui_type = "drag"; ui_min = 10.0; ui_max = 1000.0; ui_step = 1.0; ui_label = "Haze distance (m)";
	ui_tooltip = "Far away, Minecraft fades into the GTA picture around it (GTA's haze and fog don't reach Minecraft otherwise)."; > = 160.0;
uniform float HazeStrength < ui_type = "drag"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; ui_label = "Haze strength"; > = 0.85;
uniform float EdgeSoftness < ui_type = "drag"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; ui_label = "Soften Minecraft's edges";
	ui_tooltip = "Anti-alias where Minecraft meets GTA (GTA's own anti-aliasing ran before Minecraft was added)."; > = 1.0;
uniform float ContactShadow < ui_type = "drag"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; ui_label = "Contact shadows";
	ui_tooltip = "Darken GTA's surfaces right next to Minecraft's (under mobs' feet, around blocks)."; > = 0.5;
uniform float ContactRadius < ui_type = "drag"; ui_min = 0.1; ui_max = 3.0; ui_step = 0.05; ui_label = "Contact shadow size (m)"; > = 0.7;
uniform float BloomStrength < ui_type = "drag"; ui_min = 0.0; ui_max = 2.0; ui_step = 0.01; ui_label = "Minecraft glow";
	ui_tooltip = "Bright Minecraft things (lava, fire, the portal) glow over GTA's picture, as GTA's own lights do."; > = 0.55;
uniform float BloomThreshold < ui_type = "drag"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; ui_label = "Glow threshold"; > = 0.62;
// Set by the add-on: the camera shake, applied to the finished picture so GTA and Minecraft shake together
// (x, y: fraction of the screen height; z: roll, radians), and the nether portal's warp (0..1) while passing through.
uniform float3 Shake = float3(0.0, 0.0, 0.0);
uniform float PortalWarp = 0.0;
uniform float Timer < source = "timer"; >;
uniform int DebugView < ui_type = "combo"; ui_items = "Composite\0GTA depth (1 m bands)\0Minecraft depth (1 m bands)\0Depth difference\0"; > = 0;
uniform bool Reproject < ui_label = "Re-project to GTA's camera"; ui_tooltip = "Rotate Minecraft's (slightly older) frame onto GTA's current camera."; > = true;
uniform float PosePrediction < ui_type = "drag"; ui_min = -2.0; ui_max = 3.0; ui_step = 0.05; ui_label = "Pose prediction (frames)";
	ui_tooltip = "Extrapolate GTA's camera rotation by this many frames before re-projecting."; > = 0.0;

// Set by the add-on: rows of R_mc^T R_gta (GTA camera ray -> Minecraft camera ray), and
// x = tan(GTA vertical fov / 2), y = tan(Minecraft vertical fov / 2), z = Minecraft aspect.
uniform float3 WarpRow0 = float3(1.0, 0.0, 0.0);
uniform float3 WarpRow1 = float3(0.0, 1.0, 0.0);
uniform float3 WarpRow2 = float3(0.0, 0.0, 1.0);
uniform float3 WarpTan = float3(0.7, 0.7, 1.7777);
// Set by the add-on: GTA's camera position relative to Minecraft's, in Minecraft's camera space.
uniform float3 WarpT = float3(0.0, 0.0, 0.0);

// FSR 1.0. Set by the add-on from the app (Desempenho tab); McSize.xy = Minecraft's frame size in pixels.
uniform bool FsrEnable < ui_label = "FSR 1.0 (AMD) para a imagem do Minecraft"; > = true;
uniform float FsrSharpness < ui_type = "drag"; ui_min = 0.0; ui_max = 2.0; ui_step = 0.05; ui_label = "FSR: nitidez RCAS (0 = máxima)";
	ui_tooltip = "Em 'stops' como na AMD: 0 é a mais forte, 2 quase nenhuma."; > = 0.2;
uniform float3 McSize = float3(0.0, 0.0, 0.0);

// GTA's picture at quarter size with mips: its blurred levels stand in for the light around each pixel.
texture GtaLightTex { Width = BUFFER_WIDTH / 4; Height = BUFFER_HEIGHT / 4; Format = RGBA8; MipLevels = 7; };
sampler sGtaLight { Texture = GtaLightTex; AddressU = CLAMP; AddressV = CLAMP; };

// FSR 1.0: Minecraft's world and overlay brought to GTA's resolution (same orientation as MCWORLD/MCOVERLAY).
texture McUpTex { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8; };
sampler sMcUp { Texture = McUpTex; AddressU = CLAMP; AddressV = CLAMP; };
texture McSharpTex { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8; };
sampler sMcSharp { Texture = McSharpTex; AddressU = CLAMP; AddressV = CLAMP; };
texture OverlayUpTex { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8; };
sampler sOverlayUp { Texture = OverlayUpTex; AddressU = CLAMP; AddressV = CLAMP; };

// The composited world (GTA + Minecraft, no overlay) and, per pixel: Minecraft's coverage, its depth and GTA's.
texture CompositeTex { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA16F; };
sampler sComposite { Texture = CompositeTex; AddressU = CLAMP; AddressV = CLAMP; };
texture McInfoTex { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA16F; };
sampler sMcInfo { Texture = McInfoTex; MinFilter = POINT; MagFilter = POINT; AddressU = CLAMP; AddressV = CLAMP; };
// Minecraft's bright parts at quarter size with mips (the glow).
texture McBrightTex { Width = BUFFER_WIDTH / 4; Height = BUFFER_HEIGHT / 4; Format = RGBA8; MipLevels = 6; };
sampler sMcBright { Texture = McBrightTex; AddressU = CLAMP; AddressV = CLAMP; };

// level-0 read without gradients (shader model 3 rejects gradient reads inside dynamic branches)
float4 tex2D0(sampler s, float2 uv)
{
	return tex2Dlod(s, float4(uv, 0.0, 0.0));
}

float luma(float3 c)
{
	return dot(c, float3(0.2126, 0.7152, 0.0722));
}

// ---------------------------------------------------------------- AMD FidelityFX FSR 1.0 (EASU + RCAS)
// Only while Minecraft really is smaller than GTA's picture (upscaling); otherwise the plain textures are used.
bool fsr_on()
{
	return FsrEnable && McActive && McSize.x > 1.0 && McSize.y > 1.0 && McSize.x < BUFFER_WIDTH * 0.98;
}

float fsr_rcp(float x)
{
	return 1.0 / max(x, 1e-8);   // the reference's approximate reciprocal never divides by zero either
}

float3 easu_tap_rgb(sampler s, float2 p, float2 rcpSize)
{
	return tex2Dlod(s, float4((p + 0.5) * rcpSize, 0.0, 0.0)).rgb;   // exact texel centres
}

float easu_luma(float3 c)
{
	return c.b * 0.5 + (c.r * 0.5 + c.g);
}

void easu_set(inout float2 dir, inout float len, float w, float lA, float lB, float lC, float lD, float lE)
{
	// a above, b left, c centre, d right, e below
	const float dc = lD - lC, cb = lC - lB;
	float lenX = max(abs(dc), abs(cb));
	lenX = fsr_rcp(lenX);
	const float dirX = lD - lB;
	dir.x += dirX * w;
	lenX = saturate(abs(dirX) * lenX);
	lenX *= lenX;
	len += lenX * w;
	const float ec = lE - lC, ca = lC - lA;
	float lenY = max(abs(ec), abs(ca));
	lenY = fsr_rcp(lenY);
	const float dirY = lE - lA;
	dir.y += dirY * w;
	lenY = saturate(abs(dirY) * lenY);
	lenY *= lenY;
	len += lenY * w;
}

void easu_tap(inout float3 aC, inout float aW, float2 off, float2 dir, float2 len, float lob, float clp, float3 c)
{
	float2 v = float2(off.x * dir.x + off.y * dir.y, off.x * -dir.y + off.y * dir.x) * len;
	const float d2 = min(v.x * v.x + v.y * v.y, clp);
	float wB = 0.4 * d2 - 1.0;
	float wA = lob * d2 - 1.0;
	wB *= wB;
	wA *= wA;
	wB = 1.5625 * wB - 0.5625;
	const float w = wB * wA;
	aC += c * w;
	aW += w;
}

// EASU at output texture coordinate uv: s is `size` pixels big; returns the upscaled colour
float3 easu(sampler s, float2 uv, float2 size)
{
	const float2 rcpSize = 1.0 / size;
	float2 pp = uv * size - 0.5;
	const float2 fp = floor(pp);
	pp -= fp;
	//    b c
	//  e f g h
	//  i j k l
	//    n o
	const float3 bC = easu_tap_rgb(s, fp + float2( 0, -1), rcpSize), cC = easu_tap_rgb(s, fp + float2( 1, -1), rcpSize);
	const float3 eC = easu_tap_rgb(s, fp + float2(-1,  0), rcpSize), fC = easu_tap_rgb(s, fp + float2( 0,  0), rcpSize);
	const float3 gC = easu_tap_rgb(s, fp + float2( 1,  0), rcpSize), hC = easu_tap_rgb(s, fp + float2( 2,  0), rcpSize);
	const float3 iC = easu_tap_rgb(s, fp + float2(-1,  1), rcpSize), jC = easu_tap_rgb(s, fp + float2( 0,  1), rcpSize);
	const float3 kC = easu_tap_rgb(s, fp + float2( 1,  1), rcpSize), lC = easu_tap_rgb(s, fp + float2( 2,  1), rcpSize);
	const float3 nC = easu_tap_rgb(s, fp + float2( 0,  2), rcpSize), oC = easu_tap_rgb(s, fp + float2( 1,  2), rcpSize);
	const float bL = easu_luma(bC), cL = easu_luma(cC), eL = easu_luma(eC), fL = easu_luma(fC), gL = easu_luma(gC), hL = easu_luma(hC);
	const float iL = easu_luma(iC), jL = easu_luma(jC), kL = easu_luma(kC), lL = easu_luma(lC), nL = easu_luma(nC), oL = easu_luma(oC);
	// direction and length from the 4 bilinear quadrants around the sample
	float2 dir = 0.0;
	float len = 0.0;
	easu_set(dir, len, (1.0 - pp.x) * (1.0 - pp.y), bL, eL, fL, gL, jL);
	easu_set(dir, len, pp.x * (1.0 - pp.y), cL, fL, gL, hL, kL);
	easu_set(dir, len, (1.0 - pp.x) * pp.y, fL, iL, jL, kL, nL);
	easu_set(dir, len, pp.x * pp.y, gL, jL, kL, lL, oL);
	const float2 dir2 = dir * dir;
	float dirR = dir2.x + dir2.y;
	const bool zro = dirR < (1.0 / 32768.0);
	dirR = zro ? 1.0 : rsqrt(dirR);
	dir.x = zro ? 1.0 : dir.x;
	dir *= dirR;
	len = len * 0.5;
	len *= len;
	const float stretch = (dir.x * dir.x + dir.y * dir.y) * fsr_rcp(max(abs(dir.x), abs(dir.y)));
	const float2 len2 = float2(1.0 + (stretch - 1.0) * len, 1.0 - 0.5 * len);
	const float lob = 0.5 + ((1.0 / 4.0 - 0.04) - 0.5) * len;
	const float clp = fsr_rcp(lob);
	// accumulate with the window, then clamp to the 4 nearest (no ringing)
	const float3 min4 = min(min(fC, gC), min(jC, kC));
	const float3 max4 = max(max(fC, gC), max(jC, kC));
	float3 aC = 0.0;
	float aW = 0.0;
	easu_tap(aC, aW, float2( 0.0, -1.0) - pp, dir, len2, lob, clp, bC);
	easu_tap(aC, aW, float2( 1.0, -1.0) - pp, dir, len2, lob, clp, cC);
	easu_tap(aC, aW, float2(-1.0,  1.0) - pp, dir, len2, lob, clp, iC);
	easu_tap(aC, aW, float2( 0.0,  1.0) - pp, dir, len2, lob, clp, jC);
	easu_tap(aC, aW, float2( 0.0,  0.0) - pp, dir, len2, lob, clp, fC);
	easu_tap(aC, aW, float2(-1.0,  0.0) - pp, dir, len2, lob, clp, eC);
	easu_tap(aC, aW, float2( 1.0,  1.0) - pp, dir, len2, lob, clp, kC);
	easu_tap(aC, aW, float2( 2.0,  1.0) - pp, dir, len2, lob, clp, lC);
	easu_tap(aC, aW, float2( 2.0,  0.0) - pp, dir, len2, lob, clp, hC);
	easu_tap(aC, aW, float2( 1.0,  0.0) - pp, dir, len2, lob, clp, gC);
	easu_tap(aC, aW, float2( 1.0,  2.0) - pp, dir, len2, lob, clp, oC);
	easu_tap(aC, aW, float2( 0.0,  2.0) - pp, dir, len2, lob, clp, nC);
	return min(max4, max(min4, aC * fsr_rcp(aW)));
}

// premultiplied RGBA: EASU where the layer is solid around the sample, plain bilinear at its edges (coverage keeps
// its own smooth edge; EASU across transparent pixels would darken them)
float4 easu_layer(sampler s, float2 uv, float2 size)
{
	const float4 plain = tex2D0(s, uv);
	const float2 px = 1.0 / size;
	const float solid = min(min(tex2D0(s, uv + float2(-px.x, -px.y)).a, tex2D0(s, uv + float2(px.x, -px.y)).a),
		min(tex2D0(s, uv + float2(-px.x, px.y)).a, tex2D0(s, uv + float2(px.x, px.y)).a));
	[branch] if (solid < 0.999 || plain.a < 0.999)
		return plain;
	return float4(easu(s, uv, size), plain.a);
}

float4 PS_EasuWorld(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
	[branch] if (!fsr_on())
		return 0.0;
	return easu_layer(sWorld, uv, McSize.xy);
}

float4 PS_EasuOverlay(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
	[branch] if (!fsr_on())
		return 0.0;
	return easu_layer(sOverlay, uv, McSize.xy);
}

// RCAS on the upscaled Minecraft world (solid pixels only), with AMD's noise removal
float4 PS_RcasWorld(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
	[branch] if (!fsr_on())
		return 0.0;
	const float2 px = BUFFER_PIXEL_SIZE;
	const float4 e4 = tex2D0(sMcUp, uv);
	const float4 b4 = tex2D0(sMcUp, uv + float2(0.0, -px.y)), d4 = tex2D0(sMcUp, uv + float2(-px.x, 0.0));
	const float4 f4 = tex2D0(sMcUp, uv + float2(px.x, 0.0)), h4 = tex2D0(sMcUp, uv + float2(0.0, px.y));
	[branch] if (min(min(b4.a, d4.a), min(min(f4.a, h4.a), e4.a)) < 0.999)
		return e4;
	const float3 b = b4.rgb, d = d4.rgb, e = e4.rgb, f = f4.rgb, h = h4.rgb;
	const float bL = easu_luma(b), dL = easu_luma(d), eL = easu_luma(e), fL = easu_luma(f), hL = easu_luma(h);
	float nz = 0.25 * (bL + dL + fL + hL) - eL;
	nz = saturate(abs(nz) * fsr_rcp(max(max(max(bL, dL), max(eL, fL)), hL) - min(min(min(bL, dL), min(eL, fL)), hL)));
	nz = -0.5 * nz + 1.0;
	const float3 mn4 = min(min(b, d), min(f, h));
	const float3 mx4 = max(max(b, d), max(f, h));
	const float3 hitMin = min(mn4, e) / max(4.0 * mx4, 1e-5);
	const float3 hitMax = (1.0 - max(mx4, e)) / min(4.0 * mn4 - 4.0, -1e-5);
	const float3 lobeRGB = max(-hitMin, hitMax);
	float lobe = max(-(0.25 - 1.0 / 16.0), min(max(lobeRGB.r, max(lobeRGB.g, lobeRGB.b)), 0.0)) * exp2(-FsrSharpness);
	lobe *= nz;
	const float rcpL = 1.0 / (4.0 * lobe + 1.0);
	return float4(saturate((lobe * (b + d + f + h) + e) * rcpL), e4.a);
}

float4 PS_Light(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
	return float4(tex2D0(ReShade::BackBuffer, uv).rgb, 1.0);
}

/// Minecraft renders at full daylight, so treat its colour as albedo and light it with GTA's local light; then give it
/// GTA's colour grade (the whole picture's colour) and, far away, GTA's haze (fade into the picture around it).
float3 relight(float3 c, float2 uv, float zm)
{
	const float3 L = tex2Dlod(sGtaLight, float4(uv, 0, LightBlur)).rgb;
	const float lum = luma(L);
	const float gain = clamp(lum / LightReference, 0.42, 1.3);
	const float3 tint = clamp(lerp(1.0, L / max(lum, 1e-3), LightTint), 0.55, 1.5);
	c = lerp(c, c * gain * tint, LightMatch);
	// the picture's grade, gentled (GTA's own grade keeps some colour in everything) and kept off lights (bright
	// things keep their colour: fire, lava, the portal)
	const float3 M = tex2Dlod(sGtaLight, float4(0.5, 0.5, 0, 6.0)).rgb;
	const float3 grade = clamp(lerp(1.0, M / max(luma(M), 1e-3), 0.6), 0.6, 1.6);
	c = lerp(c, c * grade, GradeMatch * (1.0 - saturate((max(c.r, max(c.g, c.b)) - 0.45) * 2.5)));
	const float h = saturate((1.0 - exp(-max(zm - HazeStart, 0.0) / HazeDistance)) * HazeStrength);
	const float3 H = tex2Dlod(sGtaLight, float4(uv, 0, LightBlur + 1.0)).rgb;
	return lerp(c, H, h);
}

float mc_linear(float d)
{
	const float n = McPlanes.x, f = McPlanes.y;
	if (d <= 0.0)
		return 1e9;
	return n * f / (n + d * (f - n));
}

float host_linear(float d)
{
	const float n = HostPlanes.x, f = HostPlanes.y;
	float z;
	if (HostReversedZ)
		z = d > 0.0 ? n * f / (n + d * (f - n)) : 1e9;
	else
		z = d < 1.0 ? n * f / (f - d * (f - n)) : 1e9;
	return z * HostDepthScale;
}

float3 bands(float z)
{
	const float t = frac(z);
	return lerp(float3(0.1, 0.1, 0.1), float3(1.0, 0.85, 0.3), step(0.5, t)) * saturate(1.5 - z / 100.0);
}

void PS_Composite(float4 pos : SV_Position, float2 uv : TEXCOORD, out float4 outColor : SV_Target0, out float4 outInfo : SV_Target1)
{
	const float3 host = tex2D0(ReShade::BackBuffer, uv).rgb;
	const float zh = host_linear(tex2Dlod(ReShade::DepthBuffer, float4(uv, 0, 0)).x);
	const float zhSlope = abs(ddy(zh));
	outInfo = 0.0;
	outColor = float4(host, 1.0);
	if (!McActive)
		return;
	const float2 ouv = float2(uv.x, 1.0 - uv.y); // Minecraft's rows are bottom-up

	// Where this GTA pixel's view ray lands in Minecraft's frame.
	float2 muv = ouv;
	bool inside = true;
	// how far behind GTA's surface Minecraft may still show: more where that surface is seen at a grazing angle
	const float allow = min(DepthBias + SlopeBias * zhSlope, max(MaxBias, DepthBias));
	float zm = 1e9;
	if (Reproject)
	{
		// March this GTA pixel's ray (in GTA's current camera) from near to far, moving each point into the
		// camera Minecraft rendered with (rotation + how far the camera moved since). The first point that is
		// behind Minecraft's surface there is where Minecraft is seen: refine it and sample. Thin, close things
		// (Steve in third person) are found even when the camera has swung sideways.
		const float hostAspect = HostAspect > 0.0 ? HostAspect : BUFFER_WIDTH * BUFFER_RCP_HEIGHT;
		const float3 ray = float3((uv.x * 2.0 - 1.0) * WarpTan.x * hostAspect, (1.0 - uv.y * 2.0) * WarpTan.x, -1.0);
		const float2 mcScale = float2(WarpTan.y * WarpTan.z, WarpTan.y);
		const float zNear = 0.2, zFar = max(min(zh + allow, 400.0), 0.5);
		float2 ndc = 0.0;
		inside = false;
		[loop] for (int i = 0; i < 24; ++i)
		{
			const float z = zNear * pow(zFar / zNear, i / 23.0);
			const float3 p = ray * z;
			const float3 pm = float3(dot(WarpRow0, p), dot(WarpRow1, p), dot(WarpRow2, p)) + WarpT;
			if (pm.z > -1e-3)
				continue;
			const float2 n = pm.xy / -pm.z / mcScale;
			if (any(abs(n) > 1.0))
				continue;
			const float zmv = mc_linear(tex2Dlod(sDepth, float4(n * 0.5 + 0.5, 0, 0)).r);
			if (zmv > -pm.z + 0.03)
				continue; // still in front of whatever Minecraft drew there
			// crossed Minecraft's surface: settle on it (fixed-point on the surface point's GTA depth)
			float zg = z;
			ndc = n;
			[loop] for (int k = 0; k < 3; ++k)
			{
				const float3 pk = ray * zg;
				const float3 mk = float3(dot(WarpRow0, pk), dot(WarpRow1, pk), dot(WarpRow2, pk)) + WarpT;
				if (mk.z > -1e-3)
					break;
				const float2 nk = mk.xy / -mk.z / mcScale;
				if (any(abs(nk) > 1.0))
					break;
				const float zk = mc_linear(tex2Dlod(sDepth, float4(nk * 0.5 + 0.5, 0, 0)).r);
				if (zk > 1e8)
					break;
				ndc = nk;
				const float3 q = float3(nk * mcScale, -1.0) * zk - WarpT;
				zg = -(q.x * WarpRow0.z + q.y * WarpRow1.z + q.z * WarpRow2.z);
			}
			muv = ndc * 0.5 + 0.5;
			zm = zg;
			inside = true;
			break;
		}
	}
	const float4 world = inside ? (fsr_on() ? tex2D0(sMcSharp, muv) : tex2D0(sWorld, muv)) : 0.0;
	if (!Reproject)
		zm = mc_linear(tex2D0(sDepth, muv).r);

	outInfo = float4(0.0, 0.0, zh, 0.0);
	if (DebugView == 1)
	{
		outColor = float4(bands(zh), 1.0);
		return;
	}
	if (DebugView == 2)
	{
		outColor = float4(world.a > 0.0 ? bands(zm) : host * 0.3, 1.0);
		return;
	}
	if (DebugView == 3)
	{
		outColor = float4(world.a > 0.0 ? float3(saturate((zh - zm) * 0.5 + 0.5), saturate(-(zh - zm) * 0.5 + 0.5), 0.0) : host * 0.3, 1.0);
		return;
	}

	const float visible = zm < zh + allow ? 1.0 : 0.0;
	const float cover = world.a * visible;
	outColor = float4(relight(world.rgb, uv, zm) * visible + host * (1.0 - cover), 1.0);
	outInfo = float4(cover, cover > 0.0 ? zm : 0.0, zh, 0.0);
}

/// Minecraft's bright parts (lava, fire, the portal, blazes): what glows.
float4 PS_Bright(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
	const float cover = tex2D0(sMcInfo, uv).x;
	const float3 c = tex2D0(sComposite, uv).rgb;
	const float l = luma(c);
	return float4(c * (cover * saturate((l - BloomThreshold) / max(1.0 - BloomThreshold, 1e-3)) / max(l, 1e-3)), 1.0);
}

/// The finished picture: the world (shaken as one: GTA and Minecraft together), Minecraft's edges softened, contact
/// shadows on GTA's surfaces next to Minecraft's, Minecraft's glow, the portal's warp, and Minecraft's hand and HUD on
/// top (neither shaken nor warped).
float3 PS_Final(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
	if (!McActive)
		return tex2D0(ReShade::BackBuffer, uv).rgb;
	const float aspect = BUFFER_WIDTH * BUFFER_RCP_HEIGHT;
	const float t = Timer * 0.001;
	// shake: rotate and move the picture a little, zoomed in just enough that no edge shows
	const float amount = length(Shake.xy) + abs(Shake.z) * 0.5;
	const float zoom = 1.0 + amount * 2.2 + PortalWarp * 0.06;
	float2 d = (uv - 0.5) * float2(aspect, 1.0) / zoom;
	// the portal: a swirl and waves, strongest in the middle
	if (PortalWarp > 0.0)
	{
		const float r = length(d);
		const float swirl = PortalWarp * 1.1 * exp(-r * 2.2) * sin(t * 1.7 + 1.0);
		const float cs = cos(swirl), sn = sin(swirl);
		d = float2(d.x * cs - d.y * sn, d.x * sn + d.y * cs);
		d += PortalWarp * 0.014 * float2(sin(d.y * 38.0 + t * 7.0), cos(d.x * 31.0 + t * 6.0));
	}
	const float cr = cos(Shake.z), sr = sin(Shake.z);
	d = float2(d.x * cr - d.y * sr, d.x * sr + d.y * cr) + Shake.xy;
	const float2 wuv = d / float2(aspect, 1.0) + 0.5;

	const float2 px = BUFFER_PIXEL_SIZE;
	float3 color = tex2D0(sComposite, wuv).rgb;
	const float4 info = tex2D0(sMcInfo, wuv);
	// soften where Minecraft meets GTA (GTA's anti-aliasing never saw Minecraft)
	if (EdgeSoftness > 0.0)
	{
		const float c1 = tex2D0(sMcInfo, wuv + float2(px.x, 0)).x, c2 = tex2D0(sMcInfo, wuv - float2(px.x, 0)).x;
		const float c3 = tex2D0(sMcInfo, wuv + float2(0, px.y)).x, c4 = tex2D0(sMcInfo, wuv - float2(0, px.y)).x;
		const float edge = saturate(abs(c1 - info.x) + abs(c2 - info.x) + abs(c3 - info.x) + abs(c4 - info.x));
		if (edge > 0.0)
		{
			const float3 n = tex2D0(sComposite, wuv + float2(px.x, 0)).rgb + tex2D0(sComposite, wuv - float2(px.x, 0)).rgb
				+ tex2D0(sComposite, wuv + float2(0, px.y)).rgb + tex2D0(sComposite, wuv - float2(0, px.y)).rgb;
			color = lerp(color, (color * 2.0 + n) / 6.0, edge * EdgeSoftness);
		}
	}
	// contact shadows: GTA surface pixels with Minecraft surfaces close by (in depth), mostly above them
	if (ContactShadow > 0.0 && info.x < 0.5 && info.z < 200.0)
	{
		const float zh = info.z;
		const float r = clamp(ContactRadius / max(zh, 0.5) * BUFFER_HEIGHT / (2.0 * WarpTan.x), 2.0, 48.0);
		float occ = 0.0, weight = 0.0;
		[unroll] for (int i = 0; i < 10; ++i)
		{
			const float a = i * 2.39996 + 0.6; // golden-angle spiral
			const float rr = r * sqrt((i + 0.5) / 10.0);
			const float2 o = float2(cos(a), sin(a)) * rr;
			const float4 sm = tex2Dlod(sMcInfo, float4(wuv + o * px, 0, 0));
			const float w = o.y < 0.0 ? 1.0 : 0.35; // things stand on the ground: their shadow is below them
			weight += w;
			if (sm.x > 0.5 && abs(sm.y - zh) < ContactRadius * 1.5)
				occ += w * (1.0 - rr / (r + 1.0));
		}
		color *= 1.0 - ContactShadow * saturate(occ / max(weight, 1e-3) * 2.2);
	}
	// Minecraft's glow
	if (BloomStrength > 0.0)
	{
		const float3 b = tex2Dlod(sMcBright, float4(wuv, 0, 1.0)).rgb * 0.5 + tex2Dlod(sMcBright, float4(wuv, 0, 2.5)).rgb * 0.8
			+ tex2Dlod(sMcBright, float4(wuv, 0, 4.0)).rgb;
		color += b * BloomStrength;
	}
	// the portal's purple
	if (PortalWarp > 0.0)
	{
		const float r = length((uv - 0.5) * float2(aspect, 1.0));
		const float3 purple = color * float3(0.72, 0.38, 1.25) + float3(0.12, 0.0, 0.22) * (0.6 + 0.4 * sin(t * 3.0 + r * 9.0));
		color = lerp(color, purple, saturate(PortalWarp * (0.55 + r * 0.6)));
	}
	const float2 ouv2 = float2(uv.x, 1.0 - uv.y);
	const float4 overlay = fsr_on() ? tex2D0(sOverlayUp, ouv2) : tex2D0(sOverlay, ouv2); // screen-space: never shaken
	return overlay.rgb + saturate(color) * (1.0 - overlay.a);
}

technique FusionBridgeSA < ui_tooltip = "FusionBridge: Minecraft dentro do GTA SA. Liga sozinho quando o Minecraft esta conectado."; >
{
	pass Light
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_Light;
		RenderTarget = GtaLightTex;
	}
	pass EasuWorld
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_EasuWorld;
		RenderTarget = McUpTex;
	}
	pass RcasWorld
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_RcasWorld;
		RenderTarget = McSharpTex;
	}
	pass EasuOverlay
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_EasuOverlay;
		RenderTarget = OverlayUpTex;
	}
	pass Composite
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_Composite;
		RenderTarget0 = CompositeTex;
		RenderTarget1 = McInfoTex;
	}
	pass Bright
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_Bright;
		RenderTarget = McBrightTex;
	}
	pass Final
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_Final;
	}
}
