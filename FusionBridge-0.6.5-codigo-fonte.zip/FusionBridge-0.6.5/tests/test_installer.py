"""Tests for app/fb_installer.py (the in-app installer that replaced INSTALAR/REMOVER), on fake GTA/Minecraft folders.
usage: python3 -I tests/test_installer.py"""
import hashlib, io, json, os, shutil, struct, sys, tempfile, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "app"))
import fb_installer as fi  # noqa: E402

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(detail)[:400]), flush=True)


def fake_pe(signature_va=0x82457C, value=0x94BF):
    """A minimal PE32 with one section that holds `value` at `signature_va` (image base 0x400000)."""
    base, sect_rva, raw_ptr, raw_size = 0x400000, 0x401000, 0x400, 0x430000
    pe = 0x80
    data = bytearray(raw_ptr + raw_size)
    data[0:2] = b"MZ"
    struct.pack_into("<I", data, 0x3C, pe)
    data[pe:pe + 4] = b"PE\0\0"
    struct.pack_into("<HH", data, pe + 4, 0x14C, 1)          # machine, 1 section
    struct.pack_into("<H", data, pe + 20, 224)               # optional header size
    opt = pe + 24
    struct.pack_into("<H", data, opt, 0x10B)
    struct.pack_into("<I", data, opt + 28, base)
    sec = opt + 224
    data[sec:sec + 8] = b".text\0\0\0"
    struct.pack_into("<IIII", data, sec + 8, raw_size, sect_rva, raw_size, raw_ptr)
    off = raw_ptr + (signature_va - base - sect_rva)
    struct.pack_into("<I", data, off, value)
    return bytes(data)


def sha(b):
    return hashlib.sha256(b).hexdigest().upper()


def setup(tmp, d3d9=False, old_lua=False):
    local, appdata, gta = (os.path.join(tmp, n) for n in ("local", "appdata", "GTA San Andreas"))
    os.makedirs(os.path.join(gta, "moonloader"))
    open(os.path.join(gta, "gta_sa.exe"), "wb").write(fake_pe())
    open(os.path.join(gta, "MoonLoader.asi"), "wb").write(b"moon")
    if d3d9:
        open(os.path.join(gta, "d3d9.dll"), "wb").write(b"enb d3d9")
        open(os.path.join(gta, "ReShade.ini"), "w").write("[old]")
    if old_lua:
        open(os.path.join(gta, "moonloader", "FusionBridgeGTA.lua"), "w").write("-- 0.1.0")
    mc = os.path.join(appdata, ".minecraft")
    ver = os.path.join(mc, "versions", fi.LOADER_VERSION)
    os.makedirs(ver)
    open(os.path.join(ver, fi.LOADER_VERSION + ".json"), "w").write("{}")
    json.dump({"profiles": {"abc": {"name": "Meu", "lastVersionId": "26.3"}}, "settings": {"x": 1}},
              open(os.path.join(mc, "launcher_profiles.json"), "w"))
    paths = fi.Paths(local=local, appdata=appdata, app_root=ROOT)
    # the official downloads, faked: the ReShade setup is an exe stub with a zip appended
    os.makedirs(paths.cache)
    zbuf = io.BytesIO()
    with zipfile.ZipFile(zbuf, "w") as z:
        z.writestr("ReShade32.dll", b"reshade32-bytes")
        z.writestr("ReShade64.dll", b"reshade64-bytes")
    fakes = {"reshade": b"MZ setup stub" + b"\0" * 64 + zbuf.getvalue(), "fabric_api": b"fabric api jar",
             "reshade_fxh": b"// ReShade.fxh", "reshadeui_fxh": b"// ReShadeUI.fxh"}
    for key, data in fakes.items():
        name, url, _, ref = fi.DEPS[key]
        fi.DEPS[key] = (name, url, sha(data), ref)
        open(os.path.join(paths.cache, name), "wb").write(data)
    return paths, gta


def main():
    with tempfile.TemporaryDirectory() as t:
        p = os.path.join(t, "a.exe")
        open(p, "wb").write(fake_pe())
        check("gta_version reads 1.0 US from the file", fi.gta_version(p) == "1.0 US", fi.gta_version(p))
        open(p, "wb").write(fake_pe(0x85EC4A))
        check("gta_version recognises 3.0 Steam", fi.gta_version(p) == "3.0 Steam", fi.gta_version(p))
        open(p, "wb").write(fake_pe(value=0x1234))
        check("gta_version unknown -> None", fi.gta_version(p) is None)
        open(p, "wb").write(b"not a pe")
        check("gta_version on garbage -> None", fi.gta_version(p) is None)

    logs = []
    with tempfile.TemporaryDirectory() as t:
        paths, gta = setup(t, old_lua=True)
        g = fi.check_gta(gta, paths)
        check("check_gta: exe, 1.0 US, MoonLoader", g["exe"] and g["version"] == "1.0 US" and g["moonloader"], g)
        m = fi.check_minecraft(paths)
        check("check_minecraft: launcher + fabric, no profile yet", m["launcher"] and m["fabric"] and not m["profile"], m)
        r = fi.install(gta, log=logs.append, paths=paths)
        files = {os.path.relpath(x, gta) for x in r["created"] if x.startswith(gta)}
        want = {"d3d9.dll", "FusionBridgeSA.asi", os.path.join("reshade-shaders", "Shaders", "FusionBridgeSA.fx"),
                os.path.join("moonloader", "FusionBridgeGTA.lua"), os.path.join("reshade-shaders", "Shaders", "ReShade.fxh"),
                os.path.join("reshade-shaders", "Shaders", "ReShadeUI.fxh"), "ReShade.ini", "ReShadePreset.ini"}
        check("install puts the GTA files", files == want, files ^ want)
        check("d3d9.dll is ReShade32 from the setup's zip", open(os.path.join(gta, "d3d9.dll"), "rb").read() == b"reshade32-bytes")
        check("ReShade.ini: standard (not reversed) depth", "RESHADE_DEPTH_INPUT_IS_REVERSED=0" in open(os.path.join(gta, "ReShade.ini")).read())
        check("new Lua 0.2.4 installed", "0.2.4" in open(os.path.join(gta, "moonloader", "FusionBridgeGTA.lua"), encoding="utf-8").read())
        baks = [b for b in r["backups"] if b["Original"].endswith("FusionBridgeGTA.lua")]
        check("old Lua kept as a backup", baks and open(baks[0]["Backup"]).read() == "-- 0.1.0", r["backups"])
        mods = os.listdir(os.path.join(paths.mc_game, "mods"))
        check("isolated Minecraft profile has the 3 mods", sorted(mods) == sorted(["passthrough-0.1.0.jar", "FusionBridgeMC-0.2.0.jar", "fabric-api-0.161.0+26.3.jar"]), mods)
        lp = json.load(open(os.path.join(paths.mc_root, "launcher_profiles.json")))
        prof = lp["profiles"].get(fi.PROFILE_ID, {})
        check("launcher profile added, others kept", prof.get("gameDir") == paths.mc_game and "abc" in lp["profiles"] and lp["settings"] == {"x": 1}, lp)
        man = json.load(open(paths.manifest))
        check("manifest records every file with its hash", len(man["Files"]) == len(r["created"]) and all(len(f["SHA256"]) == 64 for f in man["Files"]))
        check("check_gta now says ours", fi.check_gta(gta, paths)["ours"] and fi.check_gta(gta, paths)["d3d9"] == "ours")
        try:
            fi.install(gta, log=logs.append, paths=paths)
            check("second install refused", False)
        except fi.InstallError as e:
            check("second install refused (already registered)", "Remover" in str(e), e)
        # a file the player changed afterwards is preserved; ReShade's own settings (it rewrites them) are set aside,
        # and so is our own mod replaced by hand (the GTA-only zip), so Remover/Instalar never get stuck
        fx = os.path.join(gta, "reshade-shaders", "Shaders", "FusionBridgeSA.fx")
        open(fx, "a").write("// mine\n")
        lua = os.path.join(gta, "moonloader", "FusionBridgeGTA.lua")
        open(lua, "a").write("-- 0.2.3 copied by hand\n")
        fxh = os.path.join(gta, "reshade-shaders", "Shaders", "ReShade.fxh")
        open(fxh, "a").write("// another ReShade\n")
        open(os.path.join(gta, "ReShade.ini"), "a").write("; ReShade wrote this\n")
        # an install from the earlier 0.6.1 build also recorded a FusionBridgeSA.ini (the player may have edited it)
        ini = os.path.join(gta, "FusionBridgeSA.ini")
        with open(ini, "w") as f:
            f.write("[FusionBridgeSA]\nJanelaSemBordas=0\n")
        man = json.load(open(paths.manifest))
        man["Files"].append({"Path": ini, "SHA256": "0" * 64})
        json.dump(man, open(paths.manifest, "w"))
        logs.clear()
        fi.remove(log=logs.append, paths=paths)
        check("remove deletes unchanged files", not os.path.exists(os.path.join(gta, "FusionBridgeSA.asi")) and not os.path.exists(os.path.join(gta, "d3d9.dll")))
        check("remove keeps a file changed afterwards", os.path.exists(fxh) and any("preservado" in l for l in logs), logs)
        shaders = os.listdir(os.path.join(gta, "reshade-shaders", "Shaders"))
        check("our .fx changed by hand is set aside (not loaded, not left in place)", not os.path.exists(fx)
              and any(f.startswith("FusionBridgeSA.fx.fusionbridge-") for f in shaders), shaders)
        ml = os.listdir(os.path.join(gta, "moonloader"))
        check("our script replaced by hand is set aside too", any(f.startswith("FusionBridgeGTA.lua.fusionbridge-") for f in ml), ml)
        aside = [f for f in os.listdir(gta) if f.startswith("ReShade.ini.fusionbridge-")]
        check("a ReShade.ini changed by ReShade is set aside, not left in place", aside and not os.path.exists(os.path.join(gta, "ReShade.ini")),
              os.listdir(gta))
        check("an old FusionBridgeSA.ini is set aside, not left behind", not os.path.exists(ini)
              and any(f.startswith("FusionBridgeSA.ini.fusionbridge-") for f in os.listdir(gta)), os.listdir(gta))
        check("old Lua restored", open(os.path.join(gta, "moonloader", "FusionBridgeGTA.lua")).read() == "-- 0.1.0")
        lp = json.load(open(os.path.join(paths.mc_root, "launcher_profiles.json")))
        check("launcher profile removed, others kept", fi.PROFILE_ID not in lp["profiles"] and "abc" in lp["profiles"])
        check("manifest kept with the preserved file", os.path.exists(paths.manifest) and len(json.load(open(paths.manifest))["Files"]) == 1)
        os.remove(fxh)
        fi.remove(log=logs.append, paths=paths)
        check("second remove finishes and deletes the manifest", not os.path.exists(paths.manifest))
        # installing again after a Remover reuses the isolated Minecraft folder (its world stays)
        open(os.path.join(paths.mc_game, "options.txt"), "w").write("mine")
        logs.clear()
        fi.install(gta, log=logs.append, paths=paths)
        check("install again after Remover works (isolated folder reused)", os.path.exists(paths.manifest) and
              open(os.path.join(paths.mc_game, "options.txt")).read() == "mine")
        fi.remove(log=logs.append, paths=paths)
        check("... and removes again", not os.path.exists(paths.manifest) and os.path.exists(os.path.join(paths.mc_game, "options.txt")))
        # a damaged registry does not lock the player out
        open(paths.manifest, "w").write('{"Version": "0.6.1", "Fi')
        try:
            fi.remove(log=logs.append, paths=paths)
            check("remove with a damaged registry explains it", False)
        except fi.InstallError as e:
            check("remove with a damaged registry explains it", "danificado" in str(e), e)
        fi.install(gta, log=logs.append, paths=paths)
        check("install sets a damaged registry aside and installs", os.path.exists(paths.manifest) and
              any(f.startswith("instalacao.json.danificado-") for f in os.listdir(paths.state_root)))
        fi.remove(log=logs.append, paths=paths)

    with tempfile.TemporaryDirectory() as t:
        paths, gta = setup(t, d3d9=True)
        try:
            fi.install(gta, log=logs.append, paths=paths)
            check("other mod's d3d9.dll stops the install", False)
        except fi.InstallError as e:
            check("other mod's d3d9.dll stops the install", "d3d9.dll" in str(e) and "Substituir" in str(e), e)
        check("... and nothing was written", not os.path.exists(os.path.join(gta, "FusionBridgeSA.asi")) and not os.path.exists(paths.manifest))
        fi.install(gta, replace_d3d9=True, log=logs.append, paths=paths)
        bak = [f for f in os.listdir(gta) if f.startswith("d3d9.dll.antes-fusionbridge-")]
        check("with replace_d3d9 the old d3d9.dll becomes a backup", bak and open(os.path.join(gta, bak[0]), "rb").read() == b"enb d3d9", bak)
        fi.remove(log=logs.append, paths=paths)
        check("remove gives the other mod's d3d9.dll and ReShade.ini back",
              open(os.path.join(gta, "d3d9.dll"), "rb").read() == b"enb d3d9" and open(os.path.join(gta, "ReShade.ini")).read() == "[old]")

    with tempfile.TemporaryDirectory() as t:
        paths, gta = setup(t, old_lua=True)
        open(os.path.join(paths.mc_root, "launcher_profiles.json"), "w").write("{ broken json")
        try:
            fi.install(gta, log=logs.append, paths=paths)
            check("a failure mid-install raises", False)
        except Exception:
            check("a failure mid-install raises", True)
        left = [f for f in ("d3d9.dll", "FusionBridgeSA.asi", "ReShade.ini") if os.path.exists(os.path.join(gta, f))]
        check("... and rolls back every file it wrote", not left, left)
        check("... and puts the old Lua back", open(os.path.join(gta, "moonloader", "FusionBridgeGTA.lua")).read() == "-- 0.1.0")
        check("... and leaves no manifest", not os.path.exists(paths.manifest))

    with tempfile.TemporaryDirectory() as t:
        paths, gta = setup(t)
        shutil.rmtree(os.path.join(gta, "moonloader"))
        try:
            fi.install(gta, log=logs.append, paths=paths)
            check("no MoonLoader: install refused", False)
        except fi.InstallError as e:
            check("no MoonLoader: install refused with instructions", "MoonLoader" in str(e), e)

    # downloads
    with tempfile.TemporaryDirectory() as t:
        paths = fi.Paths(local=os.path.join(t, "l"), appdata=os.path.join(t, "a"), app_root=os.path.join(t, "root"))
        payload = b"official bytes"
        name, url, _, ref = fi.DEPS["fabric_api"]
        fi.DEPS["fabric_api"] = (name, url, sha(payload), ref)

        class Resp(io.BytesIO):
            def __enter__(self): return self
            def __exit__(self, *a): return False
        seen = {}

        def opener(req, timeout=0):
            seen["ua"] = req.get_header("User-agent")
            return Resp(payload)
        p = fi.get_dependency("fabric_api", paths, logs.append, opener=opener)
        check("download saved and verified", open(p, "rb").read() == payload and seen["ua"].startswith("Mozilla/5.0"), seen)
        os.remove(p)
        try:
            fi.get_dependency("fabric_api", paths, logs.append, opener=lambda req, timeout=0: Resp(b"tampered"))
            check("wrong SHA-256 refused", False)
        except fi.InstallError as e:
            check("wrong SHA-256 refused and file deleted", "SHA-256" in str(e) and not os.path.exists(os.path.join(paths.cache, name)), e)

        def boom(req, timeout=0):
            raise OSError("403 Forbidden")
        try:
            fi.get_dependency("fabric_api", paths, logs.append, opener=boom)
            check("failed download explains the manual way", False)
        except fi.InstallError as e:
            check("failed download explains the manual way", url in str(e) and paths.cache in str(e), e)
        os.makedirs(os.path.join(paths.app_root, "_downloads"))
        open(os.path.join(paths.app_root, "_downloads", name), "wb").write(payload)
        check("a file put by hand in _downloads is used", fi.get_dependency("fabric_api", paths, logs.append, opener=boom).endswith(name))

    # a 0.6.0 (PowerShell) record: BOM, a lone Files object, Backups null
    with tempfile.TemporaryDirectory() as t:
        paths, gta = setup(t)
        asi = os.path.join(gta, "FusionBridgeSA.asi")
        open(asi, "wb").write(b"asi")
        os.makedirs(paths.state_root)
        rec = {"Version": "0.6.0", "Game": gta, "McGame": paths.mc_game, "LauncherProfile": os.path.join(paths.mc_root, "launcher_profiles.json"),
               "ProfileId": fi.PROFILE_ID, "Files": {"Path": asi, "SHA256": sha(b"asi")}, "Backups": None}
        open(paths.manifest, "w", encoding="utf-8-sig").write(json.dumps(rec))
        fi.remove(log=logs.append, paths=paths)
        check("removes a 0.6.0 PowerShell install too", not os.path.exists(asi) and not os.path.exists(paths.manifest))

    with tempfile.TemporaryDirectory() as t:
        paths, gta = setup(t)
        os.makedirs(paths.state_root)
        evil = {"Game": gta, "McGame": paths.mc_game, "Files": [{"Path": os.path.join(t, "outside.txt"), "SHA256": "00"}], "Backups": []}
        open(os.path.join(t, "outside.txt"), "w").write("keep me")
        json.dump(evil, open(paths.manifest, "w"))
        try:
            fi.remove(log=logs.append, paths=paths)
            check("a record pointing outside the game folder is refused", False)
        except fi.InstallError:
            check("a record pointing outside the game folder is refused", os.path.exists(os.path.join(t, "outside.txt")))

    # a protected game folder (Program Files): a clear message, nothing left behind
    with tempfile.TemporaryDirectory() as t:
        paths, gta = setup(t)
        real_copy = shutil.copyfile

        def denied(src, dst, *a, **k):
            if dst.startswith(gta):
                raise PermissionError(13, "Access is denied", dst)
            return real_copy(src, dst, *a, **k)
        fi.shutil.copyfile = denied
        try:
            fi.install(gta, log=logs.append, paths=paths)
            check("protected folder: install refused", False)
        except fi.InstallError as e:
            check("protected folder: asks for administrator", e.needs_admin and "administrador" in str(e), e)
        finally:
            fi.shutil.copyfile = real_copy
        check("... and leaves nothing behind", not os.path.exists(os.path.join(gta, "d3d9.dll")) and not os.path.exists(paths.manifest))

    # "Minecraft automático": the jars go to the portable Prism's instance; no official launcher or Fabric installer
    with tempfile.TemporaryDirectory() as t:
        paths, gta = setup(t)
        shutil.rmtree(os.path.join(paths.appdata, ".minecraft"))
        saves = os.path.join(t, "docs", "GTA San Andreas User Files")
        os.makedirs(saves)
        open(os.path.join(saves, "GTASAsf1.b"), "wb").write(b"save1")
        real = fi.gta_saves_dir
        fi.gta_saves_dir = lambda: saves
        try:
            try:
                fi.install(gta, log=logs.append, paths=paths)
                check("launcher mode without the Fabric loader: refused", False)
            except fi.InstallError as e:
                check("launcher mode without the Fabric loader: refused, pointing to the automatic Minecraft",
                      "automatico" in str(e).lower(), e)
            inst = os.path.join(paths.local, "FusionBridge", "Prism", "instances", "FusionBridge", ".minecraft")
            fi.install(gta, log=logs.append, paths=paths, mc_mode="prism", mc_game=inst)
            m = fi.load_manifest(paths)
            check("prism mode: installs without the official launcher", bool(m) and m.get("McMode") == "prism" and
                  m.get("LauncherProfile") == "" and os.path.normcase(m.get("McGame")) == os.path.normcase(inst), m)
            check("... the three jars go to the Prism instance", all(os.path.isfile(os.path.join(inst, "mods", n)) for n in
                  ("passthrough-0.1.0.jar", "FusionBridgeMC-0.2.0.jar", "fabric-api-0.161.0+26.3.jar")))
            check("... the GTA side is installed as usual", os.path.isfile(os.path.join(gta, "FusionBridgeSA.asi")) and
                  os.path.isfile(os.path.join(gta, "d3d9.dll")))
            bk = (m or {}).get("SavesBackup")
            check("... the GTA saves were copied first", bool(bk) and os.path.isfile(os.path.join(bk, "GTASAsf1.b")), bk)
            check("... and no launcher profile file was created",
                  not os.path.exists(os.path.join(paths.appdata, ".minecraft", "launcher_profiles.json")))
            fi.remove(log=logs.append, paths=paths)
            check("prism mode: Remover takes the jars out of the instance",
                  not os.path.exists(os.path.join(inst, "mods", "FusionBridgeMC-0.2.0.jar")) and not os.path.exists(paths.manifest))
            check("... and the saves backup stays", os.path.isfile(os.path.join(bk, "GTASAsf1.b")))
            try:
                fi.install(gta, log=logs.append, paths=paths, mc_mode="prism", mc_game=None)
                check("prism mode without the instance folder: refused", False)
            except fi.InstallError:
                check("prism mode without the instance folder: refused", not os.path.exists(paths.manifest))
        finally:
            fi.gta_saves_dir = real
    with tempfile.TemporaryDirectory() as t:
        paths, _ = setup(t)
        check("GTA saves backup without a saves folder: nothing, no error",
              fi.backup_gta_saves(paths, logs.append, saves=os.path.join(t, "none")) is None)
        big = os.path.join(t, "big")
        os.makedirs(big)
        open(os.path.join(big, "x"), "wb").write(b"0" * 2048)
        check("... a saves folder over the size limit is not copied", fi.backup_gta_saves(paths, logs.append, saves=big, limit=1024) is None)
    check("the Prism and SkyCraft downloads are pinned (official GitHub, SHA-256)",
          fi.DEPS["prism"][1].startswith("https://github.com/PrismLauncher/") and len(fi.DEPS["prism"][2]) == 64 and
          fi.DEPS["skycraft"][1].startswith("https://github.com/chasmlol/SkyCraft/") and len(fi.DEPS["skycraft"][2]) == 64)

    check("sac_state off Windows -> unknown", fi.sac_state() == "unknown")
    check("signature of a missing file -> ausente", fi.signature("/nope/x.dll") == "ausente")
    bad = [n for n, ok in results if not ok]
    print("\n%d/%d passaram" % (len(results) - len(bad), len(results)))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
