#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)
#  define FBGTA_EXPORT __declspec(dllexport)
#else
#  define FBGTA_EXPORT __attribute__((visibility("default")))
#endif

typedef struct FusionBridgeGtaApi {
    uint32_t abi_version;

    // Optional logger supplied by the GTA loader adapter.
    void (*log)(const char* message);

    // Return player state if available. Return 1 on success, 0 otherwise.
    int (*get_player_state)(float* x, float* y, float* z,
                            float* yaw, float* health,
                            int* in_vehicle, float* vehicle_health);

    // Minecraft -> GTA actions. The loader-specific adapter implements these
    // using the APIs/hooks available for the exact GTA SA Android build.
    int  (*spawn_proxy_entity)(const char* kind, int64_t fusion_id,
                               float x, float y, float z);
    void (*move_proxy_entity)(int64_t fusion_id, float x, float y, float z);
    void (*remove_proxy_entity)(int64_t fusion_id);
    void (*create_explosion)(float x, float y, float z, float radius, float damage);
    int  (*place_proxy_block)(const char* block_id, int64_t fusion_id,
                              float x, float y, float z);
    void (*remove_proxy_block)(int64_t fusion_id);
} FusionBridgeGtaApi;

// Configure callbacks before starting the bridge. Passing nullptr installs a safe stub API.
FBGTA_EXPORT void FusionBridgeGTA_SetApi(const FusionBridgeGtaApi* api);

// Starts the localhost bridge worker. Safe to call more than once.
FBGTA_EXPORT int FusionBridgeGTA_Init(void);

// Call once per GTA frame/tick from your loader adapter. This is where queued
// Minecraft events are applied to GTA, so game APIs stay on GTA's main thread.
FBGTA_EXPORT void FusionBridgeGTA_Tick(void);

// Stops background networking and releases resources.
FBGTA_EXPORT void FusionBridgeGTA_Shutdown(void);

// Human-readable module version.
FBGTA_EXPORT const char* FusionBridgeGTA_Version(void);

#ifdef __cplusplus
}
#endif
