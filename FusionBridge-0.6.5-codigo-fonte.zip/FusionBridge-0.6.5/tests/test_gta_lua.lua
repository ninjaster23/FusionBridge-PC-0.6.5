-- Offline logic test for moonloader/FusionBridgeGTA.lua (run with luajit).
-- Stubs the GTA opcode wrappers so handle()/rules/HUD math run without the game or Windows.
_G.FB_TEST = true

-- ---- game state the stubs report
local cjx, cjy, cjz, cjh, cjhp = 100.0, 200.0, 10.0, 90.0, 73
local calls = { obj = {}, boom = {}, heal = {}, shake = {}, del = {} }

-- ---- MoonLoader API stubs
function script_name() end
function script_author() end
function script_version() end
PLAYER_PED, PLAYER_HANDLE = 1, 0
function isPlayerPlaying() return true end
function getCharCoordinates() return cjx, cjy, cjz end
function getCharHeading() return cjh end
function getCharHealth() return cjhp end
function setCharHealth(ped, hp) calls.heal[#calls.heal + 1] = hp end
function requestModel() end
function loadAllModelsNow() end
function markModelAsNoLongerNeeded() end
function createObject(m, x, y, z) calls.obj[#calls.obj + 1] = { m = m, x = x, y = y, z = z }; return 1000 + #calls.obj end
function deleteObject(h) calls.del[#calls.del + 1] = h end
function addExplosion(x, y, z, t) calls.boom[#calls.boom + 1] = { x = x, y = y, z = z, t = t } end
function shakeCam(ms) calls.shake[#calls.shake + 1] = ms end
function getScreenResolution() return 1920, 1080 end
function renderDrawBox() end
function wait() end

local M = assert(loadfile('moonloader/FusionBridgeGTA.lua'))()

-- ---- test harness
local pass, fail = 0, 0
local function check(name, cond, detail)
  if cond then pass = pass + 1; print('PASS ' .. name)
  else fail = fail + 1; print('FAIL ' .. name .. (detail and ('  -> ' .. tostring(detail)) or '')) end
end
local sent
local conn = { send_line = function(self, l) sent[#sent + 1] = l; return true end }
local function feed(line) sent = {}; M.handle(conn, line) end
local function last_result() for i = #sent, 1, -1 do if sent[i]:find('command_result') then return sent[i] end end end
local function dist(a, b, x, y) return math.sqrt((a - x) ^ 2 + (b - y) ^ 2) end

-- JSON extractors
check('jstr reads a string field', M.jstr('{"type":"command","action":"block"}', 'action') == 'block')
check('jnum reads a number field', M.jnum('{"id":42,"model":1224}', 'model') == 1224)
check('jnum reads negatives/floats', M.jnum('{"x":-3.5}', 'x') == -3.5)
check('half from health: 73 -> 15 half-hearts', M.half_from_health(73) == 15, M.half_from_health(73))
check('half from health: 100 -> 20', M.half_from_health(100) == 20)
check('half from health: 0 -> 0', M.half_from_health(0) == 0)

-- block in front of CJ (~3 m)
calls.obj = {}
feed('{"type":"command","to":"gta","action":"block","model":1224,"id":1}')
check('block creates one object', #calls.obj == 1, #calls.obj)
check('block is ~3 m from CJ', calls.obj[1] and math.abs(dist(cjx, cjy, calls.obj[1].x, calls.obj[1].y) - 3) < 0.6,
      calls.obj[1] and dist(cjx, cjy, calls.obj[1].x, calls.obj[1].y))
check('block uses the requested model', calls.obj[1] and calls.obj[1].m == 1224)
check('block reports ok', (last_result() or ''):find('"ok":true') ~= nil, last_result())

-- numeric params cannot inject JSON (model is read as a number only)
calls.obj = {}
feed('{"type":"command","to":"gta","action":"block","model":1,"id":2}')
check('block model read as number (no injection)', calls.obj[1] and calls.obj[1].m == 1, calls.obj[1] and calls.obj[1].m)

-- boom / boom_rain
calls.boom = {}
feed('{"type":"command","to":"gta","action":"boom","id":3}')
check('boom creates one explosion', #calls.boom == 1, #calls.boom)
calls.boom = {}
feed('{"type":"command","to":"gta","action":"boom_rain","id":4}')
check('boom_rain creates 8 explosions', #calls.boom == 8, #calls.boom)

-- heal / shake
calls.heal = {}
feed('{"type":"command","to":"gta","action":"heal","id":5}')
check('heal sets health to 100', calls.heal[1] == 100, calls.heal[1])
calls.shake = {}
feed('{"type":"command","to":"gta","action":"shake","id":6}')
check('shake triggers camera shake', #calls.shake == 1)

-- unknown action refused
feed('{"type":"command","to":"gta","action":"format_c","id":7}')
check('unknown action refused', (last_result() or ''):find('"ok":false') ~= nil, last_result())

-- command for another target ignored
calls.boom = {}
feed('{"type":"command","to":"minecraft*","action":"boom","id":8}')
check('command for another target ignored', #calls.boom == 0 and #sent == 0)

-- fusion: MC explosion -> GTA explosion (rule on by default)
calls.boom = {}
M.handle(conn, '{"type":"event","from":"minecraft_server","event":"explosion","entity":"tnt"}')
check('MC TNT -> GTA explosion', #calls.boom == 1, #calls.boom)
check('fusion explosion lands near CJ (<=15 m)', calls.boom[1] and dist(cjx, cjy, calls.boom[1].x, calls.boom[1].y) <= 15,
      calls.boom[1] and dist(cjx, cjy, calls.boom[1].x, calls.boom[1].y))

-- wither -> 2 explosions + shake
calls.boom, calls.shake = {}, {}
M.handle(conn, '{"type":"event","from":"minecraft","event":"entity_spawn","entity":"wither"}')
check('MC Wither -> 2 explosions + shake', #calls.boom == 2 and #calls.shake == 1, #calls.boom .. '/' .. #calls.shake)

-- rules off: disable tnt, then MC explosion does nothing
M.handle(conn, '{"type":"command","to":"gta","action":"rules","tnt":0,"wither":1,"lightning":0,"creeper":1}')
calls.boom = {}
M.handle(conn, '{"type":"event","from":"minecraft","event":"explosion","entity":"tnt"}')
check('rule off: TNT no longer explodes in GTA', #calls.boom == 0, #calls.boom)
calls.boom = {}
M.handle(conn, '{"type":"event","from":"minecraft","event":"entity_spawn","entity":"lightning"}')
check('rule off: lightning disabled', #calls.boom == 0)
M.handle(conn, '{"type":"event","from":"minecraft","event":"entity_spawn","entity":"wither"}')
check('rule still on: wither works', #calls.boom == 2)

-- HUD toggle
M.handle(conn, '{"type":"command","to":"gta","action":"hud","on":0}')
check('hud off', M.state().hud == false)
M.handle(conn, '{"type":"command","to":"gta","action":"hud","on":1}')
check('hud on', M.state().hud == true)

-- mode from fusion_config
M.handle(conn, '{"type":"fusion_config","mode":"live","protocol":2}')
check('mode follows fusion_config', M.state().mode == 'live')

-- our own gta player_state is ignored; minecraft player_state is stored
M.set_mc(0, 0, 0)
M.handle(conn, '{"type":"player_state","side":"gta","x":5,"y":5,"z":5}')
check('own gta state ignored', M.state().mc.x == 0)
M.handle(conn, '{"type":"player_state","from":"minecraft","x":7,"y":8,"z":9}')
check('minecraft state stored', M.state().mc.x == 7)

print(('\n%d/%d passed'):format(pass, pass + fail))
os.exit(fail == 0 and 0 or 1)
