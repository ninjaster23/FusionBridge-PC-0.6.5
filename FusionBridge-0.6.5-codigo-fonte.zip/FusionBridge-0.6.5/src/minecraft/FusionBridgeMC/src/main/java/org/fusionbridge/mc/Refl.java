// Reflexao com cache: acha metodos e campos do Minecraft pelo nome, sem depender dos mapeamentos.
package org.fusionbridge.mc;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

final class Refl {
    private static final Map<String, Method> METHODS = new ConcurrentHashMap<>();
    private static final Map<String, Field> FIELDS = new ConcurrentHashMap<>();
    private static final Method NONE;

    private Refl() {
    }

    static Class<?> cls(String var0) {
        try {
            return Class.forName(var0, false, Refl.class.getClassLoader());
        } catch (Throwable var4) {
            try {
                return Class.forName(var0, false, Thread.currentThread().getContextClassLoader());
            } catch (Throwable var3) {
                return null;
            }
        }
    }

    private static boolean fits(Class<?>[] var0, Object[] var1) {
        if (var0.length != var1.length) {
            return false;
        } else {
            for (int var2 = 0; var2 < var0.length; var2++) {
                Object var3 = var1[var2];
                if (var3 == null) {
                    if (var0[var2].isPrimitive()) {
                        return false;
                    }
                } else {
                    Class var4 = box(var0[var2]);
                    if (!var4.isInstance(var3)) {
                        return false;
                    }
                }
            }

            return true;
        }
    }

    private static Class<?> box(Class<?> var0) {
        if (!var0.isPrimitive()) {
            return var0;
        } else if (var0 == int.class) {
            return Integer.class;
        } else if (var0 == long.class) {
            return Long.class;
        } else if (var0 == double.class) {
            return Double.class;
        } else if (var0 == float.class) {
            return Float.class;
        } else if (var0 == boolean.class) {
            return Boolean.class;
        } else if (var0 == short.class) {
            return Short.class;
        } else if (var0 == byte.class) {
            return Byte.class;
        } else {
            if (var0 == char.class) {
                return Character.class;
            }
            return var0;
        }
    }

    static Method find(Class<?> var0, String var1, Object... var2) {
        StringBuilder var3 = new StringBuilder(var0.getName()).append('#').append(var1);

        for (Object var7 : var2) {
            var3.append(',').append(var7 == null ? "null" : var7.getClass().getName());
        }

        String var17 = var3.toString();
        Method var18 = METHODS.get(var17);
        if (var18 != null) {
            return var18 == NONE ? null : var18;
        } else {
            Method var19 = null;

            for (Class var20 = var0; var20 != null && var19 == null; var20 = var20.getSuperclass()) {
                for (Method var11 : var20.getDeclaredMethods()) {
                    if (var11.getName().equals(var1) && fits(var11.getParameterTypes(), var2)) {
                        var19 = var11;
                        break;
                    }
                }

                if (var19 == null) {
                    for (Class var24 : var20.getInterfaces()) {
                        for (Method var15 : var24.getMethods()) {
                            if (var15.getName().equals(var1) && fits(var15.getParameterTypes(), var2)) {
                                var19 = var15;
                                break;
                            }
                        }

                        if (var19 != null) {
                            break;
                        }
                    }
                }
            }

            if (var19 != null) {
                try {
                    var19.setAccessible(true);
                } catch (Throwable var16) {
                }
            }

            METHODS.put(var17, var19 == null ? NONE : var19);
            return var19;
        }
    }

    static Object call(Object var0, String var1, Object... var2) {
        if (var0 == null) {
            return null;
        } else {
            Method var3 = find(var0.getClass(), var1, var2);
            if (var3 == null) {
                FusionCore.reflMiss(var0.getClass().getSimpleName() + "." + var1);
                return null;
            } else {
                try {
                    return var3.invoke(var0, var2);
                } catch (Throwable var5) {
                    FusionCore.reflError(var1, var5);
                    return null;
                }
            }
        }
    }

    static Object callStrict(Object var0, String var1, Object... var2) throws Throwable {
        Method var3 = find(var0.getClass(), var1, var2);
        if (var3 == null) {
            throw new NoSuchMethodException(var0.getClass().getName() + "." + var1);
        } else {
            try {
                return var3.invoke(var0, var2);
            } catch (InvocationTargetException var5) {
                throw (Throwable)(var5.getCause() == null ? var5 : var5.getCause());
            }
        }
    }

    static boolean has(Object var0, String var1, Object... var2) {
        return var0 != null && find(var0.getClass(), var1, var2) != null;
    }

    static Object scall(String var0, String var1, Object... var2) {
        Class var3 = cls(var0);
        if (var3 == null) {
            FusionCore.reflMiss(var0);
            return null;
        } else {
            Method var4 = find(var3, var1, var2);
            if (var4 == null || !Modifier.isStatic(var4.getModifiers())) {
                FusionCore.reflMiss(var0 + "." + var1);
                return null;
            }
            try {
                return var4.invoke(null, var2);
            } catch (Throwable var6) {
                FusionCore.reflError(var1, var6);
                return null;
            }
        }
    }

    static Object field(Object var0, String var1) {
        if (var0 == null) {
            return null;
        } else {
            String var2 = var0.getClass().getName() + "." + var1;
            Field var3 = FIELDS.get(var2);
            if (var3 == null) {
                for (Class var4 = var0.getClass(); var4 != null && var3 == null; var4 = var4.getSuperclass()) {
                    try {
                        var3 = var4.getDeclaredField(var1);
                        var3.setAccessible(true);
                    } catch (Throwable var7) {
                        var3 = null;
                    }
                }

                if (var3 == null) {
                    FusionCore.reflMiss(var0.getClass().getSimpleName() + "." + var1);
                    return null;
                }

                FIELDS.put(var2, var3);
            }

            try {
                return var3.get(var0);
            } catch (Throwable var6) {
                return null;
            }
        }
    }

    static double num(Object var0, String var1) {
        Object var2 = call(var0, var1);
        return var2 instanceof Number ? ((Number)var2).doubleValue() : Double.NaN;
    }

    static {
        try {
            NONE = Object.class.getMethod("hashCode");
        } catch (NoSuchMethodException var1) {
            throw new IllegalStateException(var1);
        }
    }
}
