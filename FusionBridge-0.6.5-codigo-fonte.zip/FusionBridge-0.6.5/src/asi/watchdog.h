// Hang watchdog of FusionBridgeSA.asi: when GTA's main thread stops finishing frames, it writes to FusionBridgeSA.log
// where that thread is (the module and offset of the instruction it is on, and the return addresses on its stack), so
// a freeze on a player's PC can be traced without a debugger.
#pragma once
#include <windows.h>

namespace watchdog
{
	/// What the ASI was doing on the main thread, shown in the report (set around the risky calls).
	enum Stage
	{
		kIdle,
		kPads,
		kHud,
		kRenderEffects,
		kBeginEffects,
		kOpenMapping,
		kUpload,
		kCreateTextures,
		kRegister,
		kStageCount
	};

	/// Starts the watchdog thread (call once, from DllMain: the thread runs after the loader lets go). `log` writes
	/// one line to FusionBridgeSA.log. The module is pinned so the thread never outlives it.
	void start(HMODULE self, void (*log)(const char *line));
	/// Asks the thread to stop (process exit).
	void stop();
	/// From GTA's main thread once per frame (the pads hook, the HUD hook, ReShade's present).
	void beat();
	void stage(Stage s);
}
