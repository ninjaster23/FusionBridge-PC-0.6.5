"""FusionBridge PC 0.6.5 - install / remove the visual fusion from inside the app, and Windows security checks.

This is the 0.6.0 INSTALAR/REMOVER (PowerShell) ported to Python, so nothing outside the signed app runs:
under Smart App Control, unsigned PowerShell scripts run in Constrained Language Mode, where the old installer's
.NET calls fail. Same behaviour and the same record (instalacao.json), so a 0.6.0 install is removed here too.

  GTA SA folder:   d3d9.dll (ReShade 6.8.0 add-on, 32-bit), FusionBridgeSA.asi, reshade-shaders\\Shaders\\
                   FusionBridgeSA.fx (+ ReShade.fxh, ReShadeUI.fxh), ReShade.ini, ReShadePreset.ini,
                   moonloader\\FusionBridgeGTA.lua (an older one becomes a backup)
  Minecraft:       passthrough, FusionBridgeMC, Fabric API in the portable Prism's FusionBridge instance ("Minecraft
                   automático", fb_prism.py), or in an isolated official-launcher profile (its own game folder)
  Saves:           a copy of Documents\\GTA San Andreas User Files is made before anything is written

Downloads come from the official sites and are checked against fixed SHA-256 hashes. Nothing is overwritten:
files of other mods stop the install (d3d9.dll/ReShade only with replace_d3d9, kept as a backup).
"""
import ctypes
import datetime
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import urllib.parse
import urllib.request
import uuid
import zipfile

IS_WINDOWS = sys.platform == "win32"
VERSION = "0.6.5"
LOADER_VERSION = "fabric-loader-0.19.5-26.3"
PROFILE_ID = "fusionbridge-minecraft-gtasa"
PROFILE_NAME = "FusionBridge - Minecraft no GTA SA"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"

DEPS = {
    "reshade": ("ReShade_Setup_6.8.0_Addon.exe", "https://reshade.me/downloads/ReShade_Setup_6.8.0_Addon.exe",
                "AFE4C8F13048306307983B8B3D41D5BF00A86820440B0E57DEA10950E1176445", "https://reshade.me/"),
    "fabric_api": ("fabric-api-0.161.0+26.3.jar",
                   "https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/0.161.0+26.3/fabric-api-0.161.0+26.3.jar",
                   "86F16178A3CECC887A85A4CFE9A79D92FA7341D8F39B5951A4D6AD800AB657A6", ""),
    "reshade_fxh": ("ReShade.fxh", "https://raw.githubusercontent.com/crosire/reshade-shaders/"
                    "fd0022170615ce0d8162d219bff07232fa6dd84f/Shaders/ReShade.fxh",
                    "6DABFBBAF968C3871905D2EA17F96572FF7B1CEC01310B5D0E5252B66B30174F", ""),
    "reshadeui_fxh": ("ReShadeUI.fxh", "https://raw.githubusercontent.com/crosire/reshade-shaders/"
                      "fd0022170615ce0d8162d219bff07232fa6dd84f/Shaders/ReShadeUI.fxh",
                      "78ADF672DF47460297EB9FE6DD238D2AAFA24510B52B84FEB1A745DFF70EB901", ""),
    # FSR 1.0 for any game's window (fb_upscale.py): Magpie's official release (hash as in the Scoop Extras bucket)
    "magpie": ("Magpie-v0.12.1-x64.zip", "https://github.com/Blinue/Magpie/releases/download/v0.12.1/Magpie-v0.12.1-x64.zip",
               "8BC8BC233438F546B7996B00B21D7376F4F7D3D8A4940E6A8800BABD2225B2DE", ""),
    # "Minecraft automático" (fb_prism.py): Prism Launcher's official portable release (the hash SkyCraft pins too)
    "prism": ("PrismLauncher-Windows-MSVC-Portable-11.1.1.zip",
              "https://github.com/PrismLauncher/PrismLauncher/releases/download/11.1.1/PrismLauncher-Windows-MSVC-Portable-11.1.1.zip",
              "AB35A770FB06D89D2CCC098079DB5DB329FB4E68F42B72BABD8B095EFDE3D2D7", ""),
    # SkyCraft (Minecraft inside Skyrim, fb_skycraft.py): chasmlol's official release
    "skycraft": ("SkyCraft-0.1.2.zip", "https://github.com/chasmlol/SkyCraft/releases/download/v0.1.2/SkyCraft-0.1.2.zip",
                 "1133ECDE384D70D5261CBC9BA149BC7B544E1653B78846A1623B56241BB392C3", ""),
}

# gta_sa.exe builds by the classic signature check (value 0x94BF at these addresses)
GTA_VERSIONS = [(0x82457C, "1.0 US"), (0x8245BC, "1.0 EU"), (0x8252FC, "1.01 US"), (0x82533C, "1.01 EU"),
                (0x85EC4A, "3.0 Steam")]

RESHADE_INI = ("[GENERAL]\r\nEffectSearchPaths=.\\reshade-shaders\\Shaders\\\r\nTextureSearchPaths=.\\reshade-shaders\\Textures\\\r\n"
               "PresetPath=.\\ReShadePreset.ini\r\nPreprocessorDefinitions=RESHADE_DEPTH_INPUT_IS_REVERSED=0,"
               "RESHADE_DEPTH_INPUT_IS_UPSIDE_DOWN=0,RESHADE_DEPTH_INPUT_IS_LOGARITHMIC=0,"
               "RESHADE_DEPTH_LINEARIZATION_FAR_PLANE=1000\r\n\r\n[OVERLAY]\r\nTutorialProgress=4\r\nShowClock=0\r\nShowFPS=0\r\n")
RESHADE_PRESET = "Techniques=FusionBridgeSA@FusionBridgeSA.fx\r\nTechniqueSorting=FusionBridgeSA@FusionBridgeSA.fx\r\n"
# the GTA mod's own files (lower case): Remover sets them aside if they were replaced, instead of keeping them in place
OWN_GTA_FILES = ("fusionbridgesa.asi", "fusionbridgegta.lua", "fusionbridgesa.fx")


class InstallError(Exception):
    """A reason the install/removal stopped, in words for the player (pt-BR)."""
    needs_admin = False


def _permission_error(e, action):
    fn = getattr(e, "filename", None) or ""
    profile = [os.environ.get(v) for v in ("APPDATA", "LOCALAPPDATA") if os.environ.get(v)]
    if fn and any(_under(fn, r) for r in profile):
        return InstallError("O Windows nao deixou %s em %s: o arquivo esta aberto em outro programa ou marcado como "
                            "somente leitura. Feche o Minecraft e o Minecraft Launcher e tente de novo." % (action, fn))
    err = InstallError("O Windows nao deixou %s em %s (pasta protegida). Feche o FusionBridge e abra de novo como "
                       "administrador: use o botao 'Reabrir como administrador' ou clique com o botao direito no "
                       "FusionBridge.exe > Executar como administrador." % (action, getattr(e, "filename", None) or "uma pasta"))
    err.needs_admin = True
    return err


# ====================================================================== paths
class Paths:
    """Where everything lives. The tests point these at a temporary folder."""

    def __init__(self, local=None, appdata=None, app_root=None):
        self.local = local or os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        self.appdata = appdata or os.environ.get("APPDATA") or os.path.expanduser("~")
        self.app_root = app_root or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.state_root = os.path.join(self.local, "FusionBridge", "MinecraftNoGTASA")
        self.mc_game = os.path.join(self.state_root, "mcgame")
        self.manifest = os.path.join(self.state_root, "instalacao.json")
        self.mc_root = os.path.join(self.appdata, ".minecraft")
        self.cache = os.path.join(self.local, "FusionBridge", "downloads")

    def cache_dirs(self):
        """Where a download may already be: our cache, or the _downloads folder of older packages."""
        return [self.cache, os.path.join(self.app_root, "_downloads")]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def _norm(p):
    return os.path.normcase(os.path.abspath(p))


def _under(path, root):
    path, root = _norm(path), _norm(root).rstrip("\\/") + os.sep
    return path.startswith(root)


# ====================================================================== detection
def find_gta_sa():
    candidates = []
    if IS_WINDOWS:
        import winreg
        for key in (r"SOFTWARE\WOW6432Node\Rockstar Games\GTA San Andreas\Installation",
                    r"SOFTWARE\Rockstar Games\GTA San Andreas\Installation"):
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key) as k:
                    exe = winreg.QueryValueEx(k, "ExePath")[0]
                    if exe:
                        candidates.append(os.path.dirname(exe.strip().strip('"')))
            except OSError:
                pass
        bases = [os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), "C:\\Games", "D:\\Games", "C:\\", "D:\\"]
        for base in bases:
            if base:
                candidates.append(os.path.join(base, "Rockstar Games", "GTA San Andreas"))
                candidates.append(os.path.join(base, "GTA San Andreas"))
    for c in candidates:
        if c and os.path.isfile(os.path.join(c, "gta_sa.exe")):
            return c
    return None


def gta_version(exe_path):
    """The gta_sa.exe build, read from the file (the signature the ASI also checks), or None if unknown."""
    try:
        with open(exe_path, "rb") as f:
            data = f.read()
    except OSError:
        return None
    try:
        if data[:2] != b"MZ":
            return None
        pe = struct.unpack_from("<I", data, 0x3C)[0]
        if data[pe:pe + 4] != b"PE\0\0":
            return None
        nsec = struct.unpack_from("<H", data, pe + 6)[0]
        opt_size = struct.unpack_from("<H", data, pe + 20)[0]
        opt = pe + 24
        image_base = struct.unpack_from("<I", data, opt + 28)[0]
        sections = []
        for i in range(nsec):
            o = opt + opt_size + 40 * i
            vsize, vaddr, rsize, rptr = struct.unpack_from("<IIII", data, o + 8)
            sections.append((vaddr, max(vsize, rsize), rsize, rptr))
        for va, name in GTA_VERSIONS:
            rva = va - image_base
            for vaddr, vspan, rsize, rptr in sections:
                if vaddr <= rva < vaddr + vspan and rva - vaddr + 4 <= rsize:
                    if struct.unpack_from("<I", data, rptr + rva - vaddr)[0] == 0x94BF:
                        return name
    except struct.error:
        return None
    return None


def is_running(exe_name):
    """True if a process with this file name runs (Windows only)."""
    if not IS_WINDOWS:
        return False
    from ctypes import wintypes

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD),
                    ("th32DefaultHeapID", ctypes.c_size_t), ("th32ModuleID", wintypes.DWORD),
                    ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD),
                    ("pcPriClassBase", ctypes.c_long), ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
    k.CreateToolhelp32Snapshot.argtypes = (wintypes.DWORD, wintypes.DWORD)
    k.Process32FirstW.argtypes = (ctypes.c_void_p, ctypes.POINTER(PROCESSENTRY32W))
    k.Process32NextW.argtypes = (ctypes.c_void_p, ctypes.POINTER(PROCESSENTRY32W))
    k.CloseHandle.argtypes = (ctypes.c_void_p,)
    snap = k.CreateToolhelp32Snapshot(0x2, 0)
    if not snap or snap == ctypes.c_void_p(-1).value:
        return False
    try:
        e = PROCESSENTRY32W()
        e.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        ok = k.Process32FirstW(snap, ctypes.byref(e))
        while ok:
            if e.szExeFile.lower() == exe_name.lower():
                return True
            ok = k.Process32NextW(snap, ctypes.byref(e))
    finally:
        k.CloseHandle(snap)
    return False


def load_manifest(paths):
    try:
        with open(paths.manifest, "r", encoding="utf-8-sig") as f:
            m = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(m, dict):
        return None
    for key in ("Files", "Backups"):            # PowerShell writes a lone item as an object, or null
        v = m.get(key)
        m[key] = [] if v is None else (v if isinstance(v, list) else [v])
    return m


def check_gta(path, paths=None):
    paths = paths or Paths()
    out = {"path": path, "exe": False, "version": None, "moonloader": False, "asi_loader": False,
           "d3d9": "none", "running": is_running("gta_sa.exe"), "ours": False}
    if not path:
        return out
    exe = os.path.join(path, "gta_sa.exe")
    out["exe"] = os.path.isfile(exe)
    if out["exe"]:
        out["version"] = gta_version(exe)
    out["moonloader"] = os.path.isdir(os.path.join(path, "moonloader")) and os.path.isfile(os.path.join(path, "MoonLoader.asi"))
    out["asi_loader"] = any(os.path.isfile(os.path.join(path, n)) for n in ("vorbisHooked.dll", "dinput8.dll", "winmm.dll", "vorbisFile.dll"))
    m = load_manifest(paths)
    d3d9 = os.path.join(path, "d3d9.dll")
    if os.path.isfile(d3d9):
        out["d3d9"] = "other"
        if m and _norm(m.get("Game", "")) == _norm(path):
            for item in m["Files"]:
                if _norm(item.get("Path", "")) == _norm(d3d9) and sha256_file(d3d9) == str(item.get("SHA256", "")).upper():
                    out["d3d9"] = "ours"
    out["ours"] = bool(m) and _norm(m.get("Game", "")) == _norm(path)
    return out


def launcher_profile_files(paths):
    return [p for p in (os.path.join(paths.mc_root, "launcher_profiles.json"),
                        os.path.join(paths.mc_root, "launcher_profiles_microsoft_store.json")) if os.path.isfile(p)]


def check_minecraft(paths=None):
    paths = paths or Paths()
    files = launcher_profile_files(paths)
    loader = os.path.join(paths.mc_root, "versions", LOADER_VERSION, LOADER_VERSION + ".json")
    profile = False
    for f in files:
        try:
            with open(f, "r", encoding="utf-8-sig") as fh:
                profile = profile or PROFILE_ID in (json.load(fh).get("profiles") or {})
        except (OSError, ValueError, AttributeError):
            pass
    return {"mc_root": os.path.isdir(paths.mc_root), "launcher": bool(files), "fabric": os.path.isfile(loader),
            "profile": profile, "running": is_running("javaw.exe")}


def _check_closed(what):
    """The games and the launcher rewrite or lock the files we touch: they must be closed first."""
    if is_running("gta_sa.exe"):
        raise InstallError("Feche o GTA San Andreas antes de %s." % what)
    if is_running("MinecraftLauncher.exe"):
        raise InstallError("Feche o Minecraft Launcher antes de %s (ele regrava a lista de perfis quando fecha)." % what)
    if is_running("javaw.exe"):
        raise InstallError("Feche o Minecraft (javaw.exe) antes de %s." % what)


def _write_json_atomic(path, data):
    tmp = path + ".fusionbridge-tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _set_aside(path, why_tag):
    """Moves a damaged/changed file out of the way (kept, never deleted): <path>.<tag>-<stamp>."""
    dest = "%s.%s-%s" % (path, why_tag, datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
    os.replace(path, dest)
    return dest


def _find_launcher_profile(paths):
    files = launcher_profile_files(paths)
    if not files:
        raise InstallError("Abra o Minecraft Launcher uma vez antes de instalar (falta o launcher_profiles.json).")
    for f in files:
        try:
            with open(f, "r", encoding="utf-8-sig") as fh:
                for v in (json.load(fh).get("profiles") or {}).values():
                    if isinstance(v, dict) and v.get("lastVersionId") == LOADER_VERSION:
                        return f
        except (OSError, ValueError, AttributeError):
            pass
    return max(files, key=os.path.getmtime)


# ====================================================================== downloads
WINHTTP_ERRORS = {12002: "tempo esgotado", 12007: "endereco nao encontrado (sem internet?)", 12029: "nao conectou ao site",
                  12030: "a conexao caiu", 12157: "erro na conexao segura", 12175: "o Windows recusou o certificado do site",
                  12037: "certificado do site vencido", 12038: "certificado do site com outro nome",
                  12045: "autoridade do certificado desconhecida", 12057: "certificado do site revogado"}


def winhttp_download(url, path, headers=None, timeout_s=120):
    """Downloads url into path with WinHTTP, like the 0.6.0 PowerShell installer did: Windows checks the site's
    certificate itself (fetching a missing root certificate the way a browser does, which Python's ssl can't on a
    fresh Windows) and uses the system proxy. Raises OSError with a reason in pt-BR."""
    from ctypes import wintypes as wt
    u = urllib.parse.urlsplit(url)
    if u.scheme not in ("https", "http") or not u.hostname:
        raise OSError("endereco invalido: %s" % url)
    wh = ctypes.WinDLL("winhttp", use_last_error=True)
    H = ctypes.c_void_p
    for fname, res, args in (
            ("WinHttpOpen", H, (wt.LPCWSTR, wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD)),
            ("WinHttpSetTimeouts", wt.BOOL, (H, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int)),
            ("WinHttpConnect", H, (H, wt.LPCWSTR, ctypes.c_ushort, wt.DWORD)),
            ("WinHttpOpenRequest", H, (H, wt.LPCWSTR, wt.LPCWSTR, wt.LPCWSTR, wt.LPCWSTR, ctypes.c_void_p, wt.DWORD)),
            ("WinHttpSendRequest", wt.BOOL, (H, wt.LPCWSTR, wt.DWORD, ctypes.c_void_p, wt.DWORD, wt.DWORD, ctypes.c_size_t)),
            ("WinHttpReceiveResponse", wt.BOOL, (H, ctypes.c_void_p)),
            ("WinHttpQueryHeaders", wt.BOOL, (H, wt.DWORD, wt.LPCWSTR, ctypes.c_void_p, ctypes.POINTER(wt.DWORD),
                                               ctypes.POINTER(wt.DWORD))),
            ("WinHttpReadData", wt.BOOL, (H, ctypes.c_void_p, wt.DWORD, ctypes.POINTER(wt.DWORD))),
            ("WinHttpCloseHandle", wt.BOOL, (H,))):
        fn = getattr(wh, fname)
        fn.restype, fn.argtypes = res, args

    def fail(what):
        code = ctypes.get_last_error()
        raise OSError("%s (WinHTTP %d)" % (WINHTTP_ERRORS.get(code, what), code))

    handles = []
    try:
        s = wh.WinHttpOpen(UA, 4, None, None, 0) or wh.WinHttpOpen(UA, 0, None, None, 0)   # automatic proxy, else default
        if not s:
            fail("WinHTTP nao abriu")
        handles.append(s)
        ms = int(timeout_s * 1000)
        wh.WinHttpSetTimeouts(s, ms, ms, ms, ms)
        c = wh.WinHttpConnect(s, u.hostname, u.port or (443 if u.scheme == "https" else 80), 0)
        if not c:
            fail("nao conectou ao site")
        handles.append(c)
        r = wh.WinHttpOpenRequest(c, "GET", (u.path or "/") + ("?" + u.query if u.query else ""), None, None, None,
                                  0x00800000 if u.scheme == "https" else 0)        # WINHTTP_FLAG_SECURE
        if not r:
            fail("pedido recusado")
        handles.append(r)
        extra = "".join("%s: %s\r\n" % (k, v) for k, v in (headers or {}).items() if k.lower() != "user-agent")
        if not wh.WinHttpSendRequest(r, extra or None, len(extra) if extra else 0, None, 0, 0, 0):
            fail("o pedido nao foi enviado")
        if not wh.WinHttpReceiveResponse(r, None):
            fail("o site nao respondeu")
        status, size = wt.DWORD(0), wt.DWORD(4)
        if not wh.WinHttpQueryHeaders(r, 19 | 0x20000000, None, ctypes.byref(status), ctypes.byref(size), None):
            fail("resposta sem codigo")           # 19 = WINHTTP_QUERY_STATUS_CODE, as a number
        if status.value != 200:
            raise OSError("o site respondeu HTTP %d" % status.value)
        buf = ctypes.create_string_buffer(1 << 16)
        got = wt.DWORD(0)
        with open(path, "wb") as f:
            while True:
                if not wh.WinHttpReadData(r, buf, len(buf), ctypes.byref(got)):
                    fail("a conexao caiu")
                if not got.value:
                    break
                f.write(buf.raw[:got.value])
    finally:
        for h in reversed(handles):
            wh.WinHttpCloseHandle(h)


def _urllib_download(url, path, headers, opener=None):
    req = urllib.request.Request(url, headers=headers)
    with (opener or urllib.request.urlopen)(req, timeout=120) as r, open(path, "wb") as f:
        shutil.copyfileobj(r, f)


def get_dependency(key, paths, log=print, opener=None):
    name, url, sha, referer = DEPS[key]
    for d in paths.cache_dirs():
        p = os.path.join(d, name)
        if os.path.isfile(p) and sha256_file(p) == sha:
            return p
    os.makedirs(paths.cache, exist_ok=True)
    path = os.path.join(paths.cache, name)
    log("Baixando %s do site oficial..." % name)
    headers = {"User-Agent": UA, "Accept": "text/html,application/octet-stream,*/*", "Accept-Language": "en-US"}
    if referer:
        headers["Referer"] = referer
    # Windows' own downloader first (its certificate checks), then Python's; the SHA-256 below checks either way
    ways = [lambda: _urllib_download(url, path + ".part", headers, opener)]
    if IS_WINDOWS and opener is None:
        ways.insert(0, lambda: winhttp_download(url, path + ".part", headers))
    errors = []
    for way in ways:
        try:
            way()
            os.replace(path + ".part", path)
            errors = []
            break
        except Exception as e:
            errors.append(str(e) or type(e).__name__)
            try:
                os.remove(path + ".part")
            except OSError:
                pass
    if errors:
        raise InstallError("Nao consegui baixar %s (%s).\nBaixe pelo navegador em:\n%s\ne coloque o arquivo em:\n%s\n"
                           "Depois clique em Instalar de novo." % (name, errors[0], url, paths.cache))
    got = sha256_file(path)
    if got != sha:
        os.remove(path)
        raise InstallError("O arquivo %s baixado nao e a versao testada (SHA-256 diferente). Fonte: %s" % (name, url))
    return path


# ====================================================================== install / remove
def install(gta_path, replace_d3d9=False, log=print, paths=None, check_only=False, mc_mode="launcher", mc_game=None):
    """Installs everything. Raises InstallError (nothing left half-done) when it can't.
    mc_mode 'prism': the jars go to mc_game (the portable Prism's FusionBridge instance, already set up by fb_prism)
    and the official launcher is not touched; 'launcher': the isolated official-launcher profile, as before."""
    try:
        return _install(gta_path, replace_d3d9, log, paths, check_only, mc_mode, mc_game)
    except PermissionError as e:
        raise _permission_error(e, "gravar") from e


def gta_saves_dir():
    """Documents\\GTA San Andreas User Files (the saves and gta_sa.set), or None."""
    docs = known_folder(FOLDERID_DOCUMENTS) if IS_WINDOWS else None
    docs = docs or os.path.join(os.path.expanduser("~"), "Documents")
    p = os.path.join(docs, "GTA San Andreas User Files")
    return p if os.path.isdir(p) else None


def backup_gta_saves(paths, log=print, saves=None, limit=1 << 30):
    """A copy of the GTA SA saves in %LOCALAPPDATA%\\FusionBridge\\backups before an install. Returns its folder."""
    saves = saves if saves is not None else gta_saves_dir()
    if not saves or not os.path.isdir(saves):
        log("Saves do GTA: pasta 'GTA San Andreas User Files' não encontrada (nada para copiar).")
        return None
    size = 0
    for dp, _, files in os.walk(saves):
        for n in files:
            try:
                size += os.path.getsize(os.path.join(dp, n))
            except OSError:
                pass
    if size > limit:
        log("Saves do GTA: %.1f GB, grande demais para copiar aqui; faça uma cópia à mão." % (size / 1e9))
        return None
    dest = os.path.join(paths.local, "FusionBridge", "backups", "gta-saves-%s" % datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
    shutil.copytree(saves, dest)
    log("Backup dos saves do GTA: %s" % dest)
    return dest


def _install(gta_path, replace_d3d9, log, paths, check_only, mc_mode="launcher", mc_game=None):
    paths = paths or Paths()
    prism = mc_mode == "prism"
    if prism and not mc_game:
        raise InstallError("Falta a pasta do Minecraft automático (Prism).")
    root = paths.app_root
    if not gta_path:
        raise InstallError("Escolha a pasta do GTA San Andreas (o gta_sa.exe).")
    gta_path = os.path.abspath(gta_path.strip().strip('"'))
    exe = os.path.join(gta_path, "gta_sa.exe")
    if not os.path.isfile(exe):
        raise InstallError("gta_sa.exe nao foi encontrado em %s" % gta_path)
    ver = gta_version(exe)
    if ver != "1.0 US":
        log("Aviso: o gta_sa.exe %s. O MoonLoader e o FusionBridgeSA.asi so funcionam na 1.0 US; em outra versao o "
            "ASI se desliga sozinho (sem travar o jogo)." % ("e a versao " + ver if ver else "nao foi reconhecido"))
    if not (os.path.isdir(os.path.join(gta_path, "moonloader")) and os.path.isfile(os.path.join(gta_path, "MoonLoader.asi"))):
        raise InstallError("MoonLoader nao encontrado nesta pasta do GTA (falta a pasta moonloader ou o MoonLoader.asi). "
                           "Instale o MoonLoader primeiro (ele traz o carregador de ASI) e clique em Instalar de novo.")
    profile_path = None
    if not prism:
        loader_json = os.path.join(paths.mc_root, "versions", LOADER_VERSION, LOADER_VERSION + ".json")
        if not os.path.isfile(loader_json):
            raise InstallError("Instale o Fabric Loader 0.19.5 para Minecraft Java 26.3 pelo instalador oficial "
                               "(https://fabricmc.net/use/installer/): Client, versao 26.3, Loader 0.19.5. Ou use o "
                               "Minecraft automatico (Prism), que nao precisa disso.")
        profile_path = _find_launcher_profile(paths)
    mc_game = os.path.abspath(mc_game) if prism else paths.mc_game
    log("GTA SA: %s" % gta_path)
    if prism:
        log("Minecraft: automatico (Prism), instancia em %s" % mc_game)
    else:
        log("Minecraft: %s" % paths.mc_root)
        log("Perfil do launcher: %s" % profile_path)

    sources = [
        (os.path.join(root, "gta", "FusionBridgeSA.asi"), "FusionBridgeSA.asi"),
        (os.path.join(root, "gta", "shaders", "FusionBridgeSA.fx"), os.path.join("reshade-shaders", "Shaders", "FusionBridgeSA.fx")),
        (os.path.join(root, "moonloader", "FusionBridgeGTA.lua"), os.path.join("moonloader", "FusionBridgeGTA.lua")),
    ]
    jars = [(os.path.join(root, "mod", "passthrough-0.1.0.jar"), "passthrough-0.1.0.jar"),
            (os.path.join(root, "mod", "FusionBridgeMC-0.2.0.jar"), "FusionBridgeMC-0.2.0.jar")]
    for src, _ in sources + jars:
        if not os.path.isfile(src):
            raise InstallError("Arquivo do pacote ausente: %s (extraia o ZIP inteiro de novo)." % src)

    # what's already there: other mods' d3d9.dll/ReShade only with replace_d3d9 (kept as a backup)
    conflicts, backups = [], []
    for t in ("d3d9.dll", "ReShade.ini", "ReShadePreset.ini"):
        if os.path.exists(os.path.join(gta_path, t)):
            (backups if replace_d3d9 else conflicts).append(t)
    for t in ("FusionBridgeSA.asi", os.path.join("reshade-shaders", "Shaders", "FusionBridgeSA.fx")):
        if os.path.exists(os.path.join(gta_path, t)):
            conflicts.append(t)
    lua_rel = os.path.join("moonloader", "FusionBridgeGTA.lua")
    old_lua = os.path.exists(os.path.join(gta_path, lua_rel))

    reshade = get_dependency("reshade", paths, log)
    fabric_api = get_dependency("fabric_api", paths, log)
    fxh = get_dependency("reshade_fxh", paths, log)
    uifxh = get_dependency("reshadeui_fxh", paths, log)
    try:
        with zipfile.ZipFile(reshade) as z:   # the setup carries its DLLs as an appended zip
            reshade32 = z.read("ReShade32.dll")
    except (zipfile.BadZipFile, KeyError) as e:
        raise InstallError("Nao consegui extrair o ReShade32.dll do instalador oficial do ReShade (%s)." % e)

    if check_only:
        log("Arquivos oficiais conferidos.")
        log("Arquivos que impedem a instalacao: %s" % (", ".join(conflicts) if conflicts else "nenhum"))
        return {"conflicts": conflicts, "backups": backups, "old_lua": old_lua}
    _check_closed("instalar")
    if os.path.exists(paths.manifest):
        if load_manifest(paths) is not None:
            raise InstallError("Ja existe uma instalacao registrada. Clique em Remover antes de instalar de novo.")
        log("O registro anterior estava danificado e foi guardado em %s" % _set_aside(paths.manifest, "danificado"))
    # the isolated Minecraft folder stays after a Remover (its world): it is reused; only our jars must not clash
    mods_dir = os.path.join(mc_game, "mods")
    for src, name in jars + [(fabric_api, "fabric-api-0.161.0+26.3.jar")]:
        t = os.path.join(mods_dir, name)
        if os.path.exists(t) and sha256_file(t) != sha256_file(src):
            conflicts.append(t)
    if conflicts:
        raise InstallError("Instalacao interrompida para preservar arquivos que ja existem no GTA: %s.\nSe for o "
                           "d3d9.dll/ReShade de outro mod, marque 'Substituir d3d9.dll/ReShade de outro mod' (faz "
                           "backup, e o Remover devolve)." % ", ".join(conflicts))

    created, backup_list, made_dirs = [], [], []
    profile_backup, profile_changed = None, False
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    def makedirs(d):                 # remembers the folders it creates, so a rollback can take them out again
        missing = []
        while d and not os.path.isdir(d):
            missing.append(d)
            parent = os.path.dirname(d)
            if parent == d:
                break
            d = parent
        for m in reversed(missing):
            os.mkdir(m)
            made_dirs.append(m)
    try:
        os.makedirs(paths.state_root, exist_ok=True)
        saves_backup = backup_gta_saves(paths, log)
        for t in backups + ([lua_rel] if old_lua else []):
            orig = os.path.join(gta_path, t)
            bak = "%s.antes-fusionbridge-%s" % (orig, stamp)
            os.replace(orig, bak)
            backup_list.append({"Original": orig, "Backup": bak})
            log("Backup: %s" % bak)

        def put(data_or_src, rel, base=gta_path, keep_existing=False):
            target = os.path.join(base, rel)
            if os.path.exists(target):
                if keep_existing or (not isinstance(data_or_src, bytes) and sha256_file(target) == sha256_file(data_or_src)):
                    return               # already there (a ReShade's .fxh, or our own jar left by an earlier install)
            makedirs(os.path.dirname(target))
            created.append(target)      # before writing: a write that fails half-way is rolled back too
            if isinstance(data_or_src, bytes):
                with open(target, "wb") as f:
                    f.write(data_or_src)
            else:
                shutil.copyfile(data_or_src, target)

        put(reshade32, "d3d9.dll")               # GTA SA is 32-bit Direct3D 9: ReShade goes in as d3d9.dll
        for src, rel in sources:
            put(src, rel)
        # ReShade.fxh/ReShadeUI.fxh of a ReShade install that's already there stay (they work the same)
        put(fxh, os.path.join("reshade-shaders", "Shaders", "ReShade.fxh"), keep_existing=True)
        put(uifxh, os.path.join("reshade-shaders", "Shaders", "ReShadeUI.fxh"), keep_existing=True)
        put(RESHADE_INI.encode("ascii"), "ReShade.ini")
        put(RESHADE_PRESET.encode("ascii"), "ReShadePreset.ini")

        # Minecraft: the Prism instance, or an isolated profile (your own worlds and options are untouched)
        makedirs(mods_dir)
        for src, name in jars + [(fabric_api, "fabric-api-0.161.0+26.3.jar")]:
            put(src, name, base=mods_dir)
        if not prism:
            profile_backup = os.path.join(paths.state_root, "launcher_profiles.backup-%s.json" % stamp)
            shutil.copyfile(profile_path, profile_backup)
            with open(profile_path, "r", encoding="utf-8-sig") as f:
                launcher = json.load(f)
            profiles = launcher.setdefault("profiles", {})
            if PROFILE_ID in profiles:
                raise InstallError("O perfil do FusionBridge ja existe no launcher.")
            profiles[PROFILE_ID] = {"name": PROFILE_NAME, "type": "custom", "lastVersionId": LOADER_VERSION,
                                    "gameDir": paths.mc_game, "icon": "TNT"}
            _write_json_atomic(profile_path, launcher)
            profile_changed = True

        manifest = {"Version": VERSION, "Game": gta_path, "McGame": mc_game, "McMode": "prism" if prism else "launcher",
                    "LauncherProfile": profile_path or "", "ProfileId": PROFILE_ID,
                    "Files": [{"Path": p, "SHA256": sha256_file(p)} for p in created],
                    "Backups": backup_list, "SavesBackup": saves_backup}
        _write_json_atomic(paths.manifest, manifest)
    except BaseException:
        for p in reversed(created):
            try:
                os.remove(p)
            except OSError:
                pass
        for d in reversed(made_dirs):    # only folders this install created, and only if empty
            try:
                os.rmdir(d)
            except OSError:
                pass
        for b in backup_list:
            if os.path.exists(b["Backup"]) and not os.path.exists(b["Original"]):
                os.replace(b["Backup"], b["Original"])
        if profile_changed and profile_backup and os.path.exists(profile_backup):
            tmp = profile_path + ".fusionbridge-tmp"
            shutil.copyfile(profile_backup, tmp)
            os.replace(tmp, profile_path)
        raise
    log("INSTALACAO CONCLUIDA.")
    if prism:
        log("1. Abra o GTA San Andreas: o FusionBridge abre o Minecraft sozinho (ou use Abrir o Minecraft na Ponte).")
    else:
        log("1. No Minecraft Launcher, escolha '%s' e clique em JOGAR (deixe a janela aberta)." % PROFILE_NAME)
    log("2. Carregue um save no GTA. F7 liga/desliga, F8 nivela o chao, F6 troca o mouse.")
    return {"created": created, "backups": backup_list}


def remove(log=print, paths=None):
    """Removes what install() put in (only files nobody changed since), and puts the backups back."""
    try:
        return _remove(log, paths)
    except PermissionError as e:
        raise _permission_error(e, "apagar arquivos") from e


def _remove(log, paths):
    paths = paths or Paths()
    m = load_manifest(paths)
    if m is None:
        if os.path.exists(paths.manifest):
            raise InstallError("O registro da instalacao esta danificado (%s). Clique em Instalar: ele guarda o registro "
                               "danificado e instala de novo; depois o Remover funciona." % paths.manifest)
        raise InstallError("Nao encontrei a instalacao registrada neste PC.")
    _check_closed("remover")
    game_root = m.get("Game", "")
    mods_root = os.path.join(m.get("McGame", ""), "mods")
    for item in m["Files"]:                     # check every path before touching anything
        p = item.get("Path", "")
        if not (_under(p, game_root) or _under(p, mods_root)):
            raise InstallError("Caminho inesperado no registro: %s" % p)
    remaining = []
    for item in m["Files"]:
        p = item.get("Path", "")
        if not os.path.exists(p):
            continue
        try:
            if sha256_file(p) != str(item.get("SHA256", "")).upper():
                name = os.path.basename(p).lower()
                if name in ("reshade.ini", "reshadepreset.ini", "fusionbridgesa.ini"):
                    # settings (ReShade rewrites its own while the game runs; FusionBridgeSA.ini came with an
                    # earlier 0.6.1 build): ours, just changed; kept aside
                    log("Configuracao do ReShade guardada em %s" % _set_aside(p, "fusionbridge"))
                    continue
                if name in OWN_GTA_FILES:
                    # our own mod, replaced by hand (the GTA-only zip of a newer/older version, or a tweak):
                    # kept aside under a name the game doesn't load, so Remover/Instalar never get stuck on it
                    log("Arquivo do FusionBridge diferente do instalado (atualizado a mao?) guardado em %s" % _set_aside(p, "fusionbridge"))
                    continue
                log("Arquivo alterado foi preservado: %s" % p)
                remaining.append(item)
                continue
            os.remove(p)
            log("Removido: %s" % p)
        except OSError as e:                    # in use or locked: keep going, the backups still come back
            log("Nao consegui remover %s (%s)" % (p, e.strerror or e))
            remaining.append(item)
    for b in m["Backups"]:
        if not isinstance(b, dict):
            continue
        orig, bak = b.get("Original", ""), b.get("Backup", "")
        if not (_under(orig, game_root) and _under(bak, game_root)):
            raise InstallError("Caminho inesperado no registro: %s" % orig)
        if os.path.exists(bak) and not os.path.exists(orig):
            os.replace(bak, orig)
            log("Devolvido: %s" % orig)
        elif os.path.exists(bak):
            log("Backup mantido (ja existe outro arquivo no lugar): %s" % bak)
    profile_path = m.get("LauncherProfile", "")
    if profile_path and os.path.isfile(profile_path):
        try:
            with open(profile_path, "r", encoding="utf-8-sig") as f:
                launcher = json.load(f)
            prof = (launcher.get("profiles") or {}).get(m.get("ProfileId", PROFILE_ID))
            if isinstance(prof, dict) and _norm(prof.get("gameDir", "")) == _norm(m.get("McGame", "")):
                stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                shutil.copyfile(profile_path, os.path.join(paths.state_root, "launcher_profiles.before-remove-%s.json" % stamp))
                del launcher["profiles"][m.get("ProfileId", PROFILE_ID)]
                _write_json_atomic(profile_path, launcher)
                log("Perfil do FusionBridge removido do Minecraft Launcher.")
        except (OSError, ValueError) as e:
            log("Nao consegui mexer no perfil do launcher (%s); remova o perfil '%s' a mao." % (e, PROFILE_NAME))
    if remaining:
        m["Files"] = remaining
        _write_json_atomic(paths.manifest, m)
        log("Alguns arquivos ficaram (alterados por voce, ou em uso); veja acima. O Remover pode ser usado de novo.")
    else:
        os.remove(paths.manifest)
        log("Remocao concluida. Seus saves do GTA e seus mundos normais do Minecraft nao foram tocados.")
        log("(O mundo do perfil isolado continua em %s; apague a pasta se quiser.)" % m.get("McGame", ""))
    return {"remaining": remaining}


# ====================================================================== shortcuts (IShellLinkW via COM)
class GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16), ("Data3", ctypes.c_uint16),
                ("Data4", ctypes.c_ubyte * 8)]

    @classmethod
    def from_str(cls, s):
        b = uuid.UUID(s).bytes_le
        g = cls()
        ctypes.memmove(ctypes.byref(g), b, 16)
        return g


def known_folder(fid):
    """SHGetKnownFolderPath (the real Desktop / Start menu, even when OneDrive moves them)."""
    if not IS_WINDOWS:
        return None
    shell32 = ctypes.WinDLL("shell32")
    ole32 = ctypes.WinDLL("ole32")
    p = ctypes.c_wchar_p()
    shell32.SHGetKnownFolderPath.argtypes = (ctypes.POINTER(GUID), ctypes.c_uint32, ctypes.c_void_p, ctypes.POINTER(ctypes.c_wchar_p))
    if shell32.SHGetKnownFolderPath(ctypes.byref(GUID.from_str(fid)), 0, None, ctypes.byref(p)) != 0:
        return None
    try:
        return p.value
    finally:
        ole32.CoTaskMemFree.argtypes = (ctypes.c_void_p,)
        ole32.CoTaskMemFree(ctypes.cast(p, ctypes.c_void_p))


FOLDERID_DESKTOP = "B4BFCC3A-DB2C-424C-B029-7FE99A87C641"
FOLDERID_PROGRAMS = "A77F5D77-2E2B-44C3-A6A2-ABA601054A51"
FOLDERID_DOCUMENTS = "FDD39AD0-238F-46AF-ADB4-6C85480369C7"


def create_shortcut(lnk_path, target, workdir, icon=None, description="FusionBridge", args=None):
    """Writes a .lnk with the Shell's own IShellLink (made here, so it carries no download mark)."""
    if not IS_WINDOWS:
        raise InstallError("Atalhos so existem no Windows.")
    ole32 = ctypes.WinDLL("ole32")
    ole32.CoInitializeEx.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
    ole32.CoCreateInstance.argtypes = (ctypes.POINTER(GUID), ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p))
    ole32.CoInitializeEx(None, 0x2)     # apartment-threaded; fine if already initialised
    link = ctypes.c_void_p()
    hr = ole32.CoCreateInstance(ctypes.byref(GUID.from_str("00021401-0000-0000-C000-000000000046")), None, 1,
                                ctypes.byref(GUID.from_str("000214F9-0000-0000-C000-000000000046")), ctypes.byref(link))
    if hr != 0 or not link:
        raise InstallError("O Windows nao criou o atalho (erro 0x%08X)." % (hr & 0xFFFFFFFF))

    def method(obj, index, *argtypes):
        vtbl = ctypes.cast(obj, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        return ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, *argtypes)(vtbl[index])

    try:
        method(link, 20, ctypes.c_wchar_p)(link, target)                   # SetPath
        method(link, 9, ctypes.c_wchar_p)(link, workdir)                   # SetWorkingDirectory
        if args:
            method(link, 11, ctypes.c_wchar_p)(link, args)                 # SetArguments
        method(link, 7, ctypes.c_wchar_p)(link, description)               # SetDescription
        if icon and os.path.isfile(icon):
            method(link, 17, ctypes.c_wchar_p, ctypes.c_int)(link, icon, 0)  # SetIconLocation
        pf = ctypes.c_void_p()
        hr = method(link, 0, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p))(
            link, ctypes.byref(GUID.from_str("0000010b-0000-0000-C000-000000000046")), ctypes.byref(pf))  # QueryInterface
        if hr != 0 or not pf:
            raise InstallError("O Windows nao criou o atalho (IPersistFile 0x%08X)." % (hr & 0xFFFFFFFF))
        try:
            os.makedirs(os.path.dirname(lnk_path), exist_ok=True)
            hr = method(pf, 6, ctypes.c_wchar_p, ctypes.c_int)(pf, lnk_path, 1)   # IPersistFile::Save
            if hr != 0:
                raise InstallError("Nao consegui salvar o atalho em %s (0x%08X)." % (lnk_path, hr & 0xFFFFFFFF))
        finally:
            method(pf, 2)(pf)                                              # Release
    finally:
        method(link, 2)(link)
    return lnk_path


def create_app_shortcuts(paths=None):
    """'FusionBridge' on the Desktop and in the Start menu, pointing at FusionBridge.exe with the app icon."""
    paths = paths or Paths()
    exe = os.path.join(paths.app_root, "FusionBridge.exe")
    icon = os.path.join(paths.app_root, "app", "assets", "FusionBridge.ico")
    if not os.path.isfile(exe):
        raise InstallError("FusionBridge.exe nao encontrado em %s" % paths.app_root)
    made = []
    for fid in (FOLDERID_DESKTOP, FOLDERID_PROGRAMS):
        folder = known_folder(fid)
        if folder:
            made.append(create_shortcut(os.path.join(folder, "FusionBridge.lnk"), exe, paths.app_root, icon,
                                        "FusionBridge - Minecraft dentro do GTA San Andreas", args="-s"))
    try:      # SHCNE_ASSOCCHANGED: Explorer drops its cached icons, so the new logo shows at once
        ctypes.WinDLL("shell32").SHChangeNotify(0x08000000, 0, None, None)
    except Exception:
        pass
    return made


def app_shortcut_exists():
    """True/False: is there a FusionBridge shortcut on the Desktop? None when it can't be known (not Windows)."""
    if not IS_WINDOWS:
        return None
    folder = known_folder(FOLDERID_DESKTOP)
    return bool(folder) and os.path.isfile(os.path.join(folder, "FusionBridge.lnk"))


def is_admin():
    if not IS_WINDOWS:
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def elevated_params(paths=None):
    """The command line of the elevated copy. -s: no user site-packages from another Python install. The user's
    own folders go along: from a standard account the UAC prompt runs the copy as the administrator who typed the
    password, whose AppData isn't this user's (where Minecraft and the FusionBridge settings are)."""
    params = "-s -X fb=elevated"
    if paths is not None:
        for opt, folder in (("fblocal", paths.local), ("fbappdata", paths.appdata)):
            folder = (folder or "").rstrip("\\/")
            if folder and '"' not in folder:
                params += ' -X "%s=%s"' % (opt, folder)
    return params


def relaunch_as_admin(exe, workdir, paths=None):
    """Asks Windows (UAC) to start exe elevated; True if it started. The caller then closes itself."""
    if not IS_WINDOWS:
        return False
    sh = ctypes.windll.shell32
    sh.ShellExecuteW.restype = ctypes.c_void_p
    sh.ShellExecuteW.argtypes = (ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_int)
    # FusionBridge.exe is python.org's pythonw.exe: Python itself reads the command line before the app starts and
    # stops on options it doesn't know ("--elevated" would end it silently), so the flag goes as a -X option.
    r = sh.ShellExecuteW(None, "runas", exe, elevated_params(paths), workdir, 1)
    return (r or 0) > 32


# ====================================================================== Windows security
def sac_state():
    """Smart App Control ('Controle inteligente de aplicativo'): 'on', 'eval', 'off' or 'unknown'."""
    if not IS_WINDOWS:
        return "unknown"
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\CI\Policy") as k:
            v = winreg.QueryValueEx(k, "VerifiedAndReputablePolicyState")[0]
    except OSError:
        return "unknown"
    return {0: "off", 1: "on", 2: "eval"}.get(v, "unknown")


class _WINTRUST_FILE_INFO(ctypes.Structure):
    _fields_ = [("cbStruct", ctypes.c_uint32), ("pcwszFilePath", ctypes.c_wchar_p), ("hFile", ctypes.c_void_p),
                ("pgKnownSubject", ctypes.c_void_p)]


class _WINTRUST_DATA(ctypes.Structure):
    _fields_ = [("cbStruct", ctypes.c_uint32), ("pPolicyCallbackData", ctypes.c_void_p),
                ("pSIPClientData", ctypes.c_void_p), ("dwUIChoice", ctypes.c_uint32),
                ("fdwRevocationChecks", ctypes.c_uint32), ("dwUnionChoice", ctypes.c_uint32),
                ("pFile", ctypes.POINTER(_WINTRUST_FILE_INFO)), ("dwStateAction", ctypes.c_uint32),
                ("hWVTStateData", ctypes.c_void_p), ("pwszURLReference", ctypes.c_wchar_p),
                ("dwProvFlags", ctypes.c_uint32), ("dwUIContext", ctypes.c_uint32), ("pSignatureSettings", ctypes.c_void_p)]


def signature(path):
    """'assinado', 'sem assinatura', 'nao confiavel', 'ausente' or 'desconhecido' (WinVerifyTrust, offline)."""
    if not os.path.isfile(path):
        return "ausente"
    if not IS_WINDOWS:
        return "desconhecido"
    try:
        wintrust = ctypes.WinDLL("wintrust")
        fi = _WINTRUST_FILE_INFO(ctypes.sizeof(_WINTRUST_FILE_INFO), path, None, None)
        wd = _WINTRUST_DATA()
        wd.cbStruct = ctypes.sizeof(_WINTRUST_DATA)
        wd.dwUIChoice = 2            # WTD_UI_NONE
        wd.fdwRevocationChecks = 0   # WTD_REVOKE_NONE (no network)
        wd.dwUnionChoice = 1         # WTD_CHOICE_FILE
        wd.pFile = ctypes.pointer(fi)
        wd.dwStateAction = 1         # WTD_STATEACTION_VERIFY
        wd.dwProvFlags = 0x00002000  # WTD_CACHE_ONLY_URL_RETRIEVAL
        action = GUID.from_str("00AAC56B-CD44-11d0-8CC2-00C04FC295EE")
        wintrust.WinVerifyTrust.restype = ctypes.c_long
        wintrust.WinVerifyTrust.argtypes = (ctypes.c_void_p, ctypes.POINTER(GUID), ctypes.c_void_p)
        r = wintrust.WinVerifyTrust(ctypes.c_void_p(-1), ctypes.byref(action), ctypes.byref(wd)) & 0xFFFFFFFF
        wd.dwStateAction = 2         # WTD_STATEACTION_CLOSE
        wintrust.WinVerifyTrust(ctypes.c_void_p(-1), ctypes.byref(action), ctypes.byref(wd))
    except Exception:
        return "desconhecido"
    if r == 0:
        return "assinado"
    if r in (0x800B0100, 0x800B0003, 0x80096010):   # no signature / unknown subject form / bad digest
        return "sem assinatura"
    return "nao confiavel"


def app_code_signatures(app_root):
    """Every executable file the app itself runs (FusionBridge.exe, the Python DLLs, the .pyd/.dll in runtime), with its
    signature status. Our own code is .py, so this is the whole native side of the app."""
    names = [n for n in ("FusionBridge.exe", "python313.dll", "python3.dll", "vcruntime140.dll", "vcruntime140_1.dll")]
    out = [(n, signature(os.path.join(app_root, n))) for n in names]
    rt = os.path.join(app_root, "runtime")
    if os.path.isdir(rt):
        for n in sorted(os.listdir(rt)):
            if n.lower().endswith((".pyd", ".dll", ".exe")):
                out.append(("runtime\\" + n, signature(os.path.join(rt, n))))
    return out


def code_integrity_blocks(gta_path=None, limit=200):
    """Recent Code Integrity blocks (Smart App Control / App Control) from the Windows event log.
    Returns (list of {"time","file","process","event"}, error or None)."""
    if not IS_WINDOWS:
        return [], "so no Windows"
    query = "*[System[(EventID=3033 or EventID=3034 or EventID=3076 or EventID=3077 or EventID=3089)]]"
    try:
        out = subprocess.run(["wevtutil", "qe", "Microsoft-Windows-CodeIntegrity/Operational", "/q:" + query,
                              "/c:%d" % limit, "/rd:true", "/f:xml"], capture_output=True, timeout=30,
                             creationflags=0x08000000)   # CREATE_NO_WINDOW
    except (OSError, subprocess.TimeoutExpired) as e:
        return [], "nao consegui ler o log do Windows (%s)" % e
    if out.returncode != 0:
        msg = (out.stderr or out.stdout or b"").decode("utf-8", "replace").strip()
        return [], "nao consegui ler o log do Windows%s" % (": " + msg[:200] if msg else "")
    import xml.etree.ElementTree as ET
    text = out.stdout.decode("utf-8", "replace")
    try:
        root = ET.fromstring("<Events>" + text + "</Events>")
    except ET.ParseError as e:
        return [], "resposta do log ilegivel (%s)" % e
    ns = "{http://schemas.microsoft.com/win/2004/08/events/event}"
    found, seen = [], set()
    gta_name = os.path.basename(gta_path.rstrip("\\/")).lower() if gta_path else None
    for ev in root.iter(ns + "Event"):
        sysn = ev.find(ns + "System")
        eid = sysn.findtext(ns + "EventID") if sysn is not None else ""
        tc = sysn.find(ns + "TimeCreated") if sysn is not None else None
        when = tc.get("SystemTime", "")[:19].replace("T", " ") if tc is not None else ""
        data = {}
        for d in ev.iter(ns + "Data"):
            data[(d.get("Name") or "").lower()] = d.text or ""
        file_ = next((v for k, v in data.items() if "file name" in k), "")
        proc = next((v for k, v in data.items() if "process name" in k), "")
        low = (file_ + " " + proc).lower()
        relevant = ("gta_sa.exe" in low or "fusionbridge" in low or (gta_name and gta_name in low)
                    or low.endswith(".asi") or "moonloader" in low or "reshade" in low)
        key = (file_.lower(), proc.lower())
        if relevant and key not in seen:
            seen.add(key)
            found.append({"time": when, "file": file_, "process": proc, "event": eid})
    return found, None
