# Mods fusion: como o FusionBridge reconhece um jogo

Cada jogo que o FusionBridge consegue juntar com outro tem um **mod fusion**. Para o app, um mod fusion é um arquivo `.json` com a descrição do mod. O app procura esses arquivos em duas pastas:

- `fusion-mods\` dentro da pasta do FusionBridge: os que vêm com o app;
- `%LOCALAPPDATA%\FusionBridge\fusion-mods\`: os que você adiciona. Essa pasta não pede administrador, e um arquivo dela com o mesmo `id` substitui o que vem com o app.

**Não precisa mexer no app nem reiniciar.** Copie o `.json` para uma dessas pastas e ele aparece na hora: nos cartões Host/Secundário e na frase do lado direito quando você escolhe um jogo.

O arquivo é **só dado**. O app lê os campos abaixo e nunca executa nada que esteja nele. Por isso um mod fusion novo não muda nada na segurança do Windows (Controle inteligente de aplicativo). O que roda dentro do jogo (DLL, ASI, .jar, script) é o mod do jogo em si, instalado do jeito que esse mod pede.

## Exemplo

```json
{
  "fusion_mod": 1,
  "id": "meu-jogo-fusion",
  "name": "Fusion para Meu Jogo",
  "version": "1.0",
  "author": "seu nome",
  "roles": ["host"],
  "game": {
    "name": "Meu Jogo",
    "names": ["Meu Jogo", "Meu Jogo: Edição Completa"],
    "steam": [123456],
    "epic": ["NomeDoAppNaEpic"],
    "gog": ["1234567890"],
    "files": ["MeuJogo.exe"]
  },
  "partners": ["fusionbridge-minecraft-java"],
  "installed_when": ["mods/MeuJogoFusion.dll"],
  "requires": "Meu Jogo versão 1.2 ou mais nova.",
  "how": "Copie a pasta mods para dentro da pasta do jogo."
}
```

| Campo | O que é |
|---|---|
| `fusion_mod` | sempre `1` (versão deste formato) |
| `id` | nome único do mod: letras minúsculas, números, `.`, `-`, `_` |
| `name`, `version`, `author` | o que aparece no app |
| `roles` | `["host"]` (o jogo que fica na tela e recebe o outro dentro), `["secondary"]` (o jogo desenhado dentro do Host) ou os dois |
| `game` | como reconhecer o jogo instalado. Basta um destes: `names` (nome como aparece na loja), `steam` (AppID), `epic` (AppName), `gog` (ID do jogo), `files` (arquivo que existe dentro da pasta do jogo) |
| `partners` | `id` dos mods do outro lado com que este faz par. Vazio ou ausente: faz par com qualquer um |
| `installed_when` | arquivos que, se **todos** existirem, mostram que o mod já está instalado. São relativos à pasta do jogo; use `{fusionbridge}/...` para algo dentro de `%LOCALAPPDATA%\FusionBridge` e `{localappdata}/...` para algo dentro de `%LOCALAPPDATA%` (ex.: o SkyCraft guarda o Minecraft dele em `{localappdata}/SkyCraft`) |
| `installed_when_any` | como `installed_when`, mas basta **um** existir (um mod que pode estar em mais de um lugar, ex.: o Minecraft automático ou o do launcher) |
| `check` | nome de uma verificação que o próprio app faz (ex.: `gta_sa_1_0_us`, `skyrim_skycraft`); um nome desconhecido é ignorado |
| `requires`, `how` | uma frase cada, mostrada no app |

Caminhos com `..`, com letra de unidade (`C:\`) ou absolutos são recusados. Arquivo com erro aparece no **Log** do app ("mod fusion ignorado: ... motivo").

## Onde o app encontra os jogos

O app procura os jogos nos registros dos próprios launchers: Steam, Epic Games, GOG, Ubisoft Connect, Rockstar Games Launcher, EA app, Battle.net, Riot e o app Xbox (`XboxGames`). Também encontra o Minecraft Java (pela pasta `.minecraft` ou pelo Minecraft Launcher) e o GTA San Andreas clássico. Se um jogo não aparecer, use **Outro jogo… (escolher o .exe)** no seletor.
