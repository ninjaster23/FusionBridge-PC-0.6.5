"""End-to-end test of the PC hub + control panel (fusionbridge.py).
Starts the real process, connects fake GTA and Minecraft clients, drives it over HTTP.
usage: python3 -I test_pc_hub.py [path to fusionbridge.py]
"""
import json, os, re, socket, subprocess, sys, time, urllib.request

FB = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else
                     os.path.join(os.path.dirname(__file__), "..", "app", "fusionbridge.py"))
HUB = ("127.0.0.1", 28765)
UI = 28766
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(detail)[:400]), flush=True)


def wait_for(pred, timeout=6.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            r = pred()
            if r:
                return r
        except Exception:
            pass
        time.sleep(0.1)
    return None


class C:
    def __init__(self, name=None, side="", role="", hello=True):
        self.s = socket.create_connection(HUB, timeout=3)
        self.s.settimeout(0.3)
        self.buf = b""
        self.q = []            # parsed messages not yet consumed (so expect never drops lines)
        self.name = name
        if hello and name:
            self.send({"type": "hello", "client": name, "side": side, "role": role, "version": "9.9"})
            self.expect("hello_ack")

    def send(self, o):
        self.s.sendall((json.dumps(o) + "\n").encode())

    def _pump(self, t):
        end = time.time() + t
        while time.time() < end:
            try:
                d = self.s.recv(4096)
                if not d:
                    break
                self.buf += d
            except socket.timeout:
                pass
            while b"\n" in self.buf:
                ln, self.buf = self.buf.split(b"\n", 1)
                if ln.strip():
                    self.q.append(json.loads(ln))

    def lines(self, t=0.4):
        self._pump(t)
        out, self.q = self.q, []
        return out

    def expect(self, typ, timeout=3.0, pred=None):
        end = time.time() + timeout
        while True:
            for i, m in enumerate(self.q):
                if m.get("type") == typ and (not pred or pred(m)):
                    return self.q.pop(i)
            if time.time() >= end:
                return None
            self._pump(0.2)

    def close(self):
        try:
            self.s.close()
        except Exception:
            pass


def http(path, tok=None):
    url = "http://127.0.0.1:%d%s" % (UI, path)
    if tok is not None:
        url += ("&" if "?" in path else "?") + "k=" + tok
    try:
        with urllib.request.urlopen(url, timeout=4) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def main():
    try:
        socket.create_connection(HUB, timeout=0.4).close()
        print("porta 28765 ocupada"); sys.exit(2)
    except OSError:
        pass

    p = subprocess.Popen([sys.executable, FB, "--no-browser"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    tok = None
    end = time.time() + 8
    while time.time() < end:
        line = p.stdout.readline()
        if not line:
            break
        m = re.search(r"/\?k=(\S+)", line)
        if m:
            tok = m.group(1); break
    check("process starts and prints panel token", tok is not None)
    if not tok:
        p.terminate(); sys.exit(1)
    import threading
    threading.Thread(target=lambda: [None for _ in p.stdout], daemon=True).start()
    wait_for(lambda: http("/api/status", tok)[0] == 200)
    wait_for(lambda: json.loads(http("/api/status", tok)[1])["hub"]["mode"] == "hub")

    # token enforced
    st, _ = http("/api/status")
    check("panel without token -> 403", st == 403, st)
    st, body = http("/api/status", tok)
    js = json.loads(body)
    check("status JSON, version 0.6.5, hub listening", st == 200 and js["version"] == "0.6.5" and js["hub"]["mode"] == "hub", js.get("hub", {}).get("mode"))

    # clients connect
    gta = C("gta", side="game", role="host")
    gta.send({"type": "diag", "side": "gta", "mod": "0.1.0", "note": "ok", "pad": "z" * 1000})
    gta.send({"type": "player_state", "side": "gta", "x": 2491.0, "y": -1668.0, "z": 13.0, "health": 73})
    mc = C("minecraft_server", side="server", role="secondary")
    mc.send({"type": "world_state", "side": "server", "players": 1, "counts": {"tnt": 0}})

    # the hub handles these on its own thread and refreshes the status each loop: give it a moment
    wait_for(lambda: {s["of"] for s in json.loads(http("/api/status", tok)[1])["hub"]["snapshots"]}
             >= {"gta", "minecraft_server"}, 3.0)
    js = json.loads(http("/api/status", tok)[1])
    names = {c["name"] for c in js["hub"]["clients"]}
    check("status lists gta + minecraft", {"gta", "minecraft_server"} <= names, names)
    check("gta diag stored", any(d["of"] == "gta" for d in js["hub"]["diags"]))
    check("snapshots kept (gta + minecraft)", {s["of"] for s in js["hub"]["snapshots"]} >= {"gta", "minecraft_server"})

    # panel -> GTA command
    st, _ = http("/api/gta?action=block&model=1224", tok)
    cmd = gta.expect("command", pred=lambda m: m.get("action") == "block")
    check("/api/gta block reaches GTA with numeric model", st == 200 and cmd and cmd.get("to") == "gta" and cmd.get("model") == 1224 and cmd.get("from") == "panel", cmd)
    st, _ = http("/api/gta?action=rm_rf", tok)
    check("/api/gta unknown action -> 400", st == 400, st)
    http("/api/gta?action=boom&model=1%22,%22x%22:9", tok)
    inj = gta.expect("command", pred=lambda m: m.get("action") == "boom")
    check("numeric GTA params cannot inject JSON", inj and inj.get("to") == "gta" and "x" not in inj, inj)

    # panel -> Minecraft command
    http("/api/mc?action=wither&at=spawn", tok)
    mcmd = mc.expect("command", pred=lambda m: m.get("action") == "wither")
    check("/api/mc reaches Minecraft (to minecraft*, at spawn)", mcmd and mcmd.get("to") == "minecraft*" and mcmd.get("at") == "spawn", mcmd)
    st, _ = http("/api/mc?action=format", tok)
    check("/api/mc allowlist enforced", st == 400, st)

    # GTA rules passthrough
    http("/api/gta?action=rules&tnt=0&wither=1", tok)
    r = gta.expect("command", pred=lambda m: m.get("action") == "rules")
    check("rules carry switches", r and r.get("tnt") == 0 and r.get("wither") == 1, r)

    # config change -> fusion_config to clients + status reflects it
    http("/api/cfg?mode=live", tok)
    fc = gta.expect("fusion_config", pred=lambda m: m.get("mode") == "live")
    check("cfg mode=live broadcast (state_hz 20)", fc and fc.get("state_hz") == 20, fc)
    js = json.loads(http("/api/status", tok)[1])
    check("status cfg reflects mode", js["cfg"]["mode"] == "live")
    http("/api/cfg?dlss=1&framegen=1", tok)
    js = json.loads(http("/api/status", tok)[1])
    check("dlss/framegen toggles stored", js["cfg"]["dlss"] is True and js["cfg"]["framegen"] is True, js["cfg"])

    # event feed
    mc.send({"type": "event", "event": "explosion", "entity": "tnt"})
    check("event reaches the panel feed", wait_for(lambda: any("explosion" in e["text"] for e in json.loads(http("/api/status", tok)[1])["hub"]["events"])), None)
    # ...and is routed to the GTA client
    ev = gta.expect("event", pred=lambda m: m.get("event") == "explosion")
    check("event routed MC -> GTA", ev is not None, ev)

    # late joiner gets snapshot + diag
    late = C("panel_probe")
    snap = late.expect("snapshot", pred=lambda m: m.get("of") == "gta")
    diag = late.expect("diag", timeout=2)
    check("late client gets gta snapshot", snap is not None)
    check("late client gets gta diag", diag is not None and diag.get("mod") == "0.1.0", diag)
    late.close()

    # HUD page + index served
    st, body = http("/hud", tok)
    check("/hud served", st == 200 and b"FusionBridge HUD" in body, st)
    st, body = http("/", tok)
    check("/ index served", st == 200 and b"FusionBridge" in body, st)

    # bridge off -> port closes; on -> reopens
    http("/api/hub?on=0", tok)
    time.sleep(0.6)
    try:
        socket.create_connection(HUB, timeout=0.5).close(); off = False
    except OSError:
        off = True
    check("bridge OFF closes the hub port", off)
    http("/api/hub?on=1", tok)
    check("bridge ON reopens the port", wait_for(lambda: (socket.create_connection(HUB, timeout=0.5).close() or True)))

    gta.close(); mc.close()
    p.terminate()
    try:
        p.wait(timeout=5)
    except Exception:
        p.kill()
    failed = [x for x in results if not x[1]]
    print("\n%d/%d passed" % (len(results) - len(failed), len(results)))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
