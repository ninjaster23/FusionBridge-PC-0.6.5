#pragma once
#include "protocol.h"

#include <atomic>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <string>
#include <thread>

namespace fbgta {

class BridgeClient {
public:
    BridgeClient();
    ~BridgeClient();

    bool start();
    void stop();
    bool pop(Event& out);
    void queue_player_state(const std::string& json);
    bool connected() const { return connected_.load(); }

private:
    void worker_loop();
    void push(Event&& e);
    void log(const std::string& s) const;

    std::atomic<bool> running_{false};
    std::atomic<bool> connected_{false};
    std::thread worker_;

    std::mutex event_mu_;
    std::deque<Event> events_;

    std::mutex out_mu_;
    std::string pending_state_;
};

void set_log_callback(void (*cb)(const char*));

} // namespace fbgta
