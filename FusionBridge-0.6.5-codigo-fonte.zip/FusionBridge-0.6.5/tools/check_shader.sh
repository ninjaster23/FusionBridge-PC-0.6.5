#!/usr/bin/env bash
# Checks gta/shaders/FusionBridgeSA.fx the way ReShade compiles it on Direct3D 9:
#   1. ReShade 6.8.0's own effect compiler (built here from crosire/reshade) -> HLSL for shader model 3;
#   2. optionally, Microsoft's d3dcompiler on every entry point (vs_3_0 / ps_3_0) under Wine, if you pass
#      the path of a d3dcompiler_47 DLL (e.g. D3DCompiler_47_cor3.dll from the WPF runtime NuGet package).
# usage: tools/check_shader.sh [path/to/d3dcompiler_47.dll]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${WORK:-$(mktemp -d)}"
FX="$ROOT/gta/shaders/FusionBridgeSA.fx"
cd "$WORK"
if [ ! -x rsfx/build/fxc ]; then
  rm -rf rsfx && mkdir rsfx && cd rsfx
  git init -q && git remote add origin https://github.com/crosire/reshade
  git config core.sparseCheckout true
  printf "source/effect_*\ntools/fxc.cpp\n" > .git/info/sparse-checkout
  git fetch -q --depth 1 origin tag v6.8.0 && git checkout -q tags/v6.8.0
  mkdir -p build
  printf '#define VERSION_MAJOR 6\n#define VERSION_MINOR 8\n#define VERSION_REVISION 0\n#define VERSION_STRING_PRODUCT "6.8.0"\n' > build/version.h
  printf '#include "effect_codegen.hpp"\nnamespace reshadefx {\ncodegen *create_codegen_dxbc(unsigned, bool, bool, int) { return nullptr; }\ncodegen *create_codegen_dxil(unsigned, bool, bool, int) { return nullptr; }\ncodegen *create_codegen_spirv(bool, bool, bool, bool, bool) { return nullptr; }\n}\n' > build/stub.cpp
  g++ -std=c++20 -O1 -w -I source -I build -o build/fxc tools/fxc.cpp source/effect_lexer.cpp source/effect_preprocessor.cpp \
    source/effect_parser_exp.cpp source/effect_parser_stmt.cpp source/effect_expression.cpp source/effect_symbol_table.cpp \
    source/effect_codegen_hlsl.cpp source/effect_codegen_glsl.cpp build/stub.cpp
  cd "$WORK"
fi
mkdir -p fxh
for f in ReShade.fxh ReShadeUI.fxh; do
  [ -f "fxh/$f" ] || curl -fsSL "https://raw.githubusercontent.com/crosire/reshade-shaders/fd0022170615ce0d8162d219bff07232fa6dd84f/Shaders/$f" -o "fxh/$f"
done
rsfx/build/fxc -I fxh --hlsl --shader-model 30 --width 1920 --height 1080 -Fo FusionBridgeSA.sm30.hlsl "$FX"
echo "ReShade FX compiler (shader model 3): OK -> $WORK/FusionBridgeSA.sm30.hlsl"
DLL="${1:-}"
if [ -n "$DLL" ]; then
  WINE="$(command -v wine64 || echo /usr/lib/wine/wine64)"
  x86_64-w64-mingw32-gcc -O1 -o hlslc.exe "$ROOT/tools/hlslc.c"
  cp "$DLL" d3dc.dll
  export WINEDEBUG=-all
  rc=0
  for e in "E__PostProcessVS vs_3_0" "E__PS_Light ps_3_0" "E__PS_Composite ps_3_0" "E__PS_Bright ps_3_0" "E__PS_Final ps_3_0"; do
    set -- $e
    printf "%-18s " "$1"
    "$WINE" hlslc.exe d3dc.dll FusionBridgeSA.sm30.hlsl "$1" "$2" 3 2>&1 | tr -d '\r' | grep -v '^$' | tail -3 | tr '\n' ' ' || rc=1
    echo
  done
  exit $rc
fi
