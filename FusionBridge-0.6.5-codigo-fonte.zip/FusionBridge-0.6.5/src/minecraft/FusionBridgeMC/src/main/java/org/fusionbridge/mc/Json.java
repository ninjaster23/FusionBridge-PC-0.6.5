// Leitura e escrita minima de JSON (uma mensagem por linha do hub).
package org.fusionbridge.mc;

import java.util.Locale;

final class Json {
    private Json() {
    }

    static String str(String var0, String var1) {
        int var2 = valueStart(var0, var1);
        if (var2 < 0 || var2 >= var0.length() || var0.charAt(var2) != '"') {
            return null;
        }
        StringBuilder var3 = new StringBuilder();

        for (int var4 = var2 + 1; var4 < var0.length(); var4++) {
            char var5 = var0.charAt(var4);
            if (var5 == '"') {
                return var3.toString();
            }

            if (var5 == '\\' && var4 + 1 < var0.length()) {
                char var6 = var0.charAt(++var4);
                switch (var6) {
                    case 'n':
                        var3.append('\n');
                        break;
                    case 't':
                        var3.append('\t');
                        break;
                    case 'r':
                        var3.append('\r');
                        break;
                    case 'u':
                        if (var4 + 4 < var0.length()) {
                            var3.append((char)Integer.parseInt(var0.substring(var4 + 1, var4 + 5), 16));
                            var4 += 4;
                        }
                        break;
                    default:
                        var3.append(var6);
                }
            } else {
                var3.append(var5);
            }
        }

        return null;
    }

    static double num(String var0, String var1, double var2) {
        int var4 = valueStart(var0, var1);
        if (var4 < 0) {
            return var2;
        } else {
            int var5 = var4;

            while (var5 < var0.length() && "+-0123456789.eE".indexOf(var0.charAt(var5)) >= 0) {
                var5++;
            }

            try {
                return Double.parseDouble(var0.substring(var4, var5));
            } catch (RuntimeException var7) {
                return var2;
            }
        }
    }

    private static int valueStart(String var0, String var1) {
        if (var0 == null) {
            return -1;
        } else {
            String var2 = "\"" + var1 + "\"";
            int var3 = 0;

            while (true) {
                int var4 = var0.indexOf(var2, var3);
                if (var4 < 0) {
                    return -1;
                }

                int var5 = var4 + var2.length();

                while (var5 < var0.length() && Character.isWhitespace(var0.charAt(var5))) {
                    var5++;
                }

                if (var5 < var0.length() && var0.charAt(var5) == ':') {
                    var5++;

                    while (var5 < var0.length() && Character.isWhitespace(var0.charAt(var5))) {
                        var5++;
                    }

                    return var5;
                }

                var3 = var4 + 1;
            }
        }
    }

    static String esc(String var0) {
        if (var0 == null) {
            return "";
        } else {
            StringBuilder var1 = new StringBuilder(var0.length() + 8);

            for (int var2 = 0; var2 < var0.length(); var2++) {
                char var3 = var0.charAt(var2);
                if (var3 == '"' || var3 == '\\') {
                    var1.append('\\').append(var3);
                } else if (var3 == '\n') {
                    var1.append("\\n");
                } else if (var3 == '\r') {
                    var1.append("\\r");
                } else if (var3 < ' ') {
                    var1.append(String.format("\\u%04x", Integer.valueOf(var3)));
                } else {
                    var1.append(var3);
                }
            }

            return var1.toString();
        }
    }

    static String n(double var0) {
        if (Double.isNaN(var0) || Double.isInfinite(var0)) {
            return "null";
        }
        return String.format(Locale.ROOT, "%.2f", var0);
    }
}
