-- FusionBridge GTA (PC) 0.2.4 - MoonLoader script for GTA: San Andreas (single player, 1.0).
-- Connects to the FusionBridge hub on 127.0.0.1:28765 and fuses GTA SA with Minecraft Java.
--
-- 0.1.0 (kept): CJ position/health to the panel, panel commands (block, boom, boom_rain, heal, shake, hud),
--   Minecraft events (TNT, Wither, lightning, creeper) as explosions near CJ, Minecraft hearts on screen.
-- 0.2.0 (new) - FUSAO VISUAL: Minecraft drawn *inside* GTA, like the "Minecraft x GTA V" kit:
--   * every frame sends GTA's camera and CJ to the hub (fusion_cam); the hub drives Minecraft's camera with it;
--   * probes GTA's ground around CJ (fusion_ground): it becomes invisible barrier blocks in Minecraft;
--   * forwards the mouse (attack/use), the wheel and keys 1-9 to Minecraft while you walk;
--   * hides CJ (Steve takes his place) and makes him explosion/fire proof while the fusion is on;
--   * acts out Minecraft's explosions, ender pearls and built blocks in GTA (fusion_boom/teleport/props);
--   * talks to FusionBridgeSA.asi (ReShade add-on) through FFI: exact camera, and it composites the picture.
-- 0.2.1: the connect to the hub runs in the background (a refused connect no longer freezes GTA for ~2 s), the
--   keep-alive goes out in cutscenes and menus too, and the hearts moved to the top (they covered the subtitles).
-- 0.2.2: THE FREEZE. FIONBIO (0x8004667E) reached ioctlsocket as 0x80000000 (LuaJIT's signed 32-bit conversion),
--   so the socket stayed blocking and the first recv() held GTA's thread until the app dropped the link (60 s):
--   "Nao foi possivel restaurar gta_sa.exe". Now: the right value, a socket that isn't non-blocking is never used,
--   select() before every recv, partial sends kept, lines cut in one pass, the block model streamed in the
--   background (a re-level no longer stalls the game), and milestones/errors go to moonloader.log.
-- 0.2.3: Minecraft's inventory used inside GTA (I): GTA's cursor, clicks, Shift, 1-9, Q and the wheel go to
--   Minecraft's window through the app (fusion_pointer); I or E closes it. The main loop runs each frame in a pcall:
--   an unexpected error is logged to moonloader.log and the script carries on.
-- 0.2.4: FSR 1.0 (AMD) for Minecraft's picture: fusion_state carries the app's choice (fsr, sharp) to the ASI.
-- Keys: F7 fusion on/off, F8 re-level Minecraft's ground, F6 mouse Minecraft <-> GTA.
--
-- Install: put this file in  <GTA San Andreas>\moonloader\  (needs MoonLoader; the visual fusion also needs
-- FusionBridgeSA.asi + ReShade 6.8 add-on in the game folder - INSTALAR.cmd puts them there).
-- TCP is done with LuaJIT FFI over ws2_32 (Winsock): no extra Lua libraries.

script_name('FusionBridge GTA')
script_author('FusionBridge')
script_version('0.2.4')

local ffi = require 'ffi'
local bit = require 'bit'

local HOST       = '127.0.0.1'
local PORT       = 28765
local VERSION    = '0.2.4'
local BLOCK_MODEL = 1224          -- "woodenbox": a solid, block-shaped prop
local MAX_BLOCKS  = 40            -- keep at most this many; delete the oldest
local MAX_PROPS   = 150           -- Minecraft blocks mirrored as invisible GTA walls
local STATE_HZ    = { eco = 5, live = 20, visual = 20 }
local DEFAULT_VFOV = 55.4         -- GTA SA: 70 deg horizontal on a 4:3 projection

-- virtual keys
local VK_LBUTTON, VK_RBUTTON = 0x01, 0x02
local VK_F6, VK_F7, VK_F8 = 0x75, 0x76, 0x77

----------------------------------------------------------------- Winsock (FFI, no deps)
ffi.cdef[[
  typedef uintptr_t SOCKET;
  int WSAStartup(uint16_t wVersionRequested, char* lpWSAData);
  SOCKET socket(int af, int type, int protocol);
  int connect(SOCKET s, const char* name, int namelen);
  int send(SOCKET s, const char* buf, int len, int flags);
  int recv(SOCKET s, char* buf, int len, int flags);
  int closesocket(SOCKET s);
  int ioctlsocket(SOCKET s, long cmd, unsigned long* argp);
  int setsockopt(SOCKET s, int level, int optname, const char* optval, int optlen);
  unsigned short htons(unsigned short hostshort);
  unsigned long inet_addr(const char* cp);
  int WSAGetLastError(void);
  void* GetForegroundWindow(void);
  unsigned long GetWindowThreadProcessId(void* hWnd, unsigned long* lpdwProcessId);
  unsigned long GetCurrentProcessId(void);
  int FB_Version(void);
  int FB_GetCamera(float* out);
  void FB_SetFusion(int composite, int block_mouse, float yoff);
  int FB_GetStatus(int* out);
  void FB_SetFsr(int on, float sharpness);
]]
-- select() for the connect that runs in the background (own type names: never clash with another script's cdef)
local has_select = pcall(ffi.cdef, [[
  typedef struct { unsigned int fd_count; SOCKET fd_array[64]; } fb_fd_set;
  typedef struct { long tv_sec; long tv_usec; } fb_timeval;
  int select(int nfds, fb_fd_set* readfds, fb_fd_set* writefds, fb_fd_set* exceptfds, const fb_timeval* timeout);
]])
local ok_ws2, ws2 = pcall(ffi.load, 'ws2_32')   -- Windows only; stays nil elsewhere (HUD still works)
if not ok_ws2 then ws2 = nil end
local ok_u32, u32 = pcall(ffi.load, 'user32')
if not ok_u32 then u32 = nil end
local ok_k32, k32 = pcall(ffi.load, 'kernel32')
if not ok_k32 then k32 = nil end

local AF_INET, SOCK_STREAM, IPPROTO_TCP = 2, 1, 6
local TCP_NODELAY    = 1
local SOCKET_ERROR   = -1
-- ioctlsocket's 'cmd' is a 32-bit signed C long. 0x8004667E is above 2^31, and LuaJIT turns a number that big into
-- 0x80000000 when it converts it to a 32-bit signed integer: ioctlsocket then failed, the socket stayed BLOCKING and
-- the first recv() froze GTA (fixed in 0.2.2). bit.tobit gives the same 32 bits as a negative number that fits.
local FIONBIO        = bit.tobit(0x8004667E)
local WSAEWOULDBLOCK = 10035
local WSAEINVAL, WSAEALREADY, WSAEISCONN = 10022, 10037, 10056
local CONNECT_MS     = 3000       -- a connect still pending after this long counts as failed
local MAX_READS      = 32         -- recv() calls per frame at most (8 KB each): the link never holds the game up
local MAX_OUT        = 262144     -- bytes waiting to go out; more means the app stopped reading: drop the link
local MAX_LINE       = 1048576    -- a line longer than this is garbage: skipped whole

-- one line in moonloader.log (MoonLoader writes print() there); 'key' lets a repeated message through rarely
local said = {}
local function say(msg, key)
  if key then
    local n = (said[key] or 0) + 1
    said[key] = n
    if n > 3 and n % 100 ~= 0 then return end
    if n > 3 then msg = msg .. string.format(' (%d vezes)', n) end
  end
  print('[FusionBridge] ' .. msg)
end

-- socket() failed: INVALID_SOCKET is all bits set. On 32-bit LuaJIT a SOCKET comes back as a plain number
-- (4294967295): compare it as a number, never push it through a signed 32-bit conversion (see FIONBIO)
local function bad_socket(s)
  if type(s) == 'number' then return s == 4294967295 or s == -1 end
  return tonumber(ffi.cast('intptr_t', s)) == -1
end

local function wsa_init()
  if not ws2 then return false end
  local data = ffi.new('char[?]', 512)
  return ws2.WSAStartup(0x0202, data) == 0
end

-- builds a sockaddr_in (16 bytes) for 127.0.0.1:PORT
local function sockaddr_in(ip, port)
  local sa = ffi.new('char[16]')
  ffi.fill(sa, 16, 0)
  ffi.cast('short*', sa)[0] = AF_INET
  ffi.cast('unsigned short*', sa + 2)[0] = ws2.htons(port)
  ffi.cast('unsigned long*', sa + 4)[0] = ws2.inet_addr(ip)
  return sa
end

local Conn = {}
Conn.__index = Conn
function Conn.new()
  return setmetatable({ sock = nil, pending = nil, inbuf = '', out = '', skip = false, buf = ffi.new('char[8192]') }, Conn)
end

local zero_tv = has_select and ffi.new('fb_timeval') or nil

-- true when recv() on s returns at once (data waiting, or the peer closed / reset the link)
local function readable(s)
  if not has_select then return true end      -- (non-blocking mode was confirmed by ioctlsocket)
  local r = ffi.new('fb_fd_set')
  r.fd_count, r.fd_array[0] = 1, s
  local n = ws2.select(0, r, nil, nil, zero_tv)
  if n == SOCKET_ERROR then return nil end    -- the socket itself is broken
  return r.fd_count > 0
end

-- Starts connecting without blocking the game: on Windows a connect to a port nobody listens on (the app closed)
-- takes ~2 s to be refused, and MoonLoader runs this script on GTA's own thread. Returns false when it failed at
-- once; otherwise check_pending() finishes it. A socket that can't be made non-blocking is never used.
function Conn:connect(t)
  self:close()
  if not ws2 then return false end
  local s = ws2.socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)
  if bad_socket(s) then return false end
  local nb = ffi.new('unsigned long[1]', 1)
  if ws2.ioctlsocket(s, FIONBIO, nb) ~= 0 then
    say(string.format('nao consegui deixar a conexao sem bloqueio (ioctlsocket, erro %d): sem ponte', ws2.WSAGetLastError()), 'nb')
    ws2.closesocket(s)
    return false
  end
  local one = ffi.new('int[1]', 1)
  ws2.setsockopt(s, IPPROTO_TCP, TCP_NODELAY, ffi.cast('const char*', one), 4)  -- camera every frame: no Nagle delay
  if ws2.connect(s, sockaddr_in(HOST, PORT), 16) == SOCKET_ERROR then
    local e = ws2.WSAGetLastError()
    if e ~= WSAEWOULDBLOCK then ws2.closesocket(s); return false end
    self.pending, self.pending_t = s, t or 0  -- still connecting
    return true
  end
  self.sock, self.inbuf, self.out, self.skip = s, '', '', false
  return true
end

-- the connect started by connect(): 'up' (connected: self.sock is set), 'wait' (not yet) or 'fail' (closed)
function Conn:check_pending(t)
  local s = self.pending
  if not s then return self.sock and 'up' or 'fail' end
  local state = 'wait'
  if has_select then
    local w, e = ffi.new('fb_fd_set'), ffi.new('fb_fd_set')
    w.fd_count, w.fd_array[0] = 1, s
    e.fd_count, e.fd_array[0] = 1, s
    local n = ws2.select(0, nil, w, e, zero_tv)  -- zero timeout: only looks
    if n == SOCKET_ERROR or e.fd_count > 0 then state = 'fail'
    elseif w.fd_count > 0 then state = 'up' end
  else
    -- no select(): a second connect() says how the first one went
    if ws2.connect(s, sockaddr_in(HOST, PORT), 16) == SOCKET_ERROR then
      local err = ws2.WSAGetLastError()
      if err == WSAEISCONN then state = 'up'
      elseif err ~= WSAEWOULDBLOCK and err ~= WSAEALREADY and err ~= WSAEINVAL then state = 'fail' end
    else
      state = 'up'
    end
  end
  if state == 'wait' and (t or 0) - (self.pending_t or 0) > CONNECT_MS then state = 'fail' end
  if state == 'up' then
    self.sock, self.pending, self.inbuf, self.out, self.skip = s, nil, '', '', false
  elseif state == 'fail' then
    self:close()
  end
  return state
end

function Conn:close()
  if self.sock then ws2.closesocket(self.sock); self.sock = nil end
  if self.pending then ws2.closesocket(self.pending); self.pending = nil end
  self.inbuf, self.out, self.skip = '', '', false
end

-- sends data now; what the socket can't take yet waits in self.out (in order). false: the link is gone
function Conn:send_raw(data)
  local n = ws2.send(self.sock, data, #data, 0)
  if n == SOCKET_ERROR then
    if ws2.WSAGetLastError() ~= WSAEWOULDBLOCK then self:close(); return false end
    n = 0
  end
  if n < #data then self.out = data:sub(n + 1) end
  return true
end

-- the bytes still waiting from earlier frames
function Conn:flush()
  if not self.sock then return false end
  if #self.out == 0 then return true end
  local data = self.out
  self.out = ''
  return self:send_raw(data)
end

function Conn:send_line(line)
  if not self.sock then return false end
  if #self.out > 0 then
    if #self.out > MAX_OUT then
      say('o app parou de ler a ponte: desconectando (volta sozinho)', 'out')
      self:close(); return false
    end
    self.out = self.out .. line .. '\n'
    return self:flush()
  end
  return self:send_raw(line .. '\n')
end

-- returns a table of complete lines received since last call (may be empty); nil means disconnected.
-- Never waits: select() first, at most MAX_READS reads, lines cut in one pass (no copying per line).
function Conn:poll_lines()
  if not self.sock then return nil end
  local chunks = {}
  for _ = 1, MAX_READS do
    local ok = readable(self.sock)
    if ok == nil then self:close(); return nil end
    if not ok then break end
    local n = ws2.recv(self.sock, self.buf, 8192, 0)
    if n > 0 then
      chunks[#chunks + 1] = ffi.string(self.buf, n)
    elseif n == 0 then
      self:close(); return nil                           -- peer closed
    else
      if ws2.WSAGetLastError() ~= WSAEWOULDBLOCK then self:close(); return nil end
      break                                              -- no more data this frame
    end
  end
  local lines = {}
  if #chunks == 0 then return lines end
  local data = self.inbuf .. table.concat(chunks)
  local pos = 1
  if self.skip then                                      -- the rest of a runaway line: drop up to its end
    local i = data:find('\n', 1, true)
    if not i then self.inbuf = ''; return lines end
    pos, self.skip = i + 1, false
  end
  while true do
    local i = data:find('\n', pos, true)
    if not i then break end
    lines[#lines + 1] = data:sub(pos, i - 1)
    pos = i + 1
  end
  self.inbuf = data:sub(pos)
  if #self.inbuf > MAX_LINE then self.inbuf, self.skip = '', true end
  return lines
end

----------------------------------------------------------------- tiny JSON field readers
-- The hub speaks a small, fixed JSON-lines protocol, so field extractors are enough (no full parser).
local NUM = '(-?%d+%.?%d*[eE]?[-+]?%d*)'
local function jstr(s, key)
  return s:match('"' .. key .. '"%s*:%s*"(.-)"')
end
local function jnum(s, key)
  local v = s:match('"' .. key .. '"%s*:%s*' .. NUM)
  return v and tonumber(v)
end
-- flat number array: "key":[1.5,-2,3e-2,...]
local function jarr(s, key)
  local body = s:match('"' .. key .. '"%s*:%s*%[(.-)%]')
  if not body then return nil end
  local out = {}
  for v in body:gmatch('[-+%deE%.]+') do
    local n = tonumber(v)
    if n then out[#out + 1] = n end
  end
  return out
end
-- strips anything that could break the JSON we build (quotes, backslashes, control chars)
local function jsafe(s)
  return (tostring(s or ''):gsub('[%c"\\]', ' '))
end

----------------------------------------------------------------- game helpers (opcode wrappers only)
local function game_ready()
  local ok, playing = pcall(isPlayerPlaying, PLAYER_HANDLE)
  return ok and playing
end

local function cj()
  local ped = PLAYER_PED
  local x, y, z = getCharCoordinates(ped)
  local h = getCharHeading(ped)
  local hp = getCharHealth(ped)
  return x, y, z, h, hp
end

local function forward(h)   -- unit forward vector from heading (degrees)
  local r = math.rad(h)
  return -math.sin(r), math.cos(r)
end

local g_blocks = {}
local function place_block(model, x, y, z)
  model = model or BLOCK_MODEL
  requestModel(model)
  loadAllModelsNow()
  local obj = createObject(model, x, y, z)
  g_blocks[#g_blocks + 1] = obj
  markModelAsNoLongerNeeded(model)
  if #g_blocks > MAX_BLOCKS then
    local old = table.remove(g_blocks, 1)
    pcall(deleteObject, old)
  end
  return obj
end

local function boom(x, y, z, etype)
  addExplosion(x, y, z, etype or 2)
end

local function heal()
  setCharHealth(PLAYER_PED, 100)
end

local function shake(ms)
  shakeCam(ms or 1200)
end

local function in_car()
  local ok, r = pcall(isCharInAnyCar, PLAYER_PED)
  return ok and r
end

local function paused()
  local ok, r = pcall(isPauseMenuActive)
  if ok and r then return true end
  ok, r = pcall(isGamePaused)
  return ok and r
end

-- the GTA window has the keyboard/mouse (never forward clicks typed into another program)
local function foreground()
  if not (u32 and k32) then return true end
  local w = u32.GetForegroundWindow()
  if w == nil then return false end
  local pid = ffi.new('unsigned long[1]')
  u32.GetWindowThreadProcessId(w, pid)
  return pid[0] == k32.GetCurrentProcessId()
end

----------------------------------------------------------------- FusionBridgeSA.asi (FFI)
local fb = nil            -- the ASI's exported API, when present
local fb_ver = 0
local fb_cam = ffi.new('float[16]')
local fb_st = ffi.new('int[16]')

local function load_asi()
  local paths = {}
  local okd, dir = pcall(getGameDirectory)
  if okd and type(dir) == 'string' and dir ~= '' then
    paths[#paths + 1] = dir .. '\\FusionBridgeSA.asi'
    paths[#paths + 1] = dir .. '\\scripts\\FusionBridgeSA.asi'
  end
  paths[#paths + 1] = 'FusionBridgeSA.asi'
  for _, p in ipairs(paths) do
    local ok, lib = pcall(ffi.load, p)
    if ok and lib then
      local okv, v = pcall(function() return lib.FB_Version() end)
      if okv and v and v >= 600 then return lib, v end
    end
  end
  return nil, 0
end

-- GTA's camera, GTA convention: position, heading/pitch/roll (degrees), vertical fov, projection aspect
local function read_camera()
  if fb then
    local ok, valid = pcall(fb.FB_GetCamera, fb_cam)
    if ok and valid == 1 then
      return fb_cam[0], fb_cam[1], fb_cam[2], fb_cam[3], fb_cam[4], fb_cam[5], fb_cam[6], fb_cam[9]
    end
  end
  -- without the ASI: the active camera from opcodes (no roll, default fov)
  local cx, cy, cz = getActiveCameraCoordinates()
  local tx, ty, tz = getActiveCameraPointAt()
  local fx, fy, fz = tx - cx, ty - cy, tz - cz
  local len = math.sqrt(fx * fx + fy * fy + fz * fz)
  if len < 1e-4 then return nil end
  fx, fy, fz = fx / len, fy / len, fz / len
  local heading = math.deg(math.atan2(-fx, fy))
  local pitch = math.deg(math.asin(math.max(-1, math.min(1, fz))))
  return cx, cy, cz, heading, pitch, 0.0, DEFAULT_VFOV, 4 / 3
end

----------------------------------------------------------------- Minecraft hearts HUD (pixel boxes)
-- 7x6 heart drawn as filled cells; state 0 empty, 1 half, 2 full. No font/texture needed.
local HEART = {
  '.XX.XX.',
  'XXXXXXX',
  'XXXXXXX',
  '.XXXXX.',
  '..XXX..',
  '...X...',
}
local COL_FULL  = 0xFFE81818   -- ARGB red
local COL_EMPTY = 0xFF3A1414   -- dark red
local COL_BACK  = 0xC0000000   -- outline/backdrop

local function draw_heart(px, py, cell, state)
  -- backdrop so hearts read over any scene
  renderDrawBox(px - cell, py - cell, 7 * cell + 2 * cell, 6 * cell + 2 * cell, COL_BACK)
  for row = 1, 6 do
    local line = HEART[row]
    for col = 1, 7 do
      if line:sub(col, col) == 'X' then
        local color
        if state == 2 then color = COL_FULL
        elseif state == 1 then color = (col <= 3) and COL_FULL or COL_EMPTY
        else color = COL_EMPTY end
        renderDrawBox(px + (col - 1) * cell, py + (row - 1) * cell, cell, cell, color)
      end
    end
  end
end

local function draw_hearts(half_hearts, connected)
  local sw, sh = getScreenResolution()
  local cell = math.max(2, math.floor(sh / 240))
  local hw = 7 * cell + 2 * cell          -- heart width incl. backdrop
  local gap = cell
  local total = 10 * (hw + gap)
  local x0 = (sw - total) / 2
  local y0 = sh * 0.03                    -- top centre: GTA's subtitles use the bottom of the screen
  for i = 0, 9 do
    local st = 0
    if half_hearts >= (i + 1) * 2 then st = 2
    elseif half_hearts == i * 2 + 1 then st = 1 end
    draw_heart(x0 + i * (hw + gap), y0, cell, st)
  end
  -- bridge dot at the right end
  local dot = connected and 0xFF7FE08A or 0xFFFFD166
  renderDrawBox(x0 + total + cell, y0 + cell, cell * 2, cell * 2, dot)
end

----------------------------------------------------------------- state
local g_mode = 'eco'
local g_hud_on = true
local g_rules = { tnt = true, wither = true, lightning = true, creeper = true }
local g_mc = { has = false, x = 0, y = 0, z = 0 }   -- last Minecraft player pos (for relative mapping)
local g_last_state = 0
local g_last_ping = 0
local g_rng = 12345
local function rnd() g_rng = (g_rng * 1103515245 + 12345) % 2147483648; return (g_rng % 10000) / 10000 end

-- the visual fusion, as the hub last told us (fusion_state)
local F = {
  on = false, mc = false, mouse = 'mc', hide_cj = true, cj_safe = true, props = true,
  radius = 40, probes = 96, yoff = 0.0, level = false,
  keys = { { 0x01, 'attack' }, { 0x02, 'use' } }, keys_sig = 'attack,use',   -- the hub sends the fused keys
}
-- action codes of fusion_state "keys": [vk, action, ...] (fusion_engine.KEY_ACTIONS)
local KEY_ACTIONS = { [1] = 'attack', [2] = 'use', [3] = 'inventory', [4] = 'drop', [5] = 'swap', [7] = 'prev', [8] = 'next' }
local G = {                       -- local fusion bookkeeping
  frame = 0, sampled = {}, nsampled = 0, retry = {}, spiral = nil, spiral_r = 0,
  last_pg_t = -1e9, pg = nil, hidden = false, safe = false,
  buttons = { attack = false, use = false }, inv = false, cursor = false, inv_btn = {}, inv_keys = {}, inv_at = nil, view_sent = nil, last_asi_t = -1e9, last_cam_t = -1e9,
  props = {}, nprops = 0, pending = {}, prop_model_ready = false, prop_model_asked = false,
}

-- place an effect near CJ: a ring around him, radius minr..maxr, random angle
local function near_cj(minr, maxr)
  local x, y, z = cj()
  local a = rnd() * math.pi * 2
  local r = minr + rnd() * (maxr - minr)
  return x + math.cos(a) * r, y + math.sin(a) * r, z
end

local function fusion_live()
  return F.on and F.mc
end

----------------------------------------------------------------- fusion: ground probes
-- Minecraft column (cx, cz) covers GTA x in [cx, cx+1) and y in (-cz-1, -cz]: probe its centre.
local function build_spiral(r)
  local s = {}
  for dx = -r, r do
    for dz = -r, r do
      if dx * dx + dz * dz <= r * r then s[#s + 1] = { dx, dz, dx * dx + dz * dz } end
    end
  end
  table.sort(s, function(a, b) return a[3] < b[3] end)
  return s
end

local function col_key(cx, cz) return cx * 65536 + cz end

local function ground_reset()
  G.sampled, G.nsampled, G.retry = {}, 0, {}
end

-- probes up to F.probes unsampled columns around CJ (nearest first); returns a JSON array body or nil
local function sample_ground(px, py, pz)
  if G.spiral_r ~= F.radius or not G.spiral then
    G.spiral, G.spiral_r = build_spiral(F.radius), F.radius
  end
  if G.nsampled > 200000 then ground_reset() end
  local bx, bz = math.floor(px), math.floor(-py)
  local parts, probes = {}, 0
  for i = 1, #G.spiral do
    local o = G.spiral[i]
    local cx, cz = bx + o[1], bz + o[2]
    local k = col_key(cx, cz)
    if not G.sampled[k] and (G.retry[k] or 0) <= G.frame then
      probes = probes + 1
      if probes > F.probes then break end
      local gz = getGroundZFor3dCoord(cx + 0.5, -(cz + 0.5), pz + 1.5)
      -- 0.0 = no collision there (water) or not streamed in yet: try again in about half a second
      if gz and gz ~= 0.0 then
        G.sampled[k] = true
        G.nsampled = G.nsampled + 1
        parts[#parts + 1] = string.format('[%d,%d,%.3f]', cx, cz, gz)
      else
        G.retry[k] = G.frame + 30
      end
    end
  end
  if #parts == 0 then return nil end
  return table.concat(parts, ',')
end

----------------------------------------------------------------- fusion: Minecraft blocks as invisible GTA walls
local function prop_key(x, y, z) return string.format('%.1f,%.1f,%.1f', x, y, z) end

-- release_model: also let the streamer drop the block model (fusion off). A re-level (clear_all) keeps it, so
-- the next blocks don't wait for it again.
local function props_clear_all(release_model)
  for _, obj in pairs(G.props) do pcall(deleteObject, obj) end
  G.props, G.nprops, G.pending = {}, 0, {}
  if release_model and (G.prop_model_ready or G.prop_model_asked) then
    pcall(markModelAsNoLongerNeeded, BLOCK_MODEL)
    G.prop_model_ready, G.prop_model_asked = false, false
  end
end

local function props_tick()
  if #G.pending == 0 then return end
  if not G.prop_model_ready then
    -- asked once, then checked every frame: the streamer loads it in the background (loadAllModelsNow stalled
    -- the game on every re-level)
    if not G.prop_model_asked then requestModel(BLOCK_MODEL); G.prop_model_asked = true end
    local ok, loaded = pcall(hasModelLoaded, BLOCK_MODEL)
    if not (ok and loaded) then return end
    G.prop_model_ready = true
  end
  local n = 0
  while #G.pending > 0 and n < 20 do
    local p = table.remove(G.pending, 1)   -- arrival order: the app sends the nearest first
    local k = prop_key(p[1], p[2], p[3])
    if not G.props[k] then
      if G.nprops >= MAX_PROPS then G.pending = {}; break end
      local ok, obj = pcall(createObject, BLOCK_MODEL, p[1], p[2], p[3] + 0.5)
      if ok and obj then
        pcall(setObjectVisible, obj, false)       -- Minecraft draws the block; GTA keeps only the collision
        pcall(freezeObjectPosition, obj, true)
        pcall(setObjectCollision, obj, true)
        G.props[k] = obj
        G.nprops = G.nprops + 1
      end
      n = n + 1
    end
  end
end

----------------------------------------------------------------- fusion: CJ (hide + proofs) and input
local function set_cj_hidden(want)
  if want == G.hidden then return end
  pcall(setCharVisible, PLAYER_PED, not want)
  G.hidden = want
end

local function set_cj_safe(want)
  if want == G.safe then return end
  -- bullet, fire, explosion, collision, melee
  pcall(setCharProofs, PLAYER_PED, false, want, want, false, false)
  G.safe = want
end

local function release_held(conn)
  for k, down in pairs(G.buttons) do
    if down then
      conn:send_line(string.format('{"type":"fusion_input","k":"%s","down":false}', k))
      G.buttons[k] = false
    end
  end
end

----------------------------------------------------------------- Minecraft's inventory inside GTA
-- With the inventory open, GTA shows its mouse cursor (CJ and the camera stay still) and the cursor, the clicks, the
-- wheel and the inventory keys go to Minecraft's own window through the app (fusion_pointer): the inventory drawn
-- inside GTA is used right there, without switching windows. Positions are fractions of GTA's screen.
local VK_MBUTTON = 0x04
local INV_KEYS = { 0x10, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x51 }  -- Shift, 1-9 (hotbar), Q (drop)
local INV_BUTTONS = { { VK_LBUTTON, 0 }, { VK_RBUTTON, 1 }, { VK_MBUTTON, 2 } }

-- MoonLoader's showCursor(show, lockControls): GTA's cursor, with CJ and the camera locked while it is up
local function cursor(show)
  local ok = pcall(showCursor, show, show)
  G.cursor = (show and ok) and true or false
  return ok
end

local function inv_point()
  local okc, cx, cy = pcall(getCursorPos)
  local oks, sw, sh = pcall(getScreenResolution)
  if not (okc and oks and cx and cy and sw and sh and sw > 1 and sh > 1) then return nil end
  return math.max(0, math.min(1, cx / (sw - 1))), math.max(0, math.min(1, cy / (sh - 1)))
end

local function inv_open(conn)
  release_held(conn)                             -- a click held while opening must not stay down
  conn:send_line('{"type":"fusion_input","k":"inventory","down":true}')
  conn:send_line('{"type":"fusion_input","k":"inventory","down":false}')
  G.inv, G.inv_btn, G.inv_keys, G.inv_at = true, {}, {}, nil
  if not cursor(true) then
    say('o MoonLoader nao mostrou o cursor (showCursor): o inventario abre, mas os cliques nao chegam', 'cursor')
  end
end

-- closes Minecraft's inventory and gives GTA its mouse back (conn may be nil: link already gone)
local function inv_close(conn)
  if not G.inv and not G.cursor then return end   -- (called every frame while the mouse is GTA's)
  if G.inv and conn then
    conn:send_line('{"type":"fusion_pointer","release":1}')   -- buttons/keys still held in Minecraft's window
    conn:send_line('{"type":"fusion_input","k":"escape","down":true}')
  end
  G.inv, G.inv_btn, G.inv_keys, G.inv_at = false, {}, {}, nil
  if G.cursor then cursor(false) end
end

-- one frame with the inventory open
local function inv_tick(conn)
  local x, y = inv_point()
  if not x then return end
  local at = string.format('"x":%.4f,"y":%.4f', x, y)
  if at ~= G.inv_at then
    G.inv_at = at
    conn:send_line('{"type":"fusion_pointer",' .. at .. '}')
  end
  for _, b in ipairs(INV_BUTTONS) do
    local down = isKeyDown(b[1]) and true or false
    if down ~= (G.inv_btn[b[2]] or false) then
      G.inv_btn[b[2]] = down
      conn:send_line(string.format('{"type":"fusion_pointer",%s,"b":%d,"down":%d}', at, b[2], down and 1 or 0))
    end
  end
  for _, vk in ipairs(INV_KEYS) do
    local down = isKeyDown(vk) and true or false
    if down ~= (G.inv_keys[vk] or false) then
      G.inv_keys[vk] = down
      conn:send_line(string.format('{"type":"fusion_pointer","vk":%d,"down":%d}', vk, down and 1 or 0))
    end
  end
  local okw, d = pcall(getMousewheelDelta)
  if okw and d and d ~= 0 then
    conn:send_line(string.format('{"type":"fusion_pointer",%s,"wheel":%d}', at, d > 0 and 1 or -1))
  end
end

local function release_buttons(conn)
  release_held(conn)
  inv_close(conn)                                 -- Minecraft's inventory was open: close it
end

-- held keys go down/up like in Minecraft; the others act once per press
local HELD = { attack = true, use = true, drop = true, swap = true }

local function forward_input(conn)
  if G.inv then
    -- I (or E, Minecraft's own inventory key) closes it; everything else goes to the inventory screen
    for _, e in ipairs(F.keys) do
      if (e[2] == 'inventory' or e[2] == 'next') and isKeyJustPressed(e[1]) then inv_close(conn); return end
    end
    inv_tick(conn)
    return
  end
  for _, e in ipairs(F.keys) do
    local vk, a = e[1], e[2]
    if HELD[a] then
      local down = isKeyDown(vk) and true or false
      if down ~= (G.buttons[a] or false) then
        G.buttons[a] = down
        conn:send_line(string.format('{"type":"fusion_input","k":"%s","down":%s}', a, tostring(down)))
      end
    elseif isKeyJustPressed(vk) then
      if a == 'inventory' then                    -- I opens Minecraft's inventory (with a cursor, inside GTA)
        inv_open(conn)
        return
      elseif a == 'prev' then                     -- Q: GTA's previous weapon, Minecraft's previous item
        conn:send_line('{"type":"fusion_input","scroll":1}')
      elseif a == 'next' then                     -- E: next weapon / next item
        conn:send_line('{"type":"fusion_input","scroll":-1}')
      end
    end
  end
  for i = 1, 9 do
    if isKeyJustPressed(0x30 + i) then
      conn:send_line(string.format('{"type":"fusion_input","slot":%d}', i - 1))
    end
  end
  local okw, d = pcall(getMousewheelDelta)
  if okw and d and d ~= 0 then
    conn:send_line(string.format('{"type":"fusion_input","scroll":%d}', d > 0 and 1 or -1))
  end
end

----------------------------------------------------------------- fusion: the per-frame tick
local function now() return os.clock() * 1000 end

local function asi_status()
  if not fb then return nil end
  local ok = pcall(fb.FB_GetStatus, fb_st)
  if not ok then return nil end
  return {
    sa_ok = fb_st[0], reshade = fb_st[1], frame = fb_st[2], bb_w = fb_st[3], bb_h = fb_st[4],
    uploads = fb_st[5], pad_hook = fb_st[6], hud_hook = fb_st[7], effect = fb_st[8],
  }
end

local function send_view(conn, force)
  local st = asi_status()
  local w, h, aspect
  if st and st.bb_w > 0 and st.bb_h > 0 then
    w, h = st.bb_w, st.bb_h
  else
    local ok, sw, sh = pcall(getScreenResolution)
    if ok then w, h = sw, sh end
  end
  if not w or w <= 0 then return end
  local c = { read_camera() }
  aspect = c[8] or (w / h)
  local key = string.format('%d,%d,%.3f', w, h, aspect)
  if force or key ~= G.view_sent then
    G.view_sent = key
    conn:send_line(string.format('{"type":"fusion_view","w":%d,"h":%d,"aspect":%.4f}', w, h, aspect))
  end
end

local function fusion_tick(conn)
  G.frame = G.frame + 1
  local t = now()
  local car = in_car()
  local menu = paused()
  local live = fusion_live() and conn.sock ~= nil

  -- keys (only reach us while GTA has the focus)
  if isKeyJustPressed(VK_F7) then conn:send_line('{"type":"fusion_key","k":"toggle"}') end
  if isKeyJustPressed(VK_F8) then conn:send_line('{"type":"fusion_key","k":"relevel"}') end
  if isKeyJustPressed(VK_F6) then conn:send_line('{"type":"fusion_key","k":"mouse"}') end

  -- CJ: Steve takes his place on foot; in a car CJ shows (Minecraft hides Steve and its HUD)
  set_cj_hidden(live and F.hide_cj and not car)
  set_cj_safe(live and F.cj_safe)
  if live and G.frame % 60 == 0 then
    -- missions and cutscenes reset these: put them back once a second
    if G.hidden then pcall(setCharVisible, PLAYER_PED, false) end
    if G.safe then pcall(setCharProofs, PLAYER_PED, false, true, true, false, false) end
  end

  -- mouse: Minecraft's while walking (GTA's own fire/aim blocked by the ASI), GTA's in cars or in GTA mode
  local mouse_mc = live and F.mouse == 'mc' and not car and not menu and foreground()
  if mouse_mc then forward_input(conn) else release_buttons(conn) end
  if fb then pcall(fb.FB_SetFusion, (live and not menu) and 1 or 0, mouse_mc and 1 or 0, F.yoff) end

  -- the camera GTA renders with, and CJ: every frame while the fusion runs (2x/s otherwise, for leveling)
  if live or t - G.last_cam_t > 500 then
    G.last_cam_t = t
    local cx, cy, cz, heading, pitch, roll, vfov = read_camera()
    if cx then
      local px, py, pz = getCharCoordinates(PLAYER_PED)
      local ph = getCharHeading(PLAYER_PED)
      if t - G.last_pg_t > 200 then
        G.last_pg_t = t
        local gz = getGroundZFor3dCoord(px, py, pz + 1.0)
        G.pg = (gz and gz ~= 0.0) and gz or nil
      end
      conn:send_line(string.format(
        '{"type":"fusion_cam","f":%d,"c":[%.4f,%.4f,%.4f],"r":[%.3f,%.3f,%.3f],"fov":%.3f,' ..
        '"p":[%.4f,%.4f,%.4f],"h":%.3f,"veh":%d%s}',
        G.frame, cx, cy, cz, heading, pitch, roll, vfov, px, py, pz, ph, car and 1 or 0,
        G.pg and string.format(',"pg":%.3f', G.pg) or ''))
      if live and F.level then
        local body = sample_ground(px, py, pz)
        if body then conn:send_line('{"type":"fusion_ground","g":[' .. body .. ']}') end
      end
    end
  end
  if live then props_tick() end

  -- the ASI's state for the panel, and Minecraft's window size (= GTA's picture)
  if t - G.last_asi_t > 2000 then
    G.last_asi_t = t
    local st = asi_status()
    if st then
      conn:send_line(string.format(
        '{"type":"fusion_asi","loaded":1,"version":%d,"sa_ok":%d,"reshade":%d,"frame":%d,"bb_w":%d,"bb_h":%d,' ..
        '"uploads":%d,"pad_hook":%d,"hud_hook":%d,"effect":%d}',
        fb_ver or 0, st.sa_ok, st.reshade, st.frame, st.bb_w, st.bb_h, st.uploads, st.pad_hook, st.hud_hook, st.effect))
    else
      conn:send_line('{"type":"fusion_asi","loaded":0,"note":"FusionBridgeSA.asi nao carregou: sem fusao visual (rode INSTALAR.cmd)"}')
    end
    send_view(conn, false)
  end
end

-- fusion off / hub gone: give GTA back everything we took
local function fusion_release(conn)
  set_cj_hidden(false)
  set_cj_safe(false)
  if conn then release_buttons(conn) else inv_close(nil) end   -- never leave GTA's cursor up and CJ locked
  if fb then pcall(fb.FB_SetFusion, 0, 0, F.yoff) end
end

----------------------------------------------------------------- command / event handling
local function handle(conn, line)
  local t = jstr(line, 'type')
  if not t then return end

  if t == 'fusion_config' then
    local m = jstr(line, 'mode'); if m then g_mode = m end
    return
  end

  -------------------------------------------------- visual fusion (from the hub's fusion engine)
  if t == 'fusion_state' then
    local was_live = fusion_live()
    F.on = (jnum(line, 'on') or 0) ~= 0
    F.mc = (jnum(line, 'mc') or 0) ~= 0
    F.mouse = jstr(line, 'mouse') or F.mouse
    F.hide_cj = (jnum(line, 'hide_cj') or 1) ~= 0
    F.cj_safe = (jnum(line, 'cj_safe') or 1) ~= 0
    local props = (jnum(line, 'props') or 1) ~= 0
    if F.props and not props then props_clear_all(true) end
    F.props = props
    F.radius = math.max(8, math.min(64, jnum(line, 'radius') or F.radius))
    F.probes = math.max(8, math.min(256, jnum(line, 'probes') or F.probes))
    F.yoff = jnum(line, 'yoff') or F.yoff
    F.level = (jnum(line, 'level') or 0) ~= 0
    -- FSR 1.0 for Minecraft's picture (the app's Desempenho tab), passed to FusionBridgeSA.asi when it changes
    local fsr, sharp = jnum(line, 'fsr'), jnum(line, 'sharp')
    if fsr then
      local sig = string.format('%d:%.2f', fsr, sharp or 0.2)
      if sig ~= G.fsr_sig and fb then
        if pcall(fb.FB_SetFsr, fsr ~= 0 and 1 or 0, sharp or 0.2) then G.fsr_sig = sig end  -- (older ASI: no FSR)
      end
    end
    local ks = jarr(line, 'keys')
    if ks then
      local keys, names = {}, {}
      for i = 1, #ks - 1, 2 do
        local a = KEY_ACTIONS[ks[i + 1]]
        if a and ks[i] >= 1 and ks[i] <= 254 then
          keys[#keys + 1] = { math.floor(ks[i]), a }
          names[#names + 1] = a
        end
      end
      local sig = table.concat(names, ',')
      if sig ~= F.keys_sig then
        release_buttons(conn)
        F.keys, F.keys_sig = keys, sig
        if #keys > 2 then   -- the fused keys just came on: say which they are
          pcall(printStringNow, 'FusionBridge: teclas da fusao - Q/E itens, I inventario, Z soltar, X trocar de mao', 5000)
        end
      end
    end
    if was_live and not fusion_live() then fusion_release(conn); props_clear_all(true) end
    return
  end
  if t == 'fusion_ground_reset' then ground_reset(); return end
  if t == 'fusion_boom' then
    local x, y, z, k = jnum(line, 'x'), jnum(line, 'y'), jnum(line, 'z'), jnum(line, 'kind')
    if x and y and z then boom(x, y, z, k or 2) end
    return
  end
  if t == 'fusion_teleport' then
    local x, y, z = jnum(line, 'x'), jnum(line, 'y'), jnum(line, 'z')
    if x and y and z and not in_car() then setCharCoordinates(PLAYER_PED, x, y, z) end
    return
  end
  if t == 'fusion_props' then
    if jnum(line, 'clear_all') then props_clear_all() end
    local clr = jarr(line, 'clear')
    if clr then
      for i = 1, #clr - 2, 3 do
        local k = prop_key(clr[i], clr[i + 1], clr[i + 2])
        local obj = G.props[k]
        if obj then pcall(deleteObject, obj); G.props[k] = nil; G.nprops = G.nprops - 1 end
      end
    end
    local set = jarr(line, 'set')
    if set and F.props then
      for i = 1, #set - 2, 3 do G.pending[#G.pending + 1] = { set[i], set[i + 1], set[i + 2] } end
    end
    return
  end
  if t == 'fusion_notify' then
    local txt = jstr(line, 'text')
    if txt then pcall(printStringNow, txt, 2500) end
    return
  end

  if t == 'player_state' then
    local side = jstr(line, 'side')
    if side and side:find('gta') then return end      -- ignore our own echo
    local x, y, z = jnum(line, 'x'), jnum(line, 'y'), jnum(line, 'z')
    if x and y and z then g_mc.has, g_mc.x, g_mc.y, g_mc.z = true, x, y, z end
    return
  end

  if t == 'event' then
    local from = jstr(line, 'from') or ''
    if not from:find('minecraft') then return end
    -- with the visual fusion running, explosions come back at their exact spot (fusion_boom) instead
    if fusion_live() then return end
    local ev, ent = jstr(line, 'event'), jstr(line, 'entity')
    if ev == 'explosion' and g_rules.tnt then
      local x, y, z = near_cj(7, 14); boom(x, y, z, 2)
    elseif ev == 'entity_spawn' and ent == 'wither' and g_rules.wither then
      local x, y, z = near_cj(12, 18); boom(x, y, z, 7)
      x, y, z = near_cj(12, 18); boom(x, y, z, 7)
      shake(1500)
    elseif ev == 'entity_spawn' and ent == 'lightning' and g_rules.lightning then
      local x, y, z = near_cj(8, 12); boom(x, y, z, 11)
    elseif ev == 'entity_remove' and ent == 'creeper' and g_rules.creeper then
      local x, y, z = near_cj(6, 10); boom(x, y, z, 0)
    end
    return
  end

  if t == 'command' then
    local to = jstr(line, 'to') or ''
    if to ~= 'gta' and to ~= 'gta*' then return end
    local act = jstr(line, 'action')
    local id  = jnum(line, 'id') or 0
    local ok, detail = true, ''
    local x, y, z, h = cj()
    local fx, fy = forward(h)
    if act == 'block' then
      local m = jnum(line, 'model') or BLOCK_MODEL
      place_block(m, x + fx * 3, y + fy * 3, z - 0.3); detail = 'bloco na frente do CJ'
    elseif act == 'boom' then
      boom(x + fx * 9, y + fy * 9, z, 2); detail = 'explosao 9 m a frente'
    elseif act == 'boom_rain' then
      for i = 0, 7 do boom(x + math.cos(i) * 11, y + math.sin(i) * 11, z, 2) end
      detail = 'chuva de explosoes'
    elseif act == 'heal' then
      heal(); detail = 'CJ curado'
    elseif act == 'shake' then
      shake(1200); detail = 'camera tremeu'
    elseif act == 'hud' then
      local on = jnum(line, 'on'); g_hud_on = (on == nil) or (on ~= 0)
      detail = 'HUD ' .. (g_hud_on and 'ligado' or 'desligado')
    elseif act == 'rules' then
      for _, k in ipairs({ 'tnt', 'wither', 'lightning', 'creeper' }) do
        local v = jnum(line, k); if v ~= nil then g_rules[k] = (v ~= 0) end
      end
      detail = 'regras atualizadas'
    elseif act == 'diag' then
      detail = fb and ('ok, ASI v' .. tostring(fb_ver)) or 'ok, sem ASI (sem fusao visual)'
    else
      ok = false; detail = 'acao desconhecida'
    end
    conn:send_line(string.format(
      '{"type":"command_result","to":"panel","action":"%s","id":%d,"ok":%s,"detail":"%s"}',
      jsafe(act or '?'), id, tostring(ok), jsafe(detail)))
    conn:send_line(string.format('{"type":"event","event":"gta_action","detail":"%s"}', jsafe(detail)))
  end
end

----------------------------------------------------------------- main loop
local function send_hello(conn)
  conn:send_line(string.format(
    '{"type":"hello","client":"gta","side":"game","role":"host","version":"%s","protocol":2,' ..
    '"platform":"pc","capabilities":["diag","player_state","explosion","block","heal","shake","hud","fusion"]}',
    VERSION))
  conn:send_line(string.format(
    '{"type":"diag","side":"gta","platform":"pc","mod":"%s","asi":%d,"note":"%s"}',
    VERSION, fb_ver or 0,
    fb and 'MoonLoader + FusionBridgeSA.asi (fusao visual pronta)'
       or 'MoonLoader sem FusionBridgeSA.asi: so a ponte de eventos (rode INSTALAR.cmd para a fusao visual)'))
  conn:send_line('{"type":"fusion_hello"}')
  G.view_sent = nil
  send_view(conn, true)
end

-- one frame of the main loop (in a pcall: an error is logged and the next frame runs as usual)
local function main_step(conn, L)

  -- keep a connection (the connect runs in the background: the game never waits for it)
  if not conn.sock then
    if L.was_up then
      L.was_up = false
      say('a ponte com o app caiu; tentando de novo a cada 3 s')
    end
    if F.on or G.hidden or G.safe then F.on, F.mc = false, false; fusion_release(nil); props_clear_all(true) end
    local st
    if conn.pending then
      st = conn:check_pending(now())
    elseif now() >= L.next_retry then
      st = conn:connect(now()) and (conn.sock and 'up' or 'wait') or 'fail'
    end
    if st == 'up' then
      L.was_up, L.refused = true, 0
      say('conectado ao app FusionBridge')
      send_hello(conn)
    elseif st == 'fail' then
      L.next_retry = now() + 3000
      L.refused = L.refused + 1
      if L.refused == 1 then say('o app FusionBridge nao respondeu (aberto? ponte ligada?); tentando a cada 3 s') end
    end
  else
    conn:flush()                          -- what didn't fit in the socket last frame
    local lines = conn:poll_lines()
    if lines == nil then
      L.next_retry = now() + 2000          -- dropped; retry soon
    else
      for _, ln in ipairs(lines) do
        local ok, err = pcall(handle, conn, ln)
        if not ok then
          -- never let a bad line crash the game; report it
          say('mensagem do app nao tratada: ' .. tostring(err), 'handle')
          conn:send_line('{"type":"event","event":"gta_error","detail":"handle falhou"}')
        end
      end
    end
  end

  if fusion_live() ~= L.was_live then
    L.was_live = fusion_live()
    say(L.was_live and 'fusao ligada (Minecraft dentro do GTA)' or 'fusao desligada')
  end

  if conn.sock and game_ready() then
    local ok, err = pcall(fusion_tick, conn)
    if not ok then
      say('erro na fusao: ' .. tostring(err), 'tick')
      if G.frame % 300 == 0 then
        conn:send_line('{"type":"event","event":"gta_error","detail":"fusion_tick falhou"}')
      end
    end
    -- send CJ state at the mode's rate
    local hz = STATE_HZ[g_mode] or 5
    if now() - g_last_state >= 1000 / hz then
      g_last_state = now()
      local x, y, z, h, hp = cj()
      conn:send_line(string.format(
        '{"type":"player_state","side":"gta","x":%.2f,"y":%.2f,"z":%.2f,"heading":%.1f,"health":%d,"hud":%d}',
        x, y, z, h, hp, g_hud_on and 1 or 0))
    end
  elseif fb then
    pcall(fb.FB_SetFusion, 0, 0, F.yoff)
  end
  -- keep-alive whenever connected, also in cutscenes, menus and while CJ is wasted/busted (the hub drops a
  -- client that stays quiet for a minute)
  if conn.sock and now() - g_last_ping > 5000 then
    g_last_ping = now()
    conn:send_line('{"type":"ping","client":"gta"}')
  end

  -- draw the hearts (every frame, in the render context after wait(0)); with the visual fusion running
  -- Minecraft draws its own hearts in its HUD, so ours step aside
  if g_hud_on and game_ready() and not fusion_live() then
    local ok, _, _, _, _, health = pcall(cj)
    local half = math.max(0, math.min(20, math.floor(((ok and health or 100)) / 5 + 0.5)))
    pcall(draw_hearts, half, conn.sock ~= nil)
  end
end

function main()
  wsa_init()                       -- start Winsock; harmless if already started
  while not game_ready() do wait(500) end
  fb, fb_ver = load_asi()

  local conn = Conn.new()
  local L = { next_retry = 0, was_up = false, was_live = false, refused = 0 }
  say(string.format('script %s pronto; ASI %s; procurando o app em %s:%d', VERSION,
    fb and tostring(fb_ver) or 'nao carregado', HOST, PORT))

  while true do
    wait(0)
    local ok, err = pcall(main_step, conn, L)
    if not ok then say('erro no laco principal (o script continua): ' .. tostring(err), 'main') end
  end
end

function onScriptTerminate(script, quit)
  if script == thisScript() then
    -- reloading or closing: never leave CJ invisible or GTA's mouse blocked
    pcall(fusion_release, nil)
    pcall(props_clear_all, true)
  end
end

----------------------------------------------------------------- test hook (ignored by MoonLoader)
-- Set _G.FB_TEST before loading to get the internals for offline logic tests (see tests/).
if _G.FB_TEST then
  return {
    jstr = jstr, jnum = jnum, jarr = jarr, jsafe = jsafe, handle = handle, Conn = Conn,
    half_from_health = function(hp) return math.max(0, math.min(20, math.floor(hp / 5 + 0.5))) end,
    state = function() return { mode = g_mode, hud = g_hud_on, rules = g_rules, blocks = g_blocks, mc = g_mc } end,
    set_mc = function(x, y, z) g_mc.has, g_mc.x, g_mc.y, g_mc.z = true, x, y, z end,
    F = F, G = G, fusion_tick = fusion_tick, fusion_release = fusion_release, sample_ground = sample_ground,
    build_spiral = build_spiral, read_camera = read_camera, props_tick = props_tick,
    set_fb = function(lib, v) fb, fb_ver = lib, v end,
    set_ws2 = function(lib, sel) ws2 = lib; if sel ~= nil then has_select = sel end end,
    FIONBIO = FIONBIO, props_clear_all = props_clear_all, G_state = function() return G end,
    main_step = main_step,
  }
end
