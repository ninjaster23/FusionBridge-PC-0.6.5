"""Tests for app/fb_skycraft.py (SkyCraft: Minecraft inside Skyrim) on fake Skyrim / SKSE / Address Library files.
usage: python3 -I tests/test_skycraft.py"""
import hashlib, io, json, os, shutil, struct, sys, tempfile, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "app"))
import fb_skycraft as SK  # noqa: E402

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(detail)[:400]), flush=True)


def fake_exe(ver=(1, 7, 104, 0), size=200000):
    """An .exe with a VS_FIXEDFILEINFO for `ver` near the end (where the resources are), like SkyrimSE.exe."""
    data = bytearray(b"MZ" + b"\0" * (size - 2))
    ms, ls = (ver[0] << 16) | ver[1], (ver[2] << 16) | ver[3]
    info = b"\xbd\x04\xef\xfe\x00\x00\x01\x00" + struct.pack("<IIII", ms, ls, ms, ls)
    data[size - 4000:size - 4000 + len(info)] = info
    return bytes(data)


def zbytes(entries):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for name, data in entries:
            z.writestr(name, data)
    return buf.getvalue()


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data if isinstance(data, bytes) else data.encode("utf-8"))
    return path


BUNDLE = zbytes([("bundle-version.txt", "SkyCraft 0.1.2, Prism Launcher 11.1.1"),
                 ("defaults/prismlauncher.cfg", "[General]\nLanguage=en_US\nLowMemWarning=false\n"),
                 ("Prism/prismlauncher.exe", b"MZ prism"), ("Prism/portable.txt", ""),
                 ("Prism/instances/SkyCraft/instance.cfg", "[General]\nname=SkyCraft\n"),
                 ("Prism/instances/SkyCraft/.minecraft/mods/skycraft-0.1.2.jar", b"jar")])
INI = ("; SkyCraft\r\n[Minecraft]\r\n; Start Minecraft when Skyrim starts.\r\nbStartWithSkyrim = 1\r\nsLauncher =\r\n"
       "sArguments = --launch SkyCraft\r\n\r\n[Debug]\r\n; logs\r\nbDiagnostics = 0\r\n")


def make_world(t, ver=(1, 7, 104, 0), store="steam"):
    game = os.path.join(t, "steamapps", "common", "Skyrim Special Edition")
    write(os.path.join(game, "SkyrimSE.exe"), fake_exe(ver))
    if store == "steam":
        write(os.path.join(game, "steam_api64.dll"), b"steam")
    os.makedirs(os.path.join(game, "Data"), exist_ok=True)
    local, docs = os.path.join(t, "local"), os.path.join(t, "docs")
    write(os.path.join(docs, "My Games", "Skyrim Special Edition", "Saves", "Save1.ess"), b"save one")
    sky = write(os.path.join(t, "dl", "SkyCraft-0.1.2.zip"), zbytes([
        ("SKSE/Plugins/SkyCraft.dll", b"MZ skycraft dll"), ("SKSE/Plugins/SkyCraft.ini", INI),
        ("SKSE/Plugins/SkyCraft/SkyCraft-Minecraft.zip", BUNDLE), ("SKSE/Plugins/SkyCraft/LICENSE.txt", "MIT")]))
    SK.ZIP_SHA256 = hashlib.sha256(open(sky, "rb").read()).hexdigest().upper()     # the test's own "official" zip
    skse = write(os.path.join(t, "dl", "skse64_2_03_01.zip"), zbytes([
        ("skse64_2_03_01/skse64_loader.exe", b"MZ loader 2.3.1"), ("skse64_2_03_01/skse64_1_7_104.dll", b"MZ skse 1.7.104"),
        ("skse64_2_03_01/Data/Scripts/Actor.pex", b"pex"), ("skse64_2_03_01/Data/Scripts/Source/Actor.psc", b"psc"),
        ("skse64_2_03_01/skse64_readme.txt", "readme")]))
    addr = write(os.path.join(t, "dl", "Address Library All in One.zip"), zbytes([
        ("SKSE/Plugins/versionlib-1-7-104-0.bin", b"bin 1.7.104"), ("SKSE/Plugins/versionlib-1-6-1170-0.bin", b"bin 1.6.1170")]))
    return game, local, docs, sky, skse, addr


def main():
    not_running = lambda n: False                                            # noqa: E731
    logs = []
    with tempfile.TemporaryDirectory() as t:
        p = write(os.path.join(t, "a.exe"), fake_exe((1, 7, 104, 0)))
        check("SkyrimSE.exe version read from its version resource", SK.exe_version(p) == "1.7.104.0", SK.exe_version(p))
        check("1.7.104 is the Anniversary Edition runtime", SK.runtime_of(SK.parse_version("1.7.104.0")) == "ae")
        check("1.6.1170 too", SK.runtime_of(SK.parse_version("1.6.1170.0")) == "ae")
        check("1.5.97 is the old SE runtime (not for SkyCraft)", SK.runtime_of(SK.parse_version("1.5.97.0")) == "se")
        check("SKSE and Address Library names for 1.7.104",
              SK.skse_dll_name((1, 7, 104, 0)) == "skse64_1_7_104.dll" and SK.addrlib_name((1, 7, 104, 0)) == "versionlib-1-7-104-0.bin")
        p2 = write(os.path.join(t, "b.exe"), b"MZ" + b"\0" * 9000)
        check("an .exe without a version resource -> None", SK.exe_version(p2) is None)
        big = write(os.path.join(t, "big.exe"), fake_exe((1, 6, 1170, 0), size=(9 << 20)))
        check("a big .exe (version in the last MBs) is read", SK.exe_version(big) == "1.6.1170.0", SK.exe_version(big))

    with tempfile.TemporaryDirectory() as t:
        game, local, docs, sky, skse, addr = make_world(t)
        c = SK.check(game, local, docs, running=not_running)
        check("check: Skyrim found, AE runtime, Steam", c["exe"] and c["runtime"] == "ae" and c["store"] == "steam", c)
        check("check: nothing of SkyCraft there yet", not c["skse"] and not c["addrlib"] and not c["skycraft"] and not c["ours"], c)
        check("summary says what's missing", SK.summary(c)[0] == "wait" and "SKSE64" in SK.summary(c)[1], SK.summary(c))
        check("find_skyrim from the game scan (Steam AppID)",
              SK.find_skyrim([{"name": "x", "path": t, "ids": {}}, {"name": "Skyrim", "path": game, "ids": {"steam": "489830"}}]) == game)

        # wrong SKSE / Address Library versions are refused with the reason
        bad_skse = write(os.path.join(t, "dl", "skse_old.zip"), zbytes([("skse64_2_02_06/skse64_loader.exe", b"MZ old"),
                                                                        ("skse64_2_02_06/skse64_1_6_1170.dll", b"MZ 1.6")]))
        try:
            SK.install(game, local, docs, skycraft_zip=sky, skse=bad_skse, addrlib=addr, log=logs.append, running=not_running)
            check("an SKSE for another Skyrim build is refused", False)
        except SK.SkyError as e:
            check("an SKSE for another Skyrim build is refused (and says which)", "1_6_1170" in str(e) and "1.7.104" in str(e), e)
        bad_addr = write(os.path.join(t, "dl", "addr_old.zip"), zbytes([("SKSE/Plugins/versionlib-1-6-1170-0.bin", b"x")]))
        try:
            SK.install(game, local, docs, skycraft_zip=sky, skse=skse, addrlib=bad_addr, log=logs.append, running=not_running)
            check("an Address Library without this build is refused", False)
        except SK.SkyError as e:
            check("an Address Library without this build is refused", "versionlib-1-7-104-0.bin" in str(e), e)
        try:
            SK.install(game, local, docs, skycraft_zip=sky, log=logs.append, running=not_running)
            check("without SKSE picked or installed: refused", False)
        except SK.SkyError as e:
            check("without SKSE picked or installed: refused", "SKSE" in str(e), e)
        check("... none of these left anything behind", not os.path.exists(os.path.join(game, "skse64_loader.exe")) and
              not os.path.exists(SK.manifest_path(local)) and not os.path.exists(os.path.join(game, "Data", "SKSE")))
        try:
            SK.install(game, local, docs, skycraft_zip=sky, skse=skse, addrlib=addr, log=logs.append, running=lambda n: n == "SkyrimSE.exe")
            check("installing with Skyrim open: refused", False)
        except SK.SkyError as e:
            check("installing with Skyrim open: refused", "Feche o Skyrim" in str(e), e)
        wrong = write(os.path.join(t, "dl", "other.zip"), zbytes([("SKSE/Plugins/SkyCraft.dll", b"other")]))
        try:
            SK.install(game, local, docs, skycraft_zip=wrong, skse=skse, addrlib=addr, log=logs.append, running=not_running)
            check("a SkyCraft zip with another SHA-256 is refused", False)
        except SK.SkyError as e:
            check("a SkyCraft zip with another SHA-256 is refused", "SHA-256" in str(e), e)

        # the real thing
        r = SK.install(game, local, docs, skycraft_zip=sky, skse=skse, addrlib=addr, log=logs.append, running=not_running)
        want = ["skse64_loader.exe", "skse64_1_7_104.dll", os.path.join("Data", "Scripts", "Actor.pex"),
                os.path.join("Data", "Scripts", "Source", "Actor.psc"), os.path.join("Data", "SKSE", "Plugins", "SkyCraft.dll"),
                os.path.join("Data", "SKSE", "Plugins", "SkyCraft.ini"),
                os.path.join("Data", "SKSE", "Plugins", "SkyCraft", "SkyCraft-Minecraft.zip"),
                os.path.join("Data", "SKSE", "Plugins", "versionlib-1-7-104-0.bin")]
        check("install puts SKSE, its scripts, the Address Library .bin and SkyCraft in place",
              all(os.path.isfile(os.path.join(game, w)) for w in want), [w for w in want if not os.path.isfile(os.path.join(game, w))])
        check("... only the .bin for this build (not the whole Address Library)",
              not os.path.exists(os.path.join(game, "Data", "SKSE", "Plugins", "versionlib-1-6-1170-0.bin")))
        check("... and not the SKSE readme", not os.path.exists(os.path.join(game, "skse64_readme.txt")))
        m = SK.load_manifest(local)
        rec = {os.path.normcase(f["Path"]) for f in (m or {}).get("Files", [])}
        check("... every file recorded with its SHA-256", m and m["Status"] == "instalado" and
              all(os.path.normcase(w) in rec for w in want) and all(len(f["SHA256"]) == 64 for f in m["Files"]), m)
        check("... the saves were backed up first", r["backup"] and
              os.path.isfile(os.path.join(r["backup"], "Skyrim Special Edition", "Save1.ess")), r)
        c = SK.check(game, local, docs, running=not_running)
        check("check after install: all there, installed by the FusionBridge", c["skse"] and c["addrlib"] and c["skycraft"] and
              c["bundle"] and c["ours"], c)
        check("summary: ready", SK.summary(c)[0] == "ok", SK.summary(c))
        try:
            SK.install(game, local, docs, skycraft_zip=sky, log=logs.append, running=not_running)
            check("installing twice is refused (use Remover)", False)
        except SK.SkyError as e:
            check("installing twice is refused (use Remover)", "Remover" in str(e), e)

        # SkyCraft.ini switches keep the comments, and the record follows the change
        SK.set_ini(game, "Debug", "bDiagnostics", "1", local)
        ini = SK.read_ini(game)
        text = open(SK.ini_path(game), encoding="utf-8").read()
        check("SkyCraft.ini: diagnostics on, Minecraft start untouched, comments kept",
              ini["diag"] and ini["start"] and "; logs" in text and "; Start Minecraft" in text, (ini, text))
        SK.set_ini(game, "Minecraft", "bStartWithSkyrim", "0", local)
        check("SkyCraft.ini: Minecraft start off", SK.read_ini(game)["start"] is False)

        # SkyCraft's Minecraft, unpacked the way SkyCraft.dll does it
        check("before preparing: no Prism, not signed in", not c["prism"] and not c["signed_in"])
        check("prepare_minecraft unpacks the bundle", SK.prepare_minecraft(game, local, logs.append) == "preparado" and
              os.path.isfile(SK.prism_exe(local)))
        stamp = open(os.path.join(SK.mc_dir(local), "bundle.stamp"), encoding="utf-8").read()
        st = os.stat(SK.bundle_path(game))
        check("... bundle.stamp = size + FILETIME (what SkyCraft.dll compares)",
              stamp == "%d %d" % (st.st_size, st.st_mtime_ns // 100 + 116444736000000000), stamp)
        check("... Prism's settings copied from the defaults", os.path.isfile(os.path.join(SK.mc_dir(local), "Prism", "prismlauncher.cfg")))
        check("... and a second time it is already done", SK.prepare_minecraft(game, local, logs.append) == "já preparado")
        cfg = os.path.join(SK.mc_dir(local), "Prism", "prismlauncher.cfg")
        write(cfg, "[General]\nLanguage=pt_BR\n")
        write(os.path.join(SK.mc_dir(local), "bundle.stamp"), "old")
        old_jar = write(os.path.join(SK.mc_dir(local), "Prism", "instances", "SkyCraft", ".minecraft", "mods", "skycraft-0.1.1.jar"), b"old")
        keep = write(os.path.join(SK.mc_dir(local), "Prism", "instances", "SkyCraft", ".minecraft", "saves", "SkyCraft", "level.dat"), b"world")
        SK.prepare_minecraft(game, local, logs.append)
        text = open(cfg, encoding="utf-8").read()
        check("a new bundle: the player's Prism settings stay, LowMemWarning added",
              "Language=pt_BR" in text and "LowMemWarning=false" in text, text)
        check("... the old SkyCraft jar replaced, the world kept", not os.path.exists(old_jar) and os.path.isfile(keep))
        write(os.path.join(SK.mc_dir(local), "Prism", "accounts.json"), json.dumps({"accounts": [], "formatVersion": 3}))
        check("accounts.json without accounts: not signed in", not SK.signed_in(local))
        write(os.path.join(SK.mc_dir(local), "Prism", "accounts.json"), json.dumps({"accounts": [{"type": "MSA"}], "formatVersion": 3}))
        check("accounts.json with an account: signed in", SK.signed_in(local))
        c = SK.check(game, local, docs, running=not_running)
        check("check: Prism there, stamp matches, signed in", c["prism"] and c["stamp_ok"] and c["signed_in"], c)

        # play: through skse64_loader.exe, Steam first when it is the Steam game
        calls = []
        popen = lambda args, **kw: calls.append((args, kw.get("cwd")))                                  # noqa: E731
        SK.launch(game, log=logs.append, popen=popen, running=lambda n: n == "steam.exe", sleep=lambda s: None)
        check("Jogar starts skse64_loader.exe in the game folder (Steam already open)",
              calls == [([os.path.join(game, "skse64_loader.exe")], game)], calls)
        real_steam = SK._steam_exe
        SK._steam_exe = lambda: None
        try:
            SK.launch(game, log=logs.append, popen=popen, running=not_running, sleep=lambda s: None)
            check("Steam game, Steam closed and not found: asks to open Steam", False)
        except SK.SkyError as e:
            check("Steam game, Steam closed and not found: asks to open Steam", "Steam" in str(e), e)
        state = {"n": 0}

        def steam_after_two(n):
            if n == "steam.exe":
                state["n"] += 1
                return state["n"] > 3
            return False
        SK._steam_exe = lambda: "C:/Steam/steam.exe"
        calls.clear()
        SK.launch(game, log=logs.append, popen=popen, running=steam_after_two, sleep=lambda s: None)
        check("Steam closed: opened (minimized) and waited for, then Skyrim", len(calls) == 2 and calls[0][0] == ["C:/Steam/steam.exe", "-silent"]
              and calls[1][0] == [os.path.join(game, "skse64_loader.exe")], calls)
        SK._steam_exe = real_steam
        try:
            SK.launch(game, log=logs.append, popen=popen, running=lambda n: n in ("SkyrimSE.exe", "steam.exe"), sleep=lambda s: None)
            check("Jogar with Skyrim already open: refused", False)
        except SK.SkyError:
            check("Jogar with Skyrim already open: refused", True)

        # remove: only unchanged files; a changed one stays; Prism's data (account, world) is not touched
        dll = os.path.join(game, "Data", "SKSE", "Plugins", "SkyCraft.dll")
        write(dll, b"changed by the player")
        r = SK.remove(local, log=logs.append, running=not_running)
        check("remove takes out what it put (SKSE, .bin, SkyCraft, the switched .ini)",
              not os.path.exists(os.path.join(game, "skse64_loader.exe")) and not os.path.exists(SK.ini_path(game)) and
              not os.path.exists(os.path.join(game, "Data", "SKSE", "Plugins", "versionlib-1-7-104-0.bin")), r)
        check("... keeps a file changed since (and says so)", os.path.isfile(dll) and len(r["kept"]) == 1 and SK.load_manifest(local), r)
        check("... and never touches SkyCraft's Minecraft (account, world)", os.path.isfile(keep) and SK.signed_in(local))
        os.remove(dll)
        r = SK.remove(local, log=logs.append, running=not_running)
        check("removing again finishes (the record goes away)", not r["kept"] and not os.path.exists(SK.manifest_path(local)))
        try:
            SK.remove(local, log=logs.append, running=not_running)
            check("removing with nothing registered: refused", False)
        except SK.SkyError:
            check("removing with nothing registered: refused", True)

    # a different file already there stops the install; an old SKSE can be swapped (backed up, given back on Remover)
    with tempfile.TemporaryDirectory() as t:
        game, local, docs, sky, skse, addr = make_world(t)
        write(os.path.join(game, "Data", "SKSE", "Plugins", "SkyCraft.ini"), "; another version\n")
        try:
            SK.install(game, local, docs, skycraft_zip=sky, skse=skse, addrlib=addr, log=logs.append, running=not_running)
            check("a different SkyCraft.ini already there stops the install", False)
        except SK.SkyError as e:
            check("a different SkyCraft.ini already there stops the install (nothing written)", "SkyCraft.ini" in str(e) and
                  not os.path.exists(os.path.join(game, "skse64_loader.exe")) and not os.path.exists(SK.manifest_path(local)), e)
        os.remove(os.path.join(game, "Data", "SKSE", "Plugins", "SkyCraft.ini"))
        write(os.path.join(game, "skse64_loader.exe"), b"MZ loader 2.2.6 (old)")
        write(os.path.join(game, "skse64_1_6_1170.dll"), b"MZ old dll")
        c = SK.check(game, local, docs, running=not_running)
        check("check sees the SKSE of another build", not c["skse"] and c["skse_other"] == ["skse64_1_6_1170.dll"], c)
        try:
            SK.install(game, local, docs, skycraft_zip=sky, skse=skse, addrlib=addr, log=logs.append, running=not_running)
            check("an old SKSE loader stops the install unless swapping is allowed", False)
        except SK.SkyError as e:
            check("an old SKSE loader stops the install unless swapping is allowed", "Trocar o SKSE antigo" in str(e), e)
        SK.install(game, local, docs, skycraft_zip=sky, skse=skse, addrlib=addr, log=logs.append, running=not_running,
                   replace_skse=True)
        baks = [n for n in os.listdir(game) if n.startswith("skse64_loader.exe.antes-fusionbridge-")]
        check("swapping: the new loader in place, the old one kept as a backup",
              open(os.path.join(game, "skse64_loader.exe"), "rb").read() == b"MZ loader 2.3.1" and len(baks) == 1, os.listdir(game))
        SK.remove(local, log=logs.append, running=not_running)
        check("... and Remover gives the old loader back",
              open(os.path.join(game, "skse64_loader.exe"), "rb").read() == b"MZ loader 2.2.6 (old)" and
              not any(n.startswith("skse64_loader.exe.antes") for n in os.listdir(game)), os.listdir(game))

    # picking the extracted files instead of the archives
    with tempfile.TemporaryDirectory() as t:
        game, local, docs, sky, skse, addr = make_world(t)
        ex = os.path.join(t, "extracted")
        with zipfile.ZipFile(skse) as z:
            z.extractall(ex)
        loader = os.path.join(ex, "skse64_2_03_01", "skse64_loader.exe")
        binf = write(os.path.join(t, "dl", "versionlib-1-7-104-0.bin"), b"bin 1.7.104")
        SK.install(game, local, docs, skycraft_zip=sky, skse=loader, addrlib=binf, log=logs.append, running=not_running)
        c = SK.check(game, local, docs, running=not_running)
        check("the extracted skse64_loader.exe and the .bin itself work too", c["skse"] and c["addrlib"] and c["skycraft"] and
              os.path.isfile(os.path.join(game, "Data", "Scripts", "Actor.pex")), c)
        wrongbin = write(os.path.join(t, "dl", "versionlib-1-6-1170-0.bin"), b"x")
        try:
            SK.addrlib_entries(wrongbin, (1, 7, 104, 0), t)
            check("a .bin of another build is refused", False)
        except SK.SkyError:
            check("a .bin of another build is refused", True)
        try:
            SK.skse_entries(os.path.join(game, "skse64_loader.exe"), (1, 7, 104, 0), t, game)
            check("picking the loader already in the game folder is refused", False)
        except SK.SkyError:
            check("picking the loader already in the game folder is refused", True)

    # versions and stores SkyCraft can't use
    with tempfile.TemporaryDirectory() as t:
        game, local, docs, sky, skse, addr = make_world(t, ver=(1, 5, 97, 0))
        try:
            SK.install(game, local, docs, skycraft_zip=sky, skse=skse, addrlib=addr, log=logs.append, running=not_running)
            check("Skyrim 1.5.97: refused", False)
        except SK.SkyError as e:
            check("Skyrim 1.5.97: refused, saying it needs 1.6/1.7", "1.5.97" in str(e) and "1.6 ou 1.7" in str(e), e)
        check("summary for 1.5.97 is bad", SK.summary(SK.check(game, local, docs, running=not_running))[0] == "bad")
    with tempfile.TemporaryDirectory() as t:
        gp = os.path.join(t, "XboxGames", "Skyrim", "Content")
        write(os.path.join(gp, "SkyrimSE.exe"), fake_exe())
        check("the Xbox / Game Pass Skyrim is recognized as such", SK.store_of(gp) == "gamepass")
        check("... and the summary says SKSE doesn't work there", SK.summary(SK.check(gp, os.path.join(t, "l"), t, running=not_running))[0] == "bad")
    with tempfile.TemporaryDirectory() as t:
        evil = write(os.path.join(t, "evil.zip"), zbytes([("../../outside.dll", b"x"), ("SKSE/Plugins/SkyCraft.dll", b"x")]))
        SK.ZIP_SHA256 = hashlib.sha256(open(evil, "rb").read()).hexdigest().upper()
        try:
            SK.skycraft_entries(evil)
            check("a zip with ../ paths is refused", False)
        except SK.SkyError:
            check("a zip with ../ paths is refused", True)

    lines = ["[info] Minecraft: unpacking SkyCraft's Minecraft to C:\\x", "[warn] Minecraft: unpacking failed (tar exit code 1)"]
    h = SK.log_hints(lines)
    check("SkyCraft.log in plain words: the last problem first", h and h[0][0] == "bad" and "desempacotar" in h[0][1], h)
    check("... a good start is recognized", SK.log_hints(["Minecraft: started C:\\x --launch SkyCraft"])[0][0] == "ok")
    with tempfile.TemporaryDirectory() as t:
        lp = write(os.path.join(t, "x.log"), "\n".join("linha %d" % i for i in range(500)))
        check("tail gives the last lines", SK.tail(lp, 3) == ["linha 497", "linha 498", "linha 499"], SK.tail(lp, 3))
        check("tail of a missing file is empty", SK.tail(os.path.join(t, "none.log")) == [])
    check("SkyCraft's Minecraft is never seen running off Windows", SK.mc_running() is False)

    bad = [n for n, ok in results if not ok]
    print("\n%d/%d passaram" % (len(results) - len(bad), len(results)))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
