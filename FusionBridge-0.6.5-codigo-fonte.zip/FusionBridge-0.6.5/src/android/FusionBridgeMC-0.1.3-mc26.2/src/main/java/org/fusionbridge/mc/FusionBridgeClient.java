package org.fusionbridge.mc;

import net.fabricmc.api.ClientModInitializer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lightweight FusionBridge client for Minecraft Java 26.2 running inside Amethyst. */
public final class FusionBridgeClient implements ClientModInitializer {
    private static final String HOST = "127.0.0.1";
    private static final int PORT = 28765;
    private static final AtomicBoolean STARTED = new AtomicBoolean(false);
    private static volatile boolean running = true;
    private static final Pattern SCALE_PATTERN = Pattern.compile("\\\"render_scale\\\"\\s*:\\s*([0-9.]+)");
    private static final Pattern FSR_PATTERN = Pattern.compile("\\\"fsr\\\"\\s*:\\s*(true|false)", Pattern.CASE_INSENSITIVE);

    @Override
    public void onInitializeClient() {
        if (!STARTED.compareAndSet(false, true)) {
            return;
        }
        System.out.println("[FusionBridgeMC] v0.1.3 loading for Minecraft 26.2");
        Thread worker = new Thread(FusionBridgeClient::runLoop, "FusionBridgeMC-Network");
        worker.setDaemon(true);
        worker.setUncaughtExceptionHandler((t, e) ->
                System.err.println("[FusionBridgeMC] worker error: " + e));
        worker.start();
    }

    private static void runLoop() {
        while (running && !Thread.currentThread().isInterrupted()) {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(HOST, PORT), 1800);
                socket.setTcpNoDelay(false);
                socket.setKeepAlive(true);
                socket.setSoTimeout(1000);

                try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
                     BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8))) {

                    send(out, "{\"type\":\"hello\",\"client\":\"minecraft\",\"version\":\"0.1.3\",\"minecraft\":\"26.2\",\"protocol\":1,\"capabilities\":[\"mobileglues_fsr1_config\"]}");
                    System.out.println("[FusionBridgeMC] connected to " + HOST + ":" + PORT);

                    long nextPing = 0L;
                    while (running && !socket.isClosed() && !Thread.currentThread().isInterrupted()) {
                        long now = System.currentTimeMillis();
                        if (now >= nextPing) {
                            send(out, "{\"type\":\"ping\",\"client\":\"minecraft\",\"protocol\":1}");
                            nextPing = now + 4000L;
                        }
                        try {
                            String line = in.readLine();
                            if (line == null) break;
                            if (line.isBlank() || line.contains("\"type\":\"pong\"")) continue;
                            if (line.contains("\"type\":\"boost_profile\"")) {
                                handleBoostProfile(line, out);
                            }
                        } catch (SocketTimeoutException ignored) {
                            // Expected. Keeps this worker independent of the render thread.
                        }
                    }
                }
            } catch (Throwable error) {
                System.out.println("[FusionBridgeMC] bridge unavailable: " + error.getClass().getSimpleName());
            }

            try {
                Thread.sleep(2500L);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private static void handleBoostProfile(String json, BufferedWriter out) throws IOException {
        boolean fsrEnabled = extractBoolean(json, FSR_PATTERN, false);
        double scale = extractDouble(json, SCALE_PATTERN, 0.77);
        int preset = fsrEnabled ? presetForScale(scale) : 0;

        String mgDir = System.getenv("MG_DIR_PATH");
        if (mgDir == null || mgDir.isBlank()) {
            send(out, boostResult(false, "mobileglues_fsr1_config", preset, true, "MG_DIR_PATH ausente"));
            return;
        }

        try {
            Path config = Path.of(mgDir, "config.json");
            if (!Files.exists(config)) {
                send(out, boostResult(false, "mobileglues_fsr1_config", preset, true, "config.json nao encontrado"));
                return;
            }
            String before = Files.readString(config, StandardCharsets.UTF_8);
            String after;
            Pattern p = Pattern.compile("(\\\"fsr1Setting\\\"\\s*:\\s*)-?\\d+");
            Matcher m = p.matcher(before);
            if (m.find()) {
                after = m.replaceFirst("$1" + preset);
            } else {
                int brace = before.lastIndexOf('}');
                if (brace < 0) throw new IOException("JSON invalido");
                String prefix = before.substring(0, brace).trim();
                boolean needsComma = prefix.length() > 1 && !prefix.endsWith("{") && !prefix.endsWith(",");
                after = prefix + (needsComma ? ",\n" : "\n") + "  \"fsr1Setting\": " + preset + "\n}";
            }
            if (!after.equals(before)) {
                Path backup = Path.of(mgDir, "config.fusionbridge.bak.json");
                if (!Files.exists(backup)) {
                    Files.copy(config, backup, StandardCopyOption.REPLACE_EXISTING);
                }
                Files.writeString(config, after, StandardCharsets.UTF_8);
            }
            send(out, boostResult(true, "mobileglues_fsr1_config", preset, true,
                    "FSR salvo; reinicie o Minecraft para aplicar"));
        } catch (Throwable error) {
            send(out, boostResult(false, "mobileglues_fsr1_config", preset, true,
                    error.getClass().getSimpleName()));
        }
    }

    private static String boostResult(boolean ok, String backend, int preset, boolean restart, String note) {
        return "{\"type\":\"boost_result\",\"client\":\"minecraft\",\"ok\":" + ok +
                ",\"backend\":\"" + escape(backend) + "\",\"fsr1_preset\":" + preset +
                ",\"frame_gen\":false,\"requires_restart\":" + restart +
                ",\"note\":\"" + escape(note) + "\"}";
    }

    private static int presetForScale(double scale) {
        // MobileGlues: 0 Disabled, 1 UltraQuality, 2 Quality, 3 Balanced, 4 Performance.
        if (scale >= 0.74) return 1; // ~77% / Ultra Quality
        if (scale >= 0.63) return 2; // ~67% / Quality
        if (scale >= 0.55) return 3; // Balanced
        return 4;                    // 50% / Performance
    }

    private static boolean extractBoolean(String text, Pattern pattern, boolean fallback) {
        Matcher m = pattern.matcher(text);
        return m.find() ? Boolean.parseBoolean(m.group(1)) : fallback;
    }

    private static double extractDouble(String text, Pattern pattern, double fallback) {
        Matcher m = pattern.matcher(text);
        if (!m.find()) return fallback;
        try { return Double.parseDouble(m.group(1)); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    private static String escape(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
    }

    private static void send(BufferedWriter out, String line) throws IOException {
        out.write(line);
        out.newLine();
        out.flush();
    }
}
