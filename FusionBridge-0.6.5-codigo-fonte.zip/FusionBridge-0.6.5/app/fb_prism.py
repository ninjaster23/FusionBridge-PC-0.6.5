"""FusionBridge PC 0.6.5 - "Minecraft automático" for the GTA SA fusion.

A portable Prism Launcher (GPL-3.0; the official release from GitHub, checked by a fixed SHA-256) with a ready
"FusionBridge" instance: Minecraft 26.3, Fabric Loader 0.19.5 and the fusion mods (passthrough, FusionBridgeMC and Fabric
API, put in by the installer). It is what SkyCraft (chasmlol, MIT) does for Skyrim: Prism signs in to the player's
Microsoft account and downloads Minecraft, Fabric and Java by itself, so the official Minecraft Launcher, the Fabric
installer and a launcher profile are not needed, and the versions always match. Everything lives in
%LOCALAPPDATA%\\FusionBridge\\Prism.

AutoMC (driven by the app every couple of seconds, off the window's thread) can then:
  - open Minecraft when GTA SA opens, never a second one (a Minecraft already linked, or Prism still starting one);
  - close it when GTA closes, but only a Minecraft the app opened itself (WM_CLOSE: Minecraft saves and quits, and
    Prism quits after it);
  - keep Minecraft's window off the screen instead of minimized: minimized, Minecraft drops to a few frames per second
    (and the passthrough mod sends nothing new); off-screen it keeps drawing for the fusion.
"""
import datetime
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile

import fb_installer as FI

IS_WINDOWS = sys.platform == "win32"
PRISM_VERSION = "11.1.1"
INSTANCE = "FusionBridge"
MC_VERSION, LOADER_VERSION, LWJGL_VERSION = "26.3", "0.19.5", "3.4.3"
MODS = ("passthrough-0.1.0.jar", "FusionBridgeMC-0.2.0.jar", "fabric-api-0.161.0+26.3.jar")
# Prism's settings the first time (the player's afterwards): the same as SkyCraft's
PRISM_CFG = ("[General]\nLanguage=pt_BR\nApplicationTheme=dark\nIconTheme=pe_colored\nAutomaticJavaDownload=true\n"
             "AutomaticJavaSwitch=true\nUserAskedAboutAutomaticJavaDownload=true\nCloseAfterLaunch=true\n"
             "QuitAfterGameStop=true\nShowConsole=false\nAutoCloseConsole=false\nShowConsoleOnError=true\n"
             "LowMemWarning=false\n")
INSTANCE_CFG = ("[General]\nInstanceType=OneSix\nname=FusionBridge\niconKey=default\n"
                "notes=Criada pelo FusionBridge: Minecraft 26.3 + Fabric 0.19.5 com os mods da fusao (passthrough, "
                "FusionBridgeMC, Fabric API). O FusionBridge abre esta instancia sozinho quando o GTA SA abre.\n"
                "OverrideJavaArgs=true\nJvmArgs=--enable-native-access=ALL-UNNAMED\nOverrideMemory=true\n"
                "MinMemAlloc=512\nMaxMemAlloc=4096\nOverrideConsole=true\nShowConsole=false\nAutoCloseConsole=false\n"
                "ShowConsoleOnError=true\n")
MMC_PACK = {"components": [
    {"cachedName": "LWJGL 3", "cachedVersion": LWJGL_VERSION, "cachedVolatile": True, "dependencyOnly": True,
     "uid": "org.lwjgl3", "version": LWJGL_VERSION},
    {"cachedName": "Minecraft", "cachedRequires": [{"suggests": LWJGL_VERSION, "uid": "org.lwjgl3"}],
     "cachedVersion": MC_VERSION, "important": True, "uid": "net.minecraft", "version": MC_VERSION},
    {"cachedName": "Intermediary Mappings", "cachedRequires": [{"equals": MC_VERSION, "uid": "net.minecraft"}],
     "cachedVersion": MC_VERSION, "cachedVolatile": True, "dependencyOnly": True, "uid": "net.fabricmc.intermediary",
     "version": MC_VERSION},
    {"cachedName": "Fabric Loader", "cachedRequires": [{"uid": "net.fabricmc.intermediary"}],
     "cachedVersion": LOADER_VERSION, "uid": "net.fabricmc.fabric-loader", "version": LOADER_VERSION}],
    "formatVersion": 1}


class PrismError(Exception):
    """A reason the automatic Minecraft can't be set up/opened, in words for the player (pt-BR)."""


# ====================================================================== where things are
def root(local):
    return os.path.join(local, "FusionBridge", "Prism")


def exe(local):
    return os.path.join(root(local), "prismlauncher.exe")


def instance_dir(local):
    return os.path.join(root(local), "instances", INSTANCE)


def game_dir(local):
    """The instance's Minecraft folder: the fusion world, options and mods (the installer puts the jars here)."""
    return os.path.join(instance_dir(local), ".minecraft")


def mods_dir(local):
    return os.path.join(game_dir(local), "mods")


def record_path(local):
    return os.path.join(root(local), "fusionbridge-prism.json")


def signed_in(local):
    try:
        with open(os.path.join(root(local), "accounts.json"), "r", encoding="utf-8-sig") as f:
            d = json.load(f)
        return bool(isinstance(d, dict) and d.get("accounts"))
    except (OSError, ValueError):
        return False


def state(local, running=None):
    """What the Minecraft card shows: is Prism here, the instance written, signed in, the mods in."""
    running = running or FI.is_running
    try:
        with open(record_path(local), "r", encoding="utf-8") as f:
            rec = json.load(f)
    except (OSError, ValueError):
        rec = None
    saves = os.path.join(game_dir(local), "saves")
    try:
        world = any(os.path.isdir(os.path.join(saves, n)) for n in os.listdir(saves))
    except OSError:
        world = False
    return {"installed": os.path.isfile(exe(local)) and os.path.isfile(os.path.join(instance_dir(local), "mmc-pack.json")),
            "version": (rec or {}).get("Prism") if isinstance(rec, dict) else None,
            "signed_in": signed_in(local),
            "mods": {n: os.path.isfile(os.path.join(mods_dir(local), n)) for n in MODS},
            "world": world, "prism_running": running("prismlauncher.exe")}


# ====================================================================== install / remove
def _safe_parts(name):
    n = name.replace("\\", "/")
    if n.startswith("/") or ":" in n:
        return None
    parts = [p for p in n.split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts):
        return None
    return parts


def write_instance(local):
    """The FusionBridge instance (Minecraft 26.3 + Fabric 0.19.5). Rewritten each time: it is the app's."""
    d = instance_dir(local)
    os.makedirs(os.path.join(d, ".minecraft", "mods"), exist_ok=True)
    with open(os.path.join(d, "instance.cfg"), "w", encoding="utf-8", newline="\n") as f:
        f.write(INSTANCE_CFG)
    with open(os.path.join(d, "mmc-pack.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(MMC_PACK, f, indent=4)
        f.write("\n")


def install(paths, log=print, get_dependency=None, running=None):
    """Downloads Prism (official GitHub release, fixed SHA-256), unpacks it to %LOCALAPPDATA%\\FusionBridge\\Prism and
    writes the FusionBridge instance. Safe to run again (an update keeps the sign-in and the world)."""
    running = running or FI.is_running
    get_dependency = get_dependency or FI.get_dependency
    if running("prismlauncher.exe"):
        raise PrismError("Feche o Prism Launcher (e o Minecraft aberto por ele) antes.")
    local = paths.local
    try:
        zpath = get_dependency("prism", paths, log)
    except FI.InstallError as e:
        raise PrismError(str(e))
    r = root(local)
    os.makedirs(r, exist_ok=True)
    files = []
    try:
        with zipfile.ZipFile(zpath) as z:
            for info in z.infolist():
                parts = _safe_parts(info.filename)
                if parts is None:
                    raise PrismError("O zip do Prism tem um caminho estranho (%s); nada foi instalado." % info.filename)
                target = os.path.join(r, *parts)
                if info.is_dir():
                    os.makedirs(target, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with z.open(info) as fi, open(target + ".tmp", "wb") as fo:
                    shutil.copyfileobj(fi, fo)
                os.replace(target + ".tmp", target)
                files.append("/".join(parts))
    except zipfile.BadZipFile:
        raise PrismError("O zip do Prism está danificado; apague-o da pasta de downloads e tente de novo.")
    except PermissionError as e:
        raise PrismError("O Windows não deixou gravar %s (arquivo em uso?). Feche o Prism e tente de novo." %
                         (getattr(e, "filename", None) or r))
    if not os.path.isfile(os.path.join(r, "portable.txt")):          # portable mode: everything stays in this folder
        open(os.path.join(r, "portable.txt"), "w").close()
    cfg = os.path.join(r, "prismlauncher.cfg")
    if not os.path.isfile(cfg):
        with open(cfg, "w", encoding="utf-8", newline="\n") as f:
            f.write(PRISM_CFG)
    write_instance(local)
    with open(record_path(local) + ".tmp", "w", encoding="utf-8") as f:
        json.dump({"Prism": PRISM_VERSION, "Instance": INSTANCE, "Minecraft": MC_VERSION, "Loader": LOADER_VERSION,
                   "Files": files, "When": datetime.datetime.now().isoformat(timespec="seconds")}, f, indent=1)
    os.replace(record_path(local) + ".tmp", record_path(local))
    log("Prism Launcher %s pronto em %s (instância %s: Minecraft %s + Fabric %s)." % (PRISM_VERSION, r, INSTANCE,
                                                                                    MC_VERSION, LOADER_VERSION))
    return r


def remove(local, log=print, running=None):
    """Deletes %LOCALAPPDATA%\\FusionBridge\\Prism (Prism, the sign-in, Minecraft's files). The fusion world is copied
    to %LOCALAPPDATA%\\FusionBridge\\backups first."""
    running = running or FI.is_running
    if running("prismlauncher.exe"):
        raise PrismError("Feche o Prism Launcher (e o Minecraft aberto por ele) antes de remover.")
    r = root(local)
    if not os.path.isdir(r):
        raise PrismError("O Minecraft automático não está instalado.")
    saves = os.path.join(game_dir(local), "saves")
    if os.path.isdir(saves) and os.listdir(saves):
        dest = os.path.join(local, "FusionBridge", "backups", "mundo-prism-%s" % datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
        shutil.copytree(saves, dest)
        log("Mundo da fusão guardado em %s" % dest)
    errors = []
    shutil.rmtree(r, onerror=lambda fn, p, exc: errors.append(p))
    if errors:
        raise PrismError("Não consegui apagar tudo (arquivo em uso?): %s" % errors[0])
    log("Minecraft automático removido (%s)." % r)


# ====================================================================== start it
def _detached():
    return (0x00000008 | 0x00000200) if IS_WINDOWS else 0     # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP


def sign_in(local, popen=subprocess.Popen):
    """Prism's own window, to add the Microsoft account (once)."""
    if not os.path.isfile(exe(local)):
        raise PrismError("O Minecraft automático ainda não foi instalado.")
    return popen([exe(local)], cwd=root(local), creationflags=_detached(), close_fds=True)


def launch(local, popen=subprocess.Popen):
    """Starts the FusionBridge instance (Prism downloads what's missing the first time, then opens Minecraft)."""
    if not os.path.isfile(exe(local)):
        raise PrismError("O Minecraft automático ainda não foi instalado (aba Instalar).")
    if not signed_in(local):
        raise PrismError("Entre na sua conta Microsoft no Prism primeiro (botão Entrar na conta).")
    return popen([exe(local), "--launch", INSTANCE], cwd=root(local), creationflags=_detached(), close_fds=True)


# ====================================================================== Minecraft's window
class Placer:
    """Finds Minecraft's game window (the visible GLFW window of its process) and moves it off the screen and back,
    or asks it to close. Elsewhere than Windows every call does nothing."""
    WM_CLOSE = 0x0010

    def __init__(self):
        self.u = None
        self.saved = {}            # hwnd -> (x, y) before it was moved away
        if not IS_WINDOWS:
            return
        import ctypes
        from ctypes import wintypes
        u = ctypes.WinDLL("user32", use_last_error=True)
        self.ct, self.wt, self.u = ctypes, wintypes, u
        self.ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        u.EnumWindows.argtypes = (self.ENUMPROC, wintypes.LPARAM)
        u.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
        u.GetWindowThreadProcessId.restype = wintypes.DWORD
        u.IsWindowVisible.argtypes = u.IsWindow.argtypes = u.IsIconic.argtypes = (wintypes.HWND,)
        u.GetClassNameW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
        u.GetWindowRect.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.RECT))
        u.SetWindowPos.argtypes = (wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                   wintypes.UINT)
        u.PostMessageW.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
        u.ShowWindow.argtypes = (wintypes.HWND, ctypes.c_int)
        u.GetSystemMetrics.argtypes = (ctypes.c_int,)

    def window(self, pid):
        if self.u is None or not pid:
            return None
        found = []

        def cb(hwnd, _):
            owner = self.wt.DWORD(0)
            self.u.GetWindowThreadProcessId(hwnd, self.ct.byref(owner))
            if owner.value == pid and self.u.IsWindowVisible(hwnd):
                name = self.ct.create_unicode_buffer(64)
                self.u.GetClassNameW(hwnd, name, 64)
                if name.value.startswith("GLFW"):
                    found.append(hwnd)
                    return False
            return True
        self.u.EnumWindows(self.ENUMPROC(cb), 0)
        return found[0] if found else None

    def _rect(self, hwnd):
        r = self.wt.RECT()
        if not self.u.GetWindowRect(hwnd, self.ct.byref(r)):
            return None
        return r.left, r.top, r.right - r.left, r.bottom - r.top

    def off_screen(self, hwnd):
        r = self._rect(hwnd)
        if r is None:
            return False
        vx, vy = self.u.GetSystemMetrics(76), self.u.GetSystemMetrics(77)          # SM_X/YVIRTUALSCREEN
        vw, vh = self.u.GetSystemMetrics(78), self.u.GetSystemMetrics(79)
        x, y, w, h = r
        return x + w <= vx or x >= vx + vw or y + h <= vy or y >= vy + vh

    def hide(self, pid):
        """Moves the window just left of all the screens (not minimized: Minecraft keeps drawing). True if moved."""
        hwnd = self.window(pid)
        if hwnd is None or self.off_screen(hwnd):
            return False
        if self.u.IsIconic(hwnd):
            self.u.ShowWindow(hwnd, 4)                      # SW_SHOWNOACTIVATE: un-minimize first
        r = self._rect(hwnd)
        if r is None:
            return False
        self.saved[hwnd] = (r[0], r[1])
        vx = self.u.GetSystemMetrics(76)
        return bool(self.u.SetWindowPos(hwnd, None, vx - r[2] - 200, r[1], 0, 0, 0x0001 | 0x0004 | 0x0010))

    def show(self, pid):
        """Brings the window back where it was (or to the main screen)."""
        hwnd = self.window(pid)
        if hwnd is None or not self.off_screen(hwnd):
            return False
        x, y = self.saved.pop(hwnd, (80, 80))
        return bool(self.u.SetWindowPos(hwnd, None, x, y, 0, 0, 0x0001 | 0x0004 | 0x0010))   # NOSIZE|NOZORDER|NOACTIVATE

    def close(self, pid):
        hwnd = self.window(pid)
        return bool(hwnd) and bool(self.u.PostMessageW(hwnd, self.WM_CLOSE, 0, 0))


# ====================================================================== the automatic part
class AutoMC:
    """Called every ~2 s with what GTA and the Minecraft link are doing; does at most one thing per call and says
    what in .note. prefs: {'auto_start', 'auto_close', 'hide_mc'} (bools)."""
    START_COOLDOWN = 150.0       # after asking Prism to start Minecraft, wait this long before trying again
    CLOSE_AFTER = 10.0           # GTA closed this long -> close the Minecraft the app opened

    def __init__(self, local, launcher=None, placer=None, running=None, clock=time.time, log=print):
        self.local = local
        self.launcher = launcher or (lambda: launch(local))
        self.placer = placer or Placer()
        self.running = running or FI.is_running
        self.clock = clock
        self.log = log
        self.launched_at = -1e9
        self.ours_pid = None         # the Minecraft this app opened (its pid once it links)
        self.waiting_ours = False    # asked Prism to start one, not linked yet
        self.gta_seen = -1e9
        self.gta_was = False
        self.hidden = set()          # pids whose window was moved away
        self.note = ""

    def launched_by_hand(self):
        """The player clicked Abrir o Minecraft: that one counts as opened by the app (closed with GTA)."""
        self.launched_at, self.waiting_ours = self.clock(), True

    def tick(self, prefs, gta_running, mc):
        now = self.clock()
        mc = mc or {}
        linked = mc.get("state") == "open"
        pid = (mc.get("hello") or {}).get("pid") if linked else None
        if gta_running:
            self.gta_seen = now
        if linked and self.waiting_ours and pid:
            self.ours_pid, self.waiting_ours = pid, False
        if self.waiting_ours and now - self.launched_at > self.START_COOLDOWN:
            self.waiting_ours = False
        did = None
        if prefs.get("auto_start") and gta_running and not linked and not self.waiting_ours:
            st = state(self.local, self.running)
            if not st["installed"]:
                did = "auto_start_off"
                self.note = "Minecraft automático não instalado (aba Instalar)."
            elif not st["signed_in"]:
                did = "auto_start_off"
                self.note = "Entre na conta Microsoft no Prism para o Minecraft abrir sozinho."
            elif st["prism_running"]:
                self.note = "O Prism já está abrindo o Minecraft."
            elif now - self.launched_at >= self.START_COOLDOWN:
                try:
                    self.launcher()
                    self.launched_at, self.waiting_ours = now, True
                    self.note = "GTA aberto: abrindo o Minecraft da fusão (na primeira vez o Prism baixa o jogo)."
                    self.log("[Auto] GTA aberto: abrindo o Minecraft (instância %s)" % INSTANCE)
                    did = "launched"
                except Exception as e:
                    self.launched_at = now
                    self.note = "Não deu para abrir o Minecraft: %s" % e
                    self.log("[Auto] não abriu o Minecraft: %s" % e)
                    did = "launch_failed"
        elif prefs.get("auto_close") and linked and pid and pid == self.ours_pid and not gta_running \
                and self.gta_was is False and now - self.gta_seen >= self.CLOSE_AFTER:
            if self.placer.close(pid):
                self.note = "GTA fechado: fechando o Minecraft que o FusionBridge abriu (ele salva o mundo antes)."
                self.log("[Auto] GTA fechado: Minecraft fechado")
                self.ours_pid = None
                did = "closed"
        if linked and pid:
            if prefs.get("hide_mc") and pid not in self.hidden:
                if self.placer.hide(pid):
                    self.note = "Janela do Minecraft fora da tela (continua desenhando para a fusão)."
                self.hidden.add(pid)
            elif not prefs.get("hide_mc") and pid in self.hidden:
                self.placer.show(pid)
                self.hidden.discard(pid)
                self.note = "Janela do Minecraft de volta na tela."
        self.gta_was = gta_running
        return did
