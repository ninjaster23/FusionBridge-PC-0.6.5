// GTA: San Andreas 1.0 US (the version MoonLoader runs on): the few game addresses the ASI uses.
// Everything here is checked before use: the version signature, readable memory, plausible values, and
// hooks are only installed where the expected CALL instruction is found (otherwise that feature is skipped).
#pragma once
#include <cstddef>
#include <cstdint>

namespace sa
{
	struct Camera
	{
		float pos[3];   // GTA world
		float fwd[3];   // view direction ("at" of the RenderWare camera frame)
		float up[3];
		float tan_x, tan_y; // RenderWare view window: tan of half the horizontal / vertical field of view
		float near_z, far_z;
	};

	/// True on gta_sa.exe 1.0 US (HOODLUM or compact), the only build the addresses below are for.
	bool is_10us();
	/// Reads the camera the game renders with (RenderWare: Scene.camera). False if it isn't plausible.
	bool read_camera(Camera &out);
	/// The pause menu / frontend is up.
	bool menu_active();

	using VoidFn = void(__cdecl *)();
	/// Hooks the call to CPad::UpdatePads inside CGame::Process: `after` runs right after the pads update.
	bool hook_update_pads(VoidFn after);
	/// Hooks the call to Render2dStuff in Idle: `before` runs after the 3D scene and post effects, before the HUD.
	bool hook_render2d(VoidFn before);
	/// Clears GTA's fire / aim / weapon-cycle buttons of pad 0 for this frame (call from the UpdatePads hook).
	void block_fire_and_aim();

	bool readable(const void *p, size_t n);
}
