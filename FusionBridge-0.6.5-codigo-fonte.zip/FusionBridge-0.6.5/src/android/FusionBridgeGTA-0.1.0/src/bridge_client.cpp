#include "bridge_client.h"

#include <chrono>
#include <cstring>
#include <string>

#if defined(__ANDROID__)
#include <android/log.h>
#endif

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

namespace fbgta {
namespace {
std::mutex g_log_mu;
void (*g_log_cb)(const char*) = nullptr;

void log_line(const std::string& s) {
    std::lock_guard<std::mutex> lock(g_log_mu);
    if (g_log_cb) {
        g_log_cb(s.c_str());
        return;
    }
#if defined(__ANDROID__)
    __android_log_print(ANDROID_LOG_INFO, "FusionBridgeGTA", "%s", s.c_str());
#else
    std::fprintf(stderr, "[FusionBridgeGTA] %s\n", s.c_str());
#endif
}

bool send_line(int fd, const std::string& s) {
    std::string line = s;
    line.push_back('\n');
    const char* p = line.data();
    std::size_t remaining = line.size();
    while (remaining) {
        ssize_t n = ::send(fd, p, remaining, MSG_NOSIGNAL);
        if (n <= 0) return false;
        p += n;
        remaining -= static_cast<std::size_t>(n);
    }
    return true;
}
} // namespace

void set_log_callback(void (*cb)(const char*)) {
    std::lock_guard<std::mutex> lock(g_log_mu);
    g_log_cb = cb;
}

BridgeClient::BridgeClient() = default;
BridgeClient::~BridgeClient() { stop(); }

bool BridgeClient::start() {
    bool expected = false;
    if (!running_.compare_exchange_strong(expected, true)) return true;
    worker_ = std::thread([this] { worker_loop(); });
    return true;
}

void BridgeClient::stop() {
    if (!running_.exchange(false)) return;
    if (worker_.joinable()) worker_.join();
    connected_.store(false);
}

void BridgeClient::push(Event&& e) {
    std::lock_guard<std::mutex> lock(event_mu_);
    if (events_.size() >= 1024) events_.pop_front();
    events_.emplace_back(std::move(e));
}

bool BridgeClient::pop(Event& out) {
    std::lock_guard<std::mutex> lock(event_mu_);
    if (events_.empty()) return false;
    out = std::move(events_.front());
    events_.pop_front();
    return true;
}

void BridgeClient::queue_player_state(const std::string& json) {
    std::lock_guard<std::mutex> lock(out_mu_);
    pending_state_ = json; // collapse to newest state; avoids backlog/CPU waste.
}

void BridgeClient::log(const std::string& s) const { log_line(s); }

void BridgeClient::worker_loop() {
    using namespace std::chrono_literals;
    while (running_.load()) {
        int fd = ::socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) {
            std::this_thread::sleep_for(1500ms);
            continue;
        }

        timeval tv{};
        tv.tv_sec = 1;
        tv.tv_usec = 0;
        ::setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        ::setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(28765);
        ::inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);

        if (::connect(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) {
            ::close(fd);
            std::this_thread::sleep_for(1500ms);
            continue;
        }

        connected_.store(true);
        log("connected to 127.0.0.1:28765");
        if (!send_line(fd, make_hello())) {
            connected_.store(false);
            ::close(fd);
            continue;
        }

        auto next_ping = std::chrono::steady_clock::now();
        std::string rx;
        rx.reserve(8192);

        while (running_.load()) {
            auto now = std::chrono::steady_clock::now();
            if (now >= next_ping) {
                if (!send_line(fd, make_ping())) break;
                next_ping = now + 4s;
            }

            {
                std::string state;
                {
                    std::lock_guard<std::mutex> lock(out_mu_);
                    state.swap(pending_state_);
                }
                if (!state.empty() && !send_line(fd, state)) break;
            }

            char buf[2048];
            ssize_t n = ::recv(fd, buf, sizeof(buf), 0);
            if (n > 0) {
                rx.append(buf, static_cast<std::size_t>(n));
                for (;;) {
                    std::size_t nl = rx.find('\n');
                    if (nl == std::string::npos) break;
                    std::string line = rx.substr(0, nl);
                    rx.erase(0, nl + 1);
                    Event e;
                    if (parse_event_line(line, e)) push(std::move(e));
                }
            } else if (n == 0) {
                break;
            } else {
                // Timeout is expected. Any hard socket error will be retried by reconnect loop.
            }

            std::this_thread::sleep_for(8ms);
        }

        connected_.store(false);
        ::close(fd);
        log("bridge disconnected; retrying");
        std::this_thread::sleep_for(800ms);
    }
}

} // namespace fbgta
