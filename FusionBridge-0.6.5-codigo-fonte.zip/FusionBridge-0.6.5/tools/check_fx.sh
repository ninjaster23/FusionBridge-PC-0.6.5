#!/usr/bin/env bash
# Checks gta/shaders/FusionBridgeSA.fx with ReShade's own effect compiler, the way ReShade 6.8 does for Direct3D 9
# (same built-in macros; preprocess, parse, shader-model-3 HLSL). Needs the ReShade 6.8.0 source and ReShade.fxh:
#   git clone --depth 1 --branch v6.8.0 https://github.com/crosire/reshade.git /tmp/reshade
#   RESHADE_SRC=/tmp/reshade FXH_DIR=<folder with ReShade.fxh + ReShadeUI.fxh> tools/check_fx.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="${RESHADE_SRC:?set RESHADE_SRC to a ReShade 6.8.0 checkout}/source"
FXH="${FXH_DIR:?set FXH_DIR to the folder with ReShade.fxh}"
T="$(mktemp -d)"
g++ -std=c++17 -O1 -w -I "$SRC" -I "$SRC/../include" "$ROOT/tools/fxcheck.cpp" "$SRC/effect_lexer.cpp" "$SRC/effect_preprocessor.cpp" \
  "$SRC/effect_parser_exp.cpp" "$SRC/effect_parser_stmt.cpp" "$SRC/effect_symbol_table.cpp" "$SRC/effect_expression.cpp" \
  "$SRC/effect_codegen_hlsl.cpp" -o "$T/fxcheck"
rc=0
for res in "3440 1440" "1920 1080" "1366 768"; do
  "$T/fxcheck" "$ROOT/gta/shaders/FusionBridgeSA.fx" "$FXH" "$T/out.hlsl" $res | tail -1 || rc=1
done
rm -rf "$T"
exit $rc
