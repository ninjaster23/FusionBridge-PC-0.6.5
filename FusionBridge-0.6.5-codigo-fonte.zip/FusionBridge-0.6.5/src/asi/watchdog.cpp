#include "watchdog.h"
#include "sa.h"
#include <atomic>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>

namespace
{
	// GTA SA is 32-bit; the 64-bit variant only exists so the test can run under a 64-bit-only Wine
#ifdef _WIN64
	using NtHeaders = IMAGE_NT_HEADERS64;
	constexpr WORD kOptionalMagic = IMAGE_NT_OPTIONAL_HDR64_MAGIC;
	inline uintptr_t ip_of(const CONTEXT &c) { return uintptr_t(c.Rip); }
	inline uintptr_t sp_of(const CONTEXT &c) { return uintptr_t(c.Rsp); }
	inline uintptr_t bp_of(const CONTEXT &c) { return uintptr_t(c.Rbp); }
#else
	using NtHeaders = IMAGE_NT_HEADERS32;
	constexpr WORD kOptionalMagic = IMAGE_NT_OPTIONAL_HDR32_MAGIC;
	inline uintptr_t ip_of(const CONTEXT &c) { return uintptr_t(c.Eip); }
	inline uintptr_t sp_of(const CONTEXT &c) { return uintptr_t(c.Esp); }
	inline uintptr_t bp_of(const CONTEXT &c) { return uintptr_t(c.Ebp); }
#endif

	constexpr DWORD kStallMs = 8000;          // no frame for this long: report where the main thread is
	constexpr DWORD kSecondLookMs = 30000;    // and once more if it is still stuck (same place = a real hang)
	constexpr int kMaxReports = 12;           // per session (alt-tab pauses GTA too: don't flood the log)
	constexpr size_t kStackBytes = 16 * 1024; // of the main thread's stack, from ESP up
	constexpr int kMaxFrames = 24;            // return addresses listed

	std::atomic<DWORD> g_mainTid{0};
	std::atomic<DWORD> g_lastBeat{0};
	std::atomic<int> g_stage{watchdog::kIdle};
	std::atomic<bool> g_quit{false};
	void (*g_log)(const char *) = nullptr;
	uintptr_t g_exeBase = 0, g_selfBase = 0;
	uint8_t g_stack[kStackBytes]; // filled while the main thread is suspended: no allocation, no lock

	const char *const kStageNames[watchdog::kStageCount] = {
		"fora do ASI", "gancho dos controles (CPad)", "gancho do HUD", "ReShade render_effects", "reshade_begin_effects",
		"abrindo a memoria do Minecraft", "copiando a imagem do Minecraft", "criando as texturas", "registrando no ReShade"};

	void line(const char *fmt, ...)
	{
		char buf[512];
		va_list args;
		va_start(args, fmt);
		vsnprintf(buf, sizeof(buf), fmt, args);
		va_end(args);
		if (g_log != nullptr)
			g_log(buf);
	}

	bool is_code(uintptr_t a)
	{
		MEMORY_BASIC_INFORMATION mbi;
		if (a < 0x10000 || VirtualQuery(reinterpret_cast<void *>(a), &mbi, sizeof(mbi)) == 0)
			return false;
		const DWORD exec = PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
		return mbi.State == MEM_COMMIT && mbi.Type == MEM_IMAGE && (mbi.Protect & exec) != 0 && (mbi.Protect & PAGE_GUARD) == 0;
	}

	/// The DLL name an image gives itself in its export directory: read straight from its headers, so no loader
	/// lock is taken (the main thread may be stuck holding it).
	const char *export_name(uintptr_t base)
	{
		if (!sa::readable(reinterpret_cast<void *>(base), sizeof(IMAGE_DOS_HEADER)))
			return nullptr;
		const auto *dos = reinterpret_cast<const IMAGE_DOS_HEADER *>(base);
		if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0 || dos->e_lfanew > 0x1000)
			return nullptr;
		const uintptr_t nt_at = base + uintptr_t(dos->e_lfanew);
		if (!sa::readable(reinterpret_cast<void *>(nt_at), sizeof(NtHeaders)))
			return nullptr;
		const auto *nt = reinterpret_cast<const NtHeaders *>(nt_at);
		if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != kOptionalMagic ||
			nt->OptionalHeader.NumberOfRvaAndSizes <= IMAGE_DIRECTORY_ENTRY_EXPORT)
			return nullptr;
		const IMAGE_DATA_DIRECTORY &dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
		if (dir.VirtualAddress == 0 || dir.Size < sizeof(IMAGE_EXPORT_DIRECTORY))
			return nullptr;
		const uintptr_t exp_at = base + dir.VirtualAddress;
		if (!sa::readable(reinterpret_cast<void *>(exp_at), sizeof(IMAGE_EXPORT_DIRECTORY)))
			return nullptr;
		const auto *exp = reinterpret_cast<const IMAGE_EXPORT_DIRECTORY *>(exp_at);
		if (exp->Name == 0)
			return nullptr;
		const auto *name = reinterpret_cast<const char *>(base + exp->Name);
		if (!sa::readable(name, 64))
			return nullptr;
		for (int i = 0; i < 64; ++i)
		{
			if (name[i] == 0)
				return i > 0 ? name : nullptr;
			if (name[i] < 0x20 || name[i] > 0x7E)
				return nullptr;
		}
		return nullptr;
	}

	/// "name+0x1234" (or "0x00ABCDEF" outside any image)
	void describe(uintptr_t a, char *out, size_t n)
	{
		MEMORY_BASIC_INFORMATION mbi;
		if (VirtualQuery(reinterpret_cast<void *>(a), &mbi, sizeof(mbi)) == 0 || mbi.Type != MEM_IMAGE)
		{
			snprintf(out, n, "0x%08llX", static_cast<unsigned long long>(a));
			return;
		}
		const uintptr_t base = reinterpret_cast<uintptr_t>(mbi.AllocationBase);
		const char *name = base == g_exeBase ? "gta_sa.exe" : base == g_selfBase ? "FusionBridgeSA.asi" : export_name(base);
		if (name != nullptr)
			snprintf(out, n, "%s+0x%X", name, unsigned(a - base));
		else
			snprintf(out, n, "modulo@%08llX+0x%X", static_cast<unsigned long long>(base), unsigned(a - base));
	}

	/// Suspends the main thread just long enough to copy its registers and the top of its stack, resumes it, and only
	/// then looks at what it copied (VirtualQuery, header reads, logging: nothing that could wait on the main thread
	/// runs while it is suspended).
	void report(DWORD stalled_ms, int look)
	{
		const DWORD tid = g_mainTid.load();
		if (tid == 0)
			return;
		HANDLE th = OpenThread(THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION, FALSE, tid);
		if (th == nullptr)
		{
			line("vigia: nao consegui abrir a thread do GTA (erro %lu)", GetLastError());
			return;
		}
		CONTEXT ctx;
		std::memset(&ctx, 0, sizeof(ctx));
		ctx.ContextFlags = CONTEXT_CONTROL | CONTEXT_INTEGER;
		size_t copied = 0;
		bool got = false;
		if (SuspendThread(th) != DWORD(-1))
		{
			if (GetThreadContext(th, &ctx))
			{
				got = true;
				MEMORY_BASIC_INFORMATION mbi;
				const uintptr_t sp = sp_of(ctx);
				if (VirtualQuery(reinterpret_cast<void *>(sp), &mbi, sizeof(mbi)) != 0 && mbi.State == MEM_COMMIT &&
					(mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS)) == 0)
				{
					const uintptr_t end = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
					copied = end > sp ? end - sp : 0;
					if (copied > kStackBytes)
						copied = kStackBytes;
					std::memcpy(g_stack, reinterpret_cast<const void *>(sp), copied);
				}
			}
			ResumeThread(th);
		}
		CloseHandle(th);

		DWORD fg_pid = 0;
		GetWindowThreadProcessId(GetForegroundWindow(), &fg_pid);
		const int st = g_stage.load();
		line("VIGIA: o GTA esta ha %.1f s sem completar um quadro (%s olhada; GTA em primeiro plano: %s; ASI: %s)",
			stalled_ms / 1000.0, look == 1 ? "1a" : "2a", fg_pid == GetCurrentProcessId() ? "sim" : "nao",
			st >= 0 && st < watchdog::kStageCount ? kStageNames[st] : "?");
		if (!got)
		{
			line("vigia: nao consegui ler os registradores da thread do GTA (erro %lu)", GetLastError());
			return;
		}
		char where[96];
		describe(ip_of(ctx), where, sizeof(where));
		line("  parado em %s  (ESP %08llX, EBP %08llX)", where, static_cast<unsigned long long>(sp_of(ctx)),
			static_cast<unsigned long long>(bp_of(ctx)));
		int frames = 0;
		for (size_t off = 0; off + sizeof(uintptr_t) <= copied && frames < kMaxFrames; off += sizeof(uintptr_t))
		{
			uintptr_t v;
			std::memcpy(&v, g_stack + off, sizeof(v));
			if (!is_code(v))
				continue;
			describe(v, where, sizeof(where));
			line("  pilha +%04X: %s", unsigned(off), where);
			++frames;
		}
		if (frames == 0)
			line("  (nenhum endereco de codigo na pilha copiada: %u bytes)", unsigned(copied));
	}

	DWORD WINAPI run(LPVOID)
	{
		int reports = 0, looks = 0;
		bool stalled = false;
		while (!g_quit.load())
		{
			Sleep(1000);
			const DWORD last = g_lastBeat.load();
			if (last == 0)
				continue; // the game hasn't run a frame yet (loading)
			const DWORD now = GetTickCount();
			// beat() stores tick|1, up to 1 ms ahead of `now`: a negative difference just means a frame happened now
			const DWORD gap = LONG(now - last) < 0 ? 0 : now - last;
			if (gap >= kStallMs)
			{
				if (!stalled)
				{
					stalled = true;
					looks = 0;
				}
				if (reports < kMaxReports && ((looks == 0) || (looks == 1 && gap >= kSecondLookMs)))
				{
					++looks;
					++reports;
					report(gap, looks);
				}
			}
			else if (stalled)
			{
				stalled = false;
				if (looks > 0)
					line("vigia: o GTA voltou a rodar");
			}
		}
		return 0;
	}
}

namespace watchdog
{
	void start(HMODULE self, void (*log)(const char *line))
	{
		g_log = log;
		g_exeBase = reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));
		g_selfBase = reinterpret_cast<uintptr_t>(self);
		// never unloaded while the thread runs (ASI loaders don't unload plugins anyway)
		HMODULE pinned = nullptr;
		GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN,
			reinterpret_cast<LPCWSTR>(&start), &pinned);
		HANDLE th = CreateThread(nullptr, 64 * 1024, &run, nullptr, 0, nullptr);
		if (th != nullptr)
			CloseHandle(th);
	}

	void stop()
	{
		g_quit = true;
	}

	void beat()
	{
		if (g_mainTid.load() == 0)
			g_mainTid = GetCurrentThreadId();
		g_lastBeat = GetTickCount() | 1; // never 0 (0 = no frame yet)
	}

	void stage(Stage s)
	{
		g_stage = s;
	}
}
