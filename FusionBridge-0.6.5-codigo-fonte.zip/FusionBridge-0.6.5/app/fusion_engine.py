"""FusionBridge PC 0.6.5 - fusion engine: puts Minecraft Java *inside* GTA: San Andreas.

The hub (fusionbridge.py) owns the sockets; this module is the "brain" in the middle:

  GTA SA (MoonLoader script + FusionBridgeSA.asi)            Minecraft Java 26.3 + Fabric
      fusion_cam / fusion_ground / fusion_input  --->  hub  --->  passthrough mod, WebSocket 127.0.0.1:25599
      fusion_boom / fusion_teleport / fusion_props <---     <---  explosion / pteleport / blocks
      FusionBridgeSA.asi (ReShade add-on)  <-- shared memory "Local\\MCPassthroughFrame" --  Minecraft's frames

* The GTA script sends GTA's camera and CJ every frame (GTA coordinates). The engine turns them into
  Minecraft's camera ("cam"), so Minecraft renders the exact view GTA renders, with Steve where CJ stands.
* The GTA script probes GTA's ground around CJ; the engine turns it into invisible barrier columns in
  Minecraft ("ground"), so Minecraft blocks, mobs and items rest on GTA's streets.
* Minecraft's explosions come back as GTA explosions at the same spot, ender pearls move CJ, and blocks
  you build can become invisible walls in GTA.
* The picture itself never goes through the hub: Minecraft writes colour + depth into shared memory and
  the ASI (a ReShade add-on inside GTA) composites it against GTA's depth buffer.

Coordinates (same convention as the MIT "Minecraft x GTA V passthrough" this is based on):
  1 GTA metre = 1 block.  GTA (x, y, z), z up  ->  Minecraft (x, z + yoff, -y).
  Minecraft yaw = 180 - GTA heading, Minecraft pitch = -GTA pitch, roll unchanged.
  yoff = (round(ground) - ground) + shift: the ground under CJ lands exactly on a block boundary, and
  `shift` (whole blocks) keeps Mount Chiliad (z ~ 500) inside Minecraft's build height.

Standard library only.
"""
import base64, collections, hashlib, json, math, os, socket, struct, sys, threading, time

MC_HOST = "127.0.0.1"
MC_PORT = 25599
GROUND_DEPTH = 2          # barrier layers under each GTA surface
MAX_MC_PIXELS = 1920 * 1080
SHM_NAME = "Local\\MCPassthroughFrame"
WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
MC_OUT_CAP = 512 * 1024   # stop queueing camera updates if Minecraft stops reading

DEFAULT_OPTS = {
    "hide_cj": True,       # Steve takes CJ's place (CJ invisible while on foot)
    "cj_safe": True,       # CJ fire/explosion proof while the fusion is on (Minecraft TNT goes off next to him)
    "props": True,         # Minecraft blocks become invisible GTA walls (cars and people stop at them)
    "explosions": True,    # Minecraft explosions -> GTA explosions
    "pearls": True,        # ender pearl -> CJ teleports
    "radius": 40,          # ground probed around CJ (blocks)
    "probes": 96,          # ground probes per GTA frame
    "max_pixels": MAX_MC_PIXELS,
    "auto_level": True,
    "keys_fused": True,    # one key does the matching thing in both games (FUSED_KEYS)
    "fsr": True,           # FSR 1.0 (EASU + RCAS) brings Minecraft's picture up to GTA's resolution
    "fsr_scale": 100,      # Minecraft renders at GTA's resolution / (this / 100): AMD's presets (FSR_SCALES)
    "fsr_sharp": 20,       # RCAS sharpness, hundredths of a stop (0 = strongest; AMD's default is 0.2)
}
# AMD FSR 1.0 quality modes: per-axis scale factor (x100) -> name
FSR_SCALES = {100: "Nativo", 130: "Ultra qualidade", 150: "Qualidade", 170: "Equilibrado", 200: "Desempenho"}
MAX_PROPS_TO_GTA = 120     # Minecraft blocks sent to GTA at once: its script keeps 150 invisible walls, and the rest is
                           # room for the blocks the player builds afterwards

# The keys the GTA script forwards to Minecraft while CJ walks with the mouse playing Minecraft (F6 gives them back
# to GTA). They're sent to the script in fusion_state as [vk, action, ...], so they apply as soon as the fusion
# starts. Q/E are GTA's previous/next weapon and become Minecraft's previous/next item too; the other keys are ones
# GTA SA doesn't use on foot. Action codes: KEY_ACTIONS (the script knows the same table).
KEY_ACTIONS = {"attack": 1, "use": 2, "inventory": 3, "drop": 4, "swap": 5, "prev": 7, "next": 8}
BASIC_KEYS = [(0x01, "attack"), (0x02, "use")]                       # mouse buttons
FUSED_KEYS = BASIC_KEYS + [(0x51, "prev"), (0x45, "next"),            # Q / E
                           (0x49, "inventory"), (0x5A, "drop"), (0x58, "swap")]   # I / Z / X


def keys_msg(fused):
    out = []
    for vk, action in (FUSED_KEYS if fused else BASIC_KEYS):
        out += [vk, KEY_ACTIONS[action]]
    return out


# ====================================================================== pure helpers (tested)
def wrap180(a):
    a = math.fmod(a, 360.0)
    if a > 180.0:
        a -= 360.0
    if a <= -180.0:
        a += 360.0
    return a


def gta_to_mc(x, y, z, yoff):
    return x, z + yoff, -y


def mc_to_gta(mx, my, mz, yoff):
    return mx, -mz, my - yoff


def angles_to_mc(heading, pitch, roll):
    """GTA camera heading/pitch/roll (degrees) -> Minecraft yaw/pitch/roll."""
    return wrap180(180.0 - heading), -pitch, roll


def level_offset(ground_z):
    """(frac, shift): frac puts this ground on a whole block, shift keeps it inside Minecraft's height."""
    r = math.floor(ground_z + 0.5)
    frac = r - ground_z
    shift = 0 if -50.0 <= ground_z <= 250.0 else int(128 - r)
    return frac, shift


def ground_column(cx, cz, gz, yoff, depth=GROUND_DEPTH):
    """A probed GTA ground height for Minecraft column (cx, cz) -> [x, z, ymin, ymax] barrier column."""
    top = int(math.floor(gz + yoff + 0.5)) - 1
    return [int(cx), int(cz), top - depth + 1, top]


def explosion_kind(radius, src):
    """Minecraft explosion -> GTA SA explosion type (ADD_EXPLOSION)."""
    src = src or ""
    if src in ("fireball", "dragon_fireball"):
        return 1            # molotov: a ghast's fireball leaves fire
    if src == "wither_skull":
        return 3            # weak rocket
    if radius >= 5.5:
        return 7            # aircraft: end crystals, charged creepers
    if radius >= 3.5:
        return 2            # rocket: TNT
    return 0                # grenade: creepers and small blasts


def mc_view_size(bb_w, bb_h, aspect, max_pixels=MAX_MC_PIXELS, fsr_scale=100):
    """Minecraft's window: GTA's projection aspect (4:3 without a widescreen fix), GTA's height divided by the FSR
    1.0 mode's factor (FSR brings it back up inside GTA), capped."""
    if bb_w <= 0 or bb_h <= 0:
        return None
    if not aspect or aspect <= 0.2 or aspect > 6:
        aspect = bb_w / float(bb_h)
    h = float(bb_h) * 100.0 / max(100, min(300, fsr_scale or 100))
    w = h * aspect
    scale = min(1.0, math.sqrt(max_pixels / (w * h)))
    return int(w * scale + 0.5), int(h * scale + 0.5)


def mc_command_for(action):
    """Panel 'Caos no Minecraft' actions, run through the passthrough mod when FusionBridgeMC isn't there."""
    at = "execute at @p run "
    table = {
        "wither": [at + "summon minecraft:wither ~ ~8 ~"],
        "tnt": [at + "summon minecraft:tnt ~ ~3 ~"],
        "tnt_rain": [at + "summon minecraft:tnt ~%d ~14 ~%d" % (round(math.cos(a) * 5), round(math.sin(a) * 5))
                     for a in [2 * math.pi * i / 8 for i in range(8)]],
        "creeper": [at + "summon minecraft:creeper ~3 ~ ~"],
        "charged_creeper": [at + "summon minecraft:creeper ~3 ~ ~ {powered:1b}"],
        "lightning": [at + "summon minecraft:lightning_bolt ~ ~ ~"],
        "boom": [at + "summon minecraft:tnt ~ ~1 ~ {fuse:0}"],
        "heal": ["effect give @a minecraft:instant_health 1 4 true"],
        "clear": ["kill @e[type=minecraft:wither]", "kill @e[type=minecraft:tnt]", "kill @e[type=minecraft:creeper]"],
        "day": ["time set day", "weather clear"],
        "freeze": ["tick freeze"],
        "unfreeze": ["tick unfreeze"],
        "status": [],
    }
    return table.get(action)


def _num(v, default=None):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return f if math.isfinite(f) else default


def _vec3(v):
    if isinstance(v, (list, tuple)) and len(v) >= 3:
        a, b, c = _num(v[0]), _num(v[1]), _num(v[2])
        if a is not None and b is not None and c is not None:
            return a, b, c
    return None


def _j(obj):
    return json.dumps(obj, separators=(",", ":"))


# ====================================================================== small non-blocking WebSocket client
class WSClient:
    """RFC 6455 client, text frames only, non-blocking (driven by the hub's selector)."""

    def __init__(self, host, port):
        self.host, self.port = host, port
        self.sock = None
        self.state = "off"           # off | handshake | open
        self.inbuf = bytearray()
        self.outbuf = bytearray()
        self.key = ""
        self.frag = bytearray()
        self.frag_op = 0
        self.rx = self.tx = self.dropped = 0
        self.since = 0.0
        self.error = ""

    def fileno(self):
        return self.sock.fileno() if self.sock else -1

    def open_socket(self, timeout=2.0):
        """Blocking connect (run it off the hub thread: on Windows a refused localhost connect takes ~1-2 s)."""
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        try:
            s.connect((self.host, self.port))
        except OSError as e:
            s.close()
            self.error = str(e)
            return None
        return s

    def connect(self):
        s = self.open_socket(0.3)
        return self.adopt(s) if s else False

    def adopt(self, s):
        """Takes a connected socket and starts the WebSocket handshake on it."""
        self.close()
        s.setblocking(False)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.sock = s
        self.key = base64.b64encode(os.urandom(16)).decode()
        self.outbuf += ("GET / HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                        "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n"
                        % (self.host, self.port, self.key)).encode()
        self.state = "handshake"
        self.since = time.monotonic()
        self.flush()
        return True

    def close(self):
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock = None
        self.state = "off"
        self.inbuf.clear()
        self.outbuf.clear()
        self.frag.clear()

    @staticmethod
    def _mask(payload, mask):
        n = len(payload)
        if n == 0:
            return b""
        m = (mask * (n // 4 + 1))[:n]
        return (int.from_bytes(payload, "little") ^ int.from_bytes(m, "little")).to_bytes(n, "little")

    def _frame(self, op, payload):
        n = len(payload)
        head = bytearray([0x80 | op])
        if n < 126:
            head.append(0x80 | n)
        elif n < 65536:
            head.append(0x80 | 126)
            head += struct.pack(">H", n)
        else:
            head.append(0x80 | 127)
            head += struct.pack(">Q", n)
        mask = os.urandom(4)
        return bytes(head) + mask + self._mask(payload, mask)

    def send_text(self, text, droppable=False):
        if self.state != "open":
            return False
        if droppable and len(self.outbuf) > MC_OUT_CAP:
            self.dropped += 1
            return False
        self.outbuf += self._frame(0x1, text.encode("utf-8"))
        self.tx += 1
        return True

    def flush(self):
        if not self.sock or not self.outbuf:
            return True
        try:
            n = self.sock.send(self.outbuf)
            del self.outbuf[:n]
        except (BlockingIOError, InterruptedError):
            pass
        except OSError as e:
            self.error = "escrita: %s" % e
            self.close()
            return False
        return True

    def on_readable(self):
        """Returns the text messages that arrived, or None when the connection closed."""
        try:
            data = self.sock.recv(262144)
        except (BlockingIOError, InterruptedError):
            return []
        except OSError as e:
            self.error = "leitura: %s" % e
            self.close()
            return None
        if not data:
            self.error = "o Minecraft fechou a conexao"
            self.close()
            return None
        self.inbuf += data
        out = []
        if self.state == "handshake":
            end = self.inbuf.find(b"\r\n\r\n")
            if end < 0:
                if len(self.inbuf) > 16384:
                    self.error = "resposta do handshake grande demais"
                    self.close()
                    return None
                return out
            head = bytes(self.inbuf[:end]).decode("latin-1")
            del self.inbuf[:end + 4]
            want = base64.b64encode(hashlib.sha1((self.key + WS_GUID).encode()).digest()).decode()
            if not head.startswith("HTTP/1.1 101") or want not in head:
                self.error = "o Minecraft recusou o WebSocket: " + head.split("\r\n")[0]
                self.close()
                return None
            self.state = "open"
        while self.state == "open" and len(self.inbuf) >= 2:
            b0, b1 = self.inbuf[0], self.inbuf[1]
            n = b1 & 0x7F
            pos = 2
            if n == 126:
                if len(self.inbuf) < 4:
                    break
                n = struct.unpack(">H", self.inbuf[2:4])[0]
                pos = 4
            elif n == 127:
                if len(self.inbuf) < 10:
                    break
                n = struct.unpack(">Q", self.inbuf[2:10])[0]
                pos = 10
            mask = None
            if b1 & 0x80:
                if len(self.inbuf) < pos + 4:
                    break
                mask = bytes(self.inbuf[pos:pos + 4])
                pos += 4
            if len(self.inbuf) < pos + n:
                break
            payload = bytes(self.inbuf[pos:pos + n])
            del self.inbuf[:pos + n]
            if mask:
                payload = self._mask(payload, mask)
            fin, op = b0 & 0x80, b0 & 0x0F
            if op == 0x8:                       # close
                self.error = "o Minecraft encerrou o link"
                self.close()
                return out or None
            if op == 0x9:                       # ping -> pong
                self.outbuf += self._frame(0xA, payload)
                continue
            if op == 0xA:
                continue
            if op in (0x1, 0x2):
                self.frag = bytearray(payload)
                self.frag_op = op
            elif op == 0x0:
                self.frag += payload
            else:
                continue
            if fin:
                if self.frag_op == 0x1:
                    out.append(bytes(self.frag).decode("utf-8", "replace"))
                    self.rx += 1
                self.frag = bytearray()
        return out


# ====================================================================== shared memory monitor (Windows)
class FrameMonitor:
    """Reads the header of Minecraft's frame export to show its frame rate and size in the panel."""

    def __init__(self):
        self.ok = sys.platform == "win32"
        self.view = None
        self.handle = None
        self.next_try = 0.0
        self.last_count = None
        self.last_t = 0.0
        self.fps = 0.0
        self.size = (0, 0)
        self.present = False
        if self.ok:
            try:
                import ctypes
                from ctypes import wintypes
                k = ctypes.WinDLL("kernel32", use_last_error=True)
                k.OpenFileMappingW.restype = wintypes.HANDLE
                k.OpenFileMappingW.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR)
                k.MapViewOfFile.restype = ctypes.c_void_p
                k.MapViewOfFile.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_size_t)
                k.UnmapViewOfFile.argtypes = (ctypes.c_void_p,)
                k.CloseHandle.argtypes = (wintypes.HANDLE,)
                self.k, self.ct = k, ctypes
            except Exception:
                self.ok = False

    def _open(self):
        FILE_MAP_READ = 0x0004
        h = self.k.OpenFileMappingW(FILE_MAP_READ, False, SHM_NAME)
        if not h:
            return False
        v = self.k.MapViewOfFile(h, FILE_MAP_READ, 0, 0, 4096)
        if not v:
            self.k.CloseHandle(h)
            return False
        self.handle, self.view = h, v
        return True

    def close(self):
        if self.view:
            self.k.UnmapViewOfFile(self.view)
        if self.handle:
            self.k.CloseHandle(self.handle)
        self.view = self.handle = None
        self.present = False
        self.fps = 0.0

    def poll(self, now):
        if not self.ok:
            return
        if not self.view:
            if now < self.next_try:
                return
            self.next_try = now + 2.0
            if not self._open():
                return
        raw = self.ct.string_at(self.view, 4096)
        magic, = struct.unpack_from("<I", raw, 0)
        if magic != 0x5450434D:
            self.close()
            return
        self.present = True
        count, = struct.unpack_from("<q", raw, 32)
        slot, = struct.unpack_from("<i", raw, 40)
        if 0 <= slot < 8:
            w, h = struct.unpack_from("<II", raw, 256 + 128 * slot + 24)
            self.size = (w, h)
        if self.last_count is not None and now > self.last_t:
            self.fps = max(0.0, (count - self.last_count) / (now - self.last_t))
        self.last_count, self.last_t = count, now


# ====================================================================== Minecraft's window: inventory from inside GTA
class _Win32Windows:
    """The few user32 calls McWindow needs (Windows only)."""

    def __init__(self):
        import ctypes
        from ctypes import wintypes
        u = ctypes.WinDLL("user32", use_last_error=True)
        self.ct, self.wt, self.u = ctypes, wintypes, u
        self.ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        u.EnumWindows.argtypes = (self.ENUMPROC, wintypes.LPARAM)
        u.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
        u.GetWindowThreadProcessId.restype = wintypes.DWORD
        u.IsWindow.argtypes = u.IsWindowVisible.argtypes = (wintypes.HWND,)
        u.GetClassNameW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
        u.GetClientRect.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.RECT))
        u.ClientToScreen.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.POINT))
        u.PostMessageW.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
        u.MapVirtualKeyW.argtypes = (wintypes.UINT, wintypes.UINT)
        u.MapVirtualKeyW.restype = wintypes.UINT

    def find(self, pid):
        """The visible GLFW window of process `pid` (Minecraft's game window), or None."""
        found = []

        def cb(hwnd, _):
            owner = self.wt.DWORD(0)
            self.u.GetWindowThreadProcessId(hwnd, self.ct.byref(owner))
            if owner.value == pid and self.u.IsWindowVisible(hwnd):
                name = self.ct.create_unicode_buffer(64)
                self.u.GetClassNameW(hwnd, name, 64)
                if name.value.startswith("GLFW"):
                    found.append(hwnd)
                    return False
            return True
        self.u.EnumWindows(self.ENUMPROC(cb), 0)
        return found[0] if found else None

    def alive(self, hwnd):
        return bool(self.u.IsWindow(hwnd))

    def client_size(self, hwnd):
        r = self.wt.RECT()
        if not self.u.GetClientRect(hwnd, self.ct.byref(r)):
            return 0, 0
        return r.right - r.left, r.bottom - r.top

    def to_screen(self, hwnd, x, y):
        pt = self.wt.POINT(x, y)
        self.u.ClientToScreen(hwnd, self.ct.byref(pt))
        return pt.x, pt.y

    def scancode(self, vk):
        return int(self.u.MapVirtualKeyW(vk, 0)) & 0xFF      # MAPVK_VK_TO_VSC

    def post(self, hwnd, msg, wparam, lparam):
        return bool(self.u.PostMessageW(hwnd, msg, wparam, lparam))


class McWindow:
    """Mouse and keys for Minecraft's own window (its inventory and other screens), posted as ordinary window
    messages: GLFW turns them into input even while GTA has the focus, so the inventory drawn inside GTA (the
    passthrough overlay) works without switching windows. The overlay covers GTA's whole picture and Minecraft's
    window has GTA's aspect (the hub sizes it), so a point given as a fraction of GTA's screen is the same point in
    Minecraft's window. Elsewhere than Windows (or without a window) every call does nothing."""
    WM_MOUSEMOVE, WM_MOUSEWHEEL, WM_KEYDOWN, WM_KEYUP = 0x0200, 0x020A, 0x0100, 0x0101
    BUTTONS = {0: (0x0201, 0x0202, 0x0001), 1: (0x0204, 0x0205, 0x0002), 2: (0x0207, 0x0208, 0x0010)}  # down, up, MK_
    KEYS = frozenset([0x10] + list(range(0x31, 0x3A)) + [0x51])   # Shift, 1-9 (hotbar swap), Q (drop the hovered item)

    def __init__(self, api=None):
        self.api = api
        if api is None and sys.platform == "win32":
            try:
                self.api = _Win32Windows()
            except Exception:
                self.api = None
        self.pid = None
        self.hwnd = None
        self.next_find = 0.0
        self.buttons = 0          # MK_ flags held
        self.keys_down = set()
        self.last = (0, 0)

    def set_pid(self, pid):
        pid = int(pid) if isinstance(pid, (int, float)) and pid > 0 else None
        if pid != self.pid:
            self.pid, self.hwnd, self.next_find = pid, None, 0.0

    def window(self, now):
        if self.api is None:
            return None
        if self.hwnd is not None and self.api.alive(self.hwnd):
            return self.hwnd
        self.hwnd = None
        if self.pid and now >= self.next_find:
            self.next_find = now + 1.0          # EnumWindows at most once a second
            self.hwnd = self.api.find(self.pid)
        return self.hwnd

    def pointer(self, nx, ny, now, button=None, down=None, wheel=0):
        hwnd = self.window(now)
        if hwnd is None:
            return False
        w, h = self.api.client_size(hwnd)
        if w <= 0 or h <= 0:
            return False
        x = min(w - 1, max(0, int(round(nx * (w - 1)))))
        y = min(h - 1, max(0, int(round(ny * (h - 1)))))
        self.last = (x, y)
        lp = ((y & 0xFFFF) << 16) | (x & 0xFFFF)
        if button in self.BUTTONS and down is not None:
            msg_down, msg_up, flag = self.BUTTONS[button]
            self.buttons = (self.buttons | flag) if down else (self.buttons & ~flag)
            self.api.post(hwnd, self.WM_MOUSEMOVE, self.buttons, lp)
            self.api.post(hwnd, msg_down if down else msg_up, self.buttons, lp)
        else:
            self.api.post(hwnd, self.WM_MOUSEMOVE, self.buttons, lp)
        if wheel:
            sx, sy = self.api.to_screen(hwnd, x, y)
            delta = (120 if wheel > 0 else -120) & 0xFFFF
            self.api.post(hwnd, self.WM_MOUSEWHEEL, (delta << 16) | self.buttons, ((sy & 0xFFFF) << 16) | (sx & 0xFFFF))
        return True

    def key(self, vk, down, now):
        if vk not in self.KEYS:
            return False
        hwnd = self.window(now)
        if hwnd is None:
            return False
        lp = 1 | (self.api.scancode(vk) << 16)
        if down:
            self.keys_down.add(vk)
        else:
            self.keys_down.discard(vk)
            lp |= (1 << 30) | (1 << 31)       # previous state down, transition up
        return self.api.post(hwnd, self.WM_KEYDOWN if down else self.WM_KEYUP, vk, lp)

    def release_all(self, now):
        """Lets go of whatever is still held (inventory closed, fusion off, GTA gone)."""
        for b, (_, msg_up, flag) in self.BUTTONS.items():
            if self.buttons & flag:
                self.pointer(*self._last_fraction(), now, button=b, down=False)
        for vk in list(self.keys_down):
            self.key(vk, False, now)
        self.buttons = 0
        self.keys_down.clear()

    def _last_fraction(self):
        hwnd = self.hwnd
        w, h = self.api.client_size(hwnd) if (self.api and hwnd) else (0, 0)
        if w <= 1 or h <= 1:
            return 0.5, 0.5
        return self.last[0] / (w - 1), self.last[1] / (h - 1)


# ====================================================================== the engine
class FusionEngine:
    def __init__(self, hub, settings_path=None):
        self.hub = hub
        self.ws = WSClient(MC_HOST, MC_PORT)
        self.registered = False
        self.next_connect = 0.0
        self.connecting = False
        self.connected_sock = None   # handed over by the connect thread
        self.mc_hello = {}
        self.mcwin = McWindow()      # the inventory inside GTA: mouse and keys posted to Minecraft's window
        self.on = True
        self.mouse = "mc"            # "mc": the mouse plays Minecraft on foot; "gta": GTA keeps it
        self.opts = dict(DEFAULT_OPTS)
        self.settings_path = settings_path
        self._load()
        self.have_off = False
        self.frac, self.shift = 0.0, 0
        self.relevel_req = False
        self.last_pg = None
        self.next_autolevel = 0.0
        self.blocks = set()          # Minecraft blocks the player built (from the mod's "blocks" reports)
        self.last_cam = None         # last GTA camera message (for the panel)
        self.cam_count = 0
        self.cam_rate = 0.0
        self.rate_t = time.monotonic()
        self.ground_cols = 0
        self.booms = 0
        self.teleports = 0
        self.view = None             # (bb_w, bb_h, aspect) from GTA
        self.view_sent = None
        self.in_vehicle = None
        self.asi = {}                # FusionBridgeSA.asi status reported by the GTA script
        self.actions = collections.deque()
        self.frames = FrameMonitor()
        self.next_state = 0.0
        self.pub = {}
        self.next_pub = 0.0
        self.notes = collections.deque(maxlen=20)
        self.mc_ignored = collections.Counter()

    # ---------------------------------------------------------------- settings
    def _load(self):
        if not self.settings_path:
            return
        try:
            with open(self.settings_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for k, v in (data.get("opts") or {}).items():
                if k in self.opts and type(v) is type(self.opts[k]):
                    self.opts[k] = self._valid(k, v)        # a hand-edited file can't push a value out of range
            if data.get("mouse") in ("mc", "gta"):
                self.mouse = data["mouse"]
        except (OSError, ValueError, AttributeError):
            pass

    def _save(self):
        if not self.settings_path:
            return
        tmp = self.settings_path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:     # whole file or nothing: a crash mid-write keeps the old one
                json.dump({"opts": self.opts, "mouse": self.mouse}, f, indent=1)
            os.replace(tmp, self.settings_path)
        except OSError:
            pass

    @property
    def yoff(self):
        return self.frac + self.shift

    def note(self, text):
        self.notes.appendleft({"t": time.time(), "text": text})
        self.hub.log("[Fusao] " + text)

    # ---------------------------------------------------------------- links
    def gta(self):
        for c in self.hub.clients.values():
            if c.ident and c.name == "gta":
                return c
        return None

    def to_gta(self, obj):
        c = self.gta()
        if c:
            c.queue(_j(obj))
            self.hub.flush(c)

    def to_mc(self, obj, droppable=False):
        if self.ws.send_text(_j(obj), droppable):
            self.ws.flush()
            return True
        return False

    def mc_open(self):
        return self.ws.state == "open"

    # ---------------------------------------------------------------- state push to GTA
    def state_msg(self):
        return {"type": "fusion_state", "on": 1 if self.on else 0, "mc": 1 if self.mc_open() else 0,
                "mouse": self.mouse, "hide_cj": int(self.opts["hide_cj"]), "cj_safe": int(self.opts["cj_safe"]),
                "props": int(self.opts["props"]), "radius": int(self.opts["radius"]),
                "probes": int(self.opts["probes"]), "yoff": round(self.yoff, 4), "level": 1 if self.have_off else 0,
                "keys": keys_msg(self.opts["keys_fused"]),
                "fsr": 1 if self.opts["fsr"] else 0, "sharp": round(self.opts["fsr_sharp"] / 100.0, 2)}

    def push_state(self):
        self.to_gta(self.state_msg())

    def relevel(self, why):
        self.relevel_req = True
        self.have_off = False
        self.note("nivelando o chao do Minecraft (%s)" % why)

    def _apply_level(self, pg):
        self.frac, self.shift = level_offset(pg)
        self.have_off = True
        self.relevel_req = False
        self.blocks.clear()
        self.to_mc({"t": "clear"})
        self.to_mc({"t": "blocksync", "r": 64})
        self.to_gta({"type": "fusion_ground_reset"})
        self.to_gta({"type": "fusion_props", "clear_all": 1})
        self.push_state()

    # ---------------------------------------------------------------- from GTA
    def on_gta(self, c, t, obj):
        """Handles fusion_* messages from the GTA script. Returns True when consumed."""
        if t == "fusion_cam":
            self._cam(obj)
        elif t == "fusion_ground":
            self._ground(obj)
        elif t == "fusion_input":
            self._input(obj)
        elif t == "fusion_pointer":
            self._pointer(obj)
        elif t == "fusion_view":
            w, h = int(_num(obj.get("w"), 0)), int(_num(obj.get("h"), 0))
            self.view = (w, h, _num(obj.get("aspect"), 0.0) or 0.0)
            self._send_view()
        elif t == "fusion_key":
            k = obj.get("k")
            if k == "toggle":
                self.set_on(not self.on)
            elif k == "relevel":
                self.relevel("F8")
            elif k == "mouse":
                self.set_mouse("gta" if self.mouse == "mc" else "mc")
        elif t == "fusion_asi":
            self.asi = {k: obj.get(k) for k in ("loaded", "version", "sa_ok", "reshade", "frame", "bb_w", "bb_h",
                                                 "uploads", "pad_hook", "hud_hook", "effect", "note")}
        elif t == "fusion_hello":
            self.push_state()
        else:
            return False
        return True

    def _cam(self, o):
        self.cam_count += 1
        cam, rot, pl = _vec3(o.get("c")), _vec3(o.get("r")), _vec3(o.get("p"))
        if not (cam and rot and pl):
            return
        self.last_cam = o
        pg = _num(o.get("pg"))
        if pg is not None and pg != 0.0:
            self.last_pg = pg
        if not self.on or not self.mc_open():
            return
        if (not self.have_off or self.relevel_req) and self.last_pg is not None:
            self._apply_level(self.last_pg)
        if not self.have_off:
            return
        veh = bool(_num(o.get("veh"), 0))
        if veh != self.in_vehicle:
            # in a car CJ stays visible and Steve, his hand and Minecraft's HUD step aside
            self.in_vehicle = veh
            self.to_mc({"t": "hud", "hidden": veh})
        yoff = self.yoff
        cx, cy, cz = gta_to_mc(cam[0], cam[1], cam[2], yoff)
        yaw, pitch, roll = angles_to_mc(rot[0], rot[1], rot[2])
        px, py, pz = gta_to_mc(pl[0], pl[1], pl[2] - 1.0, yoff)   # CJ's coords are his pelvis: feet ~1 m below
        h = wrap180(180.0 - (_num(o.get("h"), rot[0]) or 0.0))
        fov = _num(o.get("fov"), 70.0)
        fp = veh or bool(_num(o.get("fp"), 0)) or not self.opts["hide_cj"]
        self.to_mc({"t": "cam", "f": int(_num(o.get("f"), 0)), "p": [round(cx, 4), round(cy, 4), round(cz, 4)],
                    "r": [round(yaw, 3), round(pitch, 3), round(roll, 3)], "fov": round(fov, 3), "fp": fp,
                    "pl": [round(px, 4), round(py, 4), round(pz, 4)], "h": round(h, 3), "gun": False}, droppable=True)

    def _ground(self, o):
        if not self.have_off or not self.mc_open():
            return
        cols = []
        for e in o.get("g") or []:
            if isinstance(e, (list, tuple)) and len(e) >= 3:
                gz = _num(e[2])
                cx, cz = _num(e[0]), _num(e[1])
                if gz is None or cx is None or cz is None:
                    continue
                cols.extend(ground_column(cx, cz, gz, self.yoff))
        if cols:
            self.ground_cols += len(cols) // 4
            self.to_mc({"t": "ground", "c": cols})

    def _input(self, o):
        if not self.on or not self.mc_open():
            return
        if "k" in o and o["k"] in ("attack", "use", "pick", "drop", "swap", "inventory", "escape"):
            self.to_mc({"t": "key", "k": o["k"], "down": bool(o.get("down", True))})
        elif "slot" in o:
            n = int(_num(o.get("slot"), 0))
            if 0 <= n <= 8:
                self.to_mc({"t": "slot", "n": n})
        elif "scroll" in o:
            d = int(_num(o.get("scroll"), 0))
            if d:
                self.to_mc({"t": "scroll", "d": 1 if d > 0 else -1})

    def _pointer(self, o):
        """The GTA script's cursor while Minecraft's inventory is open: a position as a fraction of GTA's screen,
        plus a button (0 left, 1 right, 2 middle) going down/up, a wheel step, or a key (vk, inventory keys only)."""
        now = time.monotonic()
        if not self.on or not self.mc_open():
            self.mcwin.release_all(now)
            return
        self.mcwin.set_pid(self.mc_hello.get("pid"))
        if o.get("release"):
            self.mcwin.release_all(now)
            return
        if "vk" in o:
            self.mcwin.key(int(_num(o.get("vk"), 0)), bool(_num(o.get("down"), 1)), now)
            return
        nx, ny = _num(o.get("x")), _num(o.get("y"))
        if nx is None or ny is None:
            return
        nx, ny = min(1.0, max(0.0, nx)), min(1.0, max(0.0, ny))
        b = o.get("b")
        b = int(b) if isinstance(b, (int, float)) and not isinstance(b, bool) and int(b) in (0, 1, 2) else None
        down = bool(_num(o.get("down"), 0)) if b is not None else None
        w = int(_num(o.get("wheel"), 0) or 0)
        self.mcwin.pointer(nx, ny, now, button=b, down=down, wheel=w)

    def _send_view(self):
        if not self.view or not self.mc_open():
            return
        size = mc_view_size(self.view[0], self.view[1], self.view[2], int(self.opts["max_pixels"]), int(self.opts["fsr_scale"]))
        if size and size != self.view_sent:
            self.view_sent = size
            self.to_mc({"t": "view", "w": size[0], "h": size[1]})
            self.note("janela do Minecraft ajustada para %dx%d (imagem do GTA)" % size)

    # ---------------------------------------------------------------- from Minecraft
    def on_mc(self, text):
        try:
            m = json.loads(text)
        except ValueError:
            return
        if not isinstance(m, dict):
            return
        t = m.get("t")
        yoff = self.yoff
        if t == "hello":
            self.mc_hello = {"shm": m.get("shm"), "pid": m.get("pid"), "v": m.get("v")}
            self.note("Minecraft (passthrough) conectado, pid %s" % m.get("pid"))
        elif t == "explosion":
            p = _vec3(m.get("pos"))
            if p and self.opts["explosions"] and self.have_off:
                x, y, z = mc_to_gta(p[0], p[1], p[2], yoff)
                kind = explosion_kind(_num(m.get("r"), 4.0) or 4.0, m.get("src"))
                self.booms += 1
                self.to_gta({"type": "fusion_boom", "x": round(x, 2), "y": round(y, 2), "z": round(z, 2),
                             "kind": kind, "src": str(m.get("src") or "")[:24]})
                self.hub.add_event("minecraft", "explosao %s -> GTA (%.0f, %.0f, %.0f)" % (m.get("src") or "", x, y, z))
        elif t == "pteleport":
            p = _vec3(m.get("pos"))
            if p and self.opts["pearls"] and self.have_off:
                x, y, z = mc_to_gta(p[0], p[1], p[2], yoff)
                self.teleports += 1
                self.to_gta({"type": "fusion_teleport", "x": round(x, 2), "y": round(y, 2), "z": round(z + 1.0, 2)})
        elif t == "blocks":
            self._blocks(m)
        else:
            self.mc_ignored[str(t)] += 1

    def _blocks(self, m):
        def triples(v):
            v = v if isinstance(v, list) else []
            return [(int(v[i]), int(v[i + 1]), int(v[i + 2])) for i in range(0, len(v) - 2, 3)
                    if all(isinstance(v[i + k], (int, float)) for k in range(3))]
        set_, clear = triples(m.get("set")), triples(m.get("clear"))
        for b in clear:
            self.blocks.discard(b)
        for b in set_:
            self.blocks.add(b)
        if not self.opts["props"] or not self.have_off:
            return
        yoff = self.yoff
        if len(set_) > MAX_PROPS_TO_GTA:
            # a blocksync after a re-level reports thousands; the script builds walls in arrival order until it has
            # 150: send the nearest, nearest first
            pl = _vec3(self.last_cam.get("p")) if self.last_cam else None
            if pl:
                px, pz = pl[0], -pl[1]
                set_.sort(key=lambda b: (b[0] + 0.5 - px) ** 2 + (b[2] + 0.5 - pz) ** 2)
            set_ = set_[:MAX_PROPS_TO_GTA]

        def to_gta(b):
            x, y, z = mc_to_gta(b[0] + 0.5, b[1], b[2] + 0.5, yoff)
            return [round(x, 2), round(y, 2), round(z, 2)]
        out = {"type": "fusion_props", "set": [c for b in set_ for c in to_gta(b)],
               "clear": [c for b in clear for c in to_gta(b)]}
        if out["set"] or out["clear"]:
            self.to_gta(out)

    # ---------------------------------------------------------------- panel actions (queued from the HTTP thread)
    def submit(self, fn):
        self.actions.append(fn)

    def set_on(self, on):
        self.on = bool(on)
        self.note("fusao " + ("LIGADA" if self.on else "desligada"))
        if self.on:
            self.relevel("fusao ligada")
        self.push_state()
        self.to_gta({"type": "fusion_notify", "text": "FusionBridge: fusao " + ("ligada" if self.on else "desligada")})

    def set_mouse(self, mode):
        if mode in ("mc", "gta"):
            self.mouse = mode
            self._save()
            self.push_state()
            self.to_gta({"type": "fusion_notify",
                         "text": "Mouse: " + ("Minecraft (blocos e itens)" if mode == "mc" else "GTA (armas do CJ)")})

    def _valid(self, k, v):
        """An option value of the right type and range (from the app or the settings file)."""
        cur = DEFAULT_OPTS[k]
        if isinstance(cur, bool):
            return bool(v)
        if isinstance(cur, int):
            v = int(v)
            if k == "radius":
                return max(8, min(64, v))
            if k == "probes":
                return max(8, min(256, v))
            if k == "max_pixels":
                return max(320 * 240, min(3840 * 2160, v))
            if k == "fsr_scale":
                return v if v in FSR_SCALES else cur
            if k == "fsr_sharp":
                return max(0, min(200, v))
        return v

    def set_opts(self, **kw):
        changed = False
        for k, v in kw.items():
            if k not in self.opts or v is None:
                continue
            cur = self.opts[k]
            v = self._valid(k, v)
            if v != cur:
                self.opts[k] = v
                changed = True
                if k == "props" and not v:
                    self.to_gta({"type": "fusion_props", "clear_all": 1})
                if k in ("max_pixels", "fsr_scale"):
                    self.view_sent = None
                    self._send_view()
                if k == "radius":
                    self.relevel("raio do chao mudou")
        if changed:
            self._save()
            self.push_state()
        return changed

    def mc_commands(self, cmds):
        sent = 0
        for c in cmds:
            if self.to_mc({"t": "cmd", "c": c}):
                sent += 1
        return sent

    # ---------------------------------------------------------------- hub loop hooks
    def register(self, sel, selectors_mod):
        if self.ws.sock and not self.registered:
            sel.register(self.ws.sock, selectors_mod.EVENT_READ, "mclink")
            self.registered = True

    def unregister(self, sel):
        if self.registered:
            try:
                sel.unregister(self.ws.sock)
            except Exception:
                pass
            self.registered = False

    def mc_closed(self, sel):
        self.mcwin.release_all(time.monotonic())
        self.mcwin.set_pid(None)
        self.unregister(sel)
        if self.mc_hello:
            self.note("link com o Minecraft caiu (%s); tentando de novo" % (self.ws.error or "?"))
        self.ws.close()
        self.mc_hello = {}
        self.view_sent = None
        self.in_vehicle = None
        self.next_connect = time.monotonic() + 2.0
        self.push_state()

    def on_readable(self, sel):
        msgs = self.ws.on_readable()
        if msgs is None:
            self.mc_closed(sel)
            return
        was_open = bool(self.mc_hello)
        for m in msgs:
            self.on_mc(m)
        if self.mc_hello and not was_open:
            # (re)connected: level the ground again, size Minecraft's window, tell GTA
            self.relevel("Minecraft conectado")
            self._send_view()
            self.push_state()
        self.ws.flush()

    def _connect_thread(self):
        try:
            self.connected_sock = self.ws.open_socket(2.0)
        finally:
            self.connecting = False

    def tick(self, sel, selectors_mod, now):
        while self.actions:
            try:
                self.actions.popleft()()
            except Exception as e:
                self.hub.log("[Fusao] acao falhou: %s" % e)
        if not self.hub.want:
            if self.ws.sock:
                self.mc_closed(sel)
            return
        if self.connected_sock is not None:
            s, self.connected_sock = self.connected_sock, None
            if self.hub.want and self.ws.sock is None and self.ws.adopt(s):
                self.register(sel, selectors_mod)
            else:
                s.close()
        elif self.ws.sock is None and not self.connecting and now >= self.next_connect:
            self.next_connect = now + 2.0
            self.connecting = True
            threading.Thread(target=self._connect_thread, daemon=True).start()
        if self.ws.sock and self.ws.state == "handshake" and now - self.ws.since > 5.0:
            self.ws.error = "sem resposta do handshake"
            self.mc_closed(sel)
        if self.ws.sock:
            if not self.ws.flush():
                self.mc_closed(sel)
        # automatic re-level: the ground under CJ is off a block boundary (or out of the height band) and
        # nothing is built nearby (a re-level clears Minecraft's ground)
        if (self.opts["auto_level"] and self.on and self.have_off and self.last_pg is not None
                and now >= self.next_autolevel and self.last_cam):
            self.next_autolevel = now + 1.5
            mc = self.last_pg + self.yoff
            frac, shift = level_offset(self.last_pg)
            if abs(mc - math.floor(mc + 0.5)) >= 0.08 or shift != self.shift:
                pl = _vec3(self.last_cam.get("p"))
                near = False
                if pl:
                    px, pz = math.floor(pl[0]), math.floor(-pl[1])
                    near = any((b[0] - px) ** 2 + (b[2] - pz) ** 2 < 24 * 24 for b in self.blocks)
                if not near:
                    self.relevel("auto")
        if now >= self.next_state:
            self.next_state = now + 1.0
            self.push_state()
        if now - self.rate_t >= 1.0:
            self.cam_rate = self.cam_count / (now - self.rate_t)
            self.cam_count, self.rate_t = 0, now
            self.frames.poll(now)
        if now >= self.next_pub:
            self.next_pub = now + 0.25
            self._refresh_pub()

    def _refresh_pub(self):
        cam = self.last_cam or {}
        self.pub = {
            "on": self.on, "mouse": self.mouse, "opts": dict(self.opts),
            "mc": {"state": self.ws.state, "hello": dict(self.mc_hello), "rx": self.ws.rx, "tx": self.ws.tx,
                   "dropped": self.ws.dropped, "error": self.ws.error, "port": MC_PORT},
            "frames": {"present": self.frames.present, "fps": round(self.frames.fps, 1),
                       "w": self.frames.size[0], "h": self.frames.size[1], "supported": self.frames.ok},
            "gta": {"connected": self.gta() is not None, "cam_hz": round(self.cam_rate, 1),
                    "cam": cam.get("c"), "fov": cam.get("fov"), "veh": cam.get("veh"), "asi": dict(self.asi)},
            "level": {"have": self.have_off, "yoff": round(self.yoff, 4), "shift": self.shift,
                      "ground_cols": self.ground_cols, "blocks": len(self.blocks)},
            "view": list(self.view_sent) if self.view_sent else None,
            "gta_view": [int(self.view[0]), int(self.view[1])] if self.view else None,
            "booms": self.booms, "teleports": self.teleports,
            "notes": [{"age_s": int(time.time() - n["t"]), "text": n["text"]} for n in self.notes],
        }
