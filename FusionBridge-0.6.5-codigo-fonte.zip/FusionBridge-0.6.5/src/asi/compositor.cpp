// Adapted from the MIT "Minecraft x GTA V passthrough" compositor (rehan-remade/universal-modder),
// Copyright (c) 2026 Rehan and universal-modder contributors (MIT: mod/LICENSE-passthrough-MIT.txt, THIRD-PARTY-NOTICES.md),
// for GTA SA:
// 32-bit process, Direct3D 9, the camera read straight from RenderWare, shared memory mapped per slot (a 32-bit
// process can't map the whole ~300 MB export), and the effect rendered before GTA's HUD.
#include "compositor.h"
#include "camera_math.h"
#include "sa.h"
#include "watchdog.h"
#include <d3d9.h>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <initializer_list>
#include <reshade.hpp>

using namespace reshade::api;

namespace
{
	constexpr const wchar_t *kMappingName = L"Local\\MCPassthroughFrame";
	constexpr uint32_t kMagic = 0x5450434D; // "MCPT"
	constexpr int kHeader = 4096;
	constexpr int kSlotDesc = 256;
	constexpr int kSlotDescBytes = 128;
	constexpr int kMaxSlots = 8;
	constexpr DWORD kStaleMs = 1500;        // no new Minecraft frame for this long: stop compositing
	constexpr DWORD kHeartbeatMs = 500;     // the GTA script calls set_fusion every frame
	constexpr const char *kEffect = "FusionBridgeSA.fx";

	std::atomic<bool> g_registered{false};
	std::atomic<bool> g_composite{false};
	std::atomic<bool> g_hudHook{false};
	std::atomic<DWORD> g_heartbeat{0};
	std::atomic<float> g_yoff{0.0f};
	std::atomic<uint32_t> g_bbWidth{0}, g_bbHeight{0};
	std::atomic<int> g_uploads{0}, g_early{0};
	std::atomic<bool> g_effectFound{false};
	std::atomic<bool> g_fsrOn{true};
	std::atomic<float> g_fsrSharp{0.2f};
	effect_runtime *g_runtime = nullptr;

	HANDLE g_mapping = nullptr;
	const uint8_t *g_header = nullptr;
	int32_t g_slots = 0;
	int64_t g_stride = 0;
	DWORD g_nextOpenAttempt = 0;
	struct SlotView
	{
		void *base = nullptr;
		const uint8_t *data = nullptr;
		uint64_t offset = 0;
		size_t size = 0;
	} g_views[kMaxSlots];
	int64_t g_lastPublish = -1;
	DWORD g_lastPublishTick = 0;

	struct Layer
	{
		resource tex = {0};
		resource_view srv = {0};
		bool dynamic = false; // locked with DISCARD; otherwise filled through ReShade's upload texture
	};
	Layer g_world, g_depth, g_overlay;
	uint32_t g_width = 0, g_height = 0;
	bool g_hasFrame = false;
	float g_mcNear = 0.05f, g_mcFar = 1024.0f;
	int32_t g_mcFlags = 7;
	fbmath::McPose g_mcPose = {};
	bool g_mcPoseValid = false;

	enum
	{
		uMcActive,
		uMcPlanes,
		uHostPlanes,
		uHostAspect,
		uWarpRow0,
		uWarpRow1,
		uWarpRow2,
		uWarpT,
		uWarpTan,
		uMcSize,
		uFsrEnable,
		uFsrSharp,
		uCount
	};
	const char *const kUniformNames[uCount] = {"McActive", "McPlanes", "HostPlanes", "HostAspect", "WarpRow0", "WarpRow1", "WarpRow2", "WarpT", "WarpTan",
		"McSize", "FsrEnable", "FsrSharpness"};
	effect_uniform_variable g_uniforms[uCount] = {};
	bool g_uniformsLooked = false;

	template <typename T>
	T read(const uint8_t *p)
	{
		T v;
		std::memcpy(&v, p, sizeof(T));
		return v;
	}

	/// effect_runtime::find_uniform_variable returns a struct. ReShade is built with MSVC, which returns structs
	/// from member functions through a hidden pointer; GCC would expect them in registers. So when built with
	/// MinGW, call that one vtable slot with MSVC's convention spelled out (the vtable index comes from the
	/// member pointer, and both compilers lay out this interface the same: no overloads, no virtual destructor).
	effect_uniform_variable find_uniform(effect_runtime *rt, const char *effect, const char *name)
	{
#if defined(__GNUC__) && defined(__i386__)
		typedef effect_uniform_variable *(__attribute__((thiscall)) * Fn)(const effect_runtime *, effect_uniform_variable *, const char *, const char *);
		static const size_t index = [] {
			auto pmf = &effect_runtime::find_uniform_variable;
			uintptr_t raw[2] = {};
			static_assert(sizeof(pmf) == sizeof(raw), "unexpected member pointer size");
			std::memcpy(raw, &pmf, sizeof(raw));
			return size_t((raw[0] - 1) / sizeof(void *)); // virtual: offset in the vtable + 1
		}();
		void **vtbl = *reinterpret_cast<void ***>(rt);
		effect_uniform_variable out = {0};
		reinterpret_cast<Fn>(vtbl[index])(rt, &out, effect, name);
		return out;
#else
		return rt->find_uniform_variable(effect, name);
#endif
	}

	effect_uniform_variable uniform(effect_runtime *rt, int which)
	{
		if (!g_uniformsLooked)
		{
			for (int i = 0; i < uCount; ++i)
				g_uniforms[i] = find_uniform(rt, kEffect, kUniformNames[i]);
			g_uniformsLooked = true;
			g_effectFound = g_uniforms[uMcActive].handle != 0;
		}
		return g_uniforms[which];
	}

	void set_float(effect_runtime *rt, int which, float x, float y = 0.0f, float z = 0.0f)
	{
		const effect_uniform_variable v = uniform(rt, which);
		if (v.handle == 0)
			return;
		const float values[3] = {x, y, z};
		rt->set_uniform_value_float(v, values, 3);
	}

	void set_float1(effect_runtime *rt, int which, float x)
	{
		const effect_uniform_variable v = uniform(rt, which);
		if (v.handle != 0)
			rt->set_uniform_value_float(v, &x, 1);
	}

	void close_views()
	{
		for (SlotView &v : g_views)
		{
			if (v.base)
				UnmapViewOfFile(v.base);
			v = SlotView();
		}
	}

	bool open_mapping()
	{
		if (g_header != nullptr)
			return true;
		if (GetTickCount() < g_nextOpenAttempt)
			return false;
		g_nextOpenAttempt = GetTickCount() + 1000;
		g_mapping = OpenFileMappingW(FILE_MAP_READ, FALSE, kMappingName);
		if (g_mapping == nullptr)
			return false;
		const auto *header = static_cast<const uint8_t *>(MapViewOfFile(g_mapping, FILE_MAP_READ, 0, 0, kHeader));
		if (header == nullptr || read<uint32_t>(header) != kMagic)
		{
			if (header != nullptr)
				UnmapViewOfFile(header);
			CloseHandle(g_mapping);
			g_mapping = nullptr;
			return false;
		}
		g_slots = read<int32_t>(header + 12);
		g_stride = read<int64_t>(header + 16);
		if (g_slots <= 0 || g_slots > kMaxSlots || g_stride <= 0)
		{
			UnmapViewOfFile(header);
			CloseHandle(g_mapping);
			g_mapping = nullptr;
			return false;
		}
		g_header = header;
		reshade::log::message(reshade::log::level::info, "FusionBridgeSA: connected to Minecraft's frame export");
		return true;
	}

	/// A read-only view of `bytes` of slot `slot`'s data (offsets must be aligned to the allocation granularity).
	const uint8_t *slot_data(int slot, size_t bytes)
	{
		SlotView &v = g_views[slot];
		const uint64_t offset = uint64_t(kHeader) + uint64_t(g_stride) * uint64_t(slot);
		if (v.base != nullptr && v.offset == offset && v.size >= bytes)
			return v.data;
		if (v.base != nullptr)
			UnmapViewOfFile(v.base);
		v = SlotView();
		SYSTEM_INFO si;
		GetSystemInfo(&si);
		const uint64_t gran = si.dwAllocationGranularity ? si.dwAllocationGranularity : 65536;
		const uint64_t aligned = offset / gran * gran;
		const size_t delta = size_t(offset - aligned);
		void *base = MapViewOfFile(g_mapping, FILE_MAP_READ, DWORD(aligned >> 32), DWORD(aligned & 0xFFFFFFFFu), delta + bytes);
		if (base == nullptr)
			return nullptr;
		v.base = base;
		v.data = static_cast<const uint8_t *>(base) + delta;
		v.offset = offset;
		v.size = bytes;
		return v.data;
	}

	void destroy_layers(device *dev)
	{
		for (Layer *layer : {&g_world, &g_depth, &g_overlay})
		{
			if (layer->srv.handle != 0)
				dev->destroy_resource_view(layer->srv);
			if (layer->tex.handle != 0)
				dev->destroy_resource(layer->tex);
			*layer = Layer();
		}
		g_width = g_height = 0;
		g_hasFrame = false;
	}

	bool create_layer(device *dev, Layer &layer, uint32_t w, uint32_t h, format fmt)
	{
		const resource_usage usage = resource_usage::shader_resource | resource_usage::copy_dest;
		// dynamic textures are written in place (no temporary upload texture per frame); not every GPU has them
		layer.dynamic = dev->create_resource(resource_desc(w, h, 1, 1, fmt, 1, memory_heap::upload, usage, resource_flags::dynamic),
			nullptr, resource_usage::shader_resource, &layer.tex);
		if (!layer.dynamic && !dev->create_resource(resource_desc(w, h, 1, 1, fmt, 1, memory_heap::default_, usage),
				nullptr, resource_usage::shader_resource, &layer.tex))
			return false;
		return dev->create_resource_view(layer.tex, resource_usage::shader_resource, resource_view_desc(fmt), &layer.srv);
	}

	void bind(effect_runtime *runtime)
	{
		runtime->update_texture_bindings("MCWORLD", g_world.srv, g_world.srv);
		runtime->update_texture_bindings("MCDEPTH", g_depth.srv, g_depth.srv);
		runtime->update_texture_bindings("MCOVERLAY", g_overlay.srv, g_overlay.srv);
	}

	/// ReShade keeps semantic bindings across effect reloads and device resets and binds them again: point them at
	/// its empty texture before ours are freed, or it would sample (and query) freed textures.
	void release_layers(device *dev, effect_runtime *runtime)
	{
		if (runtime != nullptr && g_width != 0)
		{
			for (const char *semantic : {"MCWORLD", "MCDEPTH", "MCOVERLAY"})
				runtime->update_texture_bindings(semantic, resource_view{0}, resource_view{0});
		}
		destroy_layers(dev);
	}

	/// One Minecraft layer into its texture. A dynamic texture is locked with DISCARD: the driver hands out fresh
	/// memory instead of waiting for the GPU to finish with the last frame (ReShade's own upload locks without it,
	/// a full CPU/GPU sync per layer per frame). ReShade's D3D9 backend stores r8g8b8a8 as A8R8G8B8, so colour
	/// layers are flipped RGBA -> BGRA on the way, as its upload does.
	void write_layer(device *dev, Layer &layer, const uint8_t *src, uint32_t w, uint32_t h, bool rgba)
	{
		subresource_data mapped;
		if (layer.dynamic && dev->map_texture_region(layer.tex, 0, nullptr, map_access::write_discard, &mapped) && mapped.data != nullptr)
		{
			for (uint32_t y = 0; y < h; ++y)
			{
				auto *dst = static_cast<uint8_t *>(mapped.data) + size_t(y) * mapped.row_pitch;
				const uint8_t *row = src + size_t(y) * w * 4;
				if (!rgba)
				{
					std::memcpy(dst, row, size_t(w) * 4);
					continue;
				}
				for (uint32_t x = 0; x < w; ++x)
				{
					uint32_t v;
					std::memcpy(&v, row + size_t(x) * 4, 4);
					v = (v & 0xFF00FF00u) | ((v >> 16) & 0xFFu) | ((v & 0xFFu) << 16);
					std::memcpy(dst + size_t(x) * 4, &v, 4);
				}
			}
			dev->unmap_texture_region(layer.tex, 0);
			return;
		}
		subresource_data data;
		data.data = const_cast<uint8_t *>(src);
		data.row_pitch = w * 4;
		data.slice_pitch = w * h * 4;
		dev->update_texture_region(data, layer.tex, 0);
	}

	/// Upload the newest published Minecraft frame, if there is one we haven't shown yet.
	void upload(effect_runtime *runtime)
	{
		const int64_t published = read<int64_t>(g_header + 32);
		if (published == g_lastPublish)
			return;
		const int32_t slot = read<int32_t>(g_header + 40);
		if (slot < 0 || slot >= g_slots)
			return;
		const uint8_t *desc = g_header + kSlotDesc + kSlotDescBytes * slot;
		const int64_t seq = read<int64_t>(desc);
		if (seq & 1)
			return;
		const uint32_t w = read<uint32_t>(desc + 24), h = read<uint32_t>(desc + 28);
		if (w == 0 || h == 0 || w > 8192 || h > 8192 || uint64_t(w) * h * 12 > uint64_t(g_stride))
			return;
		const size_t layer = size_t(w) * h * 4;
		const uint8_t *base = slot_data(slot, layer * 3);
		if (base == nullptr)
			return;
		device *dev = runtime->get_device();
		if (w != g_width || h != g_height)
		{
			watchdog::stage(watchdog::kCreateTextures);
			release_layers(dev, runtime);
			if (!create_layer(dev, g_world, w, h, format::r8g8b8a8_unorm) ||
				!create_layer(dev, g_depth, w, h, format::r32_float) ||
				!create_layer(dev, g_overlay, w, h, format::r8g8b8a8_unorm))
			{
				destroy_layers(dev);
				reshade::log::message(reshade::log::level::error, "FusionBridgeSA: could not create the Minecraft textures");
				return;
			}
			g_width = w;
			g_height = h;
			bind(runtime);
		}
		watchdog::stage(watchdog::kUpload);
		write_layer(dev, g_world, base, w, h, true);
		write_layer(dev, g_depth, base + layer, w, h, false);
		write_layer(dev, g_overlay, base + 2 * layer, w, h, true);
		if (read<int64_t>(desc) != seq)
			return; // Minecraft rewrote the slot mid-copy: show the next one instead
		g_lastPublish = published;
		g_lastPublishTick = GetTickCount();
		g_mcNear = read<float>(desc + 32);
		g_mcFar = read<float>(desc + 36);
		g_mcFlags = read<int32_t>(desc + 44);
		g_mcPose.fov = read<float>(desc + 40);
		g_mcPose.yaw = read<float>(desc + 72);
		g_mcPose.pitch = read<float>(desc + 76);
		g_mcPose.roll = read<float>(desc + 80);
		g_mcPose.x = read<double>(desc + 48);
		g_mcPose.y = read<double>(desc + 56);
		g_mcPose.z = read<double>(desc + 64);
		g_mcPoseValid = true;
		g_hasFrame = true;
		++g_uploads;
	}

	bool want_composite()
	{
		return g_composite.load() && GetTickCount() - g_heartbeat.load() < kHeartbeatMs && !sa::menu_active();
	}

	bool frame_fresh()
	{
		return g_hasFrame && GetTickCount() - g_lastPublishTick < kStaleMs;
	}

	/// Reload FusionBridgeSA.fx when the file changes (ReShade doesn't watch it), so tweaks don't need a restart.
	void watch_effect_file(effect_runtime *runtime)
	{
		static DWORD next = 0;
		static FILETIME last = {};
		static wchar_t path[MAX_PATH] = {};
		if (GetTickCount() < next)
			return;
		next = GetTickCount() + 1000;
		if (path[0] == 0)
		{
			GetModuleFileNameW(nullptr, path, MAX_PATH);
			wchar_t *slash = wcsrchr(path, L'\\');
			if (slash)
				lstrcpynW(slash + 1, L"reshade-shaders\\Shaders\\FusionBridgeSA.fx", int(MAX_PATH - (slash + 1 - path)));
		}
		WIN32_FILE_ATTRIBUTE_DATA info;
		if (!GetFileAttributesExW(path, GetFileExInfoStandard, &info))
			return;
		if (last.dwLowDateTime != 0 && CompareFileTime(&info.ftLastWriteTime, &last) != 0)
			runtime->reload_effect_next_frame(kEffect);
		last = info.ftLastWriteTime;
	}

	void on_init_runtime(effect_runtime *runtime)
	{
		g_runtime = runtime;
		g_uniformsLooked = false;
	}

	void on_present(effect_runtime *runtime)
	{
		watchdog::beat();
		watchdog::stage(watchdog::kIdle); // ReShade's effects for this frame are done
		g_runtime = runtime;
		watch_effect_file(runtime); // every frame, even when the effect failed to compile
	}

	void on_begin_effects(effect_runtime *runtime, command_list *, resource_view, resource_view)
	{
		g_runtime = runtime;
		uint32_t bw = 0, bh = 0;
		runtime->get_screenshot_width_and_height(&bw, &bh);
		g_bbWidth = bw;
		g_bbHeight = bh;
		watchdog::stage(watchdog::kOpenMapping);
		bool on = want_composite() && open_mapping();
		if (on)
			upload(runtime);
		watchdog::stage(watchdog::kBeginEffects);
		on = on && frame_fresh();
		// The technique stays enabled (preset); McActive gates it, so GTA passes through untouched until a fresh
		// Minecraft frame is here. (Toggling techniques from inside this callback crashes ReShade.)
		const effect_uniform_variable active = uniform(runtime, uMcActive);
		if (active.handle != 0)
		{
			const bool value = on;
			runtime->set_uniform_value_bool(active, &value, 1);
		}
		if (!on)
			return;
		set_float(runtime, uMcPlanes, g_mcNear, g_mcFar, float(g_mcFlags));
		// FSR 1.0 (the app's choice): Minecraft's frame size, on/off and RCAS sharpness
		set_float(runtime, uMcSize, float(g_width), float(g_height), 0.0f);
		const effect_uniform_variable fsr = uniform(runtime, uFsrEnable);
		if (fsr.handle != 0)
		{
			const bool fsrOn = g_fsrOn.load();
			runtime->set_uniform_value_bool(fsr, &fsrOn, 1);
		}
		set_float1(runtime, uFsrSharp, g_fsrSharp.load());

		// GTA's camera for this very frame (RenderWare's), turned into Minecraft's convention: Minecraft's frame is
		// re-projected from the pose it was rendered with to this one (hides the link's latency)
		sa::Camera cam;
		const bool haveCam = sa::read_camera(cam);
		fbmath::McPose host = g_mcPose;
		float hostTanY = std::tan(g_mcPose.fov / fbmath::kDeg * 0.5f), hostAspect = 0.0f;
		if (haveCam)
		{
			const fbmath::Angles a = fbmath::angles_from_vectors(cam.fwd, cam.up);
			const float vfov = 2.0f * std::atan(cam.tan_y) * fbmath::kDeg;
			host = fbmath::mc_pose(cam.pos, a, vfov, g_yoff.load());
			hostTanY = cam.tan_y;
			hostAspect = cam.tan_x / cam.tan_y;
			set_float(runtime, uHostPlanes, cam.near_z, cam.far_z);
		}
		set_float1(runtime, uHostAspect, hostAspect);
		float m[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
		float t[3] = {0, 0, 0};
		if (haveCam && g_mcPoseValid)
		{
			fbmath::warp_matrix(host, g_mcPose, m);
			fbmath::warp_translation(host, g_mcPose, t);
		}
		set_float(runtime, uWarpRow0, m[0][0], m[0][1], m[0][2]);
		set_float(runtime, uWarpRow1, m[1][0], m[1][1], m[1][2]);
		set_float(runtime, uWarpRow2, m[2][0], m[2][1], m[2][2]);
		set_float(runtime, uWarpT, t[0], t[1], t[2]);
		const float tanMc = std::tan(g_mcPose.fov / fbmath::kDeg * 0.5f);
		set_float(runtime, uWarpTan, hostTanY, tanMc, float(g_width) / float(g_height ? g_height : 1));
	}

	void on_reloaded_effects(effect_runtime *runtime)
	{
		g_uniformsLooked = false;
		if (g_width != 0)
			bind(runtime);
	}

	void on_destroy_runtime(effect_runtime *runtime)
	{
		release_layers(runtime->get_device(), runtime);
		g_uniformsLooked = false;
		g_lastPublish = -1;
		if (g_runtime == runtime)
			g_runtime = nullptr;
	}

	/// IDirect3DDevice9::Reset (alt-tab, resolution change) fails while any D3DPOOL_DEFAULT texture is alive, and
	/// GTA SA then retries forever: the window hangs ("Nao foi possivel restaurar gta_sa.exe"). ReShade resets its
	/// effect runtime first (on_destroy_runtime above); free the Minecraft textures here too, so nothing of ours is
	/// left whatever the order. They come back with the next Minecraft frame.
	void on_destroy_swapchain(swapchain *chain, bool)
	{
		release_layers(chain->get_device(), g_runtime);
		g_lastPublish = -1;
	}

	void on_destroy_device(device *dev)
	{
		destroy_layers(dev);
		g_lastPublish = -1;
		g_runtime = nullptr;
	}
}

namespace compositor
{
	bool try_register(HMODULE module)
	{
		if (g_registered)
			return true;
		// looking for ReShade walks every loaded module: at most once a second while it isn't there
		static DWORD last = 0;
		static bool tried = false;
		const DWORD now = GetTickCount();
		if (tried && now - last < 1000)
			return false;
		tried = true;
		last = now;
		if (!reshade::register_addon(module))
			return false;
		reshade::register_event<reshade::addon_event::init_effect_runtime>(on_init_runtime);
		reshade::register_event<reshade::addon_event::reshade_begin_effects>(on_begin_effects);
		reshade::register_event<reshade::addon_event::reshade_present>(on_present);
		reshade::register_event<reshade::addon_event::reshade_reloaded_effects>(on_reloaded_effects);
		reshade::register_event<reshade::addon_event::destroy_effect_runtime>(on_destroy_runtime);
		reshade::register_event<reshade::addon_event::destroy_swapchain>(on_destroy_swapchain);
		reshade::register_event<reshade::addon_event::destroy_device>(on_destroy_device);
		g_registered = true;
		reshade::log::message(reshade::log::level::info, "FusionBridgeSA: registered (Minecraft no GTA SA)");
		return true;
	}

	void unregister(HMODULE module, bool process_exit)
	{
		// at process exit ReShade (loaded after us) has already been torn down: calling it would crash on the way out
		if (g_registered.exchange(false) && !process_exit)
			reshade::unregister_addon(module);
		close_views();
		if (g_header)
			UnmapViewOfFile(g_header);
		if (g_mapping)
			CloseHandle(g_mapping);
		g_header = nullptr;
		g_mapping = nullptr;
	}

	void set_fusion(bool composite, float yoff)
	{
		g_composite = composite;
		g_yoff = yoff;
		g_heartbeat = GetTickCount();
	}

	void set_hud_hook(bool installed)
	{
		g_hudHook = installed;
	}

	void set_fsr(bool on, float sharpness)
	{
		g_fsrOn = on;
		g_fsrSharp = std::isfinite(sharpness) ? (sharpness < 0.0f ? 0.0f : (sharpness > 2.0f ? 2.0f : sharpness)) : 0.2f;
	}


	void render_before_hud()
	{
		effect_runtime *runtime = g_runtime;
		if (!g_registered || runtime == nullptr || !want_composite() || !frame_fresh())
			return;
		device *dev = runtime->get_device();
		if (dev == nullptr || dev->get_api() != device_api::d3d9)
			return;
		auto *d3d = reinterpret_cast<IDirect3DDevice9 *>(static_cast<uintptr_t>(dev->get_native()));
		// lost (minimized, alt-tab) or waiting for Reset: draw nothing until GTA has its device back
		if (d3d == nullptr || d3d->TestCooperativeLevel() != D3D_OK)
			return;
		IDirect3DSurface9 *rt = nullptr, *bb = nullptr;
		d3d->GetRenderTarget(0, &rt);
		d3d->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb);
		// only when GTA is drawing straight into the back buffer (otherwise ReShade renders at present as usual).
		// Outside Present, render_effects captures and restores the whole device state itself (D3DSBT_ALL state
		// block, render targets, depth-stencil, viewport: ReShade's state_block::capture), so RenderWare's cached
		// state stays right and the HUD draws as usual.
		if (rt != nullptr && rt == bb)
		{
			command_list *cmd = runtime->get_command_queue()->get_immediate_command_list();
			resource_view rtv = {static_cast<uint64_t>(reinterpret_cast<uintptr_t>(rt))};
			watchdog::stage(watchdog::kRenderEffects);
			runtime->render_effects(cmd, rtv, resource_view{0});
			watchdog::stage(watchdog::kHud);
			++g_early;
		}
		if (rt)
			rt->Release();
		if (bb)
			bb->Release();
	}

	void status(int *out)
	{
		out[0] = g_registered ? 1 : 0;
		out[1] = frame_fresh() ? 1 : 0;
		out[2] = int(g_bbWidth.load());
		out[3] = int(g_bbHeight.load());
		out[4] = g_uploads.load();
		out[5] = g_effectFound ? 1 : 0;
		out[6] = int(g_width);
		out[7] = int(g_height);
		out[8] = g_early.load();
		out[9] = g_hudHook ? 1 : 0;
	}
}
