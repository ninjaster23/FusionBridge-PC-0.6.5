#!/usr/bin/env python3
r"""Builds FusionBridge.exe: the official, signed Python runtime (python.org's NuGet package, by the Python Software
Foundation) set up to run the FusionBridge app in app/.

Why: Windows' Smart App Control only lets programs run when they are signed by a trusted publisher (or have a
good reputation). A freshly compiled .exe can't be. So FusionBridge.exe IS python.org's pythonw.exe, unchanged
(same bytes, same PSF signature), next to a FusionBridge._pth that points it at runtime\ and app\; Python then
imports app\sitecustomize.py, which opens the FusionBridge window. Every .exe/.dll/.pyd shipped is signed by the
Python Software Foundation or Microsoft; our own code is .py files run by that interpreter.

usage: python3 tools/build_app.py [--cache DIR] [--out PACKAGE_ROOT]
The package root must already contain app/ (the code). Runs on Linux or Windows; no compiler needed.
"""
import argparse
import hashlib
import io
import os
import py_compile
import shutil
import sys
import tempfile
import urllib.request
import zipfile

PY_VERSION = "3.13.16"
NUPKG_SHA256 = "95fad176338f1d6a799e45946488063f4aa61764e6cff2f132ddeffbf7a04c34"
NUPKG_URL = "https://api.nuget.org/v3-flatcontainer/python/{v}/python.{v}.nupkg"
TAG = "313"   # python313.dll / python313.zip

ROOT_FILES = {                       # next to FusionBridge.exe (the loader needs them there)
    "tools/pythonw.exe": "FusionBridge.exe",
    "tools/python%s.dll" % TAG: "python%s.dll" % TAG,
    "tools/python3.dll": "python3.dll",
    "tools/vcruntime140.dll": "vcruntime140.dll",
    "tools/vcruntime140_1.dll": "vcruntime140_1.dll",
}
RUNTIME_DLLS = [                     # extension modules the app uses, and the DLLs they load
    "_ctypes.pyd", "libffi-8.dll",                        # ctypes: the window, the registry, file dialogs
    "_socket.pyd", "select.pyd",                          # the hub and the Minecraft link
    "_ssl.pyd", "libssl-3.dll", "libcrypto-3.dll",        # HTTPS downloads (ReShade, Fabric API, shaders)
    "_hashlib.pyd",                                       # SHA-256 checks
    "_queue.pyd", "unicodedata.pyd",                      # threads; IDNA host names
    "pyexpat.pyd", "_elementtree.pyd",                    # Code Integrity event log (XML)
    "_bz2.pyd", "_lzma.pyd",                              # zipfile (ReShade's setup archive)
]
STDLIB_SKIP = {"test", "idlelib", "tkinter", "turtledemo", "ensurepip", "site-packages", "lib2to3", "venv",
               "pydoc_data", "__phello__", "__pycache__", "unittest", "sqlite3", "lib-dynload", "curses", "dbm"}
PTH = "runtime\\python%s.zip\r\nruntime\r\napp\r\nimport site\r\n" % TAG


def fetch(cache):
    os.makedirs(cache, exist_ok=True)
    path = os.path.join(cache, "python.%s.nupkg" % PY_VERSION)
    if not os.path.exists(path):
        url = NUPKG_URL.format(v=PY_VERSION)
        print("baixando", url)
        with urllib.request.urlopen(url, timeout=120) as r, open(path + ".part", "wb") as f:
            shutil.copyfileobj(r, f)
        os.replace(path + ".part", path)
    h = hashlib.sha256(open(path, "rb").read()).hexdigest()
    if h != NUPKG_SHA256:
        raise SystemExit("SHA-256 do pacote do Python nao confere (%s). Apague %s e tente de novo." % (h, path))
    return path


def build_stdlib_zip(nupkg, out_zip):
    """The standard library, minus what the app never uses; compiled to .pyc when this Python matches."""
    compile_ok = sys.version_info[:2] == (int(TAG[0]), int(TAG[1:]))
    with zipfile.ZipFile(nupkg) as src, zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as dst, \
            tempfile.TemporaryDirectory() as tmp:
        for info in src.infolist():
            name = info.filename
            if not name.startswith("tools/Lib/") or not name.endswith(".py"):
                continue
            rel = name[len("tools/Lib/"):]
            if set(rel.split("/")[:-1]) & STDLIB_SKIP:
                continue
            data = src.read(info)
            if compile_ok:
                py = os.path.join(tmp, "m.py")
                with open(py, "wb") as f:
                    f.write(data)
                pyc = os.path.join(tmp, "m.pyc")
                py_compile.compile(py, cfile=pyc, dfile=rel, doraise=True,
                                   invalidation_mode=py_compile.PycInvalidationMode.UNCHECKED_HASH)
                dst.writestr(rel[:-3] + ".pyc", open(pyc, "rb").read())
            else:
                dst.writestr(rel, data)
    return compile_ok


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", default=os.path.join(here, "..", "_build_cache"))
    ap.add_argument("--out", default=os.path.join(here, ".."))
    a = ap.parse_args()
    out = os.path.abspath(a.out)
    if not os.path.isdir(os.path.join(out, "app")):
        raise SystemExit("app/ nao encontrado em " + out)
    nupkg = fetch(a.cache)
    runtime = os.path.join(out, "runtime")
    os.makedirs(runtime, exist_ok=True)
    with zipfile.ZipFile(nupkg) as z:
        for src, dst in ROOT_FILES.items():
            with z.open(src) as f, open(os.path.join(out, dst), "wb") as o:
                shutil.copyfileobj(f, o)
        for name in RUNTIME_DLLS:
            with z.open("tools/DLLs/" + name) as f, open(os.path.join(runtime, name), "wb") as o:
                shutil.copyfileobj(f, o)
        with z.open("tools/LICENSE.txt") as f, open(os.path.join(runtime, "LICENSE-Python.txt"), "wb") as o:
            shutil.copyfileobj(f, o)
    compiled = build_stdlib_zip(nupkg, os.path.join(runtime, "python%s.zip" % TAG))
    with open(os.path.join(out, "FusionBridge._pth"), "w", newline="") as f:
        f.write(PTH)
    print("FusionBridge.exe pronto (Python %s oficial, %s)" % (PY_VERSION, "stdlib compilada" if compiled else "stdlib .py"))


if __name__ == "__main__":
    main()
