#!/usr/bin/env python3
"""Makes the zips of a FusionBridge release from this folder:
  dist/FusionBridge-PC-<version>.zip            what players download (needs the runtime: run tools/build_app.py first)
  dist/FusionBridge-<version>-codigo-fonte.zip  the source, as it goes to GitHub (no runtime binaries, like .gitignore)
  dist/FusionBridge-GTA-SA-mod-Windows-script-<lua version>.zip  just the GTA SA (PC) mod, laid out like the game
                                                folder, to update an install by hand
usage: python3 tools/make_zips.py [--out DIR]
"""
import argparse
import glob
import os
import re
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUNTIME = {"FusionBridge.exe", "python3.dll", "vcruntime140.dll", "vcruntime140_1.dll"}   # + python3XX.dll, runtime/
SKIP_DIRS = {"__pycache__", ".git", "dist", "_build_cache", "_downloads", "build", ".gradle", ".idea", ".vscode"}
SKIP_FILES = {"fusionbridge_settings.json", ".DS_Store", "Thumbs.db"}


def version():
    with open(os.path.join(ROOT, "app", "fusionbridge.py"), encoding="utf-8") as f:
        return re.search(r'^VERSION = "([^"]+)"', f.read(), re.M).group(1)


def is_runtime(rel):
    top = rel.split("/")[0]
    return top == "runtime" or rel in RUNTIME or re.fullmatch(r"python3\d+\.dll", rel) is not None


def files():
    for d, dirs, names in os.walk(ROOT):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for n in sorted(names):
            if n in SKIP_FILES or n.endswith((".pyc", ".part")):
                continue
            p = os.path.join(d, n)
            yield os.path.relpath(p, ROOT).replace(os.sep, "/"), p


def make(path, top, keep):
    count = 0
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel, p in files():
            if keep(rel):
                info = zipfile.ZipInfo.from_file(p, top + "/" + rel)
                info.compress_type = zipfile.ZIP_DEFLATED
                if rel.endswith(".sh"):
                    info.external_attr = (0o755 << 16)
                with open(p, "rb") as f:
                    z.writestr(info, f.read())
                count += 1
    return count


GTA_README = """FusionBridge - mod do GTA San Andreas para WINDOWS (PC): script %s, ASI %s
=====================================================================

Este zip tem so o mod do GTA de PC, na mesma arrumacao da pasta do jogo:
  FusionBridgeSA.asi                          (junta a imagem do Minecraft com a do GTA)
  moonloader\\FusionBridgeGTA.lua              (o script)
  reshade-shaders\\Shaders\\FusionBridgeSA.fx   (o efeito do ReShade)

O jeito normal de instalar e o botao Instalar do FusionBridge.exe (ele tambem poe o
ReShade). Este zip serve para atualizar uma instalacao que ja existe:
  1. Feche o GTA.
  2. Copie tudo deste zip para a pasta do GTA San Andreas (a que tem o gta_sa.exe) e
     aceite substituir os arquivos.
  3. Precisa continuar la: d3d9.dll (ReShade 6.8.0 com add-on) e o MoonLoader.

O libFusionBridgeGTA.so e o mod de ANDROID (celular). O Windows nao usa esse arquivo:
pode apagar da pasta do GTA.

O FusionBridgeSA.ini de uma versao anterior nao e mais usado: pode apagar.

Se o GTA travar, mande da pasta do GTA: FusionBridgeSA.log (o ASI anota ali onde o
jogo parou), ReShade.log e moonloader\\moonloader.log, e a pagina Log do app.

Licencas: o codigo do FusionBridge e MIT (FusionBridge-LICENSE). O compositor e o efeito
foram adaptados do passthrough (MIT), o efeito tem o FSR 1.0 da AMD (MIT) e o ASI usa os
cabecalhos da API de add-ons do ReShade (BSD-3): textos completos em THIRD-PARTY-NOTICES.md.
Estes arquivos nao precisam ir para a pasta do GTA.
"""


def gta_versions():
    with open(os.path.join(ROOT, "moonloader", "FusionBridgeGTA.lua"), encoding="utf-8") as f:
        lua = re.search(r"^local VERSION\s*=\s*'([^']+)'", f.read(), re.M).group(1)
    with open(os.path.join(ROOT, "src", "asi", "main.cpp"), encoding="utf-8") as f:
        n = int(re.search(r"kVersion = (\d+);", f.read()).group(1))
    return lua, "%d.%d.%d" % (n // 1000, n // 100 % 10, n % 100)


def make_gta_mod(path):
    items = [("gta/FusionBridgeSA.asi", "FusionBridgeSA.asi"),
             ("moonloader/FusionBridgeGTA.lua", "moonloader/FusionBridgeGTA.lua"),
             ("gta/shaders/FusionBridgeSA.fx", "reshade-shaders/Shaders/FusionBridgeSA.fx")]
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for src, dst in items:
            with open(os.path.join(ROOT, *src.split("/")), "rb") as f:
                z.writestr(dst, f.read())
        z.writestr("LEIA-ME-MOD-GTA.txt", (GTA_README % gta_versions()).replace("\n", "\r\n").encode("utf-8"))
        for name in ("LICENSE", "THIRD-PARTY-NOTICES.md"):      # the licenses travel with the files they cover
            with open(os.path.join(ROOT, name), "rb") as f:
                z.writestr("FusionBridge-" + name if name == "LICENSE" else name, f.read())
    return len(items) + 3


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "dist"))
    a = ap.parse_args()
    v = version()
    os.makedirs(a.out, exist_ok=True)
    if not os.path.isfile(os.path.join(ROOT, "FusionBridge.exe")):
        print("falta o runtime: rode antes  python3 tools/build_app.py")
        return 2
    rel = os.path.join(a.out, "FusionBridge-PC-%s.zip" % v)
    src = os.path.join(a.out, "FusionBridge-%s-codigo-fonte.zip" % v)
    n1 = make(rel, "FusionBridge-PC-%s" % v, lambda r: True)
    n2 = make(src, "FusionBridge-%s" % v, lambda r: not is_runtime(r))
    for old in glob.glob(os.path.join(a.out, "FusionBridge-GTA-SA-mod-Windows-*.zip")):
        os.remove(old)                       # an older GTA mod zip (0.2.1 froze GTA) must never be shipped by mistake
    gta = os.path.join(a.out, "FusionBridge-GTA-SA-mod-Windows-script-%s.zip" % gta_versions()[0])
    n3 = make_gta_mod(gta)
    for p, n in ((rel, n1), (src, n2), (gta, n3)):
        print("%s  (%d arquivos, %.1f MB)" % (p, n, os.path.getsize(p) / 1e6))
    return 0


if __name__ == "__main__":
    sys.exit(main())
