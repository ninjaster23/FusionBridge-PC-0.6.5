FusionBridgeMC 0.1.3 for Minecraft Java 26.2 / Fabric

Install: put the JAR in .minecraft/mods and launch the Fabric 26.2 profile.
Requires Fabric Loader >= 0.19.3 and Java >= 25.

This build:
- connects to FusionBridge at 127.0.0.1:28765;
- stays off the Minecraft render thread;
- advertises MobileGlues FSR1 config support;
- receives boost_profile;
- writes fsr1Setting to the Amethyst MobileGlues config for the NEXT Minecraft launch;
- reports boost_result back to FusionBridge.

FSR1 preset mapping used by MobileGlues:
0 disabled, 1 UltraQuality, 2 Quality, 3 Balanced, 4 Performance.

Frame Generation is NOT implemented by MobileGlues/FusionBridgeMC 0.1.3.
