# FusionBridgeMC 0.2.0

O mod do Minecraft Java (Fabric) que liga o jogo ao app FusionBridge: manda o estado do jogador e do mundo e executa os comandos da aba Caos. É o `mod/FusionBridgeMC-0.2.0.jar` do pacote.

O código-fonte original desta versão tinha se perdido; este foi refeito a partir do próprio `.jar` 0.2.0 e compila para **exatamente o mesmo bytecode** (classe por classe, instrução por instrução). Por isso os nomes de variáveis locais são genéricos (`var0`, `var1`...): eles não ficam guardados no `.jar`.

Compilar: `gradle build` (Java 21). O resultado sai em `build/libs/FusionBridgeMC-0.2.0.jar`.
