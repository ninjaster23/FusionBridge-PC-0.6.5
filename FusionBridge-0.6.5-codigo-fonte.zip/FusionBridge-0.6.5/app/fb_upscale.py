"""FusionBridge PC 0.6.5 - upscaling for ANY game: AMD FSR 1.0 over the game's window, through Magpie.

FSR 2/3 and DLSS are temporal: the game itself must hand them motion vectors, depth and jittered frames, so only the
games built for them can use them. What works on any game (DirectX 9 to 12, OpenGL, Vulkan, emulators) is a spatial
upscaler over the finished picture of the game's window: FSR 1.0 (EASU + RCAS). Magpie (Blinue, GPL-3.0, free) does
exactly that: it captures the window, runs FSR 1.0 on the graphics card and shows it full screen, with the cursor
mapped back to the game. The app downloads its official release (SHA-256 checked, like ReShade), keeps it portable in
%LOCALAPPDATA%\\FusionBridge\\Magpie (config\\config.json beside Magpie.exe = portable mode), makes FSR its default
scaling mode the first time and opens it. Nothing is installed in Windows; deleting the folder removes it.

Magpie's own shortcuts: Alt+Shift+A scales the window in front to full screen (again to stop), Alt+Shift+Q scales it
in a window, Alt+Shift+D shows its toolbar.
"""
import json
import os
import posixpath
import shutil
import subprocess
import zipfile

import fb_installer as FI

MAGPIE_VERSION = "0.12.1"
CONFIG_REL = os.path.join("config", "config.json")

# Magpie's own default scaling modes (src/Magpie/AppSettings.cpp, _SetDefaultScalingModes), with FSR first so the
# global profile (profiles[0]) uses it. scalingType: 0 Normal, 1 Fit.
DEFAULT_MODES = [
    {"name": "FSR", "effects": [{"name": "FSR\\FSR_EASU", "scalingType": 1},
                                {"name": "FSR\\FSR_RCAS", "scalingType": 0, "parameters": {"sharpness": 0.87}}]},
    {"name": "Lanczos", "effects": [{"name": "Lanczos", "scalingType": 1}]},
    {"name": "FSRCNNX", "effects": [{"name": "FSRCNNX\\FSRCNNX", "scalingType": 0}]},
    {"name": "CuNNy", "effects": [{"name": "CuNNy2\\CuNNy-4x12-NVL", "scalingType": 0}]},
    {"name": "Anime4K", "effects": [{"name": "Anime4K\\Anime4K_Upscale_Denoise_L", "scalingType": 0}]},
    {"name": "CRT-Geom", "effects": [{"name": "CRT\\CRT_Geom", "scalingType": 1,
                                      "parameters": {"curvature": 0.0, "cornerSize": 0.001, "CRTGamma": 1.5,
                                                     "monitorGamma": 2.2, "interlace": 0.0}}]},
    {"name": "Integer Scale 2x", "effects": [{"name": "Nearest", "scalingType": 0, "scale": {"x": 2.0, "y": 2.0}}]},
]


class UpscaleError(Exception):
    """A reason preparing or opening the upscaler stopped, in words for the player (pt-BR)."""


def magpie_dir(local):
    return os.path.join(local, "FusionBridge", "Magpie")


def magpie_exe(local):
    return os.path.join(magpie_dir(local), "Magpie.exe")


def installed(local):
    return os.path.isfile(magpie_exe(local))


def running(is_running=FI.is_running):
    return is_running("Magpie.exe")


def _extract(zip_path, dest):
    """Extracts Magpie's zip into dest; refuses members that would land outside it."""
    base = os.path.abspath(dest)
    with zipfile.ZipFile(zip_path) as z:
        members = []
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            norm = posixpath.normpath(name)
            if name.startswith("/") or norm.startswith("..") or ":" in name or norm in (".", ""):
                raise UpscaleError("O zip do Magpie tem um caminho estranho (%s); nada foi extraído." % info.filename)
            members.append((info, norm))
        n = 0
        for info, norm in members:
            target = os.path.abspath(os.path.join(base, *norm.split("/")))
            if os.path.commonpath([base, target]) != base:
                raise UpscaleError("O zip do Magpie tem um caminho fora da pasta; nada mais foi extraído.")
            if info.is_dir():
                os.makedirs(target, exist_ok=True)
                continue
            if norm.lower().startswith("config/") and os.path.exists(target):
                continue                   # the player's own Magpie settings survive a reinstall
            os.makedirs(os.path.dirname(target), exist_ok=True)
            tmp = target + ".part"
            with z.open(info) as src, open(tmp, "wb") as out:
                while True:
                    chunk = src.read(1 << 20)
                    if not chunk:
                        break
                    out.write(chunk)
            os.replace(tmp, target)
            n += 1
    return n


def prepare_config(folder):
    """The first time: a portable config with FSR as the default scaling mode. An existing config is the player's
    (Magpie rewrites it with their choices): it is left alone, except one without any scaling mode, where the
    default modes go in. Returns True when it wrote something."""
    path = os.path.join(folder, CONFIG_REL)
    data = None
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            text = f.read()
        data = json.loads(text) if text.strip() else None
    except FileNotFoundError:
        pass
    except (OSError, ValueError):
        return False                       # Magpie shows its own message for a broken file; never overwrite it
    if isinstance(data, dict) and data.get("scalingModes"):
        return False
    data = data if isinstance(data, dict) else {}
    data["scalingModes"] = DEFAULT_MODES
    profiles = data.get("profiles") if isinstance(data.get("profiles"), list) else []
    default = profiles[0] if profiles and isinstance(profiles[0], dict) else {}
    default["scalingMode"] = 0             # FSR
    data["profiles"] = [default] + profiles[1:]
    data.setdefault("language", "pt-br")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
    os.replace(tmp, path)
    return True


def install(paths, log=print, get_dependency=FI.get_dependency, is_running=FI.is_running):
    """Downloads (SHA-256 checked) and unpacks Magpie into %LOCALAPPDATA%\\FusionBridge\\Magpie, FSR by default."""
    if is_running("Magpie.exe"):
        raise UpscaleError("Feche o Magpie antes (ícone perto do relógio → Sair) e tente de novo.")
    try:
        zip_path = get_dependency("magpie", paths, log)
    except FI.InstallError as e:
        raise UpscaleError(str(e))
    d = magpie_dir(paths.local)
    os.makedirs(d, exist_ok=True)
    n = _extract(zip_path, d)
    if not os.path.isfile(os.path.join(d, "Magpie.exe")):
        raise UpscaleError("O zip do Magpie não tinha o Magpie.exe.")
    log("Magpie %s em %s (%d arquivos)" % (MAGPIE_VERSION, d, n))
    if prepare_config(d):
        log("Modo de escala padrão do Magpie: FSR (AMD FSR 1.0)")
    return os.path.join(d, "Magpie.exe")


def launch(local, popen=subprocess.Popen, is_running=FI.is_running):
    """Opens Magpie (portable: its folder is the working folder). Already open: nothing to do."""
    exe = magpie_exe(local)
    if not os.path.isfile(exe):
        raise UpscaleError("Clique em Baixar e preparar primeiro.")
    if is_running("Magpie.exe"):
        return None
    prepare_config(magpie_dir(local))
    return popen([exe], cwd=magpie_dir(local))


def remove(local, is_running=FI.is_running):
    """Deletes the app's Magpie folder (and with it every Magpie setting). Returns False if it was not there."""
    if is_running("Magpie.exe"):
        raise UpscaleError("Feche o Magpie antes (ícone perto do relógio → Sair) e tente de novo.")
    d = magpie_dir(local)
    if not os.path.isdir(d):
        return False
    shutil.rmtree(d)
    return True
