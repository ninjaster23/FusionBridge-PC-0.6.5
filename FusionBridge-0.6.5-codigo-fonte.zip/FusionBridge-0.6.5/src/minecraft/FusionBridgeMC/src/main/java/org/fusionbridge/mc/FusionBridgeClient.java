// Ponto de entrada no cliente (Fabric).
package org.fusionbridge.mc;

import net.fabricmc.api.ClientModInitializer;

public final class FusionBridgeClient implements ClientModInitializer {
    public void onInitializeClient() {
        FusionCore.start(FusionCore.Side.CLIENT);
    }
}
