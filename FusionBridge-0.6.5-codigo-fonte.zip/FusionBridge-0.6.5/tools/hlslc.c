// Compiles one entry point of an HLSL file with Microsoft's d3dcompiler (loaded from a given DLL) and prints errors.
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
typedef struct ID3DBlobVtbl { void* q; ULONG (__stdcall *AddRef)(void*); ULONG (__stdcall *Release)(void*); void* (__stdcall *GetBufferPointer)(void*); SIZE_T (__stdcall *GetBufferSize)(void*); } ID3DBlobVtbl;
typedef struct ID3DBlob { ID3DBlobVtbl* v; } ID3DBlob;
typedef HRESULT (__stdcall *D3DCompile_t)(const void*, SIZE_T, const char*, const void*, void*, const char*, const char*, UINT, UINT, ID3DBlob**, ID3DBlob**);
typedef HRESULT (__stdcall *D3DDisassemble_t)(const void*, SIZE_T, UINT, const char*, ID3DBlob**);
int main(int argc, char** argv) {
  if (argc < 5) { printf("usage: hlslc dll file entry target [olevel]\n"); return 2; }
  HMODULE m = LoadLibraryA(argv[1]); if (!m) { printf("LoadLibrary failed %lu\n", GetLastError()); return 3; }
  D3DCompile_t comp = (D3DCompile_t)GetProcAddress(m, "D3DCompile");
  D3DDisassemble_t dis = (D3DDisassemble_t)GetProcAddress(m, "D3DDisassemble");
  FILE* f = fopen(argv[2], "rb"); fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  char* src = malloc(n + 1); fread(src, 1, n, f); src[n] = 0; fclose(f);
  UINT flags = 0;
  int ol = argc > 5 ? atoi(argv[5]) : 1;
  flags |= ol == 0 ? (1u<<14) : ol == 1 ? 0 : ol == 2 ? ((1u<<14)|(1u<<15)) : (1u<<15);
  ID3DBlob *code = NULL, *err = NULL;
  HRESULT hr = comp(src, n, argv[2], NULL, NULL, argv[3], argv[4], flags, 0, &code, &err);
  if (err) { printf("%s", (char*)err->v->GetBufferPointer(err)); }
  if (FAILED(hr)) { printf("FAILED hr=0x%08lx\n", (unsigned long)hr); return 1; }
  ID3DBlob* d = NULL;
  if (dis && SUCCEEDED(dis(code->v->GetBufferPointer(code), code->v->GetBufferSize(code), 0, NULL, &d))) {
    const char* t = (const char*)d->v->GetBufferPointer(d); const char* p = strstr(t, "// approximately");
    if (p) { const char* e = strchr(p, '\n'); printf("OK %.*s\n", (int)(e - p), p); } else printf("OK\n");
  } else printf("OK (no disasm)\n");
  return 0;
}
