# FusionBridge PC 0.6.5 — código (para quem for continuar)

## Peças e onde mexer

| Peça | Arquivo | Linguagem |
|---|---|---|
| App (janela, abas) | `app/fb_app.py` | Python 3 (stdlib + ctypes) |
| Kit de interface nativa | `app/fb_winui.py` | Win32/GDI/GDI+ via ctypes (sem tkinter) |
| Instalar/Remover, checagens de segurança | `app/fb_installer.py` | Python 3 (stdlib + ctypes) |
| Hub + `Controller` (+ API HTTP opcional) | `app/fusionbridge.py` (`app/web/` só para o modo servidor) | Python 3 (stdlib) |
| Motor de fusão (GTA ↔ Minecraft) | `app/fusion_engine.py` | Python 3 (stdlib) |
| Partida do app | `app/sitecustomize.py`, `FusionBridge._pth` | o Python oficial importa e abre a janela |
| Runtime | `tools/build_app.py` → `FusionBridge.exe`, `runtime/` | pacote oficial `python` do nuget.org |
| Script do GTA SA | `moonloader/FusionBridgeGTA.lua` | Lua (MoonLoader / LuaJIT FFI) |
| Compositor no GTA | `src/asi/*.cpp` → `gta/FusionBridgeSA.asi` | C++17, 32-bit |
| Efeito | `gta/shaders/FusionBridgeSA.fx` | ReShade FX (Direct3D 9) |
| Lista de jogos, mods fusion | `app/fb_games.py`, `fusion-mods/*.json` | Python 3 (stdlib + winreg) / JSON |
| Minecraft automático (Prism portátil, abrir/fechar com o GTA, janela fora da tela) | `app/fb_prism.py` | Python 3 (stdlib + ctypes) |
| SkyCraft (Minecraft dentro do Skyrim) | `app/fb_skycraft.py`, `fusion-mods/skycraft-*.json` | Python 3 (stdlib) |
| Logo (pixel art em código) | `app/fb_art.py` → `tools/make_icon.py` → `app/assets/FusionBridge.ico` | Python 3 |
| Mod do Minecraft (conector do hub) | `src/minecraft/FusionBridgeMC/` → `mod/FusionBridgeMC-0.2.0.jar` | Java 21 (Fabric, sem Loom) |
| Mod do Minecraft (fusão visual) | `mod/passthrough-0.1.0.jar` (MIT, código no repositório original) | Java (Fabric) |

- Conversões GTA ↔ Minecraft ficam **só** em `fusion_engine.py` (`gta_to_mc`, `mc_to_gta`, `angles_to_mc`, `level_offset`, `ground_column`, `explosion_kind`). O script do GTA manda coordenadas do GTA e recebe coordenadas do GTA.
- A câmera "de verdade" vem do ASI (`FB_GetCamera`); sem ASI o script usa os opcodes de câmera do MoonLoader (sem roll, FOV padrão).
- `src/asi/camera_math.h` é compartilhado pelo ASI e pelo teste nativo `src/asi/tests/test_math.cpp`.

## O app (FusionBridge.exe)

- `FusionBridge.exe` = `pythonw.exe` oficial, renomeado (a assinatura da PSF continua valendo). Ele lê `FusionBridge._pth` (caminhos `runtime\python313.zip`, `runtime`, `app` + `import site`), e o `site` importa `app/sitecustomize.py`, que abre `fb_app.main()` (ou `fusionbridge.main()` com `-X fb=server`) e termina com `os._exit`. As opções do app vão como `-X fb=...` porque o Python lê a linha de comando antes do app e encerra com opções que não conhece.
- Nada de código nativo nosso no app: as telas desenham com GDI+/GDI pelo `fb_winui.py` (modo imediato: `build(ui)` a cada pintura; diálogos e mensagens rodam depois da pintura via `Window.post`).
- Para refazer o runtime: `python3 tools/build_app.py` (baixa o pacote `python` 3.13.16 do nuget.org e confere o SHA-256).
- Para mexer só nas telas: edite `app/*.py` e abra o `FusionBridge.exe` de novo (não precisa recompilar nada).

## Compilar o ASI

```bash
# Linux: sudo apt install g++-mingw-w64-i686     Windows: MSYS2 mingw32 (pacman -S mingw-w64-i686-gcc)
src/asi/build.sh        # gera gta/FusionBridgeSA.asi e roda o teste da matemática da câmera
```

Arquivos: `main.cpp` (entrada, API para o script, ganchos), `sa.cpp` (endereços do jogo), `compositor.cpp` (add-on do ReShade), `watchdog.cpp` (vigia de travamento: se o jogo ficar 8 s sem completar um quadro, anota no `FusionBridgeSA.log` onde a linha do jogo parou; testado em `src/asi/tests/test_watchdog.cpp`, que roda no Windows ou no Wine).

O ReShade costuma carregar depois do ASI (o `gta_sa.exe` carrega o `d3d9.dll` quando abre o Direct3D). Então o add-on se registra a partir do jogo, depois que a tela já foi criada, e não recebe `init_effect_runtime` nem `create_swapchain` dessa primeira tela.

O ReShade é compilado com MSVC; o ASI com MinGW. As interfaces do ReShade usadas não têm métodos virtuais sobrecarregados nem destrutor virtual, então as vtables batem. A única função usada que devolve struct por valor (`effect_runtime::find_uniform_variable`) é chamada pelo slot da vtable com a convenção do MSVC (ponteiro de retorno escondido) — veja `find_uniform` em `compositor.cpp`.

## Endereços do GTA SA 1.0 US usados pelo ASI (`src/asi/sa.cpp`)

| Endereço | O que é | Proteção |
|---|---|---|
| `0x82457C` | assinatura de versão (`0x94BF` na 1.0 US) | se não bater, o ASI não usa nenhum outro |
| `0xC1703C` | `Scene.camera` (RwCamera*): frame, view window, near/far | memória legível + valores plausíveis |
| `0xBA67A4` | menu de pausa ativo | memória legível |
| `0x53BEE0` / `0x541DD0` | `CGame::Process` / `CPad::UpdatePads` | só engancha se achar exatamente 1 CALL para lá |
| `0x53E920` / `0x53E230` | `Idle` / `Render2dStuff` | idem |
| `0xB73458` | `CPad::Pads[0]` (zera tiro/mira) | só com o gancho acima instalado |

## Testes

```bash
tools/run_tests.sh            # hub, motor de fusão, instalador, Lua, matemática do ASI (+ o app no Wine, se houver)
tools/check_shader.sh [d3dcompiler_47.dll]   # shader pelo compilador do ReShade (+ d3dcompiler da Microsoft via Wine)
```

## Licenças

- O mod `passthrough`, o compositor e o efeito em que o ASI e o `.fx` se baseiam: MIT, Rehan e contribuidores (`mod/LICENSE-passthrough-MIT.txt`).
- Cabeçalhos da API de add-ons do ReShade: BSD-3, Patrick Mours (`src/third_party/reshade/LICENSE.md`).
