// FusionBridgeMC 0.2.0 - liga o Minecraft Java ao hub do FusionBridge (127.0.0.1:28765): estado do jogador e do
// mundo, eventos (TNT, Wither, Creeper...) e os comandos do app. Acessa as classes do Minecraft por reflexao (Refl),
// entao compila so com o fabric-loader. Funciona no cliente (single player) e no servidor dedicado.
package org.fusionbridge.mc;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Proxy;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

public final class FusionCore {
    public static final String VERSION = "0.2.0";
    private static final String HOST = "127.0.0.1";
    private static final int PORT = Integer.getInteger("fusionbridge.port", 28765);
    private static final long ECO_IDLE_MS = Long.getLong("fusionbridge.ecoIdleMs", 20000L);
    private static final long HUNGER_EVERY_MS = 30000L;
    private static final AtomicBoolean STARTED = new AtomicBoolean();
    private static final ArrayBlockingQueue<String> OUT = new ArrayBlockingQueue<>(512);
    private static final Set<String> MISSES = ConcurrentHashMap.newKeySet();
    private static volatile FusionCore.Side side = FusionCore.Side.CLIENT;
    private static volatile String mode = "eco";
    private static volatile int hz = 5;
    private static volatile boolean noHunger = true;
    private static volatile boolean connected = false;
    private static volatile boolean frozen = false;
    private static volatile boolean manualFreeze = false;
    private static volatile long lastActivity = System.currentTimeMillis();
    private static volatile int lastPlayers = 0;
    private static volatile int lastFusionEntities = 0;
    private static volatile long fastPendingSince = 0L;
    private static volatile long worldPendingSince = 0L;
    private static volatile boolean diagSent = false;
    private static long lastErrLog = 0L;
    private static final Map<String, FusionCore.Track> TRACK = new HashMap<>();

    private FusionCore() {
    }

    public static void start(FusionCore.Side var0) {
        if (!STARTED.compareAndSet(false, true)) {
            return;
        }
        side = var0;
        log("v0.2.0 carregando (" + (var0 == FusionCore.Side.SERVER ? "servidor dedicado / headless" : "cliente") + "), bridge em 127.0.0.1:" + PORT);
        Thread var1 = new Thread(FusionCore::netLoop, "FusionBridgeMC-Net");
        var1.setDaemon(true);
        var1.setPriority(4);
        var1.setUncaughtExceptionHandler((var0x, var1x) -> log("thread de rede terminou: " + var1x));
        var1.start();
    }

    static void log(String var0) {
        System.out.println("[FusionBridgeMC] " + var0);
    }

    static void reflMiss(String var0) {
        if (MISSES.add(var0)) {
            log("reflexao: nao encontrado " + var0);
        }
    }

    static void reflError(String var0, Throwable var1) {
        long var2 = System.currentTimeMillis();
        if (var2 - lastErrLog > 5000L) {
            lastErrLog = var2;
            log("erro em " + var0 + ": " + var1);
        }
    }

    private static String myName() {
        return side == FusionCore.Side.SERVER ? "minecraft_server" : "minecraft";
    }

    private static void netLoop() {
        long var0 = 2000L;
        boolean var2 = false;

        while (true) {
            try (Socket var3 = new Socket()) {
                var3.connect(new InetSocketAddress("127.0.0.1", PORT), 1000);
                var3.setTcpNoDelay(true);
                var3.setKeepAlive(true);
                var3.setSoTimeout(50);
                var0 = 2000L;
                var2 = false;
                session(var3);
            } catch (IOException var9) {
                if (connected) {
                    log("desconectado: " + var9.getMessage() + ". Retry in 2 seconds");
                } else if (!var2) {
                    log("FusionBridge indisponivel (" + var9.getMessage() + "). O jogo segue normal; nova tentativa a cada 2-5 s.");
                    var2 = true;
                }
            } catch (Throwable var10) {
                log("erro inesperado na rede: " + var10);
            }

            connected = false;

            try {
                Thread.sleep(var0);
            } catch (InterruptedException var6) {
                return;
            }

            var0 = Math.min(var0 + 1000L, 5000L);
        }
    }

    private static void session(Socket var0) throws IOException {
        OutputStream var1 = var0.getOutputStream();
        InputStream var2 = var0.getInputStream();
        OUT.clear();
        diagSent = false;
        write(var1, hello());
        connected = true;
        log("connected to 127.0.0.1:" + PORT);
        byte[] var3 = new byte[8192];
        ByteArrayOutputStream var4 = new ByteArrayOutputStream(256);
        long var5 = System.currentTimeMillis();
        long var7 = var5;
        long var9 = var5;
        long var11 = var5;
        long var13 = var5;
        long var15 = var5;
        long var17 = var5 + 5000L;

        while (true) {
            String var19;
            while ((var19 = OUT.poll()) != null) {
                write(var1, var19);
            }
            try {
                int var20 = var2.read(var3);
                if (var20 < 0) {
                    throw new EOFException("hub fechou a conexao");
                }

                var7 = System.currentTimeMillis();

                for (int var21 = 0; var21 < var20; var21++) {
                    byte var22 = var3[var21];
                    if (var22 == 10) {
                        handleLine(var4.toString(StandardCharsets.UTF_8).trim());
                        var4.reset();
                    } else if (var4.size() < 65536) {
                        var4.write(var22);
                    } else {
                        var4.reset();
                    }
                }
            } catch (SocketTimeoutException var23) {
            }

            var5 = System.currentTimeMillis();
            if (var5 >= var11) {
                var11 = var5 + Math.max(16, 1000 / Math.max(1, hz));
                collectFast();
            }

            if (var5 >= var13) {
                var13 = var5 + ("eco".equals(mode) ? 1000 : 500);
                collectWorld();
            }

            if (var5 - var9 >= 5000L) {
                var9 = var5;
                offer("{\"type\":\"ping\",\"client\":\"" + myName() + "\"}");
            }

            if (var5 - var7 > 20000L) {
                throw new IOException("hub sem resposta ha 20 s");
            }

            if (var5 >= var15) {
                var15 = var5 + 1000L;
                ecoTick(var5);
            }

            if (noHunger && var5 >= var17) {
                var17 = var5 + 30000L;
                hungerTick();
            }
        }
    }

    private static void write(OutputStream var0, String var1) throws IOException {
        var0.write((var1 + "\n").getBytes(StandardCharsets.UTF_8));
        var0.flush();
    }

    static void offer(String var0) {
        if (!connected) {
            return;
        }
        while (!OUT.offer(var0)) {
            OUT.poll();
        }
    }

    private static String hello() {
        return "{\"type\":\"hello\",\"client\":\""
            + myName()
            + "\",\"side\":\""
            + (side == FusionCore.Side.SERVER ? "server" : "client")
            + "\",\"role\":\""
            + (side == FusionCore.Side.SERVER ? "secondary" : "host")
            + "\",\"version\":\"0.2.0\",\"minecraft\":\""
            + Json.esc(mcVersion())
            + "\",\"protocol\":2,\"capabilities\":[\"commands\",\"player_state\",\"world_state\",\"entity_events\""
            + (side == FusionCore.Side.SERVER ? ",\"eco_freeze\"" : "")
            + "]}";
    }

    private static void handleLine(String var0) {
        if (var0.isEmpty() || var0.charAt(0) != '{') {
            return;
        }
        String var1 = Json.str(var0, "type");
        if (var1 == null) {
            return;
        }
        switch (var1) {
            case "hello_ack":
                log("hub respondeu: " + Json.str(var0, "server") + " " + Json.str(var0, "version"));
                break;
            case "fusion_config": {
                String var6 = Json.str(var0, "mode");
                if ("eco".equals(var6) || "live".equals(var6) || "visual".equals(var6)) {
                    if (!var6.equals(mode)) {
                        log("modo de fusao: " + var6);
                    }

                    mode = var6;
                }

                int var5 = (int)Json.num(var0, "state_hz", hz);
                hz = Math.max(1, Math.min(60, var5));
                if (var0.contains("\"no_hunger\":false")) {
                    noHunger = false;
                }
                break;
            }
            case "command": {
                String var4 = Json.str(var0, "to");
                if (var4 != null && !matches(var4, myName())) {
                    return;
                }

                handleCommand(Json.str(var0, "action"), Json.str(var0, "at"), (int)Json.num(var0, "id", 0.0));
                break;
            }
            case "ping":
                offer("{\"type\":\"pong\",\"client\":\"" + myName() + "\"}");
                break;
            default:
                break;
        }
    }

    private static boolean matches(String var0, String var1) {
        if (var0.endsWith("*")) {
            return var1.startsWith(var0.substring(0, var0.length() - 1));
        }
        return var0.equals(var1);
    }

    static Object minecraft() {
        return Refl.scall("net.minecraft.client.Minecraft", "getInstance");
    }

    static Object server() {
        if (side == FusionCore.Side.SERVER) {
            Object var0 = Refl.scall("net.fabricmc.loader.api.FabricLoader", "getInstance");
            return Refl.call(var0, "getGameInstance");
        } else {
            return Refl.call(minecraft(), "getSingleplayerServer");
        }
    }

    private static String mcVersion() {
        try {
            Object var0 = Refl.scall("net.fabricmc.loader.api.FabricLoader", "getInstance");
            Object var1 = Refl.call(var0, "getModContainer", "minecraft");
            if (var1 instanceof Optional && ((Optional)var1).isPresent()) {
                Object var2 = Refl.call(Refl.call(((Optional)var1).get(), "getMetadata"), "getVersion");
                Object var3 = Refl.call(var2, "getFriendlyString");
                if (var3 != null) {
                    return var3.toString();
                }
            }
        } catch (Throwable var4) {
        }

        return "?";
    }

    private static boolean exec(Object var0, Runnable var1) {
        if (var0 instanceof Executor) {
            ((Executor)var0).execute(var1);
            return true;
        } else {
            return Refl.call(var0, "execute", var1) != null || Refl.has(var0, "execute", var1);
        }
    }

    private static Object withCapture(Object var0, FusionCore.Capture var1) {
        Class var2 = Refl.cls("net.minecraft.commands.CommandSource");
        if (var2 == null || !var2.isInterface()) {
            return var0;
        }
        Object var3 = Proxy.newProxyInstance(var2.getClassLoader(), new Class[]{var2}, (var1x, var2x, var3x) -> {
            switch (var2x.getName()) {
                case "sendSystemMessage":
                    Object var6 = var3x != null && var3x.length > 0 ? var3x[0] : null;
                    Object var7 = Refl.call(var6, "getString");
                    String var8 = String.valueOf(Refl.call(var6, "getStyle"));
                    synchronized (var1) {
                        if (var1.text.length() < 300) {
                            var1.text.append(var1.text.length() > 0 ? " | " : "").append(var7);
                        }

                        if (var8.contains("red")) {
                            var1.failed = true;
                        }
                    }
                    return null;
                case "acceptsSuccess":
                case "acceptsFailure":
                    return Boolean.TRUE;
                case "shouldInformAdmins":
                case "alwaysAccepts":
                    return Boolean.FALSE;
                case "equals":
                    return var1x == (var3x == null ? null : var3x[0]);
                case "hashCode":
                    return System.identityHashCode(var1x);
                case "toString":
                    return "FusionBridgeMC";
                default:
                    return var2x.getReturnType() == boolean.class ? Boolean.FALSE : null;
            }
        });
        Object var4 = Refl.call(var0, "withSource", var3);
        return var4 != null ? var4 : var0;
    }

    private static FusionCore.Capture runCmd(Object var0, String var1) {
        FusionCore.Capture var2 = new FusionCore.Capture();

        try {
            Object var3 = Refl.call(var0, "createCommandSourceStack");
            if (var3 == null) {
                var2.failed = true;
                var2.text.append("createCommandSourceStack indisponivel");
                return var2;
            }

            Object var4 = Refl.call(var0, "getCommands");
            if (var4 == null) {
                var2.failed = true;
                var2.text.append("getCommands indisponivel");
                return var2;
            }

            Refl.callStrict(var4, "performPrefixedCommand", withCapture(var3, var2), var1);
        } catch (Throwable var5) {
            var2.failed = true;
            var2.text.append(var5.getClass().getSimpleName()).append(": ").append(var5.getMessage());
        }

        return var2;
    }

    static List<String> buildCommands(String var0, String var1, int var2) {
        String var3 = "player".equals(var1) && var2 > 0 ? "execute at @p run " : "";
        List<String> var4 = new ArrayList<>();
        switch (var0 == null ? "" : var0) {
            case "wither":
                var4.add(var3 + "summon minecraft:wither ~ ~8 ~");
                break;
            case "tnt":
                var4.add(var3 + "summon minecraft:tnt ~ ~3 ~");
                break;
            case "tnt_rain":
                for (int var7 = 0; var7 < 8; var7++) {
                    double var8 = (Math.PI * 2) * var7 / 8.0;
                    var4.add(
                        var3 + String.format(Locale.ROOT, "summon minecraft:tnt ~%d ~14 ~%d", Math.round(Math.cos(var8) * 5.0), Math.round(Math.sin(var8) * 5.0))
                    );
                }
                break;
            case "creeper":
                var4.add(var3 + "summon minecraft:creeper ~3 ~ ~");
                break;
            case "charged_creeper":
                var4.add(var3 + "summon minecraft:creeper ~3 ~ ~ {powered:1b}");
                break;
            case "lightning":
                var4.add(var3 + "summon minecraft:lightning_bolt ~ ~ ~");
                break;
            case "boom":
                var4.add(var3 + "summon minecraft:tnt ~ ~1 ~ {fuse:0}");
                break;
            case "heal":
                var4.add("effect give @a minecraft:instant_health 1 4 true");
                break;
            case "clear":
                var4.add("kill @e[type=minecraft:wither]");
                var4.add("kill @e[type=minecraft:tnt]");
                var4.add("kill @e[type=minecraft:creeper]");
                break;
            case "day":
                var4.add("time set day");
                var4.add("weather clear");
                break;
            case "freeze":
                var4.add("tick freeze");
                break;
            case "unfreeze":
                var4.add("tick unfreeze");
                break;
            case "status":
                break;
            default:
                return null;
        }

        return var4;
    }

    private static void result(String var0, int var1, boolean var2, String var3) {
        offer(
            "{\"type\":\"command_result\",\"to\":\"panel\",\"from\":\""
                + myName()
                + "\",\"action\":\""
                + Json.esc(var0)
                + "\",\"id\":"
                + var1
                + ",\"ok\":"
                + var2
                + ",\"detail\":\""
                + Json.esc(var3)
                + "\"}"
        );
    }

    private static void handleCommand(String var0, String var1, int var2) {
        Object var3 = server();
        if (var3 == null) {
            if (side == FusionCore.Side.CLIENT && Refl.call(minecraft(), "getCurrentServer") != null) {
                log("comando '" + var0 + "' ignorado: conectado a servidor remoto (o servidor com o mod executa)");
                return;
            }
            result(var0, var2, false, side == FusionCore.Side.CLIENT ? "nenhum mundo single player aberto" : "servidor ainda iniciando");
            return;
        }
        int var4 = lastPlayers;
        List<String> var5 = buildCommands(var0, var1, var4);
        if (var5 == null) {
            result(var0, var2, false, "acao desconhecida");
            return;
        }
        {
            {
                if ("freeze".equals(var0)) {
                    manualFreeze = true;
                    frozen = true;
                }

                if ("unfreeze".equals(var0)) {
                    manualFreeze = false;
                    frozen = false;
                }

                lastActivity = System.currentTimeMillis();
                boolean var6 = exec(var3, () -> {
                    StringBuilder var6x = new StringBuilder();
                    boolean var7 = true;
                    if (frozen && !manualFreeze && !"freeze".equals(var0)) {
                        runCmd(var3, "tick unfreeze");
                        frozen = false;
                        var6x.append("mundo acordou do Eco; ");
                    }

                    if ("player".equals(var1) && var4 == 0 && !var5.isEmpty() && ((String)var5.get(0)).startsWith("summon")) {
                        var6x.append("sem jogador online, usei o spawn; ");
                    }

                    for (String var9 : var5) {
                        FusionCore.Capture var10 = runCmd(var3, var9);
                        if (var10.failed && var9.contains(" {")) {
                            FusionCore.Capture var11 = runCmd(var3, var9.substring(0, var9.indexOf(" {")));
                            if (!var11.failed) {
                                var10 = var11;
                                var6x.append("(sem NBT) ");
                            }
                        }

                        if (var10.failed) {
                            var7 = false;
                        }

                        if (var5.size() == 1 || var10.failed) {
                            var6x.append((CharSequence)var10.text).append(' ');
                        }
                    }

                    if (var5.size() > 1 && var7) {
                        var6x.append(var5.size()).append(" comandos executados");
                    }

                    if (var5.isEmpty()) {
                        var6x.append("estado enviado");
                    }

                    result(var0, var2, var7, var6x.toString().trim());
                    if ("status".equals(var0)) {
                        worldPendingSince = 0L;
                    }
                });
                if (!var6) {
                    result(var0, var2, false, "nao foi possivel agendar na thread do servidor");
                }

                log("comando do painel: " + var0 + " (" + (var1 == null ? "player" : var1) + ")");
            }
        }
    }

    private static String dimOf(Object var0) {
        Object var1 = Refl.call(var0, "level");
        String var2 = String.valueOf(Refl.call(var1, "dimension"));
        int var3 = var2.lastIndexOf("/ ");
        if (var3 >= 0) {
            var2 = var2.substring(var3 + 2);
        }

        return var2.replace("]", "").trim();
    }

    private static String playerJson(Object var0, String var1, String var2) {
        String var3 = String.valueOf(Refl.call(Refl.call(var0, "getName"), "getString"));
        return "{\"type\":\""
            + var1
            + "\",\"name\":\""
            + Json.esc(var3)
            + "\",\"x\":"
            + Json.n(Refl.num(var0, "getX"))
            + ",\"y\":"
            + Json.n(Refl.num(var0, "getY"))
            + ",\"z\":"
            + Json.n(Refl.num(var0, "getZ"))
            + ",\"yaw\":"
            + Json.n(Refl.num(var0, "getYRot"))
            + ",\"pitch\":"
            + Json.n(Refl.num(var0, "getXRot"))
            + ",\"health\":"
            + Json.n(Refl.num(var0, "getHealth"))
            + ",\"dim\":\""
            + Json.esc(dimOf(var0))
            + "\""
            + var2
            + "}";
    }

    private static void collectFast() {
        if (side == FusionCore.Side.CLIENT) {
            Object var3 = Refl.field(minecraft(), "player");
            if (var3 != null) {
                offer(playerJson(var3, "player_state", ",\"side\":\"client\""));
            }
            return;
        }
        Object var0 = server();
        long var1 = System.currentTimeMillis();
        if (var0 == null || (fastPendingSince != 0L && var1 - fastPendingSince < 5000L)) {
            return;
        }
        fastPendingSince = var1;
        exec(var0, () -> {
            try {
                Object var1x = Refl.call(Refl.call(var0, "getPlayerList"), "getPlayers");
                if (var1x instanceof List && !((List)var1x).isEmpty()) {
                    offer(playerJson(((List)var1x).get(0), "player_state", ",\"side\":\"server\""));
                }
            } catch (Throwable var5) {
                reflError("player_state", var5);
            } finally {
                fastPendingSince = 0L;
            }
        });
    }

    private static String kindOf(Object var0) {
        switch (var0.getClass().getSimpleName()) {
            case "PrimedTnt":
                return "tnt";
            case "WitherBoss":
                return "wither";
            case "Creeper":
                return "creeper";
            case "WitherSkull":
                return "wither_skull";
            case "LightningBolt":
                return "lightning";
            case "EnderDragon":
                return "ender_dragon";
            case "LargeFireball":
                return "fireball";
            default:
                return null;
        }
    }

    private static void collectWorld() {
        Object var0 = server();
        long var1 = System.currentTimeMillis();
        if (var0 == null || (worldPendingSince != 0L && var1 - worldPendingSince < 5000L)) {
            return;
        }
        worldPendingSince = var1;
        exec(var0, () -> {
            try {
                buildWorld(var0);
            } catch (Throwable var5) {
                reflError("world_state", var5);
            } finally {
                worldPendingSince = 0L;
            }
        });
    }

    private static void buildWorld(Object var0) {
        Object var1 = Refl.call(Refl.call(var0, "getPlayerList"), "getPlayers");
        List<?> var2 = var1 instanceof List ? (List<?>)var1 : new ArrayList<>();
        StringBuilder var3 = new StringBuilder("[");

        for (int var4 = 0; var4 < var2.size() && var4 < 8; var4++) {
            if (var4 > 0) {
                var3.append(',');
            }

            var3.append(playerJson(var2.get(var4), "player", ""));
        }

        var3.append(']');
        Map<String, Integer> var15 = new HashMap<>();
        Map<String, FusionCore.Track> var5 = new HashMap<>();
        Object var6 = Refl.call(var0, "getAllLevels");
        if (var6 instanceof Iterable) {
            for (Object var8 : (Iterable)var6) {
                Object var9 = Refl.call(var8, "getAllEntities");
                if (!(var9 instanceof Iterable)) {
                    continue;
                }
                String var10 = String.valueOf(Refl.call(var8, "dimension"));

                for (Object var12 : (Iterable)var9) {
                    String var13 = kindOf(var12);
                    if (var13 == null) {
                        continue;
                    }
                    var15.merge(var13, 1, Integer::sum);
                    Object var14 = Refl.call(var12, "getId");
                    var5.put(var10 + "#" + var14, new FusionCore.Track(var13, Refl.num(var12, "getX"), Refl.num(var12, "getY"), Refl.num(var12, "getZ")));
                }
            }
        }

        int var16 = 0;

        for (Entry<String, FusionCore.Track> var20 : var5.entrySet()) {
            if (!TRACK.containsKey(var20.getKey()) && var16 < 20) {
                FusionCore.Track var24 = (FusionCore.Track)var20.getValue();
                var16++;
                if (!"lightning".equals(var24.kind) || var16 < 5) {
                    offer(event("entity_spawn", var24, ""));
                }
            }
        }

        for (Entry<String, FusionCore.Track> var21 : TRACK.entrySet()) {
            if (!var5.containsKey(var21.getKey()) && var16 < 40) {
                FusionCore.Track var25 = (FusionCore.Track)var21.getValue();
                var16++;
                if ("tnt".equals(var25.kind)) {
                    offer(event("explosion", var25, ",\"power\":4"));
                } else if (!"lightning".equals(var25.kind)) {
                    offer(event("entity_remove", var25, ""));
                }
            }
        }

        TRACK.clear();
        TRACK.putAll(var5);
        int var19 = 0;

        for (int var26 : var15.values()) {
            var19 += var26;
        }

        lastPlayers = var2.size();
        lastFusionEntities = var19;
        if (var19 > 0 || !var2.isEmpty() || var16 > 0) {
            lastActivity = System.currentTimeMillis();
        }

        Boolean var23 = null;
        Object var27 = null;
        Object var28 = Refl.call(var0, "tickRateManager");
        if (var28 != null) {
            Object var29 = Refl.call(var28, "isFrozen");
            if (var29 instanceof Boolean) {
                var23 = (Boolean)var29;
            }

            var27 = Refl.call(var28, "tickrate");
        }

        if (var23 != null) {
            frozen = var23;
        }

        StringBuilder var30 = new StringBuilder("{");
        String[] var31 = new String[]{"tnt", "wither", "creeper", "wither_skull", "ender_dragon", "fireball"};

        for (int var32 = 0; var32 < var31.length; var32++) {
            var30.append(var32 > 0 ? "," : "").append('"').append(var31[var32]).append("\":").append(var15.getOrDefault(var31[var32], 0));
        }

        var30.append('}');
        offer(
            "{\"type\":\"world_state\",\"side\":\""
                + (side == FusionCore.Side.SERVER ? "server" : "client")
                + "\",\"players\":"
                + var2.size()
                + ",\"player_list\":"
                + var3
                + ",\"counts\":"
                + var30
                + ",\"frozen\":"
                + frozen
                + ",\"manual_freeze\":"
                + manualFreeze
                + ",\"tickrate\":"
                + (var27 instanceof Number ? Json.n(((Number)var27).doubleValue()) : "null")
                + ",\"mode\":\""
                + mode
                + "\",\"mod\":\"0.2.0\"}"
        );
        if (!diagSent) {
            diagSent = true;
            sendDiag(var0);
        }
    }

    private static String event(String var0, FusionCore.Track var1, String var2) {
        return "{\"type\":\"event\",\"event\":\""
            + var0
            + "\",\"entity\":\""
            + var1.kind
            + "\",\"x\":"
            + Json.n(var1.x)
            + ",\"y\":"
            + Json.n(var1.y)
            + ",\"z\":"
            + Json.n(var1.z)
            + var2
            + "}";
    }

    private static void sendDiag(Object var0) {
        StringBuilder var1 = new StringBuilder("{\"type\":\"diag\",\"side\":\"")
            .append(side == FusionCore.Side.SERVER ? "server" : "client")
            .append("\",\"server_class\":\"")
            .append(Json.esc(var0.getClass().getName()))
            .append("\",\"executor\":")
            .append(var0 instanceof Executor)
            .append(",\"command_source_proxy\":")
            .append(Refl.cls("net.minecraft.commands.CommandSource") != null)
            .append(",\"missing\":[");
        int var2 = 0;

        for (String var4 : MISSES) {
            if (var2++ > 0) {
                var1.append(',');
            }

            var1.append('"').append(Json.esc(var4)).append('"');
            if (var2 > 30) {
                break;
            }
        }

        var1.append("]}");
        offer(var1.toString());
        log("diagnostico enviado ao FusionBridge (" + MISSES.size() + " nome(s) nao encontrados)");
    }

    private static void ecoTick(long var0) {
        if (side != FusionCore.Side.SERVER || manualFreeze) {
            return;
        }
        Object var2 = server();
        if (var2 == null) {
            return;
        }
        boolean var3 = lastPlayers > 0 || lastFusionEntities > 0;
        if (var3) {
            lastActivity = var0;
        }

        if ("eco".equals(mode)) {
            if (!frozen && !var3 && var0 - lastActivity > ECO_IDLE_MS) {
                frozen = true;
                exec(var2, () -> runCmd(var2, "tick freeze"));
                log("Eco: mundo ocioso, congelado (tick freeze)");
                offer("{\"type\":\"event\",\"event\":\"eco_freeze\",\"detail\":\"mundo ocioso congelado\"}");
            } else if (frozen && lastPlayers > 0) {
                frozen = false;
                exec(var2, () -> runCmd(var2, "tick unfreeze"));
                log("Eco: jogador entrou, mundo descongelado");
                offer("{\"type\":\"event\",\"event\":\"eco_unfreeze\",\"detail\":\"jogador entrou\"}");
            }
        } else if (frozen) {
            frozen = false;
            exec(var2, () -> runCmd(var2, "tick unfreeze"));
            log("modo " + mode + ": mundo descongelado");
        }
    }

    private static void hungerTick() {
        if (lastPlayers <= 0 && side == FusionCore.Side.SERVER) {
            return;
        }
        Object var0 = server();
        if (var0 == null) {
            return;
        }
        exec(var0, () -> runCmd(var0, "effect give @a minecraft:saturation 1 0 true"));
    }

    public static enum Side {
        CLIENT,
        SERVER;
    }

    private static final class Track {
        final String kind;
        double x;
        double y;
        double z;

        Track(String var1, double var2, double var4, double var6) {
            this.kind = var1;
            this.x = var2;
            this.y = var4;
            this.z = var6;
        }
    }

    private static final class Capture {
        final StringBuilder text = new StringBuilder();
        boolean failed = false;
    }
}
