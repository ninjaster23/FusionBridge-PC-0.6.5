-- Offline test of the visual-fusion part of moonloader/FusionBridgeGTA.lua (run with luajit, from the
-- package root). The MoonLoader opcode wrappers and FusionBridgeSA.asi are stubbed.
_G.FB_TEST = true

local cam = { x = 0, y = 0, z = 10, tx = 0, ty = 10, tz = 10 }
local cj = { x = 100.25, y = 200.75, z = 13.3, h = 45, hp = 100, car = false }
local keys, just, wheel = {}, {}, 0
local calls = { vis = {}, proofs = {}, tp = {}, boom = {}, obj = {}, del = {}, objvis = {}, print = {}, ground = 0 }
local groundmap = function(x, y, z) return 12.3 end

function script_name() end
function script_author() end
function script_version() end
PLAYER_PED, PLAYER_HANDLE = 1, 0
function isPlayerPlaying() return true end
function getCharCoordinates() return cj.x, cj.y, cj.z end
function getCharHeading() return cj.h end
function getCharHealth() return cj.hp end
function setCharHealth() end
function isCharInAnyCar() return cj.car end
function setCharVisible(p, v) calls.vis[#calls.vis + 1] = v end
function setCharProofs(p, b, f, e, c, m) calls.proofs[#calls.proofs + 1] = { b, f, e, c, m } end
function setCharCoordinates(p, x, y, z) calls.tp[#calls.tp + 1] = { x, y, z } end
function getActiveCameraCoordinates() return cam.x, cam.y, cam.z end
function getActiveCameraPointAt() return cam.tx, cam.ty, cam.tz end
function getGroundZFor3dCoord(x, y, z) calls.ground = calls.ground + 1; return groundmap(x, y, z) end
function isKeyDown(k) return keys[k] or false end
function isKeyJustPressed(k) local v = just[k]; just[k] = nil; return v or false end
function getMousewheelDelta() local d = wheel; wheel = 0; return d end
function isPauseMenuActive() return false end
function isGamePaused() return false end
function printStringNow(t, ms) calls.print[#calls.print + 1] = t end
local model = { loaded = false, req = 0, flush = 0, release = 0 }
function requestModel() model.req = model.req + 1 end
function loadAllModelsNow() model.flush = model.flush + 1 end
function hasModelLoaded() return model.loaded end
function markModelAsNoLongerNeeded() model.release = model.release + 1 end
function createObject(m, x, y, z) calls.obj[#calls.obj + 1] = { m, x, y, z }; return 5000 + #calls.obj end
function deleteObject(h) calls.del[#calls.del + 1] = h end
function setObjectVisible(o, v) calls.objvis[#calls.objvis + 1] = v end
function freezeObjectPosition() end
function setObjectCollision() end
function addExplosion(x, y, z, t) calls.boom[#calls.boom + 1] = { x, y, z, t } end
function shakeCam() end
function getScreenResolution() return 1920, 1080 end
local mouse = { x = 960, y = 540, cursor = nil, locked = nil }
function getCursorPos() return mouse.x, mouse.y end
function showCursor(show, lock) mouse.cursor, mouse.locked = show, lock end
function renderDrawBox() end
function wait() end

local M = assert(loadfile('moonloader/FusionBridgeGTA.lua'))()
local ffi = require 'ffi'

local pass, fail = 0, 0
local function check(name, cond, detail)
  if cond then pass = pass + 1; print('PASS ' .. name)
  else fail = fail + 1; print('FAIL ' .. name .. (detail ~= nil and ('  -> ' .. tostring(detail)) or '')) end
end
local function near(a, b, eps) return a and b and math.abs(a - b) <= (eps or 1e-3) end
local sent = {}
local conn = { sock = 1, send_line = function(self, l) sent[#sent + 1] = l; return true end }
local function feed(line) M.handle(conn, line) end
local function find(pat) for i = #sent, 1, -1 do if sent[i]:find(pat) then return sent[i] end end end
local function count(pat) local n = 0; for _, l in ipairs(sent) do if l:find(pat) then n = n + 1 end end; return n end
local function tick() M.fusion_tick(conn) end

-- JSON helpers
local a = M.jarr('{"set":[100.5,199.5,15.3,1e-05,-2]}', 'set')
check('jarr reads floats, exponents, negatives', a and #a == 5 and near(a[1], 100.5) and near(a[4], 1e-5) and a[5] == -2)
check('jnum reads exponents', near(M.jnum('{"yoff":-3.5e-01}', 'yoff'), -0.35))
check('jsafe strips quotes and newlines', M.jsafe('a"b\\c\nd') == 'a b c d', M.jsafe('a"b\\c\nd'))

-- fusion off: camera still goes out (slowly) for leveling, nothing else happens
sent = {}
tick()
local c = find('"type":"fusion_cam"')
check('camera sent even before the fusion starts (leveling)', c ~= nil)
check('opcode camera: looking north -> heading 0, pitch 0', c and near(M.jnum(c, 'f') and tonumber(c:match('"r":%[([-%d%.]+)')), 0)
      and near(tonumber(c:match('"r":%[[-%d%.]+,([-%d%.]+)')), 0), c)
check('ground under CJ included (pg)', c and near(M.jnum(c, 'pg'), 12.3), c)
check('no ground probes while the fusion is off', find('fusion_ground') == nil)
check('CJ not hidden while off', #calls.vis == 0)

-- the hub turns the fusion on (Minecraft linked, ground leveled)
feed('{"type":"fusion_state","on":1,"mc":1,"mouse":"mc","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1}')
check('fusion_state parsed', M.F.on and M.F.mc and M.F.radius == 10 and M.F.probes == 50 and near(M.F.yoff, -0.3))
cam.tx, cam.ty, cam.tz = -10, 0, 10      -- looking west
sent = {}
tick()
c = find('"type":"fusion_cam"')
check('camera every frame while live; west -> heading 90', c and near(tonumber(c:match('"r":%[([-%d%.]+)')), 90), c)
check('CJ hidden (Steve takes his place)', calls.vis[#calls.vis] == false)
check('CJ fire + explosion proof', calls.proofs[#calls.proofs] and calls.proofs[#calls.proofs][2] == true
      and calls.proofs[#calls.proofs][3] == true and calls.proofs[#calls.proofs][1] == false)
local g = find('"type":"fusion_ground"')
check('ground probes sent', g ~= nil)
local n = 0
for _ in (g or ''):gmatch('%[%-?%d+,%-?%d+,[-%d%.]+%]') do n = n + 1 end
check('probes capped per frame (50)', n == 50, n)
local first = g and g:match('"g":%[%[(%-?%d+,%-?%d+)')
check('nearest column first (CJ column 100,-201)', first == '100,-201', first)

-- columns that aren't streamed in yet (ground 0.0) are retried later
groundmap = function(x, y) if x > 105 then return 0.0 end return 12.3 end
M.G.sampled, M.G.nsampled = {}, 0
sent = {}
for _ = 1, 10 do tick() end
local total = 0
for _, l in ipairs(sent) do if l:find('fusion_ground') then for _ in l:gmatch('%[%-?%d+,%-?%d+,[-%d%.]+%]') do total = total + 1 end end end
local spiral = #M.build_spiral(10)
check('unstreamed columns not marked sampled', M.G.nsampled < spiral and M.G.nsampled == total, M.G.nsampled .. ' vs ' .. total)
groundmap = function() return 12.3 end
sent = {}
local before = M.G.nsampled
for _ = 1, 10 do tick() end
check('a column without collision is not re-probed every frame', M.G.nsampled == before, M.G.nsampled .. ' vs ' .. before)
for _ = 1, 30 do tick() end
check('they are probed once collision streams in (retried after ~30 frames)', M.G.nsampled == spiral, M.G.nsampled .. '/' .. spiral)
feed('{"type":"fusion_ground_reset"}')
check('ground reset clears the sampled set', M.G.nsampled == 0)

-- input: mouse buttons, number keys, wheel
sent = {}
keys[0x01] = true
tick()
check('left click -> attack down', find('"k":"attack","down":true') ~= nil)
keys[0x01] = nil
just[0x33] = true          -- key 3
wheel = 120
tick()
check('release -> attack up', find('"k":"attack","down":false') ~= nil)
check('key 3 -> slot 2', find('"slot":2') ~= nil)
check('wheel up -> scroll +1', find('"scroll":1') ~= nil)
-- the fused keys arrive with fusion_state and apply at once
check('before the hub says so, only the mouse buttons are forwarded', #M.F.keys == 2)
sent = {}
just[0x51] = true          -- Q (nothing yet)
tick()
check('Q not forwarded before the fused keys arrive', find('"scroll"') == nil)
calls.print = {}
feed('{"type":"fusion_state","on":1,"mc":1,"mouse":"mc","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1,"keys":[1,1,2,2,81,7,69,8,73,3,90,4,88,5]}')
check('fused keys parsed', #M.F.keys == 7, #M.F.keys)
check('the player is told which keys are fused', calls.print[1] and calls.print[1]:find('Q/E') ~= nil, calls.print[1])
sent = {}
just[0x51] = true          -- Q: previous item (like the wheel up)
tick()
check('Q -> previous item (scroll +1)', find('"scroll":1') ~= nil)
sent = {}
just[0x45] = true          -- E: next item
tick()
check('E -> next item (scroll -1)', find('"scroll":%-1') ~= nil)
sent = {}
just[0x49] = true          -- I: inventory
tick()
check('I -> Minecraft inventory', find('"k":"inventory","down":true') ~= nil and M.G.inv)
check('... with GTA\'s cursor up and CJ/camera locked', mouse.cursor == true and mouse.locked == true)
-- the inventory is used right there: cursor, clicks, keys and wheel go to Minecraft's window
sent = {}
mouse.x, mouse.y = 1919, 0
tick()
check('cursor -> fraction of the screen', find('"type":"fusion_pointer","x":1.0000,"y":0.0000}') ~= nil, sent[1])
sent = {}
tick()
check('no repeat while the cursor stays put', count('fusion_pointer') == 0)
keys[0x01] = true
mouse.x, mouse.y = 480, 270
sent = {}
tick()
check('left click on a slot -> pointer button 0 down at the cursor',
      find('"x":0.2501,"y":0.2502,"b":0,"down":1', 1, true) ~= nil, table.concat(sent, ' '))
check('... and NOT a Minecraft attack (the click belongs to the inventory)', find('"k":"attack"') == nil)
keys[0x01] = nil
sent = {}
tick()
check('release -> button 0 up', find('"b":0,"down":0') ~= nil)
keys[0x10] = true; keys[0x32] = true      -- Shift + 2
sent = {}
tick()
check('Shift and 2 go to the inventory (shift-click, hotbar swap)', find('"vk":16,"down":1') ~= nil and find('"vk":50,"down":1') ~= nil
      and find('"slot"') == nil)
keys[0x10] = nil; keys[0x32] = nil
tick()
wheel = -1
sent = {}
tick()
check('wheel -> pointer wheel', find('"wheel":%-1') ~= nil)
sent = {}
just[0x51] = true; keys[0x51] = true       -- Q in the inventory: drop the hovered item, not "previous item"
tick()
check('Q in the inventory -> key to Minecraft, no scroll', find('"vk":81,"down":1') ~= nil and find('"scroll"') == nil)
keys[0x51] = nil; just[0x51] = nil
tick()
keys[0x02] = true                          -- right button held while closing
tick()
sent = {}
just[0x49] = true          -- I again: closes it
tick()
keys[0x02] = nil
check('I again -> closes it (escape)', find('"k":"escape"') ~= nil and not M.G.inv)
check('... lets go of what is held in Minecraft\'s window', find('"release":1') ~= nil)
check('... and gives GTA its mouse back', mouse.cursor == false and mouse.locked == false)
sent = {}
just[0x45] = true          -- E closes it too (Minecraft's own inventory key)
just[0x49] = true
tick()
just[0x45] = true
tick()
check('E closes the inventory as in Minecraft', not M.G.inv and mouse.cursor == false)
sent = {}
keys[0x5A] = true          -- Z held: drop
tick()
check('Z -> drop down', find('"k":"drop","down":true') ~= nil)
keys[0x5A] = nil
keys[0x58] = true          -- X: swap hands
tick()
check('Z released -> drop up, X -> swap', find('"k":"drop","down":false') ~= nil and find('"k":"swap","down":true') ~= nil)
keys[0x58] = nil
tick()
just[0x49] = true          -- inventory open, then the mouse goes back to GTA: it closes
tick()
feed('{"type":"fusion_state","on":1,"mc":1,"mouse":"gta","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1,"keys":[1,1,2,2,81,7,69,8,73,3,90,4,88,5]}')
sent = {}
tick()
check('mouse back to GTA: Minecraft inventory closed', find('"k":"escape"') ~= nil and not M.G.inv and mouse.cursor == false)
calls.print = {}
feed('{"type":"fusion_state","on":1,"mc":1,"mouse":"mc","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1,"keys":[1,1,2,2]}')
check('fused keys off: back to the mouse buttons only, no message', #M.F.keys == 2 and #calls.print == 0)
sent = {}
just[0x51] = true
tick()
check('... and Q stays GTA\'s', find('"scroll"') == nil)
just[0x76] = true          -- F7
just[0x77] = true          -- F8
just[0x75] = true          -- F6
sent = {}
tick()
check('F7/F8/F6 -> fusion_key', find('"k":"toggle"') and find('"k":"relevel"') and find('"k":"mouse"'))

-- in a car: CJ shows, mouse stays GTA's
cj.car = true
keys[0x02] = true
sent = {}
tick()
check('in a car: CJ visible again', calls.vis[#calls.vis] == true)
check('in a car: right click not forwarded', find('"k":"use"') == nil)
c = find('"type":"fusion_cam"')
check('camera says veh=1', c and M.jnum(c, 'veh') == 1, c)
cj.car = false
keys[0x02] = nil

-- mouse mode GTA: nothing forwarded
feed('{"type":"fusion_state","on":1,"mc":1,"mouse":"gta","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1}')
keys[0x01] = true
sent = {}
tick()
check('mouse mode GTA: clicks stay in GTA', find('"k":"attack"') == nil)
keys[0x01] = nil

-- the ASI: exact camera + compositing switch
local fbcalls = {}
local fake = {
  FB_Version = function() return 600 end,
  FB_GetCamera = function(out)
    out[0], out[1], out[2] = 5, 6, 7; out[3], out[4], out[5] = 33, -12, 1.5; out[6] = 48.5; out[7], out[8] = 0.3, 900; out[9] = 1.7778
    return 1
  end,
  FB_SetFusion = function(comp, block, yoff) fbcalls[#fbcalls + 1] = { comp, block, yoff } end,
  FB_SetFsr = function(on, sharp) fbcalls.fsr = { on, sharp }; fbcalls.nfsr = (fbcalls.nfsr or 0) + 1 end,
  FB_GetStatus = function(out) for i = 0, 15 do out[i] = 0 end; out[0], out[1], out[2], out[3], out[4] = 1, 1, 1, 2560, 1440; return 1 end,
}
M.set_fb(fake, 600)
feed('{"type":"fusion_state","on":1,"mc":1,"mouse":"mc","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1}')
M.G.last_asi_t = -1e9
sent = {}
tick()
c = find('"type":"fusion_cam"')
check('ASI camera used (position, angles, fov)', c and c:find('"c":%[5%.0000,6%.0000,7%.0000%]') and c:find('"r":%[33%.000,%-12%.000,1%.500%]')
      and near(M.jnum(c, 'fov'), 48.5), c)
local last = fbcalls[#fbcalls]
check('ASI told: composite on, mouse blocked, yoff', last and last[1] == 1 and last[2] == 1 and near(last[3], -0.3), last and table.concat(last, ','))
check('ASI status reported to the hub', find('"type":"fusion_asi","loaded":1') ~= nil)
feed('{"type":"fusion_state","on":1,"mc":1,"mouse":"mc","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1,"fsr":1,"sharp":0.5}')
check('FSR choice reaches the ASI', fbcalls.fsr and fbcalls.fsr[1] == 1 and near(fbcalls.fsr[2], 0.5), fbcalls.fsr and table.concat(fbcalls.fsr, ','))
feed('{"type":"fusion_state","on":1,"mc":1,"mouse":"mc","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1,"fsr":1,"sharp":0.5}')
check('... once (not every state message)', fbcalls.nfsr == 1, fbcalls.nfsr)
feed('{"type":"fusion_state","on":1,"mc":1,"mouse":"mc","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1,"fsr":0,"sharp":0.5}')
check('FSR off reaches the ASI', fbcalls.fsr[1] == 0 and fbcalls.nfsr == 2)
local v = find('"type":"fusion_view"')
check('view = GTA backbuffer + projection aspect', v and M.jnum(v, 'w') == 2560 and M.jnum(v, 'h') == 1440 and near(M.jnum(v, 'aspect'), 1.7778), v)

-- Minecraft -> GTA
calls.boom, calls.tp = {}, {}
feed('{"type":"fusion_boom","x":100,"y":200,"z":15,"kind":2,"src":"tnt"}')
check('fusion_boom -> explosion at the exact spot', calls.boom[1] and calls.boom[1][1] == 100 and calls.boom[1][2] == 200
      and calls.boom[1][3] == 15 and calls.boom[1][4] == 2)
feed('{"type":"fusion_teleport","x":50,"y":60,"z":22}')
check('fusion_teleport moves CJ', calls.tp[1] and calls.tp[1][1] == 50 and calls.tp[1][3] == 22)
cj.car = true
feed('{"type":"fusion_teleport","x":1,"y":2,"z":3}')
check('no teleport while driving', #calls.tp == 1)
cj.car = false

calls.obj, calls.objvis, calls.del = {}, {}, {}
feed('{"type":"fusion_props","set":[100.5,199.5,15.3,101.5,199.5,15.3],"clear":[]}')
tick(); tick()
check('props wait for the block model, without a synchronous load', #calls.obj == 0 and model.req == 1 and model.flush == 0,
      #calls.obj .. ' obj, ' .. model.req .. ' req, ' .. model.flush .. ' flush')
model.loaded = true
tick()
check('props created invisible, centred on the block', #calls.obj == 2 and calls.obj[1][4] > 15.3 and calls.objvis[1] == false,
      #calls.obj)
feed('{"type":"fusion_props","set":[],"clear":[100.5,199.5,15.3]}')
check('prop cleared', #calls.del == 1 and M.G.nprops == 1, M.G.nprops)
local many = {}
for i = 1, 200 do many[#many + 1] = string.format('%d.5,10.5,5.0', i) end
feed('{"type":"fusion_props","set":[' .. table.concat(many, ',') .. '],"clear":[]}')
local first_new = #calls.obj + 1
for _ = 1, 20 do tick() end
check('props capped at 150', M.G.nprops == 150, M.G.nprops)
local lo, hi = 1e9, -1e9
for i = first_new, #calls.obj do lo = math.min(lo, calls.obj[i][2]); hi = math.max(hi, calls.obj[i][2]) end
check('walls go to the blocks that came first (the app sends the nearest first)', lo == 1.5 and hi <= 150.5, lo .. '..' .. hi)
feed('{"type":"fusion_props","clear_all":1}')
check('clear_all removes them all', M.G.nprops == 0)
check('a re-level keeps the block model loaded', model.release == 0 and M.G.prop_model_ready == true)
calls.obj = {}
feed('{"type":"fusion_props","set":[100.5,199.5,15.3],"clear":[]}')
tick()
check('... so the next blocks appear at once', #calls.obj == 1 and model.req == 1 and model.flush == 0, #calls.obj)

feed('{"type":"fusion_notify","text":"FusionBridge: fusao ligada"}')
check('notify -> printStringNow', calls.print[#calls.print] == 'FusionBridge: fusao ligada')

-- approximate rules step aside while the exact fusion runs
calls.boom = {}
feed('{"type":"event","from":"minecraft","event":"explosion"}')
check('rule explosion skipped while fusion live', #calls.boom == 0)

-- fusion off: everything given back
keys[0x01] = true
tick()
keys[0x01] = nil
sent = {}
feed('{"type":"fusion_state","on":0,"mc":1,"mouse":"mc","hide_cj":1,"cj_safe":1,"props":1,"radius":10,"probes":50,"yoff":-0.3,"level":1}')
check('off: CJ visible', calls.vis[#calls.vis] == true)
check('off: proofs cleared', calls.proofs[#calls.proofs][2] == false and calls.proofs[#calls.proofs][3] == false)
check('off: held click released in Minecraft', find('"k":"attack","down":false') ~= nil)
check('off: ASI compositing off', fbcalls[#fbcalls][1] == 0 and fbcalls[#fbcalls][2] == 0)
check('off: the block model is released', model.release == 1, model.release)
calls.boom = {}
feed('{"type":"event","from":"minecraft","event":"explosion"}')
check('rule explosion works again when the fusion is off', #calls.boom == 1)

-- the connect to the hub never blocks the game: it is started non-blocking and finished by select() later
local function fake_ws2(script)
  local W = { log = {}, closed = 0, sel = script.sel or {}, conn = script.conn or {}, err = 0,
              rx = script.rx or {}, sendplan = script.sendplan or {}, sent = '', recvs = 0 }
  function W.socket() W.log[#W.log + 1] = 'socket'; return ffi.cast('SOCKET', 7) end
  function W.ioctlsocket(s, cmd, arg)
    W.cmd = cmd
    W.log[#W.log + 1] = 'nb=' .. tonumber(arg[0])
    if script.ioctl_fails then W.err = 10022; return -1 end
    return 0
  end
  function W.recv(s, buf, len)
    W.recvs = W.recvs + 1
    local item = table.remove(W.rx, 1)
    if item == nil then W.err = 10035; return -1 end
    if item == 'close' then return 0 end
    if #item > len then table.insert(W.rx, 1, item:sub(len + 1)); item = item:sub(1, len) end  -- like recv: at most len
    ffi.copy(buf, item, #item)
    return #item
  end
  function W.send(s, data, len)
    local plan = table.remove(W.sendplan, 1)
    if plan == 'block' then W.err = 10035; return -1 end
    local n = plan and math.min(plan, len) or len
    W.sent = W.sent .. data:sub(1, n)
    return n
  end
  function W.setsockopt() return 0 end
  function W.htons(p) return p end
  function W.inet_addr() return 0x0100007F end
  function W.connect()
    W.log[#W.log + 1] = 'connect'
    local r = table.remove(W.conn, 1) or { -1, 10035 }
    W.err = r[2]; return r[1]
  end
  function W.WSAGetLastError() return W.err end
  function W.select(n, r, w, e, tv)
    if r ~= nil then                      -- readability (poll_lines): data or a close queued
      r.fd_count = (#W.rx > 0) and 1 or 0
      return r.fd_count
    end
    local v = table.remove(W.sel, 1) or 'wait'
    w.fd_count = (v == 'up') and 1 or 0
    e.fd_count = (v == 'refused') and 1 or 0
    return (v == 'wait') and 0 or 1
  end
  function W.closesocket() W.closed = W.closed + 1; return 0 end
  return W
end

local W = fake_ws2({ sel = { 'wait', 'up' } })
M.set_ws2(W, true)
local c2 = M.Conn.new()
check('connect: starts and returns at once (WSAEWOULDBLOCK = in progress)', c2:connect(1000) == true and c2.pending ~= nil and c2.sock == nil)
check('connect: socket made non-blocking before connect()', W.log[2] == 'nb=1' and W.log[3] == 'connect', table.concat(W.log, ' '))
check('pending: select says not yet -> wait', c2:check_pending(1100) == 'wait' and c2.sock == nil)
check('pending: select says writable -> up', c2:check_pending(1200) == 'up' and c2.sock ~= nil and c2.pending == nil)

W = fake_ws2({ sel = { 'refused' } })
M.set_ws2(W, true)
c2 = M.Conn.new()
c2:connect(0)
check('pending: refused -> fail, socket closed', c2:check_pending(50) == 'fail' and c2.pending == nil and c2.sock == nil and W.closed == 1)

W = fake_ws2({ sel = { 'wait', 'wait' } })
M.set_ws2(W, true)
c2 = M.Conn.new()
c2:connect(0)
check('pending: still waiting before 3 s', c2:check_pending(2500) == 'wait')
check('pending: gives up after 3 s', c2:check_pending(3500) == 'fail' and W.closed == 1)

W = fake_ws2({ conn = { { -1, 10061 } } })
M.set_ws2(W, true)
c2 = M.Conn.new()
check('connect: refused at once -> false, socket closed', c2:connect(0) == false and W.closed == 1 and c2.pending == nil)

W = fake_ws2({ conn = { { 0, 0 } } })
M.set_ws2(W, true)
c2 = M.Conn.new()
check('connect: connected at once -> sock set', c2:connect(0) == true and c2.sock ~= nil and c2.pending == nil)

-- no select() declared (another script's cdef got there first): a second connect() tells the state
W = fake_ws2({ conn = { { -1, 10035 }, { -1, 10037 }, { -1, 10056 } } })
M.set_ws2(W, false)
c2 = M.Conn.new()
c2:connect(0)
check('fallback: WSAEALREADY -> wait', c2:check_pending(10) == 'wait')
check('fallback: WSAEISCONN -> up', c2:check_pending(20) == 'up' and c2.sock ~= nil)
W = fake_ws2({ conn = { { -1, 10035 }, { -1, 10061 } } })
M.set_ws2(W, false)
c2 = M.Conn.new()
c2:connect(0)
check('fallback: refused -> fail', c2:check_pending(10) == 'fail' and W.closed == 1)
-- THE FREEZE (0.2.0/0.2.1): FIONBIO must reach ioctlsocket's 32-bit long with all its bits
local bit = require 'bit'
check('FIONBIO fits a 32-bit long and keeps the bits 0x8004667E', M.FIONBIO == bit.tobit(0x8004667E)
      and ffi.new('int32_t[1]', M.FIONBIO)[0] == bit.tobit(0x8004667E), string.format('%x', bit.tobit(M.FIONBIO)))
W = fake_ws2({ conn = { { -1, 10035 } } })
M.set_ws2(W, true)
c2 = M.Conn.new()
c2:connect(0)
check('ioctlsocket gets FIONBIO as an in-range number', W.cmd == -2147195266, tostring(W.cmd))
W = fake_ws2({ ioctl_fails = true })
M.set_ws2(W, true)
c2 = M.Conn.new()
check('a socket that stays blocking is closed and never used', c2:connect(0) == false and W.closed == 1
      and c2.sock == nil and c2.pending == nil and not table.concat(W.log, ' '):find('connect'), table.concat(W.log, ' '))

W = fake_ws2({})
W.socket = function() return 4294967295 end
M.set_ws2(W, true)
c2 = M.Conn.new()
check('INVALID_SOCKET as a plain number (32-bit LuaJIT) is seen as a failed socket()', c2:connect(0) == false
      and W.cmd == nil, tostring(W.cmd))

-- reading never waits: select() first, lines cut across chunks, a capped number of reads per frame
W = fake_ws2({ conn = { { 0, 0 } } })
M.set_ws2(W, true)
c2 = M.Conn.new()
c2:connect(0)
local ls = c2:poll_lines()
check('nothing waiting: no recv() at all', ls and #ls == 0 and W.recvs == 0, W.recvs)
W.rx = { '{"a":1}\n{"b":', '2}\n{"c"' }
ls = c2:poll_lines()
check('lines split across chunks', ls and #ls == 2 and ls[1] == '{"a":1}' and ls[2] == '{"b":2}' and c2.inbuf == '{"c"', ls and #ls)
W.rx = { ':3}\n' }
ls = c2:poll_lines()
check('partial line completed next frame', ls and #ls == 1 and ls[1] == '{"c":3}')
W.rx = {}
for i = 1, 40 do W.rx[i] = 'x\n' end
W.recvs = 0
ls = c2:poll_lines()
check('at most 32 reads per frame', W.recvs == 32 and #ls == 32 and #W.rx == 8, W.recvs)
c2:poll_lines()
W.rx = { string.rep('y', 1048577 + 8192) }
local frames = 0
repeat ls = c2:poll_lines(); frames = frames + 1 until #W.rx == 0 or frames > 200
check('a runaway line is dropped', #ls == 0 and #c2.inbuf < 8192 * 33 and c2.skip == true, #c2.inbuf)
W.rx = { 'yyy\n{"d":4}\n' }
ls = c2:poll_lines()
check('... up to its end, the next line is fine', #ls == 1 and ls[1] == '{"d":4}' and c2.skip == false, ls[1])
W.rx = { 'close' }
check('peer closed -> nil and closed', c2:poll_lines() == nil and c2.sock == nil)

-- sending keeps partial writes in order
W = fake_ws2({ conn = { { 0, 0 } }, sendplan = { 3, 'block' } })
M.set_ws2(W, true)
c2 = M.Conn.new()
c2:connect(0)
check('partial send: the rest waits', c2:send_line('hello') and W.sent == 'hel' and c2.out == 'lo\n', c2.out)
check('next line queues behind it (socket full)', c2:send_line('world') and W.sent == 'hel' and c2.out == 'lo\nworld\n', c2.out)
check('flush sends everything in order', c2:flush() and W.sent == 'hello\nworld\n' and c2.out == '', W.sent)
c2.out = string.rep('z', 262145)
check('the app stopped reading: link dropped, not grown forever', c2:send_line('more') == false and c2.sock == nil)
-- the main loop's frame: connects, says hello, reads the app's lines (what main() runs every frame, in a pcall)
W = fake_ws2({ conn = { { 0, 0 } } })
M.set_ws2(W, true)
local mc2 = M.Conn.new()
local L = { next_retry = 0, was_up = false, was_live = false, refused = 0 }
M.main_step(mc2, L)
check('main loop: connects and says hello', L.was_up and W.sent:find('"type":"hello"', 1, true) ~= nil, W.sent:sub(1, 80))
W.rx = { '{"type":"fusion_config","mode":"live"}\n' }
M.main_step(mc2, L)
check('main loop: handles the app\'s lines', M.state().mode == 'live')
W.rx = { 'close' }
M.main_step(mc2, L)
check('main loop: link closed -> retry scheduled', not mc2.sock and L.next_retry > 0)
M.set_ws2(nil, true)

print(string.format('\n%d/%d passed', pass, pass + fail))
os.exit(fail == 0 and 0 or 1)
