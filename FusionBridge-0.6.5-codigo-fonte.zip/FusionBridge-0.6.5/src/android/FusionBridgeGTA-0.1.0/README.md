# FusionBridgeGTA 0.1.0 - source

Loader-neutral native core for the **FusionBridge GTA SA Android mod**.

## What this source already does

- connects to `127.0.0.1:28765` using the FusionBridge JSON-lines protocol;
- identifies itself as client `gta`;
- reconnects automatically;
- queues Minecraft delta events off-thread and applies them only from `FusionBridgeGTA_Tick()`;
- caps event work to 64 actions per GTA frame to avoid a TNT/event storm freezing the game;
- reports GTA player state at a deliberately low ~10 Hz target for ECO operation;
- understands TNT/explosion, entity spawn/move/remove and block place/break events;
- exposes a small C ABI so an Android GTA mod loader can bind actual GTA functions without changing the networking core.

## Important boundary

This archive is **our mod source**, not the GTA San Andreas source code. It contains no Rockstar assets/code and no hard-coded game addresses.

The last loader-specific layer still has to implement `FusionBridgeGtaApi` for the exact GTA SA Android build/loader you choose. That is where `minecraft:wither`, `minecraft:creeper`, blocks and TNT become real GTA objects/effects. The networking/core is already separated so we do not need to rewrite it when the loader changes.

## Expected mobile architecture

```text
Minecraft headless / snapshot producer
           |
           | small delta packets
           v
     FusionBridge app
           |
           | localhost JSONL :28765
           v
 FusionBridgeGTA native core
           |
           v
 GTA loader adapter (main thread)
           |
           v
       GTA SA Android
```

Only GTA needs to render. The Minecraft side can be snapshot/headless.

## Build core with Android NDK

```bash
cmake -S . -B build \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-26
cmake --build build --config Release
```

Output: `libfusionbridge_gta.so`.

## Loader adapter

See `examples/loader_adapter_example.cpp`. A real adapter must call:

- `FusionBridgeGTA_SetApi(...)` once;
- `FusionBridgeGTA_Init()` once;
- `FusionBridgeGTA_Tick()` from GTA's main/game thread;
- `FusionBridgeGTA_Shutdown()` during unload.

Do not call GTA engine functions from the networking thread.

## Protocol notes

A few accepted messages:

```json
{"type":"event","event":"tnt_explosion","x":10,"y":20,"z":3,"radius":7.5,"damage":150}
{"type":"event","event":"entity_spawn","entity":"minecraft:wither","id":42,"x":0,"y":5,"z":0}
{"type":"event","event":"entity_move","id":42,"x":2,"y":5,"z":1}
{"type":"event","event":"entity_remove","id":42}
{"type":"event","event":"block_place","block":"minecraft:tnt","id":91,"x":2,"y":0,"z":4}
```

This core intentionally uses delta events instead of mirroring a whole Minecraft world every frame.
