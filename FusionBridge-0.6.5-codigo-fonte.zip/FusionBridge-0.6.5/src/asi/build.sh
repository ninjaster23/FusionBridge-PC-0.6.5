#!/usr/bin/env bash
# Builds FusionBridgeSA.asi (32-bit, GTA SA) with MinGW-w64 and runs the native camera-math test.
#   Linux:   sudo apt install g++-mingw-w64-i686 && src/asi/build.sh
#   Windows: MSYS2 "mingw32" shell (pacman -S mingw-w64-i686-gcc), same command.
# Output: gta/FusionBridgeSA.asi (next to the shader the installer copies into the game folder).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
CXX="${CXX:-i686-w64-mingw32-g++}"
OUT="$ROOT/gta/FusionBridgeSA.asi"
mkdir -p "$ROOT/gta"
"$CXX" -std=c++17 -O2 -shared -static -static-libgcc -static-libstdc++ \
  -Wall -Wextra -Wno-unused-parameter -Wno-missing-field-initializers -Wno-cast-function-type -Wno-attributes -Wno-ignored-qualifiers \
  -DWIN32_LEAN_AND_MEAN -DNOMINMAX -D_WIN32_WINNT=0x0601 \
  -I "$HERE/compat" -I "$ROOT/src/third_party/reshade" \
  "$HERE/main.cpp" "$HERE/sa.cpp" "$HERE/compositor.cpp" "$HERE/watchdog.cpp" \
  -o "$OUT" -Wl,--enable-stdcall-fixup -Wl,--subsystem,windows -lpsapi -luser32 -lkernel32
echo "built $OUT ($(stat -c %s "$OUT" 2>/dev/null || wc -c <"$OUT") bytes)"
if command -v g++ >/dev/null 2>&1; then
  T="$(mktemp -d)"
  g++ -std=c++17 -O2 "$HERE/tests/test_math.cpp" -o "$T/test_math" && "$T/test_math"
  rm -rf "$T"
fi
