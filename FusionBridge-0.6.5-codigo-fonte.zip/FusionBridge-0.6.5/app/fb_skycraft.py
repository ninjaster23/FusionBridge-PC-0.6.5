"""FusionBridge PC 0.6.5 - SkyCraft (Minecraft Java inside Skyrim, by chasmlol, MIT): check, install, play, remove.

SkyCraft is a fusion mod of its own: an SKSE plugin in Skyrim (SkyCraft.dll) and a Fabric mod in a hidden Minecraft Java
(started by the portable Prism Launcher that comes inside SkyCraft), talking through shared memory. The FusionBridge does
around it what a careful player would do by hand:

  - reads the Skyrim build from SkyrimSE.exe (1.6/1.7 = the Anniversary Edition runtime SkyCraft needs; not 1.5.97,
    not VR) and checks that the SKSE64 and Address Library files are the ones for that exact build;
  - installs the official SkyCraft zip (fixed SHA-256) and the SKSE / Address Library files the player picked (their
    archives or the files themselves), never over a different file, with a record of every file it put (SHA-256) so
    Remover takes out exactly those, and only while they are unchanged;
  - backs up the Skyrim saves before installing;
  - unpacks SkyCraft's Minecraft (Prism) the way SkyCraft.dll does it (same folder, same bundle.stamp), so the
    Microsoft sign-in can be done before Skyrim runs instead of over it;
  - opens Skyrim through skse64_loader.exe (opening Steam first when the game is the Steam one), shows SkyCraft.log and
    Minecraft's latest.log, SkyCraft.ini's switches, and the camera mods SkyCraft doesn't work with.

Nothing of Skyrim, SKSE or the Address Library comes with the FusionBridge; SkyCraft is downloaded from its GitHub.
Everything here is plain file work and process starts: no memory offsets, no hooks, nothing injected by the app.
"""
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile

import fb_installer as FI

IS_WINDOWS = sys.platform == "win32"
VERSION = "0.1.2"
ZIP_NAME = "SkyCraft-0.1.2.zip"
ZIP_SHA256 = "1133ECDE384D70D5261CBC9BA149BC7B544E1653B78846A1623B56241BB392C3"
REPO = "https://github.com/chasmlol/SkyCraft"
SKSE_SITE = "https://skse.silverlock.org/"
ADDRLIB_PAGE = "https://www.nexusmods.com/skyrimspecialedition/mods/32444?tab=files"
ALT_START_PAGE = "https://www.nexusmods.com/skyrimspecialedition/mods/272"
STEAM_APPID = "489830"
MUTEX = "Local\\SkyCraft_v1_minecraft"
# camera mods SkyCraft's README says it conflicts with (their SKSE plugin files)
CONFLICTS = (("ImprovedCameraSE.dll", "Improved Camera SE"), ("SmoothCam.dll", "SmoothCam"),
             ("TrueDirectionalMovement.dll", "True Directional Movement"))
ALT_START_ESP = "alternate start - live another life.esp"
NAMES = ("the elder scrolls v: skyrim special edition", "skyrim special edition",
         "the elder scrolls v: skyrim anniversary edition", "skyrim anniversary edition")
# Skyrim's own folder under Documents\My Games, per store
MY_GAMES = ("Skyrim Special Edition", "Skyrim Special Edition GOG", "Skyrim Special Edition EPIC", "Skyrim Special Edition MS")
MAX_SAVES_BACKUP = 8 << 30        # a saves folder bigger than this is not copied (the player is told)


class SkyError(Exception):
    """A reason SkyCraft can't be installed/opened/removed, in words for the player (pt-BR)."""


# ====================================================================== where things are
def state_dir(local):
    return os.path.join(local, "FusionBridge", "SkyCraft")


def manifest_path(local):
    return os.path.join(state_dir(local), "instalacao.json")


def mc_dir(local):
    """SkyCraft's own Minecraft (Prism, the Microsoft sign-in, Minecraft's files, the SkyCraft world)."""
    return os.path.join(local, "SkyCraft")


def prism_exe(local):
    return os.path.join(mc_dir(local), "Prism", "prismlauncher.exe")


def mc_log(local):
    return os.path.join(mc_dir(local), "Prism", "instances", "SkyCraft", ".minecraft", "logs", "latest.log")


def plugins_dir(game):
    return os.path.join(game, "Data", "SKSE", "Plugins")


def bundle_path(game):
    return os.path.join(plugins_dir(game), "SkyCraft", "SkyCraft-Minecraft.zip")


def ini_path(game):
    return os.path.join(plugins_dir(game), "SkyCraft.ini")


def documents_dir():
    if IS_WINDOWS:
        try:
            p = FI.known_folder(FI.FOLDERID_DOCUMENTS)
            if p:
                return p
        except Exception:
            pass
    return os.path.join(os.path.expanduser("~"), "Documents")


def skse_logs(docs):
    return [os.path.join(docs, "My Games", d, "SKSE", "SkyCraft.log") for d in MY_GAMES]


def saves_dirs(docs):
    return [p for p in (os.path.join(docs, "My Games", d, "Saves") for d in MY_GAMES) if os.path.isdir(p)]


# ====================================================================== the Skyrim build
_ver_cache = {}


def exe_version(path):
    """'1.7.104.0': the file version Windows shows in the .exe's Properties (its VS_FIXEDFILEINFO), or None."""
    try:
        st = os.stat(path)
    except OSError:
        return None
    key = (os.path.normcase(os.path.abspath(path)), st.st_mtime_ns, st.st_size)
    if key in _ver_cache:
        return _ver_cache[key]
    ver = None
    sig = b"\xbd\x04\xef\xfe\x00\x00\x01\x00"         # dwSignature, dwStrucVersion 1.0
    try:
        with open(path, "rb") as f:
            # the version resource lives in .rsrc, near the end: read the tail first, then the whole file
            tail = min(st.st_size, 8 << 20)
            f.seek(st.st_size - tail)
            data = f.read(tail)
            i = data.rfind(sig)
            if i < 0 and tail < st.st_size:
                f.seek(0)
                data = f.read()
                i = data.rfind(sig)
            if i >= 0 and i + 16 <= len(data):
                ms = int.from_bytes(data[i + 8:i + 12], "little")
                ls = int.from_bytes(data[i + 12:i + 16], "little")
                ver = "%d.%d.%d.%d" % (ms >> 16, ms & 0xFFFF, ls >> 16, ls & 0xFFFF)
    except OSError:
        return None
    if len(_ver_cache) > 64:
        _ver_cache.clear()
    _ver_cache[key] = ver
    return ver


def parse_version(v):
    try:
        t = tuple(int(x) for x in str(v).split("."))
    except (TypeError, ValueError):
        return None
    return t if len(t) == 4 else None


def runtime_of(vt):
    """'ae' (1.6.x / 1.7.x and newer: what SkyCraft needs), 'se' (1.5.x), or None."""
    if not vt:
        return None
    if vt[0] == 1 and vt[1] >= 6 or vt[0] > 1:
        return "ae"
    if vt[0] == 1 and vt[1] == 5:
        return "se"
    return None


def skse_dll_name(vt):
    return "skse64_%d_%d_%d.dll" % vt[:3]


def addrlib_name(vt):
    return "versionlib-%d-%d-%d-%d.bin" % vt


def store_of(game):
    """Which store this Skyrim came from, by the files only that store puts in the game folder."""
    low = os.path.abspath(game or "").lower()
    if os.path.isfile(os.path.join(game, "steam_api64.dll")):
        return "steam"
    if os.path.isfile(os.path.join(game, "Galaxy64.dll")) or os.path.isfile(os.path.join(game, "goggame-1711230643.info")):
        return "gog"
    if os.path.isdir(os.path.join(game, ".egstore")):
        return "epic"
    if "windowsapps" in low or "xboxgames" in low or os.path.isfile(os.path.join(game, "appxmanifest.xml")):
        return "gamepass"
    return "desconhecida"


STORE_LABEL = {"steam": "Steam", "gog": "GOG", "epic": "Epic Games", "gamepass": "Xbox / Game Pass", "desconhecida": "loja não identificada"}


def is_skyrim_dir(p):
    return bool(p) and os.path.isfile(os.path.join(p, "SkyrimSE.exe"))


def find_skyrim(games=None):
    """The Skyrim Special Edition folder: from the game scan (Steam/GOG/Epic...), the registry, or Steam's default."""
    for g in games or []:
        ids = g.get("ids") or {}
        name = (g.get("name") or "").strip().lower()
        if (str(ids.get("steam") or "") == STEAM_APPID or name in NAMES) and is_skyrim_dir(g.get("path")):
            return g["path"]
    for g in games or []:
        if is_skyrim_dir(g.get("path")):
            return g["path"]
    cands = []
    if IS_WINDOWS:
        try:
            import winreg
            for key in (r"SOFTWARE\WOW6432Node\Bethesda Softworks\Skyrim Special Edition",
                        r"SOFTWARE\Bethesda Softworks\Skyrim Special Edition"):
                try:
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key) as k:
                        cands.append(winreg.QueryValueEx(k, "installed path")[0])
                except OSError:
                    pass
        except ImportError:
            pass
        for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles")):
            if base:
                cands.append(os.path.join(base, "Steam", "steamapps", "common", "Skyrim Special Edition"))
    for c in cands:
        if c and is_skyrim_dir(c.strip().strip('"')):
            return os.path.abspath(c.strip().strip('"'))
    return None


# ====================================================================== SkyCraft.ini
def read_ini(game):
    """{'start': bool, 'diag': bool, 'launcher': str, 'args': str} from SkyCraft.ini (defaults when missing)."""
    out = {"start": True, "diag": False, "launcher": "", "args": "--launch SkyCraft", "found": False}
    try:
        with open(ini_path(game), "r", encoding="utf-8-sig", errors="replace") as f:
            lines = f.read().splitlines()
    except OSError:
        return out
    out["found"] = True
    sec = ""
    for line in lines:
        s = line.split(";", 1)[0].strip()
        if s.startswith("[") and s.endswith("]"):
            sec = s[1:-1].strip().lower()
            continue
        if "=" not in s:
            continue
        k, v = (x.strip() for x in s.split("=", 1))
        k = k.lower()
        if sec == "minecraft" and k == "bstartwithskyrim":
            out["start"] = v not in ("0", "false", "False")
        elif sec == "minecraft" and k == "slauncher":
            out["launcher"] = v
        elif sec == "minecraft" and k == "sarguments":
            out["args"] = v
        elif sec == "debug" and k == "bdiagnostics":
            out["diag"] = v not in ("0", "false", "False", "")
    return out


def set_ini(game, section, key, value, local=None):
    """Sets one key in SkyCraft.ini, keeping the comments and everything else. When the FusionBridge installed the
    file, its record gets the new SHA-256 (it is still ours: Remover takes it out)."""
    p = ini_path(game)
    try:
        with open(p, "r", encoding="utf-8-sig", errors="replace") as f:
            lines = f.read().splitlines()
    except OSError:
        raise SkyError("Não achei o SkyCraft.ini (instale o SkyCraft primeiro).")
    sec, done, out, sec_at = "", False, [], None
    for line in lines:
        s = line.split(";", 1)[0].strip()
        if s.startswith("[") and s.endswith("]"):
            if sec == section.lower() and not done:
                out.append("%s = %s" % (key, value))
                done = True
            sec = s[1:-1].strip().lower()
            if sec == section.lower():
                sec_at = len(out)
        elif sec == section.lower() and "=" in s and s.split("=", 1)[0].strip().lower() == key.lower() and not done:
            out.append("%s = %s" % (key, value))
            done = True
            continue
        out.append(line)
    if not done:
        if sec_at is None:
            out += ["", "[%s]" % section]
        out.append("%s = %s" % (key, value))
    tmp = p + ".fusionbridge-tmp"
    with open(tmp, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(out) + "\n")
    os.replace(tmp, p)
    if local:
        m = load_manifest(local)
        rel = os.path.relpath(p, game)
        if m and _same(m.get("Game"), game):
            for item in m["Files"]:
                if os.path.normcase(item.get("Path", "")) == os.path.normcase(rel):
                    item["SHA256"] = FI.sha256_file(p)
                    _write_manifest(local, m)
                    break


# ====================================================================== logs
def tail(path, n=12, max_bytes=65536):
    """The last n lines of a text file (empty list when it isn't there)."""
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - max_bytes))
            data = f.read()
    except OSError:
        return []
    lines = data.decode("utf-8", "replace").replace("\r\n", "\n").split("\n")
    if size > max_bytes:
        lines = lines[1:]
    return [ln.rstrip() for ln in lines if ln.strip()][-n:]


HINTS = (("unpacking failed", "bad", "O SkyCraft não conseguiu desempacotar o Minecraft dele. Use \"Preparar o Minecraft\" aqui no "
          "FusionBridge e abra de novo."),
         ("couldn't copy", "bad", "O SkyCraft não conseguiu copiar o Minecraft dele (pasta Data protegida ou cheia?)."),
         ("no SkyCraft-Minecraft.zip", "bad", "Falta o SkyCraft-Minecraft.zip ao lado do SkyCraft.dll: instale o SkyCraft de novo."),
         ("sLauncher in SkyCraft.ini", "bad", "O launcher escolhido no SkyCraft.ini (sLauncher) não existe."),
         ("couldn't start", "bad", "O Windows não abriu o Minecraft do SkyCraft."),
         ("bStartWithSkyrim = 0", "wait", "O Minecraft não abre junto com o Skyrim (desligado no SkyCraft.ini)."),
         ("already running", "ok", "O Minecraft do SkyCraft já estava aberto e foi reaproveitado."),
         ("Minecraft: started", "ok", "O Minecraft do SkyCraft foi aberto junto com o Skyrim."))


def log_hints(lines):
    """What the last lines of SkyCraft.log say, in plain words: [(state, text)] (the most recent first, no repeats)."""
    out, seen = [], set()
    for line in reversed(lines or []):
        for needle, st, text in HINTS:
            if needle in line and text not in seen:
                seen.add(text)
                out.append((st, text))
    return out[:3]


# ====================================================================== state
def _same(a, b):
    try:
        return bool(a) and bool(b) and os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))
    except (TypeError, ValueError):
        return False


def load_manifest(local):
    try:
        with open(manifest_path(local), "r", encoding="utf-8-sig") as f:
            m = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(m, dict) or not isinstance(m.get("Files"), list):
        return None
    m["Files"] = [x for x in m["Files"] if isinstance(x, dict) and isinstance(x.get("Path"), str)]
    return m


def _write_manifest(local, m):
    os.makedirs(state_dir(local), exist_ok=True)
    p = manifest_path(local)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=1)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, p)


def mo2_or_vortex(local, appdata=None):
    """Which mod managers seem to be in use (their own folders exist): ['Mod Organizer 2', 'Vortex']."""
    out = []
    if os.path.isdir(os.path.join(local, "ModOrganizer")):
        out.append("Mod Organizer 2")
    appdata = appdata or os.environ.get("APPDATA") or ""
    if appdata and os.path.isdir(os.path.join(appdata, "Vortex")):
        out.append("Vortex")
    return out


def signed_in(local):
    """Has the player signed in to Microsoft in SkyCraft's Prism (accounts.json with an account)?"""
    try:
        with open(os.path.join(mc_dir(local), "Prism", "accounts.json"), "r", encoding="utf-8-sig") as f:
            d = json.load(f)
        return bool(isinstance(d, dict) and d.get("accounts"))
    except (OSError, ValueError):
        return False


def mc_running():
    """SkyCraft's Minecraft holds this mutex while it runs (the same check SkyCraft.dll makes)."""
    if not IS_WINDOWS:
        return False
    import ctypes
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.OpenMutexW.restype = ctypes.c_void_p
    k.OpenMutexW.argtypes = (ctypes.c_uint32, ctypes.c_int, ctypes.c_wchar_p)
    k.CloseHandle.argtypes = (ctypes.c_void_p,)
    h = k.OpenMutexW(0x00100000, 0, MUTEX)        # SYNCHRONIZE
    if h:
        k.CloseHandle(h)
        return True
    return False


def bundle_stamp(game):
    """What SkyCraft.dll writes in %LOCALAPPDATA%\\SkyCraft\\bundle.stamp: the bundle's size and its last-write time
    as a Windows FILETIME (100 ns since 1601), so a bundle unpacked here is not unpacked again by SkyCraft."""
    st = os.stat(bundle_path(game))
    return "%d %d" % (st.st_size, st.st_mtime_ns // 100 + 116444736000000000)


def check(game, local, docs=None, running=None):
    """Everything the SkyCraft card shows. Reads files only (SkyrimSE.exe's version, SKSE, plugins, logs)."""
    running = running or FI.is_running
    docs = docs or documents_dir()
    out = {"game": game, "exe": False, "version": None, "runtime": None, "store": None, "skse": False, "skse_dll": None,
           "skse_other": [], "addrlib": False, "addrlib_name": None, "skycraft": False, "bundle": False, "ini": read_ini(game or ""),
           "conflicts": [], "alt_start": False, "managers": mo2_or_vortex(local), "running": False, "manifest": None,
           "ours": False, "prism": os.path.isfile(prism_exe(local)), "signed_in": signed_in(local), "mc_running": mc_running(),
           "stamp_ok": False, "skse_log": None, "skse_tail": [], "mc_tail": [], "hints": [], "saves": saves_dirs(docs)}
    m = load_manifest(local)
    out["manifest"] = m
    for p in skse_logs(docs):
        if os.path.isfile(p):
            out["skse_log"] = p
            out["skse_tail"] = tail(p, 10)
            out["hints"] = log_hints(tail(p, 200))
            break
    out["mc_tail"] = tail(mc_log(local), 8)
    if not game or not is_skyrim_dir(game):
        return out
    out["exe"] = True
    out["running"] = running("SkyrimSE.exe") or running("skse64_loader.exe")
    out["store"] = store_of(game)
    out["version"] = exe_version(os.path.join(game, "SkyrimSE.exe"))
    vt = parse_version(out["version"])
    out["runtime"] = runtime_of(vt)
    try:
        names = os.listdir(game)
    except OSError:
        names = []
    low = {n.lower() for n in names}
    found_dlls = sorted(n for n in names if n.lower().startswith("skse64_") and n.lower().endswith(".dll")
                        and n.lower() not in ("skse64_loader.dll", "skse64_steam_loader.dll"))
    if vt:
        out["skse_dll"] = skse_dll_name(vt)
        out["addrlib_name"] = addrlib_name(vt)
        out["skse"] = "skse64_loader.exe" in low and out["skse_dll"].lower() in low
        out["skse_other"] = [n for n in found_dlls if n.lower() != out["skse_dll"].lower()]
        out["addrlib"] = os.path.isfile(os.path.join(plugins_dir(game), out["addrlib_name"]))
    plugins = plugins_dir(game)
    out["skycraft"] = os.path.isfile(os.path.join(plugins, "SkyCraft.dll"))
    out["bundle"] = os.path.isfile(bundle_path(game))
    try:
        plow = {n.lower() for n in os.listdir(plugins)}
    except OSError:
        plow = set()
    out["conflicts"] = [label for dll, label in CONFLICTS if dll.lower() in plow]
    try:
        out["alt_start"] = ALT_START_ESP in {n.lower() for n in os.listdir(os.path.join(game, "Data"))}
    except OSError:
        pass
    out["ours"] = bool(m) and _same(m.get("Game"), game)
    if out["bundle"] and out["prism"]:
        try:
            with open(os.path.join(mc_dir(local), "bundle.stamp"), "r", encoding="utf-8", errors="replace") as f:
                out["stamp_ok"] = f.readline().strip() == bundle_stamp(game)
        except OSError:
            pass
    return out


def summary(c):
    """One line for the game picker ('check' of the fusion mod): (state, text)."""
    if not c.get("exe"):
        return "wait", "Não achei o SkyrimSE.exe nesta pasta."
    v = c.get("version") or "não reconhecida"
    if c.get("runtime") != "ae":
        return "bad", ("SkyrimSE.exe %s: o SkyCraft precisa da 1.6 ou 1.7 (runtime da Anniversary Edition). A 1.5.97 e o VR "
                       "não servem." % v)
    if c.get("store") == "gamepass":
        return "bad", "Skyrim do Xbox / Game Pass: o SKSE não funciona nessa versão, então o SkyCraft também não."
    missing = [n for k, n in (("skse", "SKSE64 %s" % v), ("addrlib", "Address Library %s" % v), ("skycraft", "SkyCraft"))
               if not c.get(k)]
    if missing:
        return "wait", "SkyrimSE.exe %s. Falta: %s (página Mods fusion, cartão SkyCraft)." % (v, ", ".join(missing))
    if c.get("conflicts"):
        return "wait", "Pronto, mas %s mexe na câmera e briga com o SkyCraft." % " e ".join(c["conflicts"])
    return "ok", "SkyrimSE.exe %s com SKSE, Address Library e SkyCraft: pronto." % v


# ====================================================================== what to install
class _Src:
    """A file to install: a member of a zip, or a file on disk."""

    def __init__(self, zip_path=None, member=None, path=None):
        self.zip_path, self.member, self.path = zip_path, member, path

    def data(self):
        if self.path:
            with open(self.path, "rb") as f:
                return f.read()
        with zipfile.ZipFile(self.zip_path) as z:
            return z.read(self.member)

    def sha256(self):
        return hashlib.sha256(self.data()).hexdigest().upper()


def _safe_parts(name):
    """The parts of a path inside an archive, or None when it would leave the folder (absolute, '..', drive)."""
    n = name.replace("\\", "/")
    if n.startswith("/") or ":" in n:
        return None
    parts = [p for p in n.split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts):
        return None
    return parts


def skycraft_entries(zip_path):
    """The SkyCraft release zip (SKSE/Plugins/...) -> [(path inside the game folder, source)]."""
    try:
        got = FI.sha256_file(zip_path)
    except OSError as e:
        raise SkyError("Não deu para ler o %s (%s)." % (os.path.basename(zip_path), e.strerror or e))
    if got != ZIP_SHA256:
        raise SkyError("Esse arquivo não é o SkyCraft %s oficial (SHA-256 diferente). Baixe o %s em %s/releases."
                       % (VERSION, ZIP_NAME, REPO))
    out = []
    try:
        with zipfile.ZipFile(zip_path) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                parts = _safe_parts(info.filename)
                if parts is None:
                    raise SkyError("O zip do SkyCraft tem um caminho estranho (%s); nada foi instalado." % info.filename)
                out.append((os.path.join("Data", *parts), _Src(zip_path, info.filename)))
    except zipfile.BadZipFile:
        raise SkyError("O zip do SkyCraft está danificado.")
    if not any(rel.lower().endswith("skycraft.dll") for rel, _ in out):
        raise SkyError("O zip do SkyCraft não tem o SkyCraft.dll.")
    return out


def _tar_extract(archive, dest):
    """Windows' own tar.exe (bsdtar: .zip, .7z, .rar, .tar...) into dest."""
    tar = os.path.join(os.environ.get("SystemRoot") or "C:\\Windows", "System32", "tar.exe")
    if not os.path.isfile(tar):
        raise SkyError("O Windows deste PC não tem o tar.exe para abrir %s. Extraia o arquivo com o 7-Zip e escolha o "
                       "arquivo de dentro." % os.path.basename(archive))
    try:
        r = subprocess.run([tar, "-xf", archive, "-C", dest], capture_output=True, timeout=300,
                           creationflags=0x08000000 if IS_WINDOWS else 0)            # CREATE_NO_WINDOW
    except (OSError, subprocess.TimeoutExpired) as e:
        raise SkyError("Não consegui abrir %s (%s)." % (os.path.basename(archive), e))
    if r.returncode != 0:
        raise SkyError("O tar do Windows não abriu %s. Extraia com o 7-Zip e escolha o arquivo de dentro (o "
                       "skse64_loader.exe ou o versionlib .bin)." % os.path.basename(archive))


def _open_tree(source, tmp_parent, tag):
    """A picked file -> (kind, root): ('zip', zip path) for a .zip, ('dir', folder) for an extracted archive or the
    folder of a picked .exe/.bin."""
    low = source.lower()
    if low.endswith(".zip"):
        try:
            with zipfile.ZipFile(source):
                pass
            return "zip", source
        except zipfile.BadZipFile:
            raise SkyError("%s está danificado (zip inválido)." % os.path.basename(source))
    if low.endswith((".7z", ".rar", ".tar", ".gz", ".xz", ".tgz")):
        dest = os.path.join(tmp_parent, "%s-%s" % (tag, datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f")))
        os.makedirs(dest)
        _tar_extract(source, dest)
        return "dir", dest
    return "dir", os.path.dirname(source)


def _list_tree(kind, root):
    """[(relative path with /, source)] of every file in a zip or under a folder."""
    out = []
    if kind == "zip":
        with zipfile.ZipFile(root) as z:
            for info in z.infolist():
                if not info.is_dir() and _safe_parts(info.filename):
                    out.append(("/".join(_safe_parts(info.filename)), _Src(root, info.filename)))
        return out
    for dp, _, files in os.walk(root):
        for n in files:
            p = os.path.join(dp, n)
            out.append((os.path.relpath(p, root).replace("\\", "/"), _Src(path=p)))
    return out


def _skse_pick(files, vt):
    """files: [(path with / relative to the SKSE folder, source)] -> the files that go in the game folder."""
    want = skse_dll_name(vt).lower()
    top = [(rel, src) for rel, src in files if "/" not in rel]
    dlls = [rel for rel, _ in top if rel.lower().endswith(".dll") and rel.lower().startswith("skse64_1_")]
    if want not in [d.lower() for d in dlls]:
        raise SkyError("Esse SKSE é para outra versão do Skyrim (%s). O seu SkyrimSE.exe é %d.%d.%d: baixe o SKSE "
                       "dessa versão em %s." % (", ".join(dlls) or "sem skse64_*.dll", vt[0], vt[1], vt[2], SKSE_SITE))
    out = [(rel, src) for rel, src in top if rel.lower().endswith((".dll", ".exe"))]
    out += [(os.path.join(*rel.split("/")), src) for rel, src in files if rel.lower().startswith("data/scripts/")]
    return out


def skse_entries(source, vt, tmp_parent, game=None):
    """The SKSE64 files for this Skyrim build, from what the player picked: the SKSE archive (.7z/.zip from the SKSE
    site or Nexus) or the skse64_loader.exe of an extracted one. -> [(path inside the game folder, source)]"""
    if source.lower().endswith(".exe"):
        if os.path.basename(source).lower() != "skse64_loader.exe":
            raise SkyError("Escolha o skse64_loader.exe (ou o arquivo .7z/.zip do SKSE).")
        base = os.path.dirname(os.path.abspath(source))
        if game and _same(base, game):
            raise SkyError("Esse skse64_loader.exe já é o que está na pasta do Skyrim. Escolha o SKSE baixado (o .7z/.zip, "
                           "ou a pasta extraída dele).")
        files = [(n, _Src(path=os.path.join(base, n))) for n in os.listdir(base) if os.path.isfile(os.path.join(base, n))]
        scripts = os.path.join(base, "Data", "Scripts")
        for dp, _, names in os.walk(scripts):
            for n in names:
                p = os.path.join(dp, n)
                files.append((os.path.relpath(p, base).replace("\\", "/"), _Src(path=p)))
        return _skse_pick(files, vt)
    kind, root = _open_tree(source, tmp_parent, "skse")
    files = _list_tree(kind, root)
    loaders = [rel for rel, _ in files if rel.lower().rsplit("/", 1)[-1] == "skse64_loader.exe"]
    if len(loaders) != 1:
        raise SkyError("Isso não parece o SKSE64: escolha o arquivo baixado do SKSE (.7z ou .zip) ou o skse64_loader.exe "
                       "de dentro dele.")
    base = loaders[0][:-len("skse64_loader.exe")]
    return _skse_pick([(rel[len(base):], src) for rel, src in files if rel.startswith(base)], vt)


def addrlib_entries(source, vt, tmp_parent):
    """versionlib-<build>.bin for this Skyrim build, from the Address Library archive (.zip) or the .bin itself."""
    want = addrlib_name(vt).lower()
    if source.lower().endswith(".bin"):
        if os.path.basename(source).lower() != want:
            raise SkyError("Esse .bin é de outra versão do Skyrim (%s); o seu precisa do %s." % (os.path.basename(source), addrlib_name(vt)))
        return [(os.path.join("Data", "SKSE", "Plugins", addrlib_name(vt)), _Src(path=source))]
    kind, root = _open_tree(source, tmp_parent, "addrlib")
    if kind == "dir" and not source.lower().endswith((".7z", ".rar", ".tar", ".gz", ".xz", ".tgz")):
        raise SkyError("Escolha o arquivo da Address Library (.zip/.7z) ou o %s." % addrlib_name(vt))
    files = _list_tree(kind, root)
    hit = [src for rel, src in files if rel.lower().rsplit("/", 1)[-1] == want]
    if not hit:
        have = sorted({rel.rsplit("/", 1)[-1] for rel, _ in files if rel.lower().rsplit("/", 1)[-1].startswith("versionlib-")})
        raise SkyError("Essa Address Library não tem o arquivo do seu Skyrim (%s). %s Baixe o \"All in one (Anniversary "
                       "Edition)\" em %s." % (addrlib_name(vt), ("Ela tem: %s." % ", ".join(have[-4:])) if have else
                                              "Não achei nenhum versionlib .bin nela.", ADDRLIB_PAGE))
    return [(os.path.join("Data", "SKSE", "Plugins", addrlib_name(vt)), hit[0])]


# ====================================================================== install / remove
def _backup_saves(docs, local, log):
    dirs = saves_dirs(docs)
    if not dirs:
        log("Nenhuma pasta de saves do Skyrim encontrada (nada para copiar).")
        return None
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest_root = os.path.join(state_dir(local), "backup-saves-%s" % stamp)
    for d in dirs:
        size = 0
        for dp, _, files in os.walk(d):
            for n in files:
                try:
                    size += os.path.getsize(os.path.join(dp, n))
                except OSError:
                    pass
        if size > MAX_SAVES_BACKUP:
            log("Saves em %s têm %.1f GB: grande demais para copiar aqui; faça uma cópia à mão." % (d, size / 1e9))
            continue
        dest = os.path.join(dest_root, os.path.basename(os.path.dirname(d)))
        shutil.copytree(d, dest)
        log("Backup dos saves: %s (%.0f MB)" % (dest, size / 1e6))
    return dest_root if os.path.isdir(dest_root) else None


def install(game, local, docs=None, skycraft_zip=None, skse=None, addrlib=None, log=print, running=None,
            replace_skse=False):
    """Installs SkyCraft (and SKSE / the Address Library when they were picked) into this Skyrim. Raises SkyError with
    nothing left half-done. replace_skse: an SKSE of another build already in the folder is kept as a backup (Remover
    puts it back) instead of stopping the install."""
    running = running or FI.is_running
    docs = docs or documents_dir()
    if not is_skyrim_dir(game):
        raise SkyError("Escolha a pasta do Skyrim Special Edition (a que tem o SkyrimSE.exe).")
    game = os.path.abspath(game)
    ver = exe_version(os.path.join(game, "SkyrimSE.exe"))
    vt = parse_version(ver)
    if runtime_of(vt) != "ae":
        raise SkyError("O SkyrimSE.exe é a versão %s. O SkyCraft só funciona na 1.6 ou 1.7 (o runtime da Anniversary "
                       "Edition, que a Steam instala hoje); a 1.5.97 e o Skyrim VR não servem." % (ver or "não reconhecida"))
    if store_of(game) == "gamepass":
        raise SkyError("Este é o Skyrim do Xbox / Game Pass: o SKSE não funciona nele, então o SkyCraft também não.")
    if running("SkyrimSE.exe") or running("skse64_loader.exe"):
        raise SkyError("Feche o Skyrim antes de instalar.")
    if mc_running():
        raise SkyError("Feche o Minecraft do SkyCraft antes de instalar.")
    old = load_manifest(local)
    if old is not None:
        raise SkyError("Já existe uma instalação do SkyCraft registrada (%s). Use Remover antes de instalar de novo."
                       % old.get("Game", "?"))
    if os.path.exists(manifest_path(local)):
        log("O registro anterior estava danificado e foi guardado em %s" % FI._set_aside(manifest_path(local), "danificado"))
    if not skycraft_zip:
        raise SkyError("Falta o %s." % ZIP_NAME)
    log("Skyrim: %s (SkyrimSE.exe %s, %s)" % (game, ver, STORE_LABEL.get(store_of(game))))
    tmp = os.path.join(state_dir(local), "tmp")
    os.makedirs(tmp, exist_ok=True)
    m = None
    try:
        entries = [(rel, src, "skycraft") for rel, src in skycraft_entries(skycraft_zip)]
        names = {n.lower() for n in os.listdir(game)}
        if skse:
            entries += [(rel, src, "skse") for rel, src in skse_entries(skse, vt, tmp, game)]
        elif not ("skse64_loader.exe" in names and skse_dll_name(vt).lower() in names):
            raise SkyError("Falta o SKSE64 para o Skyrim %s: escolha o arquivo do SKSE baixado em %s." % (ver, SKSE_SITE))
        if addrlib:
            entries += [(rel, src, "addrlib") for rel, src in addrlib_entries(addrlib, vt, tmp)]
        elif not os.path.isfile(os.path.join(plugins_dir(game), addrlib_name(vt))):
            raise SkyError("Falta a Address Library para o Skyrim %s (%s): escolha o arquivo baixado (\"All in one "
                           "(Anniversary Edition)\")." % (ver, addrlib_name(vt)))
        # what's there already: the same file is left alone (and not recorded: it isn't ours), a different one stops it
        # (an old SKSE's files only with replace_skse: backed up, and Remover puts them back)
        plan, conflicts, seen = [], [], set()
        for rel, src, origin in entries:
            key = os.path.normcase(rel)
            if key in seen:
                continue
            seen.add(key)
            target = os.path.join(game, rel)
            sha = src.sha256()
            if os.path.exists(target):
                if os.path.isfile(target) and FI.sha256_file(target) == sha:
                    continue
                if origin == "skse" and replace_skse and os.path.isfile(target):
                    plan.append((rel, src, sha, True))
                    continue
                conflicts.append((rel, origin))
            else:
                plan.append((rel, src, sha, False))
        if conflicts:
            skse_c = any(o == "skse" for _, o in conflicts)
            raise SkyError("Instalação interrompida para não sobrescrever arquivos diferentes que já existem: %s%s.%s"
                           % (", ".join(r for r, _ in conflicts[:6]), " e mais %d" % (len(conflicts) - 6) if len(conflicts) > 6 else "",
                              " Se for um SKSE de outra versão, marque 'Trocar o SKSE antigo' (faz backup e o Remover devolve)."
                              if skse_c else " Se for um SkyCraft de outra versão, tire-o pelo gerenciador de mods que o colocou."))
        backup = _backup_saves(docs, local, log)
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        m = {"Version": "0.6.5", "SkyCraft": VERSION, "Game": game, "SkyrimVersion": ver,
             "Created": datetime.datetime.now().isoformat(timespec="seconds"), "Status": "instalando", "Files": [],
             "Backups": [], "SavesBackup": backup}
        _write_manifest(local, m)              # the record comes first: an install cut in half can still be removed
        made_dirs = []
        try:
            for rel, src, sha, replace in plan:
                target = os.path.join(game, rel)
                d = os.path.dirname(target)
                missing = []
                while d and not os.path.isdir(d):
                    missing.append(d)
                    d = os.path.dirname(d)
                for x in reversed(missing):
                    os.mkdir(x)
                    made_dirs.append(x)
                if replace:
                    bak = "%s.antes-fusionbridge-%s" % (rel, stamp)
                    m["Backups"].append({"Original": rel, "Backup": bak})
                    _write_manifest(local, m)
                    os.replace(target, os.path.join(game, bak))
                    log("Backup do SKSE antigo: %s" % bak)
                m["Files"].append({"Path": rel, "SHA256": sha})
                _write_manifest(local, m)
                with open(target + ".fusionbridge-tmp", "wb") as f:
                    f.write(src.data())
                os.replace(target + ".fusionbridge-tmp", target)
                log("Instalado: %s" % rel)
            m["Status"] = "instalado"
            _write_manifest(local, m)
        except BaseException:
            for item in reversed(m["Files"]):
                for p in (os.path.join(game, item["Path"]), os.path.join(game, item["Path"]) + ".fusionbridge-tmp"):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
            for b in m["Backups"]:
                o, k = os.path.join(game, b["Original"]), os.path.join(game, b["Backup"])
                if os.path.exists(k) and not os.path.exists(o):
                    os.replace(k, o)
            for d in reversed(made_dirs):
                try:
                    os.rmdir(d)
                except OSError:
                    pass
            try:
                os.remove(manifest_path(local))
            except OSError:
                pass
            raise
    except PermissionError as e:
        raise SkyError("O Windows não deixou gravar em %s (pasta protegida). Feche o FusionBridge e abra de novo como "
                       "administrador." % (getattr(e, "filename", None) or game))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    log("SkyCraft %s instalado (%d arquivos)." % (VERSION, len(m["Files"])))
    return {"files": len(m["Files"]), "backup": m.get("SavesBackup"), "backups": len(m["Backups"])}


def remove(local, log=print, running=None):
    """Takes out the files install() put (only those still unchanged). Keeps %LOCALAPPDATA%\\SkyCraft (the Microsoft
    sign-in and the SkyCraft world) and the saves backup."""
    running = running or FI.is_running
    m = load_manifest(local)
    if m is None:
        if os.path.exists(manifest_path(local)):
            raise SkyError("O registro da instalação do SkyCraft está danificado (%s)." % manifest_path(local))
        raise SkyError("Não há instalação do SkyCraft registrada pelo FusionBridge.")
    game = m.get("Game") or ""
    if running("SkyrimSE.exe") or running("skse64_loader.exe"):
        raise SkyError("Feche o Skyrim antes de remover.")
    backups = [b for b in (m.get("Backups") or []) if isinstance(b, dict)]
    for rel in [item["Path"] for item in m["Files"]] + [b.get("Original", "") for b in backups] + [b.get("Backup", "") for b in backups]:
        if _safe_parts(rel) is None:
            raise SkyError("Caminho inesperado no registro: %s" % rel)
    kept = []
    for item in m["Files"]:
        p = os.path.join(game, item["Path"])
        if not os.path.exists(p):
            continue
        try:
            if FI.sha256_file(p) != str(item.get("SHA256", "")).upper():
                log("Preservado (foi alterado depois): %s" % item["Path"])
                kept.append(item)
                continue
            os.remove(p)
            log("Removido: %s" % item["Path"])
        except OSError as e:
            log("Não consegui remover %s (%s)" % (item["Path"], e.strerror or e))
            kept.append(item)
    for b in backups:
        o, k = os.path.join(game, b["Original"]), os.path.join(game, b["Backup"])
        if os.path.exists(k) and not os.path.exists(o):
            os.replace(k, o)
            log("Devolvido: %s" % b["Original"])
        elif os.path.exists(k):
            log("Backup mantido (já existe outro arquivo no lugar): %s" % b["Backup"])
    for d in (os.path.join(plugins_dir(game), "SkyCraft"), plugins_dir(game), os.path.join(game, "Data", "SKSE")):
        try:
            os.rmdir(d)                          # only when empty
        except OSError:
            pass
    if kept:
        m["Files"] = kept
        m["Backups"] = [b for b in backups if os.path.exists(os.path.join(game, b["Backup"]))]
        _write_manifest(local, m)
        log("Alguns arquivos ficaram (alterados ou em uso). O Remover pode ser usado de novo.")
    else:
        os.remove(manifest_path(local))
        log("SkyCraft removido. A conta Microsoft e o mundo do SkyCraft continuam em %s." % mc_dir(local))
    return {"kept": kept}


# ====================================================================== SkyCraft's Minecraft
def prepare_minecraft(game, local, log=print):
    """Unpacks SkyCraft-Minecraft.zip to %LOCALAPPDATA%\\SkyCraft like SkyCraft.dll does (the same jar clean-up, the
    same Prism settings and bundle.stamp), so the Microsoft sign-in can happen before Skyrim opens. Prism's own data
    there (account, Minecraft's files, the SkyCraft world) is kept."""
    src = bundle_path(game)
    if not os.path.isfile(src):
        raise SkyError("Falta o SkyCraft-Minecraft.zip (instale o SkyCraft primeiro).")
    if mc_running():
        raise SkyError("O Minecraft do SkyCraft está aberto: feche o Skyrim e espere ele fechar.")
    root = mc_dir(local)
    stamp = bundle_stamp(game)
    try:
        with open(os.path.join(root, "bundle.stamp"), "r", encoding="utf-8", errors="replace") as f:
            if f.readline().strip() == stamp and os.path.isfile(prism_exe(local)):
                return "já preparado"
    except OSError:
        pass
    os.makedirs(root, exist_ok=True)
    mods = os.path.join(root, "Prism", "instances", "SkyCraft", ".minecraft", "mods")
    try:
        for n in os.listdir(mods):
            if n.startswith(("skycraft-", "fabric-api-", "e4mc-")):
                os.remove(os.path.join(mods, n))
    except OSError:
        pass
    log("Desempacotando o Minecraft do SkyCraft em %s…" % root)
    try:
        with zipfile.ZipFile(src) as z:
            for info in z.infolist():
                parts = _safe_parts(info.filename)
                if parts is None:
                    raise SkyError("O SkyCraft-Minecraft.zip tem um caminho estranho (%s)." % info.filename)
                target = os.path.join(root, *parts)
                if info.is_dir():
                    os.makedirs(target, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with z.open(info) as fi, open(target + ".tmp", "wb") as fo:
                    shutil.copyfileobj(fi, fo)
                os.replace(target + ".tmp", target)
    except zipfile.BadZipFile:
        raise SkyError("O SkyCraft-Minecraft.zip está danificado: instale o SkyCraft de novo.")
    cfg = os.path.join(root, "Prism", "prismlauncher.cfg")
    if not os.path.isfile(cfg):
        shutil.copyfile(os.path.join(root, "defaults", "prismlauncher.cfg"), cfg)
    else:
        with open(cfg, "rb") as f:
            text = f.read().decode("utf-8", "replace")
        if "LowMemWarning=" not in text:
            at = text.find("[General]")
            if at >= 0:
                eol = text.find("\n", at)
                text = text[:eol + 1] + "LowMemWarning=false\n" + text[eol + 1:] if eol >= 0 else text + "\nLowMemWarning=false\n"
            else:
                text += "\n[General]\nLowMemWarning=false\n"
            with open(cfg, "wb") as f:
                f.write(text.encode("utf-8"))
    with open(os.path.join(root, "bundle.stamp"), "w", encoding="utf-8") as f:
        f.write(stamp)
    log("Minecraft do SkyCraft pronto.")
    return "preparado"


def _detached():
    return (0x00000008 | 0x00000200) if IS_WINDOWS else 0     # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP


def sign_in(local, popen=subprocess.Popen):
    """Opens SkyCraft's Prism on its own window, for the Microsoft sign-in (once)."""
    exe = prism_exe(local)
    if not os.path.isfile(exe):
        raise SkyError("O Minecraft do SkyCraft ainda não foi preparado.")
    return popen([exe], cwd=os.path.dirname(exe), creationflags=_detached(), close_fds=True)


def _steam_exe():
    if not IS_WINDOWS:
        return None
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
            p = winreg.QueryValueEx(k, "SteamExe")[0]
        p = os.path.normpath(p)
        return p if os.path.isfile(p) else None
    except OSError:
        return None


def launch(game, log=print, popen=subprocess.Popen, running=None, steam_wait_s=40, sleep=time.sleep):
    """Opens Skyrim through skse64_loader.exe (SkyCraft only loads with SKSE). The Steam version needs Steam open
    first: it is opened (minimized) and waited for. Run off the window's thread (it can wait for Steam)."""
    running = running or FI.is_running
    loader = os.path.join(game or "", "skse64_loader.exe")
    if not os.path.isfile(loader):
        raise SkyError("Falta o skse64_loader.exe na pasta do Skyrim (instale o SKSE64).")
    if running("SkyrimSE.exe"):
        raise SkyError("O Skyrim já está aberto.")
    if store_of(game) == "steam" and not running("steam.exe"):
        steam = _steam_exe()
        if not steam:
            raise SkyError("Abra a Steam antes de jogar: o Skyrim da Steam só abre com ela.")
        log("Abrindo a Steam…")
        popen([steam, "-silent"], creationflags=_detached(), close_fds=True)
        t = 0.0
        while not running("steam.exe") and t < steam_wait_s:
            sleep(1.0)
            t += 1.0
        if not running("steam.exe"):
            raise SkyError("A Steam não abriu a tempo. Abra a Steam e clique em Jogar de novo.")
        sleep(6.0)                               # let Steam sign in before the game asks for it
    popen([loader], cwd=game, creationflags=_detached(), close_fds=True)
    log("Skyrim aberto pelo SKSE (skse64_loader.exe).")
    return True
