"""FusionBridge.exe boot. FusionBridge.exe is python.org's signed pythonw.exe; FusionBridge._pth puts this folder
on its path and turns the site module on, and site imports this module at startup. Here the app starts: the
native window (fb_app.py), or with "-X fb=server" the headless hub (fusionbridge.py, HTTP API for development).

Options go as -X because Python reads the command line before this runs and ends on options it doesn't know."""
import os
import sys


def _only_app_paths():
    """Keep sys.path inside the FusionBridge folder. CPython 3.13 still adds the user's own site-packages
    (%APPDATA%\\Python\\Python313) next to a ._pth; whatever another Python install put there must not shadow
    or change the app."""
    root = os.path.normcase(os.path.dirname(os.path.abspath(sys.executable))).rstrip("\\/") + os.sep
    sys.path[:] = [p for p in sys.path if p and os.path.normcase(os.path.abspath(p)).startswith(root)]


def _boot():
    exe = os.path.splitext(os.path.basename(sys.executable or ""))[0].lower()
    if exe != "fusionbridge":
        return            # any other interpreter that happens to see this folder: do nothing
    try:
        _only_app_paths()
        if sys._xoptions.get("fb") == "server":
            import fusionbridge
            fusionbridge.main()
        else:
            import fb_app
            fb_app.main()
        code = 0
    except SystemExit as e:
        code = e.code if isinstance(e.code, int) else 0
    except BaseException:
        import traceback
        text = traceback.format_exc()
        path = None
        try:
            base = os.environ.get("LOCALAPPDATA") or os.path.dirname(sys.executable)
            d = os.path.join(base, "FusionBridge")
            os.makedirs(d, exist_ok=True)
            path = os.path.join(d, "FusionBridge-erro.log")
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
        except OSError:
            pass
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, "O FusionBridge encontrou um erro e vai fechar.\n\n%s\n%s" % (
                text.strip().splitlines()[-1], ("Detalhes em: " + path) if path else ""), "FusionBridge", 0x10)
        except Exception:
            pass
        code = 1
    sys.stdout and sys.stdout.flush()
    os._exit(code)    # never fall through into the interactive interpreter


_boot()
