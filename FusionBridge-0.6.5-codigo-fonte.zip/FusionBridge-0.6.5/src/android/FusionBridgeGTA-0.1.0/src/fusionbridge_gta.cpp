#include "fusionbridge_gta.h"
#include "bridge_client.h"
#include "protocol.h"

#include <atomic>
#include <cstring>
#include <mutex>

namespace {
std::mutex g_api_mu;
FusionBridgeGtaApi g_api{};
fbgta::BridgeClient g_bridge;
std::atomic<bool> g_started{false};
std::uint32_t g_state_divider = 0;

void stub_log(const char*) {}
int stub_get_player_state(float*, float*, float*, float*, float*, int*, float*) { return 0; }
int stub_spawn(const char*, std::int64_t, float, float, float) { return 0; }
void stub_move(std::int64_t, float, float, float) {}
void stub_remove(std::int64_t) {}
void stub_explosion(float, float, float, float, float) {}
int stub_block(const char*, std::int64_t, float, float, float) { return 0; }

FusionBridgeGtaApi make_safe_api() {
    FusionBridgeGtaApi a{};
    a.abi_version = 1;
    a.log = stub_log;
    a.get_player_state = stub_get_player_state;
    a.spawn_proxy_entity = stub_spawn;
    a.move_proxy_entity = stub_move;
    a.remove_proxy_entity = stub_remove;
    a.create_explosion = stub_explosion;
    a.place_proxy_block = stub_block;
    a.remove_proxy_block = stub_remove;
    return a;
}

FusionBridgeGtaApi api_copy() {
    std::lock_guard<std::mutex> lock(g_api_mu);
    return g_api;
}

void apply_event(const fbgta::Event& e, const FusionBridgeGtaApi& api) {
    switch (e.type) {
        case fbgta::Event::Type::TntExplosion:
        case fbgta::Event::Type::Explosion:
            if (api.create_explosion) api.create_explosion(e.x, e.y, e.z, e.radius, e.damage);
            break;
        case fbgta::Event::Type::EntitySpawn:
            if (api.spawn_proxy_entity) api.spawn_proxy_entity(e.kind.c_str(), e.id, e.x, e.y, e.z);
            break;
        case fbgta::Event::Type::EntityMove:
            if (api.move_proxy_entity) api.move_proxy_entity(e.id, e.x, e.y, e.z);
            break;
        case fbgta::Event::Type::EntityRemove:
            if (api.remove_proxy_entity) api.remove_proxy_entity(e.id);
            break;
        case fbgta::Event::Type::BlockPlace:
            if (api.place_proxy_block) api.place_proxy_block(e.block_id.c_str(), e.id, e.x, e.y, e.z);
            break;
        case fbgta::Event::Type::BlockBreak:
            if (api.remove_proxy_block) api.remove_proxy_block(e.id);
            break;
        default:
            break;
    }
}
} // namespace

extern "C" FBGTA_EXPORT void FusionBridgeGTA_SetApi(const FusionBridgeGtaApi* api) {
    FusionBridgeGtaApi next = make_safe_api();
    if (api && api->abi_version == 1) {
        // Copy only the published v1 struct. Null callbacks fall back to safe no-ops.
        next = *api;
        if (!next.log) next.log = stub_log;
        if (!next.get_player_state) next.get_player_state = stub_get_player_state;
        if (!next.spawn_proxy_entity) next.spawn_proxy_entity = stub_spawn;
        if (!next.move_proxy_entity) next.move_proxy_entity = stub_move;
        if (!next.remove_proxy_entity) next.remove_proxy_entity = stub_remove;
        if (!next.create_explosion) next.create_explosion = stub_explosion;
        if (!next.place_proxy_block) next.place_proxy_block = stub_block;
        if (!next.remove_proxy_block) next.remove_proxy_block = stub_remove;
    }
    {
        std::lock_guard<std::mutex> lock(g_api_mu);
        g_api = next;
    }
    fbgta::set_log_callback(next.log);
}

extern "C" FBGTA_EXPORT int FusionBridgeGTA_Init(void) {
    bool expected = false;
    if (!g_started.compare_exchange_strong(expected, true)) return 1;
    {
        std::lock_guard<std::mutex> lock(g_api_mu);
        if (g_api.abi_version != 1) g_api = make_safe_api();
    }
    fbgta::set_log_callback(api_copy().log);
    return g_bridge.start() ? 1 : 0;
}

extern "C" FBGTA_EXPORT void FusionBridgeGTA_Tick(void) {
    if (!g_started.load()) return;
    const FusionBridgeGtaApi api = api_copy();

    // Apply at most 64 events per GTA frame to prevent a TNT storm from freezing a frame.
    fbgta::Event e;
    for (int i = 0; i < 64 && g_bridge.pop(e); ++i) apply_event(e, api);

    // About 10 Hz at 60 FPS. Player-state packets are deliberately low-rate/ECO.
    if (++g_state_divider >= 6) {
        g_state_divider = 0;
        float x=0, y=0, z=0, yaw=0, health=0, vehicle_health=0;
        int in_vehicle=0;
        if (api.get_player_state && api.get_player_state(&x,&y,&z,&yaw,&health,&in_vehicle,&vehicle_health)) {
            g_bridge.queue_player_state(fbgta::make_player_state(x,y,z,yaw,health,in_vehicle,vehicle_health));
        }
    }
}

extern "C" FBGTA_EXPORT void FusionBridgeGTA_Shutdown(void) {
    if (!g_started.exchange(false)) return;
    g_bridge.stop();
}

extern "C" FBGTA_EXPORT const char* FusionBridgeGTA_Version(void) {
    return "0.1.0";
}
