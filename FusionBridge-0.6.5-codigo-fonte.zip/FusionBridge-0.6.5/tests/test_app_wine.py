"""End-to-end test of the real FusionBridge.exe (signed Python runtime + app/) under Wine, on a virtual display.

A fake Minecraft (passthrough WebSocket) and a fake GTA script connect to the hub that runs INSIDE the app; the
test clicks the window with xdotool and checks that each click reaches the right game, then the game picker
(Host card -> installed games -> choose; a new fusion mod file recognised without restarting), the single
instance guard, that closing the window ends the process, and the -X fb=server / -X fb=elevated starts.
Screenshots go to $SHOTS (default: a temp dir).
Needs: wine64 (or /usr/lib/wine/wine64), Xvfb, xdotool, ImageMagick (import); run tools/build_app.py first.
usage: python3 -I tests/test_app_wine.py
"""
import json, os, shutil, socket, struct, subprocess, sys, tempfile, threading, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.argv = sys.argv[:1]
import test_fusion as tf  # noqa: E402  (FakeMC, GTA)

WINE = shutil.which("wine64") or "/usr/lib/wine/wine64"
SHOTS = os.environ.get("SHOTS") or tempfile.mkdtemp(prefix="fb-shots-")
os.makedirs(SHOTS, exist_ok=True)
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(detail)[:300]), flush=True)


def sh(*args, **kw):
    return subprocess.run(list(args), capture_output=True, text=True, **kw)


class Recorder(tf.GTA):
    """The fake GTA script, keeping everything the hub sends it."""

    def __init__(self):
        super().__init__()
        self.all = []
        self.alive = True
        threading.Thread(target=self.loop, daemon=True).start()

    def loop(self):
        f = 0
        while self.alive:
            f += 1
            try:
                self.send({"type": "fusion_cam", "f": f, "c": [2490.0, -1670.0, 15.0], "r": [90.0, -10.0, 0.0], "fov": 55.4,
                           "p": [2491.0, -1668.0, 14.3], "h": 45.0, "veh": 0, "pg": 13.3})
                self.pump(0.03)
                self.all.extend(self.q)
                self.q.clear()
            except OSError:
                return

    def seen(self, pred, timeout=6.0):
        end = time.time() + timeout
        while time.time() < end:
            for m in list(self.all):
                if pred(m):
                    return m
            time.sleep(0.1)
        return None


def port_open(port):
    s = socket.socket()
    try:
        s.settimeout(1)
        s.connect(("127.0.0.1", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def fake_pc(env):
    """A Steam with Portal 2 and a .minecraft folder inside the Wine prefix, for the game picker. Returns the
    prefix's %LOCALAPPDATA%\\FusionBridge folder."""
    # the first wine command also creates the prefix if it isn't there yet
    sh(WINE, "reg", "add", "HKCU\\Software\\Valve\\Steam", "/v", "SteamPath", "/t", "REG_SZ", "/d", "c:/FBTestSteam", "/f", env=env)
    c = os.path.join(env["WINEPREFIX"], "drive_c")
    users = os.path.join(c, "users")
    user = next((u for u in sorted(os.listdir(users)) if u.lower() != "public"), "root") if os.path.isdir(users) else "root"
    prof = os.path.join(users, user)
    steam = os.path.join(c, "FBTestSteam")
    os.makedirs(os.path.join(steam, "steamapps", "common", "Portal 2"), exist_ok=True)
    with open(os.path.join(steam, "steamapps", "appmanifest_620.acf"), "w") as f:
        f.write('"AppState"\n{\n\t"appid"\t\t"620"\n\t"name"\t\t"Portal 2"\n\t"StateFlags"\t\t"4"\n\t"installdir"\t\t"Portal 2"\n}\n')
    # a Steam Skyrim SE 1.7.104 with SKSE and the Address Library, without SkyCraft (for the Mods fusion page)
    sky = os.path.join(steam, "steamapps", "common", "Skyrim Special Edition")
    os.makedirs(os.path.join(sky, "Data", "SKSE", "Plugins"), exist_ok=True)
    exe = bytearray(b"MZ" + b"\0" * 60000)
    info = b"\xbd\x04\xef\xfe\x00\x00\x01\x00" + struct.pack("<IIII", (1 << 16) | 7, 104 << 16, (1 << 16) | 7, 104 << 16)
    exe[50000:50000 + len(info)] = info
    for name, data in (("SkyrimSE.exe", bytes(exe)), ("steam_api64.dll", b"x"), ("skse64_loader.exe", b"MZ"),
                       ("skse64_1_7_104.dll", b"MZ"), (os.path.join("Data", "SKSE", "Plugins", "versionlib-1-7-104-0.bin"), b"b")):
        with open(os.path.join(sky, name), "wb") as f:
            f.write(data)
    with open(os.path.join(steam, "steamapps", "appmanifest_489830.acf"), "w") as f:
        f.write('"AppState"\n{\n\t"appid"\t\t"489830"\n\t"name"\t\t"The Elder Scrolls V: Skyrim Special Edition"\n'
                '\t"StateFlags"\t\t"4"\n\t"installdir"\t\t"Skyrim Special Edition"\n}\n')
    os.makedirs(os.path.join(prof, "AppData", "Roaming", ".minecraft"), exist_ok=True)
    fb = os.path.join(prof, "AppData", "Local", "FusionBridge")
    os.makedirs(fb, exist_ok=True)
    for n in ("jogos.json", "skycraft.json", "preferencias.json", os.path.join("fusion-mods", "portal-teste.json")):
        try:
            os.remove(os.path.join(fb, n))
        except OSError:
            pass
    open(os.path.join(fb, "atalho-oferecido"), "w").close()   # no Desktop-shortcut banner: the click positions stay put
    return fb


def read_choice(fb, role):
    try:
        with open(os.path.join(fb, "jogos.json"), encoding="utf-8") as f:
            return (json.load(f).get(role) or {}).get("name")
    except (OSError, ValueError):
        return None


def wait_choice(fb, role, want, timeout=6.0):
    end = time.time() + timeout
    while time.time() < end:
        got = read_choice(fb, role)
        if got == want:
            return got
        time.sleep(0.3)
    return read_choice(fb, role)


def main():
    if not os.path.isfile(os.path.join(ROOT, "FusionBridge.exe")):
        print("rode tools/build_app.py antes"); sys.exit(2)
    disp = ":%d" % (90 + os.getpid() % 9)
    xvfb = subprocess.Popen(["Xvfb", disp, "-screen", "0", "1400x1000x24"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    env = dict(os.environ, DISPLAY=disp, WINEDEBUG="-all", WINEPREFIX=os.environ.get("WINEPREFIX") or os.path.join(tempfile.gettempdir(), "fb-wineprefix"))
    env["PATH"] = "/usr/lib/wine:" + env.get("PATH", "")
    os.environ.update(DISPLAY=disp)
    time.sleep(1.5)
    fbdir = fake_pc(env)
    mc = tf.FakeMC()
    app = subprocess.Popen([WINE, "start", "/wait", "/unix", os.path.join(ROOT, "FusionBridge.exe")], cwd=ROOT, env=env,
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    g = None
    try:
        for _ in range(240):
            try:
                g = Recorder()
                break
            except OSError:
                time.sleep(0.5)
        check("the app starts and its hub accepts the GTA script", g is not None)
        if g is None:
            return
        g.send({"type": "fusion_hello"})
        g.send({"type": "fusion_asi", "loaded": 1, "version": 600, "sa_ok": 1, "reshade": 1, "frame": 1, "bb_w": 1920,
                "bb_h": 1080, "uploads": 10, "pad_hook": 1, "hud_hook": 1, "effect": 1})
        g.send({"type": "player_state", "side": "gta", "x": 2491.0, "y": -1668.0, "z": 13.0, "heading": 90, "health": 73, "hud": 1})
        check("the hub inside the app linked to Minecraft", g.seen(lambda m: m.get("type") == "fusion_state" and m.get("mc") == 1, 15) is not None)
        check("Minecraft got GTA's camera through the app", mc.wait("cam", timeout=10) is not None)
        wid = None
        for _ in range(60):
            r = sh("xdotool", "search", "--name", "FusionBridge PC", env=env)
            if r.stdout.strip():
                wid = r.stdout.split()[0]
                break
            time.sleep(0.5)
        check("the app window exists (no browser)", wid is not None)
        geo = sh("xdotool", "getwindowgeometry", wid, env=env).stdout
        pos = [int(v) for v in geo.split("Position:")[1].split()[0].split(",")]
        X, Y = pos

        def click(x, y, wait=1.2):
            sh("xdotool", "mousemove", str(X + x), str(Y + y), "click", "1", env=env)
            time.sleep(wait)

        def shot(name):
            sh("import", "-display", disp, "-window", "root", os.path.join(SHOTS, name + ".png"), env=env)
        time.sleep(2)
        shot("01-fusao")
        n = len(g.all)
        click(1082, 63)       # the "Fusao ligada" switch (page header, Ponte) -> off
        check("click: fusion off reaches GTA", g.seen(lambda m: m.get("type") == "fusion_state" and m.get("on") == 0) is not None)
        click(1082, 63)
        check("click: fusion on again", g.seen(lambda m: m.get("type") == "fusion_state" and m.get("on") == 1 and g.all.index(m) > n) is not None)
        click(732, 536)       # quick action "Mouse no Minecraft" -> GTA (armas do CJ)
        check("click: mouse -> GTA reaches GTA", g.seen(lambda m: m.get("type") == "fusion_state" and m.get("mouse") == "gta") is not None)
        shot("02-mouse-gta")
        click(120, 157)       # sidebar: Caos
        shot("03-caos")
        mc.take()
        click(495, 205)       # Caos, No Minecraft: TNT
        cmd = mc.wait("cmd", timeout=6)
        check("click: TNT reaches Minecraft", cmd is not None and "summon minecraft:tnt" in cmd.get("c", ""), cmd)
        click(495, 450)       # Caos, No GTA San Andreas: Explosao
        check("click: GTA explosion reaches GTA", g.seen(lambda m: m.get("type") == "command" and m.get("action") == "boom") is not None)
        second = subprocess.Popen([WINE, "start", "/wait", "/unix", os.path.join(ROOT, "FusionBridge.exe")], cwd=ROOT, env=env,
                                  stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            second.wait(30)
            check("a second FusionBridge.exe exits (single instance)", True)
        except subprocess.TimeoutExpired:
            second.kill()
            check("a second FusionBridge.exe exits (single instance)", False)
        wins = sh("xdotool", "search", "--name", "FusionBridge PC", env=env).stdout.split()
        check("still one window", len(wins) == 1, wins)
        # the game picker: Host card -> installed games -> the sentence on the right -> choose (Enter)
        click(120, 113)       # sidebar: Ponte (the Host/Secundario cards live there)
        click(446, 225, 3.0)  # Host card
        shot("06-seletor-host")
        click(300, 303)       # 3rd row: Portal 2 (no fusion mod; Skyrim (SkyCraft) is 1st, Minecraft (mod for the other side) 2nd)
        shot("07-portal-sem-mod")
        sh("xdotool", "key", "Return", env=env)
        check("picker: a game without a fusion mod can be chosen as Host", wait_choice(fbdir, "host", "Portal 2") == "Portal 2",
              read_choice(fbdir, "host"))
        shot("08-host-portal")
        click(446, 225, 2.0)
        click(300, 247)       # 2nd row: Minecraft
        sh("xdotool", "key", "Return", env=env)
        check("picker: Skyrim (SkyCraft) first, then Minecraft", wait_choice(fbdir, "host", "Minecraft: Java Edition") == "Minecraft: Java Edition",
              read_choice(fbdir, "host"))
        os.makedirs(os.path.join(fbdir, "fusion-mods"), exist_ok=True)
        with open(os.path.join(fbdir, "fusion-mods", "portal-teste.json"), "w", encoding="utf-8") as f:
            json.dump({"fusion_mod": 1, "id": "portal-teste", "name": "Portal Teste", "roles": ["host"], "game": {"steam": [620]}}, f)
        time.sleep(3)
        shot("09-mod-novo")
        click(446, 225, 2.0)
        click(300, 191)       # Portal 2 now has a Host fusion mod, so it is the 1st row
        shot("10-portal-com-mod")
        sh("xdotool", "key", "Return", env=env)
        check("a fusion mod file added while the app is open is recognised at once",
              wait_choice(fbdir, "host", "Portal 2") == "Portal 2", read_choice(fbdir, "host"))
        click(446, 225, 2.0)
        click(300, 247)       # Skyrim: 2nd of the games with a Host fusion mod (after Portal 2)
        sh("xdotool", "key", "Return", env=env)
        sky_name = "The Elder Scrolls V: Skyrim Special Edition"
        check("picker: Skyrim chosen as Host (SkyCraft)", wait_choice(fbdir, "host", sky_name) == sky_name, read_choice(fbdir, "host"))
        time.sleep(2.5)
        shot("13-ponte-skycraft")
        click(446, 225, 2.0)
        sh("xdotool", "key", "Escape", env=env)
        time.sleep(1)
        click(120, 245)       # sidebar: Instalar (only works if Esc closed the picker)
        shot("04-instalacao")
        sh("xdotool", "mousemove", str(X + 700), str(Y + 520), "click", "--repeat", "25", "--delay", "40", "5", env=env)
        time.sleep(1.5)
        shot("04b-instalacao-minecraft-automatico")
        click(120, 289)       # sidebar: Mods fusion (SkyCraft)
        time.sleep(3.0)
        shot("12-mods-fusion")
        try:
            with open(os.path.join(fbdir, "skycraft.json"), encoding="utf-8") as f:
                sky_game = json.load(f).get("game") or ""
        except (OSError, ValueError):
            sky_game = ""
        check("Mods fusion: the SkyCraft card found the Steam Skyrim by itself", sky_game.lower().rstrip("\\/").endswith("skyrim special edition"),
              sky_game)
        sh("xdotool", "mousemove", str(X + 700), str(Y + 520), "click", "--repeat", "18", "--delay", "40", "5", env=env)
        time.sleep(1.0)
        shot("12b-mods-skycraft-teclas")
        sh("xdotool", "mousemove", str(X + 700), str(Y + 520), "click", "--repeat", "30", "--delay", "40", "5", env=env)
        time.sleep(1.0)
        shot("12c-mods-fim")
        click(120, 333)       # sidebar: Desempenho
        time.sleep(1.5)
        shot("11-desempenho")
        sh("xdotool", "mousemove", str(X + 700), str(Y + 520), "click", "--repeat", "30", "--delay", "40", "5", env=env)
        time.sleep(1.0)
        shot("11b-desempenho-qualquer-jogo")
        click(120, 377)       # sidebar: Seguranca
        time.sleep(1.5)
        shot("05-seguranca")
        # close it like a user: Alt+F4 -> WM_SYSCOMMAND/SC_CLOSE -> WM_CLOSE (xdotool windowclose would just destroy
        # the X window behind Wine's back)
        click(600, 150, 0.5)
        sh("xdotool", "windowfocus", wid, env=env)
        sh("xdotool", "key", "--window", wid, "alt+F4", env=env)
        try:
            app.wait(20)
            closed = True
        except subprocess.TimeoutExpired:
            closed = False
        check("closing the window ends the app", closed)
        time.sleep(1)
        s = socket.socket()
        try:
            s.settimeout(1)
            s.connect(("127.0.0.1", 28765))
            freed = False
        except OSError:
            freed = True
        finally:
            s.close()
        check("... and frees the hub port", freed)
        # Python reads the command line before the app: the app's own options are -X fb=...
        srv = subprocess.Popen([WINE, "start", "/wait", "/unix", os.path.join(ROOT, "FusionBridge.exe"), "-X", "fb=server"], cwd=ROOT,
                               env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        up = False
        for _ in range(60):
            if port_open(28766):
                up = True
                break
            time.sleep(0.5)
        check("FusionBridge.exe -X fb=server starts the headless hub (API on 28766, no window)",
              up and not sh("xdotool", "search", "--name", "FusionBridge PC", env=env).stdout.strip())
        subprocess.run(["wineserver", "-k"], env=env, capture_output=True)
        srv.wait(20)
        elev = subprocess.Popen([WINE, "start", "/wait", "/unix", os.path.join(ROOT, "FusionBridge.exe"), "-X", "fb=elevated"], cwd=ROOT,
                                env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        seen = None
        for _ in range(60):
            seen = sh("xdotool", "search", "--name", "FusionBridge PC", env=env).stdout.split()
            if seen:
                break
            time.sleep(0.5)
        check("FusionBridge.exe -X fb=elevated (the 'Reabrir como administrador' relaunch) opens the window", bool(seen))
        subprocess.run(["wineserver", "-k"], env=env, capture_output=True)
        elev.wait(20)
    finally:
        if g:
            g.alive = False
        if app.poll() is None:
            app.kill()
        subprocess.run(["wineserver", "-k"], env=env, capture_output=True)
        xvfb.kill()
    print("capturas em", SHOTS)
    bad = [n for n, ok in results if not ok]
    print("\n%d/%d passaram" % (len(results) - len(bad), len(results)))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
