# FusionBridge PC — o Minecraft Java dentro do GTA San Andreas (e do Skyrim)

O **FusionBridge** é um app de Windows que junta dois jogos rodando ao mesmo tempo. O **GTA San Andreas** é o **Host** (fica na tela) e o **Minecraft Java** é o **Secundário** (é desenhado dentro do Host).

- A câmera do GTA comanda a câmera do Minecraft, e o Minecraft desenha o mundo dele exatamente desse ponto de vista.
- O chão do GTA vira chão invisível no Minecraft: blocos, mobs e itens ficam em cima das ruas de Los Santos.
- A imagem do Minecraft entra no GTA pela profundidade: um poste do GTA tapa a sua casa de blocos, e a casa tapa o carro atrás dela.
- O Steve fica no lugar do CJ a pé, e o mouse e as teclas 1–9 jogam o Minecraft.
- TNT e creeper explodem nos dois jogos, a pérola do Ender teleporta o CJ, e os blocos que você constrói viram parede para os carros.

Na página **Mods fusion**, o app também instala e abre o **SkyCraft** (Minecraft dentro do Skyrim, de chasmlol), outro mod que junta dois jogos de verdade.

Tudo fica numa janela própria, com barra lateral: **Ponte, Caos, Controles, Instalar, Mods fusion, Desempenho, Segurança, Diagnóstico e Log**. Nada abre no navegador, e o app é compatível com o **Controle inteligente de aplicativo** do Windows 11.

> Projeto de fã, para **single player**. Não use estes mods em servidores online (SA-MP/MTA).

---

## Instalação passo a passo

### 1. O que você precisa

| | |
|---|---|
| Windows | 10 ou 11, 64 bits |
| GTA San Andreas | de PC, **versão 1.0 US**, com o **[MoonLoader](https://www.blast.hk/moonloader/)** instalado. As versões da Steam e do Rockstar Launcher precisam de downgrade para a 1.0 |
| Minecraft Java | comprado numa conta Microsoft. No modo **automático** (padrão) é só isso: o app usa um Prism Launcher portátil que baixa o Minecraft 26.3, o Fabric 0.19.5 e o Java sozinho |
| (só no modo Minecraft Launcher) | o Minecraft Launcher aberto uma vez e o **Fabric Loader 0.19.5 para 26.3** pelo [instalador oficial do Fabric](https://fabricmc.net/use/installer/) |

Não precisa instalar Python, Java nem nada mais: o app já vem pronto.

### 2. Baixar

1. Na página **[Releases](../../releases)** deste repositório, baixe **`FusionBridge-PC-0.6.5.zip`**. O botão verde *Code → Download ZIP* baixa só o código-fonte, que não roda sozinho.
2. Clique com o botão direito no zip → **Extrair tudo** → escolha uma pasta sua, por exemplo `Documentos\FusionBridge`. Evite *Arquivos de Programas*, porque lá o Windows pede administrador.

### 3. Abrir o app

3. Abra o **`FusionBridge.exe`**. Se o Windows perguntar, o editor verificado é **"Python Software Foundation"**: o `FusionBridge.exe` é o Python oficial, e o código do app roda dentro dele. O motivo está em [`SEGURANCA-WINDOWS.md`](SEGURANCA-WINDOWS.md). Na primeira vez o app oferece criar o atalho com a logo na Área de Trabalho.

### 4. Instalar a fusão nos jogos

4. Vá na página **Instalar**. O app procura o GTA sozinho. Se não achar, clique em **Escolher gta_sa.exe…**. As bolinhas mostram o que já está pronto (verde) e o que falta.
5. No cartão **Minecraft Java**, deixe **Automático (Prism)** ou escolha **Minecraft Launcher**.
6. Feche o GTA e clique em **Instalar**. O app:
   - faz uma cópia dos saves do GTA (`%LOCALAPPDATA%\FusionBridge\backups`);
   - baixa dos sites oficiais o **ReShade 6.8.0 com add-on**, o **Fabric API**, dois arquivos de shader e, no modo automático, o **Prism Launcher 11.1.1 portátil**, e confere o SHA-256 de cada um;
   - coloca no GTA o `d3d9.dll` (ReShade), o `FusionBridgeSA.asi`, o efeito `FusionBridgeSA.fx` e o script `moonloader\FusionBridgeGTA.lua`;
   - prepara o Minecraft: a instância **FusionBridge** do Prism (modo automático) ou o perfil **FusionBridge - Minecraft no GTA SA** no Minecraft Launcher, sempre com pasta própria. Seus mundos normais não são tocados.
7. Modo automático: **Entrar na conta** (uma vez) e, no Prism, **Contas → Adicionar Microsoft**.
8. Se o GTA já tiver um `d3d9.dll` de outro mod, a instalação para sem apagar nada. Para trocar, marque **Substituir d3d9.dll/ReShade de outro mod**: o antigo vira backup e o **Remover** devolve.
9. Se o GTA estiver numa pasta protegida, aparece o botão **Reabrir como administrador**.

Se um download falhar, o app mostra o endereço oficial. Baixe pelo navegador, coloque o arquivo na pasta que o botão **Pasta de downloads** abre e clique em **Instalar** de novo.

### 5. Jogar

10. Com o **FusionBridge.exe** aberto, abra o **GTA San Andreas** e carregue um save.
    - **Modo automático:** o FusionBridge abre o Minecraft sozinho quando o GTA abre (ou clique em **Abrir o Minecraft** na Ponte) e fecha quando o GTA fecha. Na primeira vez o Prism baixa o jogo: alguns minutos.
    - **Modo Minecraft Launcher:** abra o perfil **FusionBridge - Minecraft no GTA SA** e clique em **JOGAR**. Deixe a janela do Minecraft aberta, sem minimizar.
11. O mod abre sozinho um mundo vazio e em alguns segundos aparece *"FusionBridge: fusao ligada"*.

As teclas dos dois jogos são **fundidas** sozinhas quando a fusão começa: com o CJ a pé e o mouse no Minecraft, cada tecla faz a ação correspondente nos dois jogos.

| Tecla | Minecraft | GTA SA |
|---|---|---|
| botão esquerdo / direito | quebrar / colocar bloco, acender TNT, atirar, pérola | (tiro e mira do CJ ficam bloqueados) |
| **1 – 9** | barra de itens | — |
| rodinha, **Q / E** | item anterior / próximo | arma anterior / próxima (o mesmo gesto nos dois) |
| **I** | abre o inventário **dentro do GTA**: aparece o cursor, e clique, Shift+clique, 1–9 e Q funcionam ali mesmo; **I** ou **E** fecha | — (o CJ e a câmera param enquanto ele está aberto) |
| **Z** | soltar o item da mão | — |
| **X** | trocar o item de mão | — |
| **F7** | liga / desliga a fusão | |
| **F8** | nivela o chão do Minecraft onde o CJ está (blocos flutuando ou enterrados) | |
| **F6** | mouse e teclas do Minecraft ↔ do GTA (para usar as armas do CJ) | |

No carro, ou depois do F6, todas as teclas voltam a ser do GTA. A fusão das teclas pode ser desligada em **Controles**.

### 6. Escolher os jogos (Host e Secundário)

Clique no cartão **Host** ou **Secundário**, na **Ponte**. Ele lista os jogos instalados no PC (Steam, Epic Games, GOG, Ubisoft Connect, Rockstar, EA app, Battle.net, Riot, app Xbox, Minecraft Java e GTA SA clássico). Clique num jogo e, do lado direito, aparece se ele **tem mod fusion ou não** para aquele lado. Depois clique em **Selecionar** (ou aperte Enter). Escolhendo o **Skyrim** como Host, a Ponte avisa que essa fusão é do SkyCraft e leva para a página dele.

### 7. SkyCraft (Minecraft dentro do Skyrim)

O **[SkyCraft](https://github.com/chasmlol/SkyCraft)**, de chasmlol (MIT), roda um Minecraft Java de verdade escondido ao lado do Skyrim, e os dois conversam por memória compartilhada. Na página **Mods fusion**, cartão **SkyCraft**, o app:

- acha o Skyrim e lê a versão do `SkyrimSE.exe` (precisa do runtime da Anniversary Edition, 1.6 ou 1.7; a 1.5.97, o VR e o do Game Pass não servem);
- confere se o **SKSE64** e a **Address Library** são os da mesma versão. Faltando, você baixa pelos botões ([SKSE](https://skse.silverlock.org/), [Address Library](https://www.nexusmods.com/skyrimspecialedition/mods/32444)) e escolhe o arquivo baixado (`.7z`/`.zip`) ou o de dentro;
- baixa o **SkyCraft 0.1.2** oficial do GitHub (SHA-256 conferido) e instala **sem sobrescrever nada**, com **backup dos saves** antes e o registro de cada arquivo para o **Remover**;
- prepara o Minecraft do SkyCraft para você **entrar na conta Microsoft antes de jogar**;
- **Jogar** abre o Skyrim pelo SKSE, abrindo a Steam antes se ela estiver fechada;
- mostra o que o `SkyCraft.log` e o `latest.log` do Minecraft dizem, liga e desliga as opções do `SkyCraft.ini` e avisa dos mods de câmera que brigam com ele (Improved Camera SE, SmoothCam, True Directional Movement) e da falta do Alternate Start.

### 8. Desempenho: FSR 1.0, DLSS e Frame Generation

A página **Desempenho** só mostra o que funciona de verdade:

- **Ritmo e peso da fusão:** modo da ponte, raio do chão e tamanho máximo do Minecraft.
- **FSR 1.0 (AMD FidelityFX):** o Minecraft renderiza menor e o FSR 1.0 (EASU + RCAS) leva a imagem dele até a resolução do GTA, dentro do próprio GTA. Funciona em qualquer placa. Modos da AMD: Nativo, Ultra qualidade, Qualidade, Equilibrado e Desempenho.
- **DLSS:** indisponível. Ele precisa vir de dentro do jogo e só existe em DirectX 11/12 e Vulkan; o GTA SA é Direct3D 9 e o Minecraft Java é OpenGL. No lugar dele, a página explica o Upscale em qualquer jogo, o NIS (NVIDIA) e o RSR (AMD).
- **Frame Generation:** por fora do jogo. O Lossless Scaling (o app acha e abre), o Smooth Motion da NVIDIA (RTX 40/50, quando o driver aceita o jogo) ou o AFMF da AMD.
- **Upscale em qualquer jogo (FSR 1.0 na janela do jogo):** vale para todos os jogos do PC. **Baixar e preparar** baixa o [Magpie](https://github.com/Blinue/Magpie) 0.12.1 (GPL-3.0) do GitHub oficial, confere o SHA-256 e o deixa em `%LOCALAPPDATA%\FusionBridge\Magpie`. Com o jogo em janela numa resolução menor, **Abrir upscaler (FSR)** e **Alt+Shift+A** no jogo.

### 9. Remover

- **Fusão do GTA:** página **Instalar** → **Remover**. Sai só o que o Instalar colocou, os backups voltam e (no modo Minecraft Launcher) o perfil do launcher é apagado.
- **Minecraft automático:** **Instalar → Minecraft automático → Remover o Prism** (o mundo da fusão vai para os backups antes).
- **SkyCraft:** **Mods fusion → SkyCraft → Remover**.

### Se algo não funcionar

A **Ponte** mostra qual peça falta (Minecraft, script do GTA, ASI, ReShade, efeito, chão) e, no modo automático, o que falta para o Minecraft abrir sozinho. A página **Segurança** mostra se o Windows bloqueou algum mod.

- **GTA travado com "Não foi possível restaurar gta_sa.exe":** era o script do GTA até a 0.2.1. Corrigido no script 0.2.2 (Remover e Instalar). Se ainda travar, mande o `FusionBridgeSA.log` (pasta do GTA), o `ReShade.log`, o `moonloader\moonloader.log` e a página **Log**.
- **`libFusionBridgeGTA.so`** é o mod de **Android**; o Windows não usa esse arquivo.

Mais detalhes em [`COMECE-AQUI.md`](COMECE-AQUI.md).

---

## Controle inteligente de aplicativo (Windows 11)

- **O app** é aceito pelo Controle inteligente: todo código nativo do pacote é assinado pela Python Software Foundation ou pela Microsoft, e não há `.bat`, `.cmd` nem PowerShell.
- **Os mods** (MoonLoader, carregador de ASI, `d3d9.dll` do ReShade, `FusionBridgeSA.asi`, SKSE, SkyCraft) e os programas que o app baixa (Prism, Magpie) não têm assinatura reconhecida, como quase todo mod. Com o Controle inteligente **ligado**, o Windows pode bloqueá-los. A página **Segurança** mostra o estado e procura os bloqueios. As opções estão em [`SEGURANCA-WINDOWS.md`](SEGURANCA-WINDOWS.md).

---

## O que tem neste repositório

| Parte | Pastas | Linguagem |
|---|---|---|
| **App FusionBridge 0.6.5** | `app/` (janela, hub, motor de fusão, instalador, lista de jogos, Minecraft automático, SkyCraft), `fusion-mods/`, `FusionBridge._pth`, `tools/build_app.py` | Python 3.13 (só biblioteca padrão + ctypes) |
| **Mod do GTA San Andreas** (Host) | `moonloader/FusionBridgeGTA.lua`, `src/asi/` (código do `FusionBridgeSA.asi`), `gta/shaders/FusionBridgeSA.fx`, `gta/FusionBridgeSA.asi` (compilado) | Lua (MoonLoader), C++17 32-bit, ReShade FX |
| **Mod do Minecraft Java** (Secundário) | `src/minecraft/FusionBridgeMC/` (código do conector do hub), `mod/` (jars compilados: `FusionBridgeMC-0.2.0.jar` e o `passthrough-0.1.0.jar`, MIT, [código original](https://github.com/rehan-remade/universal-modder/tree/main/examples/minecraft-gta5-passthrough)) | Java 21 (Fabric) |
| **Minecraft automático** | `app/fb_prism.py` (baixa o Prism Launcher 11.1.1 oficial com SHA-256, escreve a instância FusionBridge, abre e fecha o Minecraft junto com o GTA; o Prism não vem no pacote) | Python; Prism é GPL-3.0 |
| **SkyCraft** (mod fusion de terceiros) | `app/fb_skycraft.py`, `fusion-mods/skycraft-*.json` (o SkyCraft é baixado do GitHub oficial; SKSE e Address Library não vêm no pacote) | Python; SkyCraft é MIT, de chasmlol |
| **Upscale em qualquer jogo** | `app/fb_upscale.py` (baixa o Magpie 0.12.1 oficial com SHA-256 e abre; o Magpie não vem no pacote) | Python; Magpie é GPL-3.0, de Blinue |
| Versões antigas para Android (0.1.x) | `src/android/`; não são usadas no PC | C++, Java |
| Testes e ferramentas | `tests/`, `tools/` | Python, Lua, C++, shell |
| Documentos | `COMECE-AQUI.md`, `SEGURANCA-WINDOWS.md`, `README-WINDOWS.md`, `CHANGELOG.md`, `GUIA-GTA-PC.txt`, `src/README.md` | |
| Licenças | `LICENSE` (MIT, o código do FusionBridge) e `THIRD-PARTY-NOTICES.md` (os textos completos das licenças de terceiros) | |

O runtime do Python (`FusionBridge.exe`, `python313.dll`, `runtime\` etc.) **não fica no repositório**: ele é o pacote oficial do python.org. Para jogar, use o zip da Release, que já vem com ele.

---

## Licença

O código do FusionBridge é **MIT** ([`LICENSE`](LICENSE)). As partes de terceiros mantêm as licenças delas, com os textos completos em [`THIRD-PARTY-NOTICES.md`](THIRD-PARTY-NOTICES.md): o mod `passthrough` e o compositor/efeito adaptados dele (MIT), o FSR 1.0 da AMD dentro do `FusionBridgeSA.fx` (MIT), os cabeçalhos da API de add-ons do ReShade (BSD-3) e as fontes (SIL OFL 1.1). Nada dos jogos vem no repositório.

## Créditos

- A fusão visual (mod `passthrough`, e o compositor e o efeito em que o ASI e o `.fx` se baseiam) vem do projeto [Minecraft x GTA V Passthrough](https://github.com/rehan-remade/universal-modder/tree/main/examples/minecraft-gta5-passthrough), de Rehan e contribuidores, licença MIT (`mod/LICENSE-passthrough-MIT.txt`).
- **[SkyCraft](https://github.com/chasmlol/SkyCraft)**, de chasmlol, MIT. A ideia do Minecraft automático (Prism portátil que abre e fecha junto com o jogo) vem dele. [Prism Launcher](https://prismlauncher.org), GPL-3.0. [SKSE64](https://skse.silverlock.org/) e [Address Library](https://www.nexusmods.com/skyrimspecialedition/mods/32444) (meh321) não vêm no pacote.
- [ReShade](https://reshade.me) e a API de add-ons por crosire, BSD-3 (`src/third_party/reshade/LICENSE.md`).
- O `FusionBridge.exe` e o `runtime\` são o Python oficial (python.org, Python Software Foundation), sem modificação. A licença está em `runtime\LICENSE-Python.txt`, no zip da Release.
- [MoonLoader](https://www.blast.hk/moonloader/), [Fabric](https://fabricmc.net). Fontes Jersey 15 e IBM Plex Mono (SIL Open Font License).
- Minecraft é marca da Mojang/Microsoft; GTA San Andreas, da Rockstar Games/Take-Two; Skyrim, da Bethesda. Este é um projeto de fã, sem ligação com essas empresas.
