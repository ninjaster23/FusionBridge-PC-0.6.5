#include "sa.h"
#include <windows.h>
#include <cmath>
#include <cstring>

namespace sa
{
	namespace addr
	{
		constexpr uintptr_t kVersionCheck = 0x82457C;  // 0x94BF on 1.0 US (the classic game-version signature)
		constexpr uintptr_t kSceneCamera = 0xC1703C;   // Scene.camera (RwCamera *)
		constexpr uintptr_t kMenuActive = 0xBA67A4;    // FrontEndMenuManager.m_bMenuActive
		constexpr uintptr_t kGameProcess = 0x53BEE0;   // CGame::Process
		constexpr uintptr_t kUpdatePads = 0x541DD0;    // CPad::UpdatePads
		constexpr uintptr_t kIdle = 0x53E920;          // Idle (the main loop's frame)
		constexpr uintptr_t kRender2dStuff = 0x53E230; // Render2dStuff (HUD, radar, text)
		constexpr uintptr_t kPads = 0xB73458;          // CPad::Pads[0]; NewState is its first member
	}

	// RenderWare 3.6 layouts
	constexpr size_t kRwCameraFrame = 0x04;     // RwCamera.object.object.parent (RwFrame *)
	constexpr size_t kRwCameraViewWindow = 0x68;
	constexpr size_t kRwCameraNear = 0x80, kRwCameraFar = 0x84;
	constexpr size_t kRwFrameModelling = 0x10;  // RwMatrix: right 0x00, up 0x10, at 0x20, pos 0x30

	bool readable(const void *p, size_t n)
	{
		auto at = reinterpret_cast<uintptr_t>(p);
		const uintptr_t end = at + n;
		if (at == 0 || end < at)
			return false;
		while (at < end)
		{
			MEMORY_BASIC_INFORMATION mbi;
			if (VirtualQuery(reinterpret_cast<void *>(at), &mbi, sizeof(mbi)) == 0)
				return false;
			const DWORD ok = PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
			if (mbi.State != MEM_COMMIT || (mbi.Protect & ok) == 0 || (mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS)) != 0)
				return false;
			at = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
		}
		return true;
	}

	template <typename T>
	static bool peek(uintptr_t a, T &out)
	{
		if (!readable(reinterpret_cast<void *>(a), sizeof(T)))
			return false;
		std::memcpy(&out, reinterpret_cast<void *>(a), sizeof(T));
		return true;
	}

	bool is_10us()
	{
		uint32_t v = 0;
		return peek(addr::kVersionCheck, v) && v == 0x94BF;
	}

	static bool finite3(const float v[3])
	{
		return std::isfinite(v[0]) && std::isfinite(v[1]) && std::isfinite(v[2]);
	}

	bool read_camera(Camera &c)
	{
		uintptr_t cam = 0, frame = 0;
		if (!peek(addr::kSceneCamera, cam) || cam == 0 || !readable(reinterpret_cast<void *>(cam), 0x90))
			return false;
		if (!peek(cam + kRwCameraFrame, frame) || frame == 0 || !readable(reinterpret_cast<void *>(frame), kRwFrameModelling + 0x40))
			return false;
		const auto *m = reinterpret_cast<const float *>(frame + kRwFrameModelling);
		std::memcpy(c.up, m + 4, sizeof(c.up));
		std::memcpy(c.fwd, m + 8, sizeof(c.fwd));
		std::memcpy(c.pos, m + 12, sizeof(c.pos));
		const auto *vw = reinterpret_cast<const float *>(cam + kRwCameraViewWindow);
		c.tan_x = vw[0];
		c.tan_y = vw[1];
		c.near_z = *reinterpret_cast<const float *>(cam + kRwCameraNear);
		c.far_z = *reinterpret_cast<const float *>(cam + kRwCameraFar);
		if (!finite3(c.pos) || !finite3(c.fwd) || !finite3(c.up))
			return false;
		const float fl = c.fwd[0] * c.fwd[0] + c.fwd[1] * c.fwd[1] + c.fwd[2] * c.fwd[2];
		if (fl < 0.8f || fl > 1.2f || std::fabs(c.pos[0]) > 100000.0f || std::fabs(c.pos[1]) > 100000.0f)
			return false;
		if (!(c.tan_y > 0.05f && c.tan_y < 10.0f && c.tan_x > 0.05f && c.tan_x < 20.0f))
			return false;
		if (!(c.near_z > 0.005f && c.near_z < 20.0f && c.far_z > c.near_z + 1.0f && c.far_z < 200000.0f))
			return false;
		return true;
	}

	bool menu_active()
	{
		uint8_t v = 0;
		return peek(addr::kMenuActive, v) && v != 0;
	}

	/// The one CALL rel32 to `target` in [from, from + len), or 0 if there isn't exactly one.
	static uintptr_t find_call(uintptr_t from, size_t len, uintptr_t target)
	{
		if (!readable(reinterpret_cast<void *>(from), len + 5))
			return 0;
		uintptr_t found = 0;
		int count = 0;
		for (uintptr_t a = from; a < from + len; ++a)
		{
			if (*reinterpret_cast<const uint8_t *>(a) != 0xE8)
				continue;
			int32_t rel;
			std::memcpy(&rel, reinterpret_cast<void *>(a + 1), 4);
			if (a + 5 + uintptr_t(intptr_t(rel)) == target)
			{
				found = a;
				++count;
			}
		}
		return count == 1 ? found : 0;
	}

	static bool redirect_call(uintptr_t site, void *hook)
	{
		DWORD old;
		if (!VirtualProtect(reinterpret_cast<void *>(site), 5, PAGE_EXECUTE_READWRITE, &old))
			return false;
		const int32_t rel = int32_t(reinterpret_cast<uintptr_t>(hook) - (site + 5));
		std::memcpy(reinterpret_cast<void *>(site + 1), &rel, 4);
		VirtualProtect(reinterpret_cast<void *>(site), 5, old, &old);
		FlushInstructionCache(GetCurrentProcess(), reinterpret_cast<void *>(site), 5);
		return true;
	}

	static VoidFn g_afterPads = nullptr, g_before2d = nullptr;

	static void __cdecl update_pads_hook()
	{
		reinterpret_cast<VoidFn>(addr::kUpdatePads)();
		if (g_afterPads)
			g_afterPads();
	}

	static void __cdecl render2d_hook()
	{
		if (g_before2d)
			g_before2d();
		reinterpret_cast<VoidFn>(addr::kRender2dStuff)();
	}

	bool hook_update_pads(VoidFn after)
	{
		const uintptr_t site = find_call(addr::kGameProcess, 0x80, addr::kUpdatePads);
		if (site == 0)
			return false;
		g_afterPads = after;
		return redirect_call(site, reinterpret_cast<void *>(&update_pads_hook));
	}

	bool hook_render2d(VoidFn before)
	{
		const uintptr_t site = find_call(addr::kIdle, 0x400, addr::kRender2dStuff);
		if (site == 0)
			return false;
		g_before2d = before;
		return redirect_call(site, reinterpret_cast<void *>(&render2d_hook));
	}

	void block_fire_and_aim()
	{
		// CControllerState (all shorts): LeftShoulder2 0x0A, RightShoulder1 0x0C (aim/target),
		// RightShoulder2 0x0E (weapon cycle), ButtonCircle 0x22 (fire)
		auto *state = reinterpret_cast<int16_t *>(addr::kPads);
		if (!readable(state, 0x30))
			return;
		state[0x0A / 2] = 0;
		state[0x0C / 2] = 0;
		state[0x0E / 2] = 0;
		state[0x22 / 2] = 0;
	}
}
