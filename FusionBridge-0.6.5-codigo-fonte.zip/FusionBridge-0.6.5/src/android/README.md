# Versões antigas do lado Android (0.1.x)

Estes são os códigos-fonte das primeiras versões dos mods do FusionBridge, feitas para o celular (Android). O pacote de PC 0.6.5 não usa estes arquivos; eles ficam aqui como histórico do projeto.

| Pasta | O que é |
|---|---|
| `FusionBridgeGTA-0.1.0/` | núcleo nativo (C++) do mod do GTA SA para Android: conecta no app em `127.0.0.1:28765`, manda o estado do CJ e aplica os eventos do Minecraft. Só o código do mod, sem código nem arquivos da Rockstar. Licença MIT (`LICENSE`). |
| `FusionBridgeMC-0.1.3-mc26.2/` | conector do Minecraft Java 26.2 (Fabric) da época do Android, com o ajuste de FSR1 do MobileGlues. Licença MIT (`fabric.mod.json`). No PC ele foi substituído pelo FusionBridgeMC 0.2.0 (`src/minecraft/FusionBridgeMC/`). |
