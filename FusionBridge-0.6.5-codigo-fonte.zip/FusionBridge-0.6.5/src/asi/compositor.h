// ReShade add-on half of FusionBridgeSA.asi: uploads Minecraft's latest frame (shared memory
// "Local\MCPassthroughFrame", written by the passthrough mod) into textures that FusionBridgeSA.fx composites
// into GTA SA's picture against GTA's depth buffer.
#pragma once
#include <windows.h>

namespace compositor
{
	/// Registers with ReShade once it is loaded; call until it returns true.
	bool try_register(HMODULE module);
	/// process_exit: ReShade may already be unloaded, so it isn't called.
	void unregister(HMODULE module, bool process_exit);
	/// From the GTA script every frame: composite or not, and the Minecraft height offset (yoff).
	/// Compositing stops by itself if this isn't called for half a second (script stopped, game paused).
	void set_fusion(bool composite, float yoff);
	/// Called just before GTA draws its HUD: renders the effect there, so GTA's HUD stays on top.
	void render_before_hud();
	/// out[16]: registered, fresh frame, bb w, bb h, uploads, effect found, mc w, mc h, early renders
	void status(int *out);
	void set_hud_hook(bool installed);
	/// FSR 1.0 for Minecraft's picture (the app's Desempenho tab): on/off and RCAS sharpness in stops (0 = strongest).
	void set_fsr(bool on, float sharpness);
}
