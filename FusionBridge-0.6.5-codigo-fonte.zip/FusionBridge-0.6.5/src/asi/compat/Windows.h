// reshade.hpp includes <Windows.h>; MinGW's header is lowercase (matters when cross-compiling on Linux).
#include <windows.h>
