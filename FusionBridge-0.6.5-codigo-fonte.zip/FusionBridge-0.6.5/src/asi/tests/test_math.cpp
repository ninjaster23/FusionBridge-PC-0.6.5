// Native check of camera_math.h: any GTA camera (forward + up) converted to Minecraft's yaw/pitch/roll must
// give Minecraft a camera that looks the same way with the same up. Build: g++ -O2 test_math.cpp && ./a.out
#include "../camera_math.h"
#include <cstdio>
#include <cstdlib>

static void to_mc(const float v[3], float o[3]) { o[0] = v[0]; o[1] = v[2]; o[2] = -v[1]; }
static void norm(float v[3]) { float l = std::sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]); for (int i=0;i<3;++i) v[i]/=l; }
static void cross(const float a[3], const float b[3], float o[3]) { o[0]=a[1]*b[2]-a[2]*b[1]; o[1]=a[2]*b[0]-a[0]*b[2]; o[2]=a[0]*b[1]-a[1]*b[0]; }

int main()
{
	int fails = 0, n = 0;
	srand(7);
	for (int it = 0; it < 20000; ++it)
	{
		float f[3] = {float(rand()) / RAND_MAX * 2 - 1, float(rand()) / RAND_MAX * 2 - 1, float(rand()) / RAND_MAX * 1.6f - 0.8f};
		norm(f);
		// an up vector: world up tilted by a random roll around f
		float r0[3], u0[3];
		const float Z[3] = {0, 0, 1};
		cross(f, Z, r0); norm(r0); cross(r0, f, u0);
		const float roll = (float(rand()) / RAND_MAX * 2 - 1) * 0.6f; // +-34 deg
		float u[3];
		for (int i = 0; i < 3; ++i) u[i] = u0[i] * std::cos(roll) + r0[i] * std::sin(roll);
		const fbmath::Angles a = fbmath::angles_from_vectors(f, u);
		const float pos[3] = {10, 20, 30};
		const fbmath::McPose p = fbmath::mc_pose(pos, a, 60, 0.25f);
		float m[3][3];
		fbmath::mc_camera_rotation(p.yaw, p.pitch, p.roll, m);
		float fwd[3] = {-m[0][2], -m[1][2], -m[2][2]}, up[3] = {m[0][1], m[1][1], m[2][1]};
		float wf[3], wu[3];
		to_mc(f, wf); to_mc(u, wu);
		float ef = 0, eu = 0;
		for (int i = 0; i < 3; ++i) { ef += std::fabs(fwd[i] - wf[i]); eu += std::fabs(up[i] - wu[i]); }
		++n;
		if (ef > 1e-3f || eu > 1e-3f) { if (fails < 5) printf("mismatch f=(%.3f %.3f %.3f) roll=%.3f ef=%g eu=%g\n", f[0], f[1], f[2], roll, ef, eu); ++fails; }
	}
	// fixed cases
	const float north[3] = {0, 1, 0}, west[3] = {-1, 0, 0}, up[3] = {0, 0, 1};
	fbmath::Angles a = fbmath::angles_from_vectors(north, up);
	if (std::fabs(a.heading) > 1e-3f || std::fabs(a.pitch) > 1e-3f || std::fabs(a.roll) > 1e-3f) { printf("north wrong\n"); ++fails; }
	a = fbmath::angles_from_vectors(west, up);
	if (std::fabs(a.heading - 90) > 1e-3f) { printf("west wrong %f\n", a.heading); ++fails; }
	const float pos[3] = {100, 200, 15};
	fbmath::McPose p = fbmath::mc_pose(pos, a, 55, -0.3f);
	if (std::fabs(p.yaw - 90) > 1e-3f || std::fabs(p.y - 14.7) > 1e-4 || std::fabs(p.z + 200) > 1e-4) { printf("pose wrong\n"); ++fails; }
	// identical poses -> identity warp, zero translation
	float w[3][3], t[3];
	fbmath::warp_matrix(p, p, w);
	fbmath::warp_translation(p, p, t);
	for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) if (std::fabs(w[i][j] - (i == j)) > 1e-5f) { printf("warp not identity\n"); ++fails; i = 3; break; }
	if (std::fabs(t[0]) + std::fabs(t[1]) + std::fabs(t[2]) > 1e-6f) { printf("translation not zero\n"); ++fails; }
	printf("%d random cameras + fixed cases: %s\n", n, fails ? "FALHOU" : "OK");
	return fails ? 1 : 0;
}
