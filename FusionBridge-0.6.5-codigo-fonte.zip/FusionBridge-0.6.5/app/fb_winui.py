"""FusionBridge PC 0.6.5 - a small native Windows UI toolkit (ctypes only: user32, gdi32, gdiplus, comdlg32).

Look: dark "obsidian" ground, grass-green accent, block-style bevels, Jersey 15 pixel titles (bundled, OFL).

Why not tkinter: the app runs on the official, signed Python runtime (so Windows' Smart App Control trusts it),
and that runtime has no Tcl/Tk. Everything here is plain Win32: one window, double-buffered painting, GDI+ for
anti-aliased shapes and GDI (ClearType) for text, per-monitor DPI, and an immediate-mode API:

    def build(ui):                       # called on every paint
        ui.text(20, 20, 300, "Hello", size=20, bold=True)
        if ui.button("go", 20, 60, 120, 36, "Go"):
            ...                          # clicked

Coordinates are logical pixels (96 dpi); the toolkit scales them. Nothing here knows about FusionBridge.
"""
import ctypes
import os
import sys
import time
from ctypes import wintypes

IS_WINDOWS = sys.platform == "win32"

if IS_WINDOWS:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    gdiplus = ctypes.WinDLL("gdiplus")
    comdlg32 = ctypes.WinDLL("comdlg32")
    shell32 = ctypes.WinDLL("shell32")
    try:
        dwmapi = ctypes.WinDLL("dwmapi")
    except OSError:
        dwmapi = None

LRESULT = ctypes.c_ssize_t
WPARAM = ctypes.c_size_t
LPARAM = ctypes.c_ssize_t
HANDLE = ctypes.c_void_p
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, HANDLE, ctypes.c_uint, WPARAM, LPARAM) if IS_WINDOWS else None

# messages and constants
WM_DESTROY, WM_SIZE, WM_PAINT, WM_CLOSE, WM_ERASEBKGND = 0x0002, 0x0005, 0x000F, 0x0010, 0x0014
WM_SETCURSOR, WM_GETMINMAXINFO, WM_SETICON, WM_NCHITTEST = 0x0020, 0x0024, 0x0080, 0x0084
WM_KEYDOWN, WM_TIMER, WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP = 0x0100, 0x0113, 0x0200, 0x0201, 0x0202
WM_MOUSEWHEEL, WM_MOUSELEAVE, WM_DPICHANGED, WM_APP = 0x020A, 0x02A3, 0x02E0, 0x8000
WM_ACTIVATE = 0x0006
WS_OVERLAPPEDWINDOW, WS_VISIBLE, WS_POPUP, WS_CLIPCHILDREN = 0x00CF0000, 0x10000000, 0x80000000, 0x02000000
WS_EX_TOPMOST, WS_EX_TOOLWINDOW, WS_EX_APPWINDOW = 0x00000008, 0x00000080, 0x00040000
CS_HREDRAW, CS_VREDRAW, CS_DBLCLKS = 0x0002, 0x0001, 0x0008
CW_USEDEFAULT = -0x80000000
SW_SHOW, SW_RESTORE = 5, 9
IDC_ARROW, IDC_HAND = 32512, 32649
HTCLIENT, HTCAPTION = 1, 2
DT_LEFT, DT_CENTER, DT_RIGHT, DT_VCENTER, DT_SINGLELINE = 0x0, 0x1, 0x2, 0x4, 0x20
DT_WORDBREAK, DT_CALCRECT, DT_NOPREFIX, DT_END_ELLIPSIS, DT_EDITCONTROL = 0x10, 0x400, 0x800, 0x8000, 0x2000
TRANSPARENT = 1
SRCCOPY = 0x00CC0020
FW_NORMAL, FW_SEMIBOLD, FW_BOLD = 400, 600, 700
CLEARTYPE_QUALITY = 5
IMAGE_ICON, LR_LOADFROMFILE, LR_DEFAULTSIZE = 1, 0x10, 0x40
ICON_SMALL, ICON_BIG = 0, 1
TME_LEAVE = 0x2
SWP_NOZORDER, SWP_NOACTIVATE = 0x0004, 0x0010
MB_OK, MB_OKCANCEL, MB_YESNO, MB_ICONINFO, MB_ICONWARN, MB_ICONERROR = 0x0, 0x1, 0x4, 0x40, 0x30, 0x10
IDOK, IDYES = 1, 6
VK_F5, VK_ESCAPE, VK_RETURN, VK_BACK, VK_UP, VK_DOWN = 0x74, 0x1B, 0x0D, 0x08, 0x26, 0x28
WM_CHAR = 0x0102
CF_UNICODETEXT, GMEM_MOVEABLE = 13, 0x0002


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class MSG(ctypes.Structure):
    _fields_ = [("hwnd", HANDLE), ("message", ctypes.c_uint), ("wParam", WPARAM), ("lParam", LPARAM),
                ("time", wintypes.DWORD), ("pt", POINT), ("lPrivate", wintypes.DWORD)]


class PAINTSTRUCT(ctypes.Structure):
    _fields_ = [("hdc", HANDLE), ("fErase", wintypes.BOOL), ("rcPaint", RECT), ("fRestore", wintypes.BOOL),
                ("fIncUpdate", wintypes.BOOL), ("rgbReserved", ctypes.c_byte * 32)]


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("style", ctypes.c_uint), ("lpfnWndProc", ctypes.c_void_p),
                ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int), ("hInstance", HANDLE), ("hIcon", HANDLE),
                ("hCursor", HANDLE), ("hbrBackground", HANDLE), ("lpszMenuName", wintypes.LPCWSTR),
                ("lpszClassName", wintypes.LPCWSTR), ("hIconSm", HANDLE)]


class MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", RECT), ("rcWork", RECT), ("dwFlags", wintypes.DWORD)]


class MINMAXINFO(ctypes.Structure):
    _fields_ = [("ptReserved", POINT), ("ptMaxSize", POINT), ("ptMaxPosition", POINT), ("ptMinTrackSize", POINT),
                ("ptMaxTrackSize", POINT)]


class TRACKMOUSEEVENT(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("dwFlags", wintypes.DWORD), ("hwndTrack", HANDLE),
                ("dwHoverTime", wintypes.DWORD)]


class SIZE(ctypes.Structure):
    _fields_ = [("cx", ctypes.c_long), ("cy", ctypes.c_long)]


class GdiplusStartupInput(ctypes.Structure):
    _fields_ = [("GdiplusVersion", ctypes.c_uint32), ("DebugEventCallback", ctypes.c_void_p),
                ("SuppressBackgroundThread", wintypes.BOOL), ("SuppressExternalCodecs", wintypes.BOOL)]


class OPENFILENAMEW(ctypes.Structure):
    _fields_ = [("lStructSize", wintypes.DWORD), ("hwndOwner", HANDLE), ("hInstance", HANDLE),
                ("lpstrFilter", wintypes.LPCWSTR), ("lpstrCustomFilter", wintypes.LPWSTR),
                ("nMaxCustFilter", wintypes.DWORD), ("nFilterIndex", wintypes.DWORD), ("lpstrFile", wintypes.LPWSTR),
                ("nMaxFile", wintypes.DWORD), ("lpstrFileTitle", wintypes.LPWSTR), ("nMaxFileTitle", wintypes.DWORD),
                ("lpstrInitialDir", wintypes.LPCWSTR), ("lpstrTitle", wintypes.LPCWSTR), ("Flags", wintypes.DWORD),
                ("nFileOffset", wintypes.WORD), ("nFileExtension", wintypes.WORD), ("lpstrDefExt", wintypes.LPCWSTR),
                ("lCustData", LPARAM), ("lpfnHook", ctypes.c_void_p), ("lpTemplateName", wintypes.LPCWSTR),
                ("pvReserved", ctypes.c_void_p), ("dwReserved", wintypes.DWORD), ("FlagsEx", wintypes.DWORD)]


def _sig(dll, name, restype, *argtypes):
    f = getattr(dll, name)
    f.restype = restype
    f.argtypes = argtypes
    return f


if IS_WINDOWS:
    _sig(user32, "RegisterClassExW", wintypes.ATOM, ctypes.POINTER(WNDCLASSEXW))
    _sig(user32, "CreateWindowExW", HANDLE, wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
         ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, HANDLE, HANDLE, HANDLE, ctypes.c_void_p)
    _sig(user32, "DefWindowProcW", LRESULT, HANDLE, ctypes.c_uint, WPARAM, LPARAM)
    _sig(user32, "GetMessageW", wintypes.BOOL, ctypes.POINTER(MSG), HANDLE, ctypes.c_uint, ctypes.c_uint)
    _sig(user32, "TranslateMessage", wintypes.BOOL, ctypes.POINTER(MSG))
    _sig(user32, "DispatchMessageW", LRESULT, ctypes.POINTER(MSG))
    _sig(user32, "PostQuitMessage", None, ctypes.c_int)
    _sig(user32, "PostMessageW", wintypes.BOOL, HANDLE, ctypes.c_uint, WPARAM, LPARAM)
    _sig(user32, "ShowWindow", wintypes.BOOL, HANDLE, ctypes.c_int)
    _sig(user32, "UpdateWindow", wintypes.BOOL, HANDLE)
    _sig(user32, "DestroyWindow", wintypes.BOOL, HANDLE)
    _sig(user32, "InvalidateRect", wintypes.BOOL, HANDLE, ctypes.c_void_p, wintypes.BOOL)
    _sig(user32, "BeginPaint", HANDLE, HANDLE, ctypes.POINTER(PAINTSTRUCT))
    _sig(user32, "EndPaint", wintypes.BOOL, HANDLE, ctypes.POINTER(PAINTSTRUCT))
    _sig(user32, "GetClientRect", wintypes.BOOL, HANDLE, ctypes.POINTER(RECT))
    _sig(user32, "SetTimer", ctypes.c_size_t, HANDLE, ctypes.c_size_t, ctypes.c_uint, ctypes.c_void_p)
    _sig(user32, "KillTimer", wintypes.BOOL, HANDLE, ctypes.c_size_t)
    _sig(user32, "LoadCursorW", HANDLE, HANDLE, ctypes.c_void_p)
    _sig(user32, "SetCursor", HANDLE, HANDLE)
    _sig(user32, "SetCapture", HANDLE, HANDLE)
    _sig(user32, "ReleaseCapture", wintypes.BOOL)
    _sig(user32, "TrackMouseEvent", wintypes.BOOL, ctypes.POINTER(TRACKMOUSEEVENT))
    _sig(user32, "ScreenToClient", wintypes.BOOL, HANDLE, ctypes.POINTER(POINT))
    _sig(user32, "LoadImageW", HANDLE, HANDLE, wintypes.LPCWSTR, ctypes.c_uint, ctypes.c_int, ctypes.c_int, ctypes.c_uint)
    _sig(user32, "SendMessageW", LRESULT, HANDLE, ctypes.c_uint, WPARAM, LPARAM)
    _sig(user32, "SetWindowPos", wintypes.BOOL, HANDLE, HANDLE, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint)
    _sig(user32, "MonitorFromWindow", HANDLE, HANDLE, wintypes.DWORD)
    _sig(user32, "GetMonitorInfoW", wintypes.BOOL, HANDLE, ctypes.c_void_p)
    _sig(user32, "MessageBoxW", ctypes.c_int, HANDLE, wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.c_uint)
    _sig(user32, "FindWindowW", HANDLE, wintypes.LPCWSTR, wintypes.LPCWSTR)
    _sig(user32, "SetForegroundWindow", wintypes.BOOL, HANDLE)
    _sig(user32, "IsIconic", wintypes.BOOL, HANDLE)
    _sig(user32, "GetSystemMetrics", ctypes.c_int, ctypes.c_int)
    _sig(user32, "OpenClipboard", wintypes.BOOL, HANDLE)
    _sig(user32, "EmptyClipboard", wintypes.BOOL)
    _sig(user32, "SetClipboardData", HANDLE, ctypes.c_uint, HANDLE)
    _sig(user32, "CloseClipboard", wintypes.BOOL)
    _sig(user32, "SetWindowTextW", wintypes.BOOL, HANDLE, wintypes.LPCWSTR)
    _sig(kernel32, "GlobalAlloc", HANDLE, ctypes.c_uint, ctypes.c_size_t)
    _sig(kernel32, "GlobalLock", ctypes.c_void_p, HANDLE)
    _sig(kernel32, "GlobalUnlock", wintypes.BOOL, HANDLE)
    _sig(kernel32, "GetModuleHandleW", HANDLE, wintypes.LPCWSTR)
    _sig(kernel32, "CreateMutexW", HANDLE, ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR)
    _sig(gdi32, "CreateCompatibleDC", HANDLE, HANDLE)
    _sig(gdi32, "CreateCompatibleBitmap", HANDLE, HANDLE, ctypes.c_int, ctypes.c_int)
    _sig(gdi32, "SelectObject", HANDLE, HANDLE, HANDLE)
    _sig(gdi32, "DeleteObject", wintypes.BOOL, HANDLE)
    _sig(gdi32, "DeleteDC", wintypes.BOOL, HANDLE)
    _sig(gdi32, "BitBlt", wintypes.BOOL, HANDLE, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, HANDLE,
         ctypes.c_int, ctypes.c_int, wintypes.DWORD)
    _sig(gdi32, "CreateFontW", HANDLE, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
         wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
         wintypes.DWORD, wintypes.DWORD, wintypes.LPCWSTR)
    _sig(gdi32, "SetBkMode", ctypes.c_int, HANDLE, ctypes.c_int)
    _sig(gdi32, "SetTextColor", wintypes.DWORD, HANDLE, wintypes.DWORD)
    _sig(gdi32, "SaveDC", ctypes.c_int, HANDLE)
    _sig(gdi32, "RestoreDC", wintypes.BOOL, HANDLE, ctypes.c_int)
    _sig(gdi32, "IntersectClipRect", ctypes.c_int, HANDLE, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int)
    _sig(user32, "DrawTextW", ctypes.c_int, HANDLE, wintypes.LPCWSTR, ctypes.c_int, ctypes.POINTER(RECT), ctypes.c_uint)
    _sig(gdiplus, "GdiplusStartup", ctypes.c_int, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(GdiplusStartupInput), ctypes.c_void_p)
    _sig(gdiplus, "GdipCreateFromHDC", ctypes.c_int, HANDLE, ctypes.POINTER(ctypes.c_void_p))
    _sig(gdiplus, "GdipDeleteGraphics", ctypes.c_int, ctypes.c_void_p)
    _sig(gdiplus, "GdipSetSmoothingMode", ctypes.c_int, ctypes.c_void_p, ctypes.c_int)
    _sig(gdiplus, "GdipSetPixelOffsetMode", ctypes.c_int, ctypes.c_void_p, ctypes.c_int)
    _sig(gdiplus, "GdipCreateSolidFill", ctypes.c_int, ctypes.c_uint32, ctypes.POINTER(ctypes.c_void_p))
    _sig(gdiplus, "GdipDeleteBrush", ctypes.c_int, ctypes.c_void_p)
    _sig(gdiplus, "GdipCreatePen1", ctypes.c_int, ctypes.c_uint32, ctypes.c_float, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p))
    _sig(gdiplus, "GdipDeletePen", ctypes.c_int, ctypes.c_void_p)
    _sig(gdiplus, "GdipSetPenStartCap", ctypes.c_int, ctypes.c_void_p, ctypes.c_int)
    _sig(gdiplus, "GdipSetPenEndCap", ctypes.c_int, ctypes.c_void_p, ctypes.c_int)
    _sig(gdiplus, "GdipSetPenLineJoin", ctypes.c_int, ctypes.c_void_p, ctypes.c_int)
    _sig(gdiplus, "GdipDrawEllipse", ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_float, ctypes.c_float,
         ctypes.c_float, ctypes.c_float)
    _sig(gdi32, "AddFontResourceExW", ctypes.c_int, wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_void_p)
    _sig(gdiplus, "GdipCreatePath", ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p))
    _sig(gdiplus, "GdipDeletePath", ctypes.c_int, ctypes.c_void_p)
    _sig(gdiplus, "GdipAddPathArc", ctypes.c_int, ctypes.c_void_p, ctypes.c_float, ctypes.c_float, ctypes.c_float,
         ctypes.c_float, ctypes.c_float, ctypes.c_float)
    _sig(gdiplus, "GdipClosePathFigure", ctypes.c_int, ctypes.c_void_p)
    _sig(gdiplus, "GdipFillPath", ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)
    _sig(gdiplus, "GdipDrawPath", ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)
    _sig(gdiplus, "GdipFillRectangle", ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_float, ctypes.c_float,
         ctypes.c_float, ctypes.c_float)
    _sig(gdiplus, "GdipFillEllipse", ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_float, ctypes.c_float,
         ctypes.c_float, ctypes.c_float)
    _sig(gdiplus, "GdipDrawLine", ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_float, ctypes.c_float,
         ctypes.c_float, ctypes.c_float)
    _sig(gdiplus, "GdipSetClipRect", ctypes.c_int, ctypes.c_void_p, ctypes.c_float, ctypes.c_float, ctypes.c_float,
         ctypes.c_float, ctypes.c_int)
    _sig(gdiplus, "GdipResetClip", ctypes.c_int, ctypes.c_void_p)
    _sig(gdiplus, "GdipGetDC", ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(HANDLE))
    _sig(gdiplus, "GdipReleaseDC", ctypes.c_int, ctypes.c_void_p, HANDLE)
    _sig(comdlg32, "GetOpenFileNameW", wintypes.BOOL, ctypes.POINTER(OPENFILENAMEW))
    try:
        _sig(user32, "SetProcessDpiAwarenessContext", wintypes.BOOL, ctypes.c_void_p)
    except AttributeError:
        pass
    try:
        _sig(user32, "GetDpiForWindow", ctypes.c_uint, HANDLE)
    except AttributeError:
        pass
    try:
        _sig(shell32, "SetCurrentProcessExplicitAppUserModelID", ctypes.c_long, wintypes.LPCWSTR)
    except AttributeError:
        pass
    if dwmapi is not None:
        try:
            _sig(dwmapi, "DwmSetWindowAttribute", ctypes.c_long, HANDLE, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD)
        except AttributeError:
            dwmapi = None


def rgb(hex_color):
    """'#rrggbb' -> (r, g, b)."""
    h = hex_color.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def colorref(c):
    r, g, b = rgb(c) if isinstance(c, str) else c
    return r | (g << 8) | (b << 16)


def argb(c, alpha=255):
    r, g, b = rgb(c) if isinstance(c, str) else c
    return ((alpha & 255) << 24) | (r << 16) | (g << 8) | b


def message_box(text, title="FusionBridge", flags=MB_OK | MB_ICONINFO, owner=None):
    if not IS_WINDOWS:
        return IDOK
    return user32.MessageBoxW(owner, text, title, flags)


def set_clipboard_text(hwnd, text):
    if not IS_WINDOWS:
        return False
    data = (text + "\0").encode("utf-16-le")
    if not user32.OpenClipboard(hwnd):
        return False
    try:
        user32.EmptyClipboard()
        h = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not h:
            return False
        p = kernel32.GlobalLock(h)
        ctypes.memmove(p, data, len(data))
        kernel32.GlobalUnlock(h)
        return bool(user32.SetClipboardData(CF_UNICODETEXT, h))
    finally:
        user32.CloseClipboard()


def open_file_dialog(owner, title, filter_pairs, initial_dir=None):
    """Native 'Open' dialog. filter_pairs: [("gta_sa.exe", "gta_sa.exe"), ...]. Returns the path or None."""
    if not IS_WINDOWS:
        return None
    flt = "".join("%s\0%s\0" % pair for pair in filter_pairs) + "\0"
    buf = ctypes.create_unicode_buffer(1024)
    ofn = OPENFILENAMEW()
    ofn.lStructSize = ctypes.sizeof(OPENFILENAMEW)
    ofn.hwndOwner = owner
    ofn.lpstrFilter = flt
    ofn.lpstrFile = ctypes.cast(buf, wintypes.LPWSTR)
    ofn.nMaxFile = 1024
    ofn.lpstrTitle = title
    ofn.lpstrInitialDir = initial_dir
    ofn.Flags = 0x00001000 | 0x00000800 | 0x00000008 | 0x00080000  # FILEMUSTEXIST|PATHMUSTEXIST|NOCHANGEDIR|EXPLORER
    if comdlg32.GetOpenFileNameW(ctypes.byref(ofn)):
        return buf.value
    return None


# ====================================================================== theme
# One palette for every widget (dark "obsidian" ground, grass-green accent, block-style bevels). fb_app.py uses
# the same names, so the window, the picker and the floating HUD all look like one app.
T = {"bg": "#101215", "side": "#0b0d10", "panel": "#191c21", "panel2": "#1d2229", "raise": "#23282f",
     "inset": "#0e1013", "line": "#2a2f37", "line2": "#3a414b", "shadow": "#08090b",
     "text": "#ece9e2", "head": "#f4f1ea", "muted": "#9aa1ab", "soft": "#c3c8cf",
     "green": "#6cc04a", "green_d": "#3f7a2a", "green_t": "#a8dd86", "on_green": "#0f1e08",
     "amber": "#e9a23b", "amber_d": "#8a5a17", "amber_t": "#f2c77a", "red": "#d8442a", "red_t": "#f08a70",
     "blue": "#8fb8f2", "ok": "#8fd46a", "wait": "#f2c77a", "bad": "#f08a70", "off": "#5a616b"}

PILL = {"ok": ("#213318", "#a8dd86"), "wait": ("#352712", "#f2c77a"), "bad": ("#3a1d18", "#f4a08a"),
        "info": ("#16233a", "#a9c7f2"), "off": ("#23282f", "#c3c8cf")}

# bundled fonts (app/assets/fonts, SIL Open Font License): Jersey 15 (pixel) for titles, IBM Plex Mono for numbers/log.
# Loaded privately for this process only; without them the toolkit falls back to Segoe UI / Consolas.
_private = {"pixel": False, "mono": False}


def load_fonts(folder):
    if not IS_WINDOWS or not folder or not os.path.isdir(folder):
        return dict(_private)
    for n in sorted(os.listdir(folder)):
        if not n.lower().endswith((".ttf", ".otf")):
            continue
        try:
            if gdi32.AddFontResourceExW(os.path.join(folder, n), 0x10, None) > 0:     # FR_PRIVATE
                if n.lower().startswith("jersey"):
                    _private["pixel"] = True
                elif n.lower().startswith("ibmplexmono"):
                    _private["mono"] = True
        except Exception:
            pass
    return dict(_private)


# 24-unit stroke icons (drawn with GDI+ lines, so no icon font or image files are needed)
def _arc(cx, cy, r, a0, a1, n=14):
    import math
    return [(cx + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)), cy + r * math.sin(math.radians(a0 + (a1 - a0) * i / n)))
            for i in range(n + 1)]


ICONS = {
    "ponte": [[(3, 18), (21, 18)], _arc(12, 18, 7, 180, 360), [(9, 18), (9, 14.2)], [(15, 18), (15, 14.2)]],
    "caos": [[(6, 9), (18, 9), (18, 21), (6, 21), (6, 9)], [(6, 13), (18, 13)], [(6, 17), (18, 17)], [(12, 9), (14, 5)],
             [(15, 2.5), (16, 4)], [(17.5, 4.5), (19, 4)], [(16, 6.5), (17.5, 7.5)]],
    "controles": [[(4, 6), (14, 6)], [(18, 6), (20, 6)], [(4, 12), (6, 12)], [(10, 12), (20, 12)], [(4, 18), (12, 18)],
                  [(16, 18), (20, 18)], ("c", 16, 6, 2), ("c", 8, 12, 2), ("c", 14, 18, 2)],
    "instalar": [[(12, 3), (12, 15)], [(7, 10), (12, 15), (17, 10)], [(4, 20), (20, 20)]],
    "desempenho": [_arc(12, 18, 8, 180, 360), [(12, 18), (16, 12)], [(4, 18), (20, 18)]],
    "seguranca": [[(12, 3), (19, 6), (19, 11), (17.5, 15.5), (12, 21), (6.5, 15.5), (5, 11), (5, 6), (12, 3)],
                  [(9, 12), (11, 14), (15, 10)]],
    "diag": [[(3, 12), (7, 12), (9.5, 6.5), (13.5, 17.5), (16, 12), (21, 12)]],
    "log": [[(5, 6), (19, 6)], [(5, 10), (19, 10)], [(5, 14), (16, 14)], [(5, 18), (12, 18)]],
    "nivelar": [[(3, 19), (21, 19)], [(6, 15), (10, 15), (10, 19)], [(14, 11), (18, 11), (18, 19)], [(12, 3), (12, 7)]],
    "mouse": [[(9, 4), (15, 4), (18, 7), (18, 17), (15, 20), (9, 20), (6, 17), (6, 7), (9, 4)], [(12, 4), (12, 10)]],
    "lixo": [[(4, 7), (20, 7)], [(9, 7), (9, 4), (15, 4), (15, 7)], [(6, 7), (7, 20), (17, 20), (18, 7)], [(10, 11), (10, 16)],
             [(14, 11), (14, 16)]],
    "pasta": [[(3, 7), (3, 19), (21, 19), (21, 9), (11, 9), (9, 6), (3, 6), (3, 7)]],
    "copiar": [[(8, 8), (19, 8), (19, 20), (8, 20), (8, 8)], [(5, 16), (5, 4), (16, 4)]],
    "atalho": [[(4, 20), (4, 6), (11, 6)], [(14, 4), (20, 4), (20, 10)], [(20, 4), (11, 13)]],
    "escudo": [[(12, 3), (19, 6), (19, 11), (17.5, 15.5), (12, 21), (6.5, 15.5), (5, 11), (5, 6), (12, 3)]],
    "busca": [("c", 10.5, 10.5, 6), [(15, 15), (20, 20)]],
    "recarregar": [_arc(12, 12, 7, -60, 220, 18), [(19.5, 4.5), (15.5, 6), (19, 8.5)]],
    "check": [[(5, 12.5), (10, 17.5), (19, 7)]],
    "x": [[(6, 6), (18, 18)], [(18, 6), (6, 18)]],
    "seta_d": [[(9, 6), (15, 12), (9, 18)]],
    "seta_b": [[(6, 9), (12, 15), (18, 9)]],
    "info": [("c", 12, 12, 9), [(12, 11), (12, 16.5)], [(12, 7.5), (12, 7.6)]],
    "raio": [[(13, 3), (6, 13), (12, 13), (10, 21), (18, 10), (12, 10), (13, 3)]],
    "pacote": [[(4, 8), (12, 4), (20, 8), (20, 16), (12, 20), (4, 16), (4, 8)], [(4, 8), (12, 12), (20, 8)], [(12, 12), (12, 20)]],
    "fusao": [[(3, 12), (9, 12)], [(15, 12), (21, 12)], [(9, 8), (15, 8), (15, 16), (9, 16), (9, 8)]],
    "blocos": [[(3, 12), (11, 12), (11, 20), (3, 20), (3, 12)], [(13, 12), (21, 12), (21, 20), (13, 20), (13, 12)],
               [(8, 3), (16, 3), (16, 11), (8, 11), (8, 3)]],
    "jogar": [[(7, 4), (19, 12), (7, 20), (7, 4)]],
    "conta": [("c", 12, 8, 4), [(5, 20), (6, 16.5), (9, 14.5), (15, 14.5), (18, 16.5), (19, 20)]],
}


# ====================================================================== painter (one per paint)
class Painter:
    """Draws into a memory DC: GDI+ for shapes (anti-aliased), GDI for ClearType text."""

    def __init__(self, hdc, scale, fonts):
        self.hdc = hdc
        self.s = scale
        self.fonts = fonts
        self.g = ctypes.c_void_p()
        gdiplus.GdipCreateFromHDC(hdc, ctypes.byref(self.g))
        gdiplus.GdipSetSmoothingMode(self.g, 4)       # anti-alias
        gdiplus.GdipSetPixelOffsetMode(self.g, 4)     # half: crisp edges
        self.clip = None
        self._brushes = {}

    def close(self):
        for b in self._brushes.values():
            gdiplus.GdipDeleteBrush(b)
        self._brushes.clear()
        if self.g:
            gdiplus.GdipDeleteGraphics(self.g)
            self.g = ctypes.c_void_p()

    def _brush(self, color, alpha=255):
        key = (color, alpha)
        b = self._brushes.get(key)
        if b is None:
            b = ctypes.c_void_p()
            gdiplus.GdipCreateSolidFill(argb(color, alpha), ctypes.byref(b))
            self._brushes[key] = b
        return b

    def set_clip(self, x, y, w, h):
        s = self.s
        self.clip = (int(x * s), int(y * s), int((x + w) * s), int((y + h) * s))
        gdiplus.GdipSetClipRect(self.g, x * s, y * s, w * s, h * s, 0)

    def reset_clip(self):
        self.clip = None
        gdiplus.GdipResetClip(self.g)

    def _round_path(self, x, y, w, h, r):
        s = self.s
        x, y, w, h, r = x * s, y * s, w * s, h * s, min(r * s, w / 2.0, h / 2.0)
        path = ctypes.c_void_p()
        gdiplus.GdipCreatePath(0, ctypes.byref(path))
        d = r * 2.0
        if r <= 0.5:
            gdiplus.GdipAddPathArc(path, x, y, 0.01, 0.01, 180, 90)
            gdiplus.GdipAddPathArc(path, x + w - 0.01, y, 0.01, 0.01, 270, 90)
            gdiplus.GdipAddPathArc(path, x + w - 0.01, y + h - 0.01, 0.01, 0.01, 0, 90)
            gdiplus.GdipAddPathArc(path, x, y + h - 0.01, 0.01, 0.01, 90, 90)
        else:
            gdiplus.GdipAddPathArc(path, x, y, d, d, 180, 90)
            gdiplus.GdipAddPathArc(path, x + w - d, y, d, d, 270, 90)
            gdiplus.GdipAddPathArc(path, x + w - d, y + h - d, d, d, 0, 90)
            gdiplus.GdipAddPathArc(path, x, y + h - d, d, d, 90, 90)
        gdiplus.GdipClosePathFigure(path)
        return path

    def rect(self, x, y, w, h, color, radius=0, alpha=255):
        if w <= 0 or h <= 0:
            return
        if radius <= 0:
            s = self.s
            gdiplus.GdipFillRectangle(self.g, self._brush(color, alpha), x * s, y * s, w * s, h * s)
            return
        path = self._round_path(x, y, w, h, radius)
        gdiplus.GdipFillPath(self.g, self._brush(color, alpha), path)
        gdiplus.GdipDeletePath(path)

    def _pen(self, color, width, alpha):
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(argb(color, alpha), width * self.s, 2, ctypes.byref(pen))
        gdiplus.GdipSetPenStartCap(pen, 2)            # round caps and joins: the stroke icons read like the SVGs
        gdiplus.GdipSetPenEndCap(pen, 2)
        gdiplus.GdipSetPenLineJoin(pen, 2)
        return pen

    def outline(self, x, y, w, h, color, radius=0, width=1.0, alpha=255):
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(argb(color, alpha), width * self.s, 2, ctypes.byref(pen))
        path = self._round_path(x + 0.5, y + 0.5, w - 1, h - 1, radius)
        gdiplus.GdipDrawPath(self.g, pen, path)
        gdiplus.GdipDeletePath(path)
        gdiplus.GdipDeletePen(pen)

    def circle(self, cx, cy, r, color, alpha=255):
        s = self.s
        gdiplus.GdipFillEllipse(self.g, self._brush(color, alpha), (cx - r) * s, (cy - r) * s, 2 * r * s, 2 * r * s)

    def ring(self, cx, cy, r, color, width=1.0, alpha=255):
        pen = self._pen(color, width, alpha)
        s = self.s
        gdiplus.GdipDrawEllipse(self.g, pen, (cx - r) * s, (cy - r) * s, 2 * r * s, 2 * r * s)
        gdiplus.GdipDeletePen(pen)

    def line(self, x1, y1, x2, y2, color, width=1.0, alpha=255):
        pen = self._pen(color, width, alpha)
        s = self.s
        gdiplus.GdipDrawLine(self.g, pen, x1 * s, y1 * s, x2 * s, y2 * s)
        gdiplus.GdipDeletePen(pen)

    def polyline(self, pts, color, width=1.0, alpha=255):
        if len(pts) < 2:
            return
        pen = self._pen(color, width, alpha)
        s = self.s
        for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
            gdiplus.GdipDrawLine(self.g, pen, x1 * s, y1 * s, x2 * s, y2 * s)
        gdiplus.GdipDeletePen(pen)

    def _with_dc(self, fn):
        hdc = HANDLE()
        if gdiplus.GdipGetDC(self.g, ctypes.byref(hdc)) != 0 or not hdc:
            return None
        saved = gdi32.SaveDC(hdc)
        try:
            if self.clip:
                gdi32.IntersectClipRect(hdc, *self.clip)
            return fn(hdc)
        finally:
            gdi32.RestoreDC(hdc, saved)
            gdiplus.GdipReleaseDC(self.g, hdc)

    def text(self, x, y, w, h, s, color, size=14, weight=FW_NORMAL, mono=False, flags=DT_LEFT | DT_WORDBREAK, pixel=False):
        if not s:
            return
        font = self.fonts.get(size, weight, mono, pixel)
        sc = self.s

        def draw(hdc):
            gdi32.SelectObject(hdc, font)
            gdi32.SetBkMode(hdc, TRANSPARENT)
            gdi32.SetTextColor(hdc, colorref(color))
            left, top = int(round(x * sc)), int(round(y * sc))
            r = RECT(left, top, left + int(round(w * sc)) + 1, top + int(round(h * sc)) + 1)
            user32.DrawTextW(hdc, s, -1, ctypes.byref(r), flags | DT_NOPREFIX)
        self._with_dc(draw)


class Fonts:
    def __init__(self):
        self.scale = 1.0
        self.cache = {}

    def set_scale(self, scale):
        if scale != self.scale:
            self.clear()
            self.scale = scale

    def clear(self):
        for f in self.cache.values():
            gdi32.DeleteObject(f)
        self.cache.clear()

    def get(self, size, weight=FW_NORMAL, mono=False, pixel=False):
        key = (size, weight, mono, pixel)
        f = self.cache.get(key)
        if f is None:
            wt = weight
            if pixel:
                if _private["pixel"]:
                    face, wt = "Jersey 15", FW_NORMAL        # one weight; it is already heavy (no synthetic bold)
                else:
                    face, wt = "Segoe UI", FW_BOLD
            elif mono:
                if _private["mono"]:
                    face, wt = ("IBM Plex Mono SemiBold", FW_NORMAL) if weight >= FW_SEMIBOLD else ("IBM Plex Mono", FW_NORMAL)
                else:
                    face = "Consolas"
            else:
                face = "Segoe UI Semibold" if weight == FW_SEMIBOLD else "Segoe UI"
            f = gdi32.CreateFontW(-int(round(size * self.scale)), 0, 0, 0, wt, 0, 0, 0, 1, 0, 0, CLEARTYPE_QUALITY, 0, face)
            self.cache[key] = f
        return f


# ====================================================================== immediate-mode UI
class UI:
    """One frame of UI: drawing helpers plus widgets that report clicks. Built anew on every paint."""

    def __init__(self, win, painter, width, height):
        self.win = win
        self.p = painter
        self.w = width            # logical size of the client area
        self.h = height
        self.mouse = win.mouse    # logical coordinates, or None when outside
        self.click = win.take_click()
        self.keys, self.chars = win.take_keys()   # keys pressed (virtual-key codes) and text typed since last frame
        self.wheel = 0
        self.hot = False          # something clickable under the mouse (hand cursor)
        self.fired = False        # a widget fired: paint again with the new state
        self.clip = None          # (x, y, w, h) of the active scroll area
        self.dy = 0               # scroll offset of the active scroll area

    # ---------------------------------------------------------------- geometry helpers
    def _visible(self, x, y, w, h):
        if self.clip is None:
            return True
        cx, cy, cw, ch = self.clip
        return not (y + h < cy or y > cy + ch or x + w < cx or x > cx + cw)

    def _inside(self, pt, x, y, w, h):
        if pt is None:
            return False
        px, py = pt
        if self.clip is not None:
            cx, cy, cw, ch = self.clip
            if not (cx <= px < cx + cw and cy <= py < cy + ch):
                return False
        return x <= px < x + w and y <= py < y + h

    def hover(self, x, y, w, h):
        return self._inside(self.mouse, x, y + self.dy, w, h)

    def clicked(self, x, y, w, h):
        """A full click (press and release) inside this rectangle."""
        if self.click is None:
            return False
        down, up = self.click
        y += self.dy
        if self._inside(down, x, y, w, h) and self._inside(up, x, y, w, h):
            self.click = None
            self.fired = True
            return True
        return False

    def interactive(self, x, y, w, h, enabled=True):
        """Hover/click bookkeeping for a clickable rectangle. Returns (hovered, clicked)."""
        if not enabled:
            return False, False
        hv = self.hover(x, y, w, h)
        if hv:
            self.hot = True
        return hv, self.clicked(x, y, w, h)

    def pressing(self, hv):
        return hv and self.win.lbutton_down

    def measure(self, s, w, size=14, weight=FW_NORMAL, mono=False, wrap=True, pixel=False):
        return self.win.measure(s, w, size, weight, mono, wrap, pixel)

    # ---------------------------------------------------------------- drawing (scroll-aware)
    def rect(self, x, y, w, h, color, radius=0, alpha=255):
        if self._visible(x, y + self.dy, w, h):
            self.p.rect(x, y + self.dy, w, h, color, radius, alpha)

    def outline(self, x, y, w, h, color, radius=0, width=1.0, alpha=255):
        if self._visible(x, y + self.dy, w, h):
            self.p.outline(x, y + self.dy, w, h, color, radius, width, alpha)

    def circle(self, cx, cy, r, color, alpha=255):
        if self._visible(cx - r, cy - r + self.dy, 2 * r, 2 * r):
            self.p.circle(cx, cy + self.dy, r, color, alpha)

    def ring(self, cx, cy, r, color, width=1.0, alpha=255):
        if self._visible(cx - r, cy - r + self.dy, 2 * r, 2 * r):
            self.p.ring(cx, cy + self.dy, r, color, width, alpha)

    def line(self, x1, y1, x2, y2, color, width=1.0, alpha=255):
        self.p.line(x1, y1 + self.dy, x2, y2 + self.dy, color, width, alpha)

    def text(self, x, y, w, s, color="#ece9e2", size=14, weight=FW_NORMAL, mono=False, align="left", wrap=True,
             h=None, pixel=False):
        """Draws text at (x, y) in a box w wide; returns the height it used (logical px)."""
        if not s:
            return 0
        tw, th = self.measure(s, w, size, weight, mono, wrap, pixel)
        if h is None:
            h = th
        if self._visible(x, y + self.dy, w, h):
            flags = {"left": DT_LEFT, "center": DT_CENTER, "right": DT_RIGHT}[align]
            flags |= DT_WORDBREAK | DT_EDITCONTROL if wrap else DT_SINGLELINE | DT_END_ELLIPSIS | DT_VCENTER
            self.p.text(x, y + self.dy, w, h, s, color, size, weight, mono, flags, pixel)
        return th

    def icon(self, name, x, y, size, color, width=1.9, alpha=255):
        """A stroke icon from ICONS, drawn in a size x size box at (x, y)."""
        shapes = ICONS.get(name)
        if not shapes or not self._visible(x, y + self.dy, size, size):
            return
        k = size / 24.0
        wd = max(1.2, width * size / 20.0)
        for sh in shapes:
            if isinstance(sh, tuple) and sh and sh[0] == "c":
                self.p.ring(x + sh[1] * k, y + self.dy + sh[2] * k, sh[3] * k, color, wd, alpha)
            else:
                self.p.polyline([(x + px * k, y + self.dy + py * k) for px, py in sh], color, wd, alpha)

    def pixels(self, x, y, cell, rows, palette):
        """Pixel art: rows of characters, each a palette key (anything not in the palette is transparent)."""
        if not self._visible(x, y + self.dy, cell * max(len(r) for r in rows), cell * len(rows)):
            return
        for j, row in enumerate(rows):
            i = 0
            while i < len(row):                       # runs of the same colour as one rectangle
                ch = row[i]
                n = 1
                while i + n < len(row) and row[i + n] == ch:
                    n += 1
                col = palette.get(ch)
                if col:
                    self.p.rect(x + i * cell, y + self.dy + j * cell, n * cell + 0.02, cell + 0.02, col)
                i += n

    # ---------------------------------------------------------------- scroll areas
    def begin_scroll(self, key, x, y, w, h, content_height):
        """Everything until end_scroll() scrolls inside (x, y, w, h). Returns the scroll offset (<= 0)."""
        off = self.win.scroll.get(key, 0.0)
        if self.win.wheel and self.mouse and x <= self.mouse[0] < x + w and y <= self.mouse[1] < y + h:
            off += self.win.wheel * 0.6
            self.win.wheel = 0
        off = max(min(0.0, off), min(0.0, h - content_height))
        self.win.scroll[key] = off
        self._scroll_state = (off, content_height)
        self.clip = (x, y, w, h)
        self.dy = off
        self.p.set_clip(x, y, w, h)
        return off

    def end_scroll(self, x, y, w, h, color=None):
        """Closes the scroll area opened by begin_scroll and draws its scroll bar."""
        self.p.reset_clip()
        self.clip = None
        self.dy = 0
        off, content_height = getattr(self, "_scroll_state", (0.0, 0.0))
        if content_height > h + 1:
            bar_h = max(30.0, h * h / float(content_height))
            pos = (-off) / max(1.0, content_height - h)
            self.p.rect(x + w - 7, y + 4 + (h - 8 - bar_h) * pos, 4, bar_h, color or T["line2"], 2, 230)

    # ---------------------------------------------------------------- surfaces
    def panel(self, x, y, w, h, bg=None, border=None, radius=6, shadow=True, alpha=255):
        """A raised card: 3 px shadow under it, a hairline border and a light top edge (block-game bevel)."""
        if shadow:
            self.rect(x, y + 3, w, h, T["shadow"], radius, alpha)
        self.rect(x, y, w, h, bg or T["panel"], radius, alpha)
        self.outline(x, y, w, h, border or T["line"], radius, 1.0, alpha)
        if w > 2 * radius + 2:
            self.rect(x + radius, y + 1, w - 2 * radius, 1, "#ffffff", 0, 14)

    def inset(self, x, y, w, h, bg=None, radius=4):
        """A sunken well (fields, logs, metric chips)."""
        self.rect(x, y, w, h, bg or T["inset"], radius)
        self.outline(x, y, w, h, T["line"], radius)

    def pill(self, x, y, text, kind="off", size=12, h=24, align="left"):
        """A small status label; returns its width. align='right': x is the right edge."""
        bg, fg = PILL.get(kind, PILL["off"])
        tw = self.measure(text, 600, size, FW_SEMIBOLD, wrap=False)[0] + 20
        if align == "right":
            x -= tw
        self.rect(x, y, tw, h, bg, 3)
        self.text(x, y, tw, text, fg, size, FW_SEMIBOLD, align="center", wrap=False, h=h)
        return tw

    def keycap(self, x, y, label, size=17, h=28, min_w=0):
        """A light-gray key in the style of a block-game button; returns its width."""
        kw = max(min_w, self.measure(label, 300, size, FW_SEMIBOLD, wrap=False, pixel=True)[0] + 22)
        self.rect(x, y, kw, h, "#555555", 3)
        self.rect(x, y, kw - 2, h - 3, "#ffffff", 3)
        self.rect(x + 2, y + 2, kw - 4, h - 5, "#c6c6c6", 2)
        self.text(x, y, kw, label, "#1e1e1e", size, FW_SEMIBOLD, align="center", wrap=False, h=h - 2, pixel=True)
        return kw

    # ---------------------------------------------------------------- widgets
    BTN = {"primary": ("#6cc04a", "#0f1e08", "#3f7a2a", None, 70),
           "secondary": ("#1d2229", "#ece9e2", "#121418", "#3a414b", 16),
           "danger": ("#2a1916", "#f6d3c8", "#170c0a", "#5a2a22", 14),
           "amber": ("#e9a23b", "#1e1405", "#8a5a17", None, 70),
           "ghost": ("#101215", "#c3c8cf", "#0b0d10", "#2a2f37", 10)}

    def button(self, key, x, y, w, h, label, bg=None, fg=None, enabled=True, radius=4, size=14,
               weight=FW_SEMIBOLD, hover_bg=None, border=None, kind=None, icon=None):
        """Block-style button: a darker band at the bottom that disappears when pressed. kind: primary (green),
        secondary, danger, amber, ghost; or explicit bg/fg/border colours."""
        hv, ck = self.interactive(x, y, w, h, enabled)
        pressed = self.pressing(hv)
        if kind is None and bg is None:
            kind = "secondary"
        if kind:
            base, fcol, band, bcol, hi = self.BTN[kind]
        else:
            base, fcol, band, bcol, hi = bg, fg or T["text"], T["shadow"], border, 18
        if hover_bg and hv:
            base = hover_bg
        a = 255 if enabled else 105
        oy = 2 if pressed else 0
        if not pressed:
            self.rect(x, y + 2, w, h, T["shadow"], radius, a)
        self.rect(x, y + oy, w, h, band, radius, a)
        self.rect(x, y + oy, w, h - (1 if pressed else 4), base, radius, a)
        if enabled:
            self.rect(x + 3, y + oy + 1, w - 6, 2 if kind in ("primary", "amber") else 1, "#ffffff", 0, hi)
        if bcol:
            self.outline(x, y + oy, w, h, bcol, radius, 1.0, a)
        if hv and enabled:
            self.rect(x, y + oy, w, h, "#ffffff", radius, 22)
        tc = (fg or fcol) if enabled else T["muted"]
        if icon:
            tw = self.measure(label, w, size, weight, wrap=False)[0]
            isz = min(18, h - 12)
            total = isz + 8 + tw
            ix = x + max(10, (w - total) / 2)
            self.icon(icon, ix, y + oy + (h - 2 - isz) / 2, isz, tc)
            self.text(ix + isz + 8, y + oy, w - (ix - x) - isz - 14, label, tc, size, weight, wrap=False, h=h - 2)
        else:
            self.text(x + 6, y + oy, w - 12, label, tc, size, weight, align="center", wrap=False, h=h - 2)
        return ck

    def block(self, key, x, y, w, h, title, sub, top, body, shade, enabled=True):
        """A Minecraft-block button (grass top / dirt body, TNT, wither...)."""
        hv, ck = self.interactive(x, y, w, h, enabled)
        pressed = self.pressing(hv)
        oy = 2 if pressed else 0
        a = 255 if enabled else 80
        if not pressed:
            self.rect(x, y + 3, w, h, T["shadow"], 4, a)
        self.rect(x, y + oy, w, h, shade, 4, a)
        self.rect(x, y + oy, w, h - 5, body, 4, a)
        self.rect(x, y + oy, w, 10, top, 4, a)
        self.rect(x, y + oy + 6, w, 4, top, 0, a)
        for i in range(int(w // 14)):                     # a few darker "pixels" along the top edge
            if (i * 7 + int(w)) % 3 == 0:
                self.rect(x + 4 + i * 14, y + oy + 10, 6, 3, top, 0, a)
        self.rect(x + 3, y + oy + 1, w - 6, 1, "#ffffff", 0, 60 if enabled else 20)
        if hv:
            self.rect(x, y + oy, w, h, "#ffffff", 4, 26)
        tc = "#fffaf2" if enabled else "#d6d0c8"
        self.text(x + 13, y + oy + 16, w - 22, title, "#1a120c", 20, FW_BOLD, pixel=True)    # 1 px shadow
        th = self.text(x + 12, y + oy + 15, w - 22, title, tc, 20, FW_BOLD, pixel=True)
        if sub:
            self.text(x + 12, y + oy + 20 + th, w - 22, sub, tc, 12)
        return ck

    def checkbox(self, key, x, y, w, label, checked, enabled=True, size=14):
        th = self.measure(label, w - 32, size)[1]
        h = max(24, th + 2)
        hv, ck = self.interactive(x, y, w, h, enabled)
        a = 255 if enabled else 110
        if hv:
            self.rect(x - 6, y - 2, w + 12, h + 4, "#ffffff", 4, 10)
        if checked:
            self.rect(x, y + 2, 20, 20, T["green_d"], 3, a)
            self.rect(x, y + 2, 20, 18, T["green"], 3, a)
            self.line(x + 5, y + 12, x + 9, y + 16, T["on_green"], 2.4)
            self.line(x + 9, y + 16, x + 15, y + 7, T["on_green"], 2.4)
        else:
            self.rect(x, y + 2, 20, 20, T["inset"], 3, a)
            self.outline(x, y + 2, 20, 20, T["line2"], 3, 1.0, a)
        self.text(x + 30, y + 3, w - 32, label, T["text"] if enabled else T["muted"], size)
        return ck, h

    def segmented(self, key, x, y, options, current, size=13, pad=14, height=38, bg=None):
        """options: [(value, label)]. Returns (new value or None, width used)."""
        widths = [self.measure(lbl, 1000, size, FW_SEMIBOLD, wrap=False)[0] + 2 * pad for _, lbl in options]
        total = sum(widths) + 8 + 4 * (len(options) - 1)
        self.inset(x, y, total, height, bg or T["inset"], 5)
        cx = x + 4
        chosen = None
        for (val, lbl), bw in zip(options, widths):
            on = val == current
            hv, ck = self.interactive(cx, y + 4, bw, height - 8)
            if on:
                self.rect(cx, y + 4, bw, height - 8, T["green_d"], 3)
                self.rect(cx, y + 4, bw, height - 10, T["green"], 3)
                self.rect(cx + 3, y + 5, bw - 6, 1, "#ffffff", 0, 60)
            elif hv:
                self.rect(cx, y + 4, bw, height - 8, "#ffffff", 3, 16)
            self.text(cx, y + 4, bw, lbl, T["on_green"] if on else T["soft"], size, FW_SEMIBOLD, align="center",
                      wrap=False, h=height - (10 if on else 8))
            if ck and not on:
                chosen = val
            cx += bw + 4
        return chosen, total

    def dot(self, cx, cy, state, r=5.5):
        color = {"ok": T["ok"], "wait": T["wait"], "bad": T["bad"]}.get(state, T["off"])
        if state in ("ok", "wait", "bad"):
            self.circle(cx, cy, r + 3, color, 40)
        self.circle(cx, cy, r, color)

    def switch(self, x, y, on, w=52, h=28):
        """A block-style on/off switch (drawing only)."""
        self.rect(x, y, w, h, "#000000", 3, 90)
        k = h - 6
        kx = x + w - k - 3 if on else x + 3
        self.rect(kx, y + 3, k, k, "#bdb6a6", 2)
        self.rect(kx, y + 3, k, k - 3, "#f4f1ea", 2)

    def toggle_button(self, key, x, y, w, h, on, label_on, label_off, enabled=True):
        """The big fusion switch: green when on, dark when off, with a sliding knob."""
        hv, ck = self.interactive(x, y, w, h, enabled)
        pressed = self.pressing(hv)
        kind = "primary" if on else "secondary"
        base, fcol, band, bcol, hi = self.BTN[kind]
        oy = 2 if pressed else 0
        if not pressed:
            self.rect(x, y + 2, w, h, T["shadow"], 4)
        self.rect(x, y + oy, w, h, band, 4)
        self.rect(x, y + oy, w, h - (1 if pressed else 4), base, 4)
        self.rect(x + 3, y + oy + 1, w - 6, 2 if on else 1, "#ffffff", 0, hi)
        if bcol:
            self.outline(x, y + oy, w, h, bcol, 4)
        if hv:
            self.rect(x, y + oy, w, h, "#ffffff", 4, 22)
        sw_h = min(28, h - 18)
        self.switch(x + 12, y + oy + (h - 4 - sw_h) / 2, on, w=int(sw_h * 1.85), h=sw_h)
        tx = x + 12 + int(sw_h * 1.85) + 12
        self.text(tx, y + oy, x + w - tx - 10, label_on if on else label_off, fcol, 15, FW_BOLD, wrap=False, h=h - 3)
        return ck

    def nav_item(self, key, x, y, w, h, icon, label, active, badge=None):
        """A sidebar row. badge: dot state shown at the right ('ok', 'wait', 'bad') or None."""
        hv, ck = self.interactive(x, y, w, h)
        if active:
            self.rect(x, y, w, h, T["panel2"], 4)
            self.rect(x + 4, y + 1, w - 8, 1, "#ffffff", 0, 16)
            self.rect(x, y + 10, 3, h - 20, T["green"], 1)
        elif hv:
            self.rect(x, y, w, h, "#ffffff", 4, 10)
        col = T["green"] if active else (T["text"] if hv else T["muted"])
        self.icon(icon, x + 14, y + (h - 18) / 2, 18, col)
        self.text(x + 44, y, w - 66, label, T["head"] if active else (T["text"] if hv else T["soft"]), 14,
                  FW_SEMIBOLD if active else FW_NORMAL, wrap=False, h=h)
        if badge:
            self.dot(x + w - 16, y + h / 2, badge, 4)
        return ck and not active

    def tabs(self, x, y, w, options, current):
        """Top navigation: [(key, label)]. Returns the clicked key or None."""
        chosen = None
        cx = x
        for key, lbl in options:
            tw = self.measure(lbl, 1000, 15, FW_SEMIBOLD, wrap=False)[0] + 32
            on = key == current
            hv, ck = self.interactive(cx, y, tw, 40)
            if on:
                self.rect(cx, y, tw, 40, T["panel2"], 4)
            elif hv:
                self.rect(cx, y, tw, 40, "#ffffff", 4, 12)
            self.text(cx, y, tw, lbl, T["head"] if on else T["soft"], 15, FW_SEMIBOLD, align="center", wrap=False, h=40)
            if ck and not on:
                chosen = key
            cx += tw + 6
        self.rect(x, y + 40, w, 1, T["line"])
        return chosen


# ====================================================================== the window
class Window:
    """A top-level window whose content is drawn by build(ui) on every paint."""

    _classes = set()
    _windows = {}

    def __init__(self, title, width, height, build, class_name="FusionBridgeWindow", icon=None, min_size=(900, 620),
                 timer_ms=400, ex_style=0, style=WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, bg="#101215", on_close=None,
                 drag_anywhere=False, x=None, y=None):
        self.build = build
        self.bg = bg
        self.min_size = min_size
        self.on_close = on_close
        self.drag_anywhere = drag_anywhere
        self.mouse = None
        self.lbutton_down = False
        self._down_pos = None
        self._click = None
        self._keys, self._chars = [], []
        self.wheel = 0
        self.scroll = {}
        self.fonts = Fonts()
        self.scale = 1.0
        self.hot = False
        self.tracking = False
        self._measure_dc = None
        self._measure_cache = {}
        self.closed = False
        self._posted = []
        hinst = kernel32.GetModuleHandleW(None)
        if class_name not in Window._classes:
            wc = WNDCLASSEXW()
            wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
            wc.style = CS_HREDRAW | CS_VREDRAW
            wc.lpfnWndProc = ctypes.cast(Window._dispatch_proc, ctypes.c_void_p)
            wc.hInstance = hinst
            wc.hCursor = user32.LoadCursorW(None, ctypes.c_void_p(IDC_ARROW))
            wc.lpszClassName = class_name
            if not user32.RegisterClassExW(ctypes.byref(wc)):
                raise OSError("RegisterClassExW failed: %d" % ctypes.get_last_error())
            Window._classes.add(class_name)
        Window._creating = self
        self.hwnd = user32.CreateWindowExW(ex_style, class_name, title, style,
                                           CW_USEDEFAULT if x is None else x, CW_USEDEFAULT if y is None else y,
                                           width, height, None, None, hinst, None)
        Window._creating = None
        if not self.hwnd:
            raise OSError("CreateWindowExW failed: %d" % ctypes.get_last_error())
        Window._windows[self.hwnd] = self
        self._update_scale()
        if x is None:
            self._fit_to_screen(width, height)
        self._dark_title()
        if icon and os.path.exists(icon):
            big = user32.LoadImageW(None, icon, IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
            small = user32.LoadImageW(None, icon, IMAGE_ICON, 16, 16, LR_LOADFROMFILE)
            if big:
                user32.SendMessageW(self.hwnd, WM_SETICON, ICON_BIG, big)
            if small:
                user32.SendMessageW(self.hwnd, WM_SETICON, ICON_SMALL, small)
        if timer_ms:
            user32.SetTimer(self.hwnd, 1, timer_ms, None)

    # -- one shared window procedure for every Window instance
    @staticmethod
    def _route(hwnd, msg, wparam, lparam):
        w = Window._windows.get(hwnd) or getattr(Window, "_creating", None)
        if w is not None:
            try:
                return w._wndproc(hwnd, msg, wparam, lparam)
            except Exception as e:  # never let an exception unwind through Windows
                Window.report_error(e)
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    error_handler = None

    @staticmethod
    def report_error(e):
        if Window.error_handler:
            try:
                Window.error_handler(e)
            except Exception:
                pass

    def show(self):
        user32.ShowWindow(self.hwnd, SW_SHOW)
        user32.UpdateWindow(self.hwnd)

    def close(self):
        if self.hwnd and not self.closed:
            user32.DestroyWindow(self.hwnd)

    def invalidate(self):
        if self.hwnd and not self.closed:
            user32.InvalidateRect(self.hwnd, None, False)

    def post(self, fn):
        """Runs fn after the current paint, from the message loop (for dialogs and message boxes)."""
        self._posted.append(fn)
        if self.hwnd and not self.closed:
            user32.PostMessageW(self.hwnd, WM_APP, 0, 0)

    def take_click(self):
        c, self._click = self._click, None
        return c

    def take_keys(self):
        k, c = self._keys, "".join(self._chars)
        self._keys, self._chars = [], []
        return k, c

    def _update_scale(self):
        dpi = 96
        try:
            dpi = user32.GetDpiForWindow(self.hwnd) or 96
        except Exception:
            pass
        self.scale = dpi / 96.0
        self.fonts.set_scale(self.scale)
        self._measure_cache.clear()

    def _fit_to_screen(self, width, height):
        """Scale the window to the monitor's DPI and keep it inside the work area (a 1366x768 laptop, or 125%
        scaling on 1080p, is smaller than 1200x820), centred."""
        w, h = int(width * self.scale), int(height * self.scale)
        try:
            mon = user32.MonitorFromWindow(self.hwnd, 2)        # MONITOR_DEFAULTTONEAREST
            mi = MONITORINFO()
            mi.cbSize = ctypes.sizeof(MONITORINFO)
            if mon and user32.GetMonitorInfoW(mon, ctypes.byref(mi)):
                wa = mi.rcWork
                ww, wh = wa.right - wa.left, wa.bottom - wa.top
                w, h = min(w, ww - 16), min(h, wh - 16)
                user32.SetWindowPos(self.hwnd, None, wa.left + (ww - w) // 2, wa.top + (wh - h) // 2, w, h,
                                    SWP_NOZORDER | SWP_NOACTIVATE)
                return
        except Exception:
            pass
        user32.SetWindowPos(self.hwnd, None, 0, 0, w, h, 0x0002 | SWP_NOZORDER | SWP_NOACTIVATE)  # SWP_NOMOVE

    def _dark_title(self):
        if dwmapi is None:
            return
        on = ctypes.c_int(1)
        for attr in (20, 19):   # DWMWA_USE_IMMERSIVE_DARK_MODE (20H1+), older builds used 19
            if dwmapi.DwmSetWindowAttribute(self.hwnd, attr, ctypes.byref(on), 4) == 0:
                break
        cap = ctypes.c_uint(colorref(self.bg))
        dwmapi.DwmSetWindowAttribute(self.hwnd, 35, ctypes.byref(cap), 4)   # DWMWA_CAPTION_COLOR (Windows 11)

    def measure(self, s, w, size, weight, mono, wrap, pixel=False):
        key = (s, int(w), size, weight, mono, wrap, pixel)
        r = self._measure_cache.get(key)
        if r is not None:
            return r
        if self._measure_dc is None:
            self._measure_dc = gdi32.CreateCompatibleDC(None)
        hdc = self._measure_dc
        gdi32.SelectObject(hdc, self.fonts.get(size, weight, mono, pixel))
        rc = RECT(0, 0, max(1, int(round(w * self.scale))), 0)
        flags = DT_CALCRECT | DT_NOPREFIX | (DT_WORDBREAK | DT_EDITCONTROL if wrap else DT_SINGLELINE)
        user32.DrawTextW(hdc, s, -1, ctypes.byref(rc), flags)
        r = ((rc.right - rc.left) / self.scale, (rc.bottom - rc.top) / self.scale)
        if len(self._measure_cache) > 4000:
            self._measure_cache.clear()
        self._measure_cache[key] = r
        return r

    def _client_size(self):
        rc = RECT()
        user32.GetClientRect(self.hwnd, ctypes.byref(rc))
        return rc.right - rc.left, rc.bottom - rc.top

    def _logical(self, lparam):
        x = ctypes.c_short(lparam & 0xFFFF).value
        y = ctypes.c_short((lparam >> 16) & 0xFFFF).value
        return x / self.scale, y / self.scale

    def _paint(self):
        ps = PAINTSTRUCT()
        hdc = user32.BeginPaint(self.hwnd, ctypes.byref(ps))
        try:
            cw, ch = self._client_size()
            if cw <= 0 or ch <= 0:
                return
            mem = gdi32.CreateCompatibleDC(hdc)
            bmp = gdi32.CreateCompatibleBitmap(hdc, cw, ch)
            old = gdi32.SelectObject(mem, bmp)
            fired = False
            hot = False
            try:
                painter = Painter(mem, self.scale, self.fonts)
                try:
                    painter.rect(0, 0, cw / self.scale + 1, ch / self.scale + 1, self.bg)
                    ui = UI(self, painter, cw / self.scale, ch / self.scale)
                    self.build(ui)
                    fired, hot = ui.fired, ui.hot
                    self.wheel = 0          # wheel turns over no scroll area are dropped
                finally:
                    painter.close()
                gdi32.BitBlt(hdc, 0, 0, cw, ch, mem, 0, 0, SRCCOPY)
            finally:                        # every frame, even when build() raised: no GDI leak
                gdi32.SelectObject(mem, old)
                gdi32.DeleteObject(bmp)
                gdi32.DeleteDC(mem)
            self.hot = hot
            if fired:
                self.invalidate()   # a widget changed state: show it right away
        finally:
            user32.EndPaint(self.hwnd, ctypes.byref(ps))

    def _wndproc(self, hwnd, msg, wparam, lparam):
        if msg == WM_PAINT:
            self._paint()
            return 0
        if msg == WM_ERASEBKGND:
            return 1
        if msg in (WM_SIZE, WM_TIMER):
            self.invalidate()
            return 0
        if msg == WM_MOUSEMOVE:
            self.mouse = self._logical(lparam)
            if not self.tracking:
                tme = TRACKMOUSEEVENT(ctypes.sizeof(TRACKMOUSEEVENT), TME_LEAVE, hwnd, 0)
                user32.TrackMouseEvent(ctypes.byref(tme))
                self.tracking = True
            self.invalidate()
            return 0
        if msg == WM_MOUSELEAVE:
            self.mouse = None
            self.tracking = False
            self.invalidate()
            return 0
        if msg == WM_LBUTTONDOWN:
            self.lbutton_down = True
            self._down_pos = self._logical(lparam)
            self.mouse = self._down_pos
            user32.SetCapture(hwnd)
            self.invalidate()
            return 0
        if msg == WM_LBUTTONUP:
            user32.ReleaseCapture()
            up = self._logical(lparam)
            if self.lbutton_down and self._down_pos is not None:
                self._click = (self._down_pos, up)
            self.lbutton_down = False
            self._down_pos = None
            self.invalidate()
            return 0
        if msg == WM_MOUSEWHEEL:
            delta = ctypes.c_short((wparam >> 16) & 0xFFFF).value
            pt = POINT(ctypes.c_short(lparam & 0xFFFF).value, ctypes.c_short((lparam >> 16) & 0xFFFF).value)
            user32.ScreenToClient(hwnd, ctypes.byref(pt))
            self.mouse = (pt.x / self.scale, pt.y / self.scale)
            self.wheel += delta
            self.invalidate()
            return 0
        if msg == WM_SETCURSOR and (lparam & 0xFFFF) == HTCLIENT:
            user32.SetCursor(user32.LoadCursorW(None, ctypes.c_void_p(IDC_HAND if self.hot else IDC_ARROW)))
            return 1
        if msg == WM_NCHITTEST and self.drag_anywhere:
            r = user32.DefWindowProcW(hwnd, msg, wparam, lparam)
            if r == HTCLIENT and not self.hot:
                return HTCAPTION
            return r
        if msg == WM_GETMINMAXINFO:
            mmi = ctypes.cast(lparam, ctypes.POINTER(MINMAXINFO)).contents
            mmi.ptMinTrackSize.x = int(self.min_size[0] * self.scale)
            mmi.ptMinTrackSize.y = int(self.min_size[1] * self.scale)
            return 0
        if msg == WM_DPICHANGED:
            r = ctypes.cast(lparam, ctypes.POINTER(RECT)).contents
            user32.SetWindowPos(hwnd, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE)
            self._update_scale()
            self.invalidate()
            return 0
        if msg == WM_APP:
            posted, self._posted = self._posted, []
            for fn in posted:
                try:
                    fn()
                except Exception as e:
                    Window.report_error(e)
            self.invalidate()
            return 0
        if msg == WM_KEYDOWN:
            if len(self._keys) < 64:
                self._keys.append(int(wparam))
            self.invalidate()
            return 0
        if msg == WM_CHAR:
            ch = chr(wparam) if 0 < wparam < 0x110000 else ""
            if ch.isprintable() and len(self._chars) < 256:
                self._chars.append(ch)
            self.invalidate()
            return 0
        if msg == WM_CLOSE:
            if self.on_close is not None and self.on_close() is False:
                return 0
            user32.DestroyWindow(hwnd)
            return 0
        if msg == WM_DESTROY:
            self.closed = True
            user32.KillTimer(hwnd, 1)
            Window._windows.pop(hwnd, None)
            if self._measure_dc:
                gdi32.DeleteDC(self._measure_dc)
                self._measure_dc = None
            self.fonts.clear()
            if getattr(self, "is_main", False):
                user32.PostQuitMessage(0)
            return 0
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)


if IS_WINDOWS:
    Window._dispatch_proc = WNDPROC(Window._route)


_gdiplus_token = ctypes.c_size_t(0)


def init_process(app_id="FusionBridge.PC"):
    """Per-monitor DPI, GDI+ and the taskbar identity. Call once before creating windows."""
    try:
        user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))   # PER_MONITOR_AWARE_V2
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass
    inp = GdiplusStartupInput(1, None, False, False)
    gdiplus.GdiplusStartup(ctypes.byref(_gdiplus_token), ctypes.byref(inp), None)
    try:
        shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass


def single_instance(name, class_name, wait_s=0.0):
    """True if this is the only instance; otherwise brings the other window to the front and returns False.
    wait_s: keep trying that long first (an elevated relaunch starts while the old window is still closing)."""
    _sig(kernel32, "CloseHandle", wintypes.BOOL, HANDLE)
    end = time.time() + wait_s
    while True:
        h = kernel32.CreateMutexW(None, False, name)
        err = ctypes.get_last_error()
        # 183 ERROR_ALREADY_EXISTS; 5 ERROR_ACCESS_DENIED = it exists, made by a copy running as administrator
        if h and err not in (183, 5):
            single_instance.handle = h       # keep it for the life of the process
            return True
        if h:
            kernel32.CloseHandle(h)
        if time.time() >= end:
            break
        time.sleep(0.25)
    other = user32.FindWindowW(class_name, None)
    if other:
        if user32.IsIconic(other):
            user32.ShowWindow(other, SW_RESTORE)
        user32.SetForegroundWindow(other)
    return False


def run_loop():
    msg = MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))
