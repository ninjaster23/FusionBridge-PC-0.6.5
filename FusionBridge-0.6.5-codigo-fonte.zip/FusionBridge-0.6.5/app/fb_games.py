"""FusionBridge PC 0.6.5 - the games installed on this PC, and which of them have a fusion mod.

Everything here only reads:
  * scan() lists the installed games from the launchers' own records: Steam (libraryfolders.vdf and
    appmanifest_*.acf), Epic Games (Manifests\\*.item), GOG, Ubisoft Connect and Rockstar Games Launcher (registry),
    EA app / Battle.net / Riot games (their uninstall entries), the Xbox app (<drive>:\\XboxGames), plus Minecraft
    Java, the classic GTA San Andreas and the games the player added by hand.
  * ModRegistry holds the fusion mods: one JSON file per mod in <app>\\fusion-mods and in
    %LOCALAPPDATA%\\FusionBridge\\fusion-mods. Copying a new file there is all it takes: the app sees it while it is
    open. A fusion mod file is data only - nothing in it is ever run (see fusion-mods\\COMO-ADICIONAR-MOD.md).
  * verdict() says, for a game and a side (host / secondary), whether there is a fusion mod for it.
"""
import glob
import json
import os
import re
import sys
import threading
import time
import unicodedata

IS_WINDOWS = sys.platform == "win32"
ROLES = ("host", "secondary")
ROLE_LABEL = {"host": "Host", "secondary": "Secundário"}
SOURCE_LABEL = {"steam": "Steam", "epic": "Epic Games", "gog": "GOG", "ubisoft": "Ubisoft Connect",
                "rockstar": "Rockstar Games Launcher", "xbox": "Xbox / Microsoft Store", "ea": "EA app",
                "battlenet": "Battle.net", "riot": "Riot Games", "minecraft": "Minecraft Launcher",
                "classic": "instalação avulsa", "manual": "adicionado por você"}
MOD_FILE_MAX = 64 * 1024
MOD_FILES_MAX = 200
# Steam entries that are tools, not games
STEAM_SKIP_IDS = {"228980", "1070560", "1391110", "1628350", "1493710", "2180100", "250820", "1826330"}
STEAM_SKIP_NAME = re.compile(r"^(proton\b|steam linux runtime|steamworks|steamvr\b)|redistributable", re.I)
# uninstall entries of launchers that put their games there (and the launchers themselves, which are not games)
UNINSTALL_PUBLISHERS = {"electronic arts": "ea", "electronic arts, inc.": "ea", "blizzard entertainment": "battlenet",
                        "riot games, inc": "riot", "riot games, inc.": "riot", "rockstar games": "rockstar"}
UNINSTALL_SKIP = re.compile(r"^(ea app|origin|battle\.net|riot client|ea desktop|rockstar games social club)$|uninstall|"
                            r"redistributable|launcher$", re.I)


# ====================================================================== names
def norm_name(s):
    """'Grand Theft Auto: San Andreas(TM)' -> 'grand theft auto san andreas' (accents, marks, punctuation off)."""
    s = re.sub("[\u2122\u00ae\u00a9]", " ", str(s or ""))           # TM, (R), (C) signs
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("ascii").lower()
    s = re.sub(r"\((tm|r|c)\)", " ", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return " ".join(s.split())


def norm_path(p):
    return os.path.normcase(os.path.normpath(os.path.abspath(p))) if p else ""


# ====================================================================== Steam's KeyValues text (VDF/ACF)
_VDF_TOKEN = re.compile(r'"((?:[^"\\]|\\.)*)"|([{}])|//[^\n]*|([^\s{}"]+)')


def _vdf_unescape(s):
    return re.sub(r"\\(.)", lambda m: {"n": "\n", "t": "\t"}.get(m.group(1), m.group(1)), s)


def parse_vdf(text):
    """Valve's KeyValues text format -> nested dicts with lower-case keys. Tolerant: bad input gives what was read."""
    root, stack, key = {}, [], None
    cur = root
    for m in _VDF_TOKEN.finditer(text):
        quoted, brace, bare = m.group(1), m.group(2), m.group(3)
        if brace == "{":
            new = {}
            if key is not None:
                cur[key.lower()] = new
            stack.append(cur)
            cur, key = new, None
            continue
        if brace == "}":
            if stack:
                cur = stack.pop()
            key = None
            continue
        if quoted is not None:
            val = _vdf_unescape(quoted)
        elif bare is not None:
            val = bare
        else:
            continue                      # a // comment
        if key is None:
            key = val
        else:
            cur[key.lower()] = val
            key = None
    return root


def _read_text(path, limit=4 << 20):
    try:
        with open(path, "rb") as f:
            data = f.read(limit)
        return data.decode("utf-8", "replace")
    except OSError:
        return ""


# ====================================================================== where to look (real Windows, or fakes in the tests)
class WinEnv:
    """Registry and disk access on Windows. Every call returns empty on any error."""
    HKLM, HKCU = "HKLM", "HKCU"

    def __init__(self):
        self.environ = os.environ

    def _open(self, hive, path, view64=False):
        import winreg
        h = winreg.HKEY_LOCAL_MACHINE if hive == "HKLM" else winreg.HKEY_CURRENT_USER
        flags = winreg.KEY_READ | (winreg.KEY_WOW64_64KEY if view64 else 0)
        return winreg.OpenKey(h, path, 0, flags)

    def values(self, hive, path, view64=False):
        import winreg
        out = {}
        try:
            with self._open(hive, path, view64) as k:
                i = 0
                while True:
                    try:
                        name, val, _ = winreg.EnumValue(k, i)
                    except OSError:
                        break
                    out[name.lower()] = val
                    i += 1
        except OSError:
            pass
        return out

    def subkeys(self, hive, path, view64=False):
        import winreg
        out = []
        try:
            with self._open(hive, path, view64) as k:
                i = 0
                while True:
                    try:
                        out.append(winreg.EnumKey(k, i))
                    except OSError:
                        break
                    i += 1
        except OSError:
            pass
        return out

    def fixed_drives(self):
        import ctypes
        k32 = ctypes.windll.kernel32
        mask = k32.GetLogicalDrives()
        out = []
        for i in range(26):
            if mask & (1 << i):
                root = "%s:\\" % chr(65 + i)
                if k32.GetDriveTypeW(root) == 3:          # DRIVE_FIXED: no network shares, no CD/USB sticks
                    out.append(root)
        return out


# ====================================================================== the scanners
def _s(v):
    """A registry value as text ('' for numbers, binary data and lists)."""
    return v.strip() if isinstance(v, str) else ""


def _game(source, name, path, **ids):
    key = source + ":" + (ids.get("steam") or ids.get("epic") or ids.get("gog") or ids.get("ubisoft")
                          or norm_path(path) or norm_name(name))
    return {"key": key, "name": (name or "").strip() or os.path.basename(os.path.normpath(path or "")) or "?",
            "source": source, "path": path or "", "ids": {k: str(v) for k, v in ids.items() if v}}


def scan_steam(env):
    roots = []
    for hive, key, view64 in (("HKCU", r"Software\Valve\Steam", False), ("HKLM", r"SOFTWARE\WOW6432Node\Valve\Steam", False),
                              ("HKLM", r"SOFTWARE\Valve\Steam", True)):
        vals = env.values(hive, key, view64)
        v = _s(vals.get("steampath")) or _s(vals.get("installpath"))
        if v:
            roots.append(v)
    pf86 = env.environ.get("ProgramFiles(x86)")
    if pf86:
        roots.append(os.path.join(pf86, "Steam"))
    libs, seen = [], set()

    def add_lib(p):
        n = norm_path(p)
        if p and n not in seen and os.path.isdir(os.path.join(p, "steamapps")):
            seen.add(n)
            libs.append(p)
    for r in roots:
        r = os.path.normpath(r)
        add_lib(r)
        for vdf in (os.path.join(r, "steamapps", "libraryfolders.vdf"), os.path.join(r, "config", "libraryfolders.vdf")):
            data = parse_vdf(_read_text(vdf))
            folders = data.get("libraryfolders") or {}
            for k, val in folders.items():
                if isinstance(val, dict):
                    add_lib(val.get("path"))
                elif k.isdigit() and isinstance(val, str):        # the pre-2021 format
                    add_lib(val)
    games = []
    for lib in libs:
        for acf in sorted(glob.glob(os.path.join(glob.escape(lib), "steamapps", "appmanifest_*.acf")))[:2000]:
            st = parse_vdf(_read_text(acf, 1 << 20)).get("appstate") or {}
            appid, name, inst = st.get("appid"), st.get("name"), st.get("installdir")
            if not appid or not inst or appid in STEAM_SKIP_IDS or STEAM_SKIP_NAME.search(name or ""):
                continue
            flags = st.get("stateflags")
            if flags and flags.isdigit() and not int(flags) & 4:      # 4 = fully installed
                continue
            path = os.path.join(lib, "steamapps", "common", inst)
            if os.path.isdir(path):
                games.append(_game("steam", name, path, steam=appid))
    return games


def scan_epic(env):
    pd = env.environ.get("ProgramData") or "C:\\ProgramData"
    games = []
    for item in sorted(glob.glob(os.path.join(glob.escape(pd), "Epic", "EpicGamesLauncher", "Data", "Manifests", "*.item")))[:2000]:
        try:
            d = json.loads(_read_text(item, 1 << 20) or "{}")
        except ValueError:
            continue
        if not isinstance(d, dict) or d.get("bIsIncompleteInstall"):
            continue
        app, main = d.get("AppName"), d.get("MainGameAppName")
        if main and app and main != app:                          # a DLC of another game
            continue
        cats = d.get("AppCategories")
        if isinstance(cats, list) and cats and "games" not in cats:
            continue
        path = d.get("InstallLocation")
        if path and os.path.isdir(path):
            games.append(_game("epic", d.get("DisplayName"), path, epic=app))
    return games


def scan_gog(env):
    games = []
    base = r"SOFTWARE\WOW6432Node\GOG.com\Games"
    for sub in env.subkeys("HKLM", base)[:2000]:
        v = env.values("HKLM", base + "\\" + sub)
        if _s(v.get("dependson")):                                # DLC
            continue
        path = _s(v.get("path"))
        if path and os.path.isdir(path):
            games.append(_game("gog", _s(v.get("gamename")) or _s(v.get("productname")), path, gog=_s(v.get("gameid")) or sub))
    return games


def scan_ubisoft(env):
    games = []
    base = r"SOFTWARE\WOW6432Node\Ubisoft\Launcher\Installs"
    for sub in env.subkeys("HKLM", base)[:2000]:
        path = _s(env.values("HKLM", base + "\\" + sub).get("installdir")).rstrip("\\/")
        if path and os.path.isdir(path):
            games.append(_game("ubisoft", os.path.basename(os.path.normpath(path)), path, ubisoft=sub))
    return games


def scan_rockstar(env):
    games = []
    base = r"SOFTWARE\WOW6432Node\Rockstar Games"
    for sub in env.subkeys("HKLM", base)[:500]:
        if re.search(r"launcher|social club", sub, re.I):
            continue
        path = _s(env.values("HKLM", base + "\\" + sub).get("installfolder"))
        if path and os.path.isdir(path):
            games.append(_game("rockstar", sub, path))
    return games


def scan_uninstall(env):
    """EA app, Battle.net and Riot games: only their uninstall entries say where they are."""
    games = []
    for hive, base, view64 in (("HKLM", r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", False),
                               ("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", True),
                               ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Uninstall", False)):
        for sub in env.subkeys(hive, base, view64)[:5000]:
            v = env.values(hive, base + "\\" + sub, view64)
            src = UNINSTALL_PUBLISHERS.get(_s(v.get("publisher")).lower())
            name = _s(v.get("displayname"))
            if not src or not name or UNINSTALL_SKIP.search(name) or v.get("systemcomponent") == 1:
                continue
            path = _s(v.get("installlocation")).strip('"')
            if path and os.path.isdir(path):
                games.append(_game(src, name, path))
    return games


def xbox_roots(drive):
    """The Xbox app's game folders on a drive: the ones listed in <drive>\\.GamingRoot (the folder the player
    picked in the app; "RGBX" + a count + UTF-16 paths), plus the default XboxGames."""
    roots = [os.path.join(drive, "XboxGames")]
    try:
        with open(os.path.join(drive, ".GamingRoot"), "rb") as f:
            data = f.read(64 * 1024)
    except OSError:
        data = b""
    if data[:4] == b"RGBX":
        body = data[8:]
        for part in body[:len(body) // 2 * 2].decode("utf-16-le", "ignore").split("\x00"):
            part = part.strip()
            if part and part.isprintable():
                p = part if (len(part) > 2 and part[1] == ":") else os.path.join(drive, part.lstrip("\\/"))
                if norm_path(p) not in {norm_path(r) for r in roots}:
                    roots.append(p)
    return roots


def scan_xbox(env):
    games = []
    for drive in env.fixed_drives():
        for root in xbox_roots(drive):
            try:
                names = sorted(os.listdir(root))[:1000]
            except OSError:
                continue
            for n in names:
                p = os.path.join(root, n)
                if n.startswith(".") or not os.path.isdir(p) or n.lower() in ("gamesave", "gamesaves"):
                    continue
                content = os.path.join(p, "Content")
                games.append(_game("xbox", n, content if os.path.isdir(content) else p))
    return games


def scan_minecraft(env):
    """Minecraft Java has no store record: its launcher folder or the .minecraft folder it creates says it is there."""
    appdata = env.environ.get("APPDATA")
    mc = os.path.join(appdata, ".minecraft") if appdata else None
    if mc and os.path.isdir(mc):
        return [_game("minecraft", "Minecraft: Java Edition", mc, special="minecraft-java")]
    for pf in (env.environ.get("ProgramFiles(x86)"), env.environ.get("ProgramFiles")):
        if pf and os.path.isfile(os.path.join(pf, "Minecraft Launcher", "MinecraftLauncher.exe")):
            return [_game("minecraft", "Minecraft: Java Edition", os.path.join(pf, "Minecraft Launcher"), special="minecraft-java")]
    return []


def scan(env=None, extra=(), gta_sa_dirs=()):
    """All installed games, deduplicated and sorted by name. extra: games added by hand; gta_sa_dirs: folders
    known to hold the classic gta_sa.exe (from fb_installer.find_gta_sa or the Instalacao tab)."""
    env = env or WinEnv()
    found, errors = [], []
    for fn in (scan_minecraft, scan_steam, scan_epic, scan_gog, scan_ubisoft, scan_rockstar, scan_uninstall, scan_xbox):
        try:
            found.extend(fn(env))
        except Exception as e:                                    # one broken launcher record must not hide the rest
            errors.append("%s: %s" % (fn.__name__, e))
    for d in gta_sa_dirs:
        if d and os.path.isfile(os.path.join(d, "gta_sa.exe")):
            found.append(_game("classic", "GTA: San Andreas", d, special="gta-sa"))
    for g in extra or ():
        if isinstance(g, dict) and g.get("path"):
            found.append(dict(g, source="manual"))
    out, by_path, by_name = [], {}, set()
    has_mc = any(g["ids"].get("special") == "minecraft-java" for g in found)
    for g in found:
        if g["source"] == "xbox" and norm_name(g["name"]) == "minecraft launcher":
            if has_mc:
                continue                                          # the same Minecraft Java, through the Xbox app
            g = dict(g, name="Minecraft: Java Edition", ids=dict(g["ids"], special="minecraft-java"))
            has_mc = True
        p = norm_path(g["path"])
        if p and p in by_path:                                    # same folder from two records: keep the first
            first = by_path[p]
            for k, v in g["ids"].items():
                first["ids"].setdefault(k, v)
            continue
        if g["key"] in by_name:
            continue
        by_name.add(g["key"])
        if p:
            by_path[p] = g
        out.append(g)
    out.sort(key=lambda g: (norm_name(g["name"]), g["source"]))
    return out, errors


# ====================================================================== fusion mods
class FusionMod:
    """One fusion mod file, checked. Raises ValueError with a reason in pt-BR when the file is not usable."""

    def __init__(self, data, path):
        if not isinstance(data, dict) or data.get("fusion_mod") != 1:
            raise ValueError('falta "fusion_mod": 1')
        self.path = path
        self.id = self._text(data.get("id"), "id", 64)
        if not re.match(r"^[a-z0-9][a-z0-9._-]*$", self.id):
            raise ValueError('"id" só pode ter letras minúsculas, números, ponto, hífen e _')
        self.name = self._text(data.get("name") or self.id, "name", 120)
        self.version = self._text(data.get("version") or "", "version", 40, empty=True)
        self.author = self._text(data.get("author") or "", "author", 120, empty=True)
        roles = data.get("roles")
        roles = [roles] if isinstance(roles, str) else roles
        if not isinstance(roles, list) or not roles or any(r not in ROLES for r in roles):
            raise ValueError('"roles" precisa ser ["host"], ["secondary"] ou os dois')
        self.roles = list(dict.fromkeys(roles))
        game = data.get("game")
        if not isinstance(game, dict):
            raise ValueError('falta "game"')
        self.game_name = self._text(game.get("name") or "", "game.name", 120, empty=True)
        self.steam = self._ids(game.get("steam"), "game.steam")
        self.epic = self._ids(game.get("epic"), "game.epic")
        self.gog = self._ids(game.get("gog"), "game.gog")
        self.special = self._ids(game.get("special"), "game.special")
        self.names = {norm_name(n) for n in self._list(game.get("names"), "game.names") + [self.game_name] if norm_name(n)}
        self.files = [self._rel(f, "game.files") for f in self._list(game.get("files"), "game.files")]
        if not (self.steam or self.epic or self.gog or self.special or self.names or self.files):
            raise ValueError('"game" precisa dizer como reconhecer o jogo (names, steam, epic, gog ou files)')
        self.partners = self._ids(data.get("partners"), "partners")
        self.installed_when = [self._rel(f, "installed_when", tokens=True) for f in self._list(data.get("installed_when"), "installed_when")]
        # installed_when_any: installed when ANY of these exists (a mod that can live in more than one place)
        self.installed_any = [self._rel(f, "installed_when_any", tokens=True)
                              for f in self._list(data.get("installed_when_any"), "installed_when_any")]
        self.requires = self._text(data.get("requires") or "", "requires", 300, empty=True)
        self.how = self._text(data.get("how") or "", "how", 300, empty=True)
        self.check = self._text(data.get("check") or "", "check", 40, empty=True)

    @staticmethod
    def _text(v, field, maxlen, empty=False):
        if not isinstance(v, str) or (not empty and not v.strip()):
            raise ValueError('"%s" precisa ser um texto' % field)
        v = " ".join(v.split())
        if len(v) > maxlen:
            raise ValueError('"%s" é grande demais' % field)
        return v

    @staticmethod
    def _list(v, field):
        if v is None:
            return []
        if isinstance(v, (str, int)):
            v = [v]
        if not isinstance(v, list) or len(v) > 64:
            raise ValueError('"%s" precisa ser uma lista' % field)
        return v

    def _ids(self, v, field):
        out = set()
        for x in self._list(v, field):
            if isinstance(x, bool) or not isinstance(x, (str, int)) or not str(x).strip() or len(str(x)) > 120:
                raise ValueError('"%s" tem um valor inválido' % field)
            out.add(str(x).strip().lower())
        return out

    @staticmethod
    def _rel(f, field, tokens=False):
        """A path inside the game folder (or {fusionbridge}/..., {localappdata}/...): never absolute, never '..'."""
        if not isinstance(f, str) or not f.strip() or len(f) > 260:
            raise ValueError('"%s" tem um caminho inválido' % field)
        f = f.strip().replace("\\", "/")
        base = "game"
        if tokens and f.startswith("{fusionbridge}/"):
            base, f = "fusionbridge", f[len("{fusionbridge}/"):]
        elif tokens and f.startswith("{localappdata}/"):
            base, f = "localappdata", f[len("{localappdata}/"):]
        elif tokens and f.startswith("{game}/"):
            f = f[len("{game}/"):]
        parts = [p for p in f.split("/") if p not in ("", ".")]
        if not parts or any(p == ".." or ":" in p or "{" in p for p in parts) or f.startswith("/"):
            raise ValueError('"%s": use caminhos dentro da pasta do jogo (sem "..", sem C:\\)' % field)
        return base, os.path.join(*parts)

    def matches(self, game):
        ids = game.get("ids") or {}
        if ids.get("steam") and ids["steam"].lower() in self.steam:
            return True
        if ids.get("epic") and ids["epic"].lower() in self.epic:
            return True
        if ids.get("gog") and ids["gog"].lower() in self.gog:
            return True
        if ids.get("special") and ids["special"].lower() in self.special:
            return True
        if norm_name(game.get("name")) in self.names:
            return True
        path = game.get("path")
        return bool(path and self.files and any(os.path.isfile(os.path.join(path, rel)) for _, rel in self.files))

    def _root(self, base, game, fb_data):
        if base == "fusionbridge":
            return fb_data
        if base == "localappdata":                 # %LOCALAPPDATA% itself: the folder fb_data (…\\FusionBridge) is in
            return os.path.dirname(fb_data.rstrip("\\/")) if fb_data else None
        return game.get("path")

    def installed(self, game, fb_data):
        """True/False when the mod says how to tell, None when it doesn't."""
        if not self.installed_when and not self.installed_any:
            return None
        if self.installed_any:
            hit = False
            for base, rel in self.installed_any:
                root = self._root(base, game, fb_data)
                if root and os.path.exists(os.path.join(root, rel)):
                    hit = True
                    break
            if not hit:
                return False
        for base, rel in self.installed_when:
            root = self._root(base, game, fb_data)
            if not root or not os.path.exists(os.path.join(root, rel)):
                return False
        return True


class ModRegistry:
    """The fusion mods in the given folders, re-read whenever a file there is added, changed or removed."""

    def __init__(self, dirs, log=None):
        self.dirs = [d for d in dirs if d]
        self.log = log or (lambda m: None)
        self.mods = []
        self.problems = []          # (file name, reason) for files that were skipped
        self._sig = None
        self._lock = threading.Lock()
        self.loaded_at = 0.0

    def _files(self):
        out = []
        for d in self.dirs:
            try:
                names = sorted(n for n in os.listdir(d) if n.lower().endswith(".json"))[:MOD_FILES_MAX]
            except OSError:
                continue
            for n in names:
                p = os.path.join(d, n)
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                out.append((p, st.st_mtime_ns, st.st_size))
        return out

    def refresh(self, force=False):
        """Re-reads the folders if anything changed. Returns True when the list of mods changed."""
        files = self._files()
        sig = tuple(files)
        with self._lock:
            if not force and sig == self._sig:
                return False
            mods, problems, by_id = [], [], {}
            for p, _, size in files:
                name = os.path.basename(p)
                if size > MOD_FILE_MAX:
                    problems.append((name, "arquivo grande demais (máximo 64 KB)"))
                    continue
                try:
                    with open(p, "rb") as f:
                        data = json.loads(f.read(MOD_FILE_MAX + 1).decode("utf-8-sig"))
                    m = FusionMod(data, p)
                except OSError as e:
                    problems.append((name, "não deu para ler (%s)" % e.strerror))
                    continue
                except UnicodeDecodeError:
                    problems.append((name, "o arquivo precisa estar em UTF-8"))
                    continue
                except json.JSONDecodeError as e:
                    problems.append((name, "JSON inválido (linha %d)" % e.lineno))
                    continue
                except ValueError as e:                            # FusionMod's own checks
                    problems.append((name, str(e)))
                    continue
                except Exception as e:                             # e.g. RecursionError from absurd nesting
                    problems.append((name, "arquivo inválido (%s)" % type(e).__name__))
                    continue
                if m.id in by_id:                                  # the later folder (the user's) wins
                    mods[by_id[m.id]] = m
                else:
                    by_id[m.id] = len(mods)
                    mods.append(m)
            changed = self._sig is not None
            self._sig, self.mods, self.problems, self.loaded_at = sig, mods, problems, time.time()
        if changed:
            self.log("[Jogos] mods fusion recarregados: %d (%s)" % (len(mods), ", ".join(m.name for m in mods) or "nenhum"))
        for name, why in problems:
            self.log("[Jogos] mod fusion ignorado: %s: %s" % (name, why))
        return True

    def for_game(self, game):
        with self._lock:
            return [m for m in self.mods if m.matches(game)]

    def by_id(self, mod_id):
        with self._lock:
            return next((m for m in self.mods if m.id == mod_id), None)


# ====================================================================== the sentence on the right side
def verdict(game, role, registry, other=None, fb_data="", checks=None):
    """What the picker says about this game on this side. other: the game chosen for the other side.
    -> {"state": "ok"|"wait"|"bad", "title", "lines": [(state, text)], "mod": FusionMod or None}"""
    mods = registry.for_game(game) if game else []
    mine = [m for m in mods if role in m.roles]
    other_role = "secondary" if role == "host" else "host"
    if not mine:
        if mods:
            m = mods[0]
            return {"state": "wait", "mod": None, "title": "Tem mod fusion, mas não como %s" % ROLE_LABEL[role],
                    "lines": [("wait", "O %s funciona com este jogo como %s. Escolha ele do outro lado." % (
                        m.name, " e ".join(ROLE_LABEL[r] for r in m.roles)))]}
        return {"state": "bad", "mod": None, "title": "Não tem mod fusion para este jogo",
                "lines": [("bad", "Sem um mod fusion, o FusionBridge não consegue juntar este jogo com o outro."),
                          ("", "Quando sair um mod fusion para ele, é só colocar o arquivo dele na pasta fusion-mods: "
                               "ele aparece aqui na hora, sem mexer no app.")]}
    theirs = [o for o in registry.for_game(other) if other_role in o.roles] if other else []
    m = next((x for x in mine if any(_pairs(x, o) for o in theirs)), mine[0])   # prefer the one that pairs
    lines = [("ok", "%s%s funciona com este jogo como %s." % (m.name, (" " + m.version) if m.version else "", ROLE_LABEL[role]))]
    inst = m.installed(game, fb_data)
    if inst is True:
        lines.append(("ok", "Mod instalado neste jogo."))
    elif inst is False:
        lines.append(("wait", ("Mod ainda não instalado. " + m.how) if m.how else "Mod ainda não instalado."))
    if m.check and checks and m.check in checks:
        try:
            st, txt = checks[m.check](game)
            if txt:
                lines.append((st, txt))
        except Exception:
            pass
    if m.requires:
        lines.append(("", "Precisa: " + m.requires))
    if other:
        theirs = [o for o in registry.for_game(other) if other_role in o.roles]
        if not theirs:
            lines.append(("wait", "O jogo do outro lado (%s) não tem mod fusion como %s." % (other.get("name"), ROLE_LABEL[other_role])))
        elif not any(_pairs(m, o) for o in theirs):
            lines.append(("wait", "Este mod não faz par com o %s do %s." % (theirs[0].name, other.get("name"))))
        else:
            lines.append(("ok", "Faz a fusão com %s." % other.get("name")))
    return {"state": "ok", "mod": m, "title": "Tem mod fusion para este jogo", "lines": lines}


def _pairs(a, b):
    """Two mods pair when either names the other in "partners", or when neither has a partner list."""
    return b.id in a.partners or a.id in b.partners or (not a.partners and not b.partners)


# ====================================================================== what the player chose
class Choices:
    """The host/secondary games and the games added by hand, kept in %LOCALAPPDATA%\\FusionBridge\\jogos.json."""

    def __init__(self, path):
        self.path = path
        self.host = None
        self.secondary = None
        self.custom = []
        self.gta_path = None        # the GTA folder picked in the Instalacao tab
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict):
                self.host = self._game(d.get("host"))
                self.secondary = self._game(d.get("secondary"))
                custom = d.get("custom")
                self.custom = [g for g in (self._game(x) for x in (custom if isinstance(custom, list) else [])[:200]) if g]
                self.gta_path = d.get("gta_path") if isinstance(d.get("gta_path"), str) else None
        except Exception:                                          # a broken file just starts empty
            self.host = self.secondary = None
            self.custom = []

    @staticmethod
    def _game(g):
        if not isinstance(g, dict) or not isinstance(g.get("name"), str) or not isinstance(g.get("key"), str):
            return None
        ids = g.get("ids") if isinstance(g.get("ids"), dict) else {}
        return {"key": g["key"][:600], "name": g["name"][:200], "source": str(g.get("source") or "manual")[:20],
                "path": str(g.get("path") or "")[:600], "ids": {str(k)[:20]: str(v)[:120] for k, v in list(ids.items())[:8]}}

    def get(self, role):
        return self.host if role == "host" else self.secondary

    def set(self, role, game):
        g = self._game(game)
        if role == "host":
            self.host = g
        else:
            self.secondary = g
        self.save()

    GENERIC_DIRS = {"bin", "bin64", "bin32", "binaries", "win64", "win32", "x64", "x86", "game", "retail", "release", "exe"}

    def add_custom(self, exe_path):
        """A game the player picked by its .exe; it is named after the first folder above it that isn't 'bin' & co."""
        folder = os.path.dirname(exe_path)
        name, d = os.path.splitext(os.path.basename(exe_path))[0], folder
        for _ in range(4):
            base = os.path.basename(d)
            if not base or os.path.dirname(d) == d:
                break
            if base.lower() not in self.GENERIC_DIRS:
                name = base
                break
            d = os.path.dirname(d)
        g = _game("manual", name, folder)
        g["exe"] = os.path.basename(exe_path)
        self.custom = [c for c in self.custom if norm_path(c.get("path")) != norm_path(folder)] + [self._game(g)]
        self.save()
        return self.custom[-1]

    def save(self):
        d = {"host": self.host, "secondary": self.secondary, "custom": self.custom, "gta_path": self.gta_path}
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.path)
            return True
        except OSError:
            return False


def default_dirs(app_root, local=None):
    """The bundled fusion mods, then the player's own folder (which wins on equal ids)."""
    local = local or os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return [os.path.join(app_root, "fusion-mods"), os.path.join(local, "FusionBridge", "fusion-mods")]
