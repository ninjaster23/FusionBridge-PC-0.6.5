"""FusionBridge PC 0.6.5 - what really makes the two games lighter on this PC: the graphics cards, and the frame
generation / upscaling tools that work with games this old. The app only finds and opens them; it never installs
anything or changes a driver setting.

Honest status, shown in the Desempenho tab:
  * DLSS (super resolution and frame generation) has to come from inside a game (motion vectors, jittered frames)
    and exists only for DirectX 11/12 and Vulkan: GTA SA is Direct3D 9 and Minecraft Java is OpenGL, so nothing can
    switch real DLSS on in them. The app shows no button that would do nothing.
  * FSR 1.0 (AMD FidelityFX, spatial) works on any picture: FusionBridgeSA.fx applies it to Minecraft's picture
    inside GTA (EASU + RCAS), so Minecraft can render smaller.
  * Frame generation / upscaling of the whole GTA window: Lossless Scaling (any windowed game), the driver's own
    scaler (NVIDIA Image Scaling, AMD RSR) or Magpie (free, FSR 1.0 for any window).
"""
import os
import sys

DISPLAY_CLASS = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
LOSSLESS_STEAM_ID = "993090"


def gpu_names(winreg_mod=None):
    """The display adapters' names (DriverDesc in the registry), discrete ones first."""
    if winreg_mod is None:
        if sys.platform != "win32":
            return []
        import winreg as winreg_mod
    out = []
    try:
        root = winreg_mod.OpenKey(winreg_mod.HKEY_LOCAL_MACHINE, DISPLAY_CLASS)
    except OSError:
        return []
    with root:
        for i in range(64):
            try:
                sub = winreg_mod.EnumKey(root, i)
            except OSError:
                break
            if not sub.isdigit():
                continue
            try:
                with winreg_mod.OpenKey(root, sub) as k:
                    name = winreg_mod.QueryValueEx(k, "DriverDesc")[0]
            except OSError:
                continue
            if not isinstance(name, str):
                continue
            name = name.strip()[:120]
            low = name.lower()
            if name and name not in out and "basic display" not in low and "remote" not in low and "virtual" not in low:
                out.append(name)
    # the card that runs games first: NVIDIA, then a Radeon RX/Pro, then the rest (integrated graphics)
    rank = lambda n: (0 if "nvidia" in n.lower() else 1 if any(t in n.lower() for t in (" rx ", "rx ", "radeon pro")) else 2)
    return sorted(out, key=rank)


def vendor(name):
    low = (name or "").lower()
    if "nvidia" in low:
        return "nvidia"
    if "amd" in low or "radeon" in low:
        return "amd"
    if "intel" in low:
        return "intel"
    return ""


def is_rtx_40_50(name):
    """NVIDIA Smooth Motion (driver frame generation) is for the RTX 40 and 50 series."""
    low = (name or "").lower()
    return "rtx" in low and any(" %d" % n in low or "%d " % n in low for n in (4050, 4060, 4070, 4080, 4090, 5050, 5060, 5070, 5080, 5090))


def find_lossless_scaling(games):
    """LosslessScaling.exe of the Steam app among the scanned games (Steam lists it like a game), or None."""
    for g in games or []:
        ids = g.get("ids") or {}
        if str(ids.get("steam") or "") == LOSSLESS_STEAM_ID or (g.get("name") or "").strip().lower() == "lossless scaling":
            exe = os.path.join(g.get("path") or "", "LosslessScaling.exe")
            if os.path.isfile(exe):
                return exe
    return None
