#!/usr/bin/env bash
# Runs the FusionBridge PC test suites.
#   - hub + panel end-to-end (Python 3), 0.5.0 suite
#   - fusion engine end-to-end with a fake Minecraft passthrough mod and a fake GTA script (Python 3)
#   - GTA script logic, 0.5.0 + fusion (needs luajit; skipped with a note if absent)
#   - the ASI's camera math (needs g++; skipped if absent)
#   - the in-app installer, the installed-games scan + fusion mods, and the real FusionBridge.exe under Wine
#     when wine64/Xvfb/xdotool are there
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
rc=0

echo "== hub + panel (Python) =="
python3 -I tests/test_pc_hub.py || rc=1

echo
echo "== fusion engine (Python, fake Minecraft + fake GTA) =="
python3 -I tests/test_fusion.py || rc=1

echo
echo "== in-app installer (Python, fake GTA/Minecraft folders) =="
python3 -I tests/test_installer.py || rc=1

echo
echo "== installed games + fusion mods (Python, fake launcher records) =="
python3 -I tests/test_games.py || rc=1


echo
echo "== upscale for any game (Python, fake Magpie zip) =="
python3 -I tests/test_upscale.py || rc=1

echo
echo "== SkyCraft: Minecraft inside Skyrim (Python, fake Skyrim/SKSE/Address Library) =="
python3 -I tests/test_skycraft.py || rc=1

echo
echo "== automatic Minecraft: portable Prism + AutoMC (Python, fake Prism zip) =="
python3 -I tests/test_prism.py || rc=1

echo
echo "== GTA script logic (LuaJIT) =="
if command -v luajit >/dev/null 2>&1; then
  luajit tests/test_gta_lua.lua || rc=1
  luajit tests/test_fusion_lua.lua || rc=1
else
  echo "luajit nao encontrado; pulando (so afeta o teste, nao o uso)."
fi

echo
echo "== ASI camera math (C++) =="
if command -v g++ >/dev/null 2>&1; then
  T="$(mktemp -d)"
  g++ -std=c++17 -O2 src/asi/tests/test_math.cpp -o "$T/test_math" && "$T/test_math" || rc=1
  rm -rf "$T"
else
  echo "g++ nao encontrado; pulando."
fi

echo
echo "== FusionBridgeSA.fx with ReShade's own effect compiler (optional) =="
if [ -n "${RESHADE_SRC:-}" ] && [ -n "${FXH_DIR:-}" ] && command -v g++ >/dev/null 2>&1; then
  tools/check_fx.sh || rc=1
else
  echo "RESHADE_SRC/FXH_DIR nao definidos; pulando (veja tools/check_fx.sh)."
fi

echo
echo "== ASI hang watchdog (MinGW + Wine, optional) =="
WINE_BIN="$(command -v wine64 || { [ -x /usr/lib/wine/wine64 ] && echo /usr/lib/wine/wine64; } || true)"
if command -v x86_64-w64-mingw32-g++ >/dev/null 2>&1 && [ -n "$WINE_BIN" ]; then
  # the game build is 32-bit; the watchdog also builds 64-bit so it can run under a 64-bit-only Wine
  T="$(mktemp -d)"
  if x86_64-w64-mingw32-g++ -std=c++17 -O2 -static -I src/asi -I src/asi/compat src/asi/tests/test_watchdog.cpp \
       src/asi/watchdog.cpp src/asi/sa.cpp -o "$T/test_watchdog.exe"; then
    WP="${WINEPREFIX:-$T/prefix}"
    WINEDEBUG=-all WINEPREFIX="$WP" PATH="/usr/lib/wine:$PATH" timeout 120 "$WINE_BIN" "$T/test_watchdog.exe" 2>/dev/null \
      | grep -v "^  |"
    [ "${PIPESTATUS[0]}" = 0 ] || rc=1
    WINEPREFIX="$WP" PATH="/usr/lib/wine:$PATH" wineserver -k >/dev/null 2>&1 || true
  else
    rc=1
  fi
  rm -rf "$T"
else
  echo "MinGW x86_64 ou Wine ausentes; pulando."
fi

echo
echo "== the real FusionBridge.exe under Wine (optional) =="
if [ -f FusionBridge.exe ] && command -v Xvfb >/dev/null 2>&1 && command -v xdotool >/dev/null 2>&1 \
   && { command -v wine64 >/dev/null 2>&1 || [ -x /usr/lib/wine/wine64 ]; }; then
  python3 -I tests/test_app_wine.py || rc=1
else
  echo "Wine/Xvfb/xdotool ou o runtime (tools/build_app.py) ausentes; pulando."
fi

echo
[ "$rc" = 0 ] && echo "TUDO OK" || echo "ALGUM TESTE FALHOU"
exit $rc
