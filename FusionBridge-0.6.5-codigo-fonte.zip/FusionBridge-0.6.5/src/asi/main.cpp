// FusionBridgeSA.asi - the GTA: San Andreas half of FusionBridge's visual fusion (Minecraft inside GTA SA).
//
// Loaded by the ASI loader (MoonLoader brings one). It
//   * registers as a ReShade 6.8 add-on and composites Minecraft's frames into GTA's picture (compositor.cpp);
//   * exports a tiny C API that FusionBridgeGTA.lua (MoonLoader) calls through LuaJIT FFI:
//       FB_Version, FB_GetCamera (the exact camera GTA renders with), FB_SetFusion (every frame), FB_GetStatus;
//   * blocks GTA's fire/aim buttons while the mouse plays Minecraft (CPad::UpdatePads hook);
//   * renders the effect before GTA's HUD (Render2dStuff hook), so the radar and texts stay on top.
// Game addresses are for gta_sa.exe 1.0 US only and are checked before use (sa.cpp).
#include "camera_math.h"
#include "compositor.h"
#include "sa.h"
#include "watchdog.h"
#include <windows.h>
#include <atomic>
#include <cmath>
#include <cstdarg>
#include <cstdio>

#define FB_API extern "C" __declspec(dllexport)

namespace
{
	constexpr int kVersion = 603; // 0.6.3
	HMODULE g_module = nullptr;
	bool g_saOk = false;
	bool g_padHook = false, g_hudHook = false;
	std::atomic<bool> g_blockMouse{false};
	std::atomic<DWORD> g_blockBeat{0};
	FILE *g_log = nullptr;
	CRITICAL_SECTION g_logLock; // the watchdog thread logs too

	void logf(const char *fmt, ...)
	{
		EnterCriticalSection(&g_logLock);
		if (g_log == nullptr)
		{
			char path[MAX_PATH] = {};
			GetModuleFileNameA(g_module, path, MAX_PATH);
			char *dot = strrchr(path, '.');
			if (dot)
				lstrcpynA(dot, ".log", int(MAX_PATH - (dot - path)));
			g_log = fopen(path, "w");
			if (g_log == nullptr)
			{
				LeaveCriticalSection(&g_logLock);
				return;
			}
		}
		SYSTEMTIME t;
		GetLocalTime(&t);
		fprintf(g_log, "%02d:%02d:%02d ", t.wHour, t.wMinute, t.wSecond);
		va_list args;
		va_start(args, fmt);
		vfprintf(g_log, fmt, args);
		va_end(args);
		fputc('\n', g_log);
		fflush(g_log);
		LeaveCriticalSection(&g_logLock);
	}

	void log_line(const char *line)
	{
		logf("%s", line);
	}

	/// ReShade's d3d9.dll usually loads after the ASI (gta_sa.exe loads it when it starts Direct3D), so registering
	/// often succeeds only later, from the game loop: say when, once.
	void register_with_reshade()
	{
		static bool logged = false;
		watchdog::stage(watchdog::kRegister);
		const bool ok = compositor::try_register(g_module); // cheap once registered
		watchdog::stage(watchdog::kPads);
		if (ok && !logged)
		{
			logged = true;
			logf("ReShade: registrado (a partir do jogo)");
		}
	}

	void __cdecl after_update_pads()
	{
		watchdog::beat();
		watchdog::stage(watchdog::kPads);
		register_with_reshade();
		if (g_blockMouse.load() && GetTickCount() - g_blockBeat.load() < 500 && !sa::menu_active())
			sa::block_fire_and_aim();
		watchdog::stage(watchdog::kIdle);
	}

	void __cdecl before_hud()
	{
		watchdog::beat();
		watchdog::stage(watchdog::kHud);
		compositor::render_before_hud();
		watchdog::stage(watchdog::kIdle);
	}
}

/// 603 for 0.6.3.
FB_API int FB_Version()
{
	return kVersion;
}

/// out[10]: camera x, y, z (GTA), heading, pitch, roll (degrees, GTA convention), vertical fov (degrees),
/// near, far, projection aspect (tan x / tan y). Returns 1 when the camera could be read.
FB_API int FB_GetCamera(float *out)
{
	if (!g_saOk || out == nullptr)
		return 0;
	sa::Camera c;
	if (!sa::read_camera(c))
		return 0;
	const fbmath::Angles a = fbmath::angles_from_vectors(c.fwd, c.up);
	out[0] = c.pos[0];
	out[1] = c.pos[1];
	out[2] = c.pos[2];
	out[3] = a.heading;
	out[4] = a.pitch;
	out[5] = a.roll;
	out[6] = 2.0f * std::atan(c.tan_y) * fbmath::kDeg;
	out[7] = c.near_z;
	out[8] = c.far_z;
	out[9] = c.tan_x / c.tan_y;
	return 1;
}

/// Every frame from the GTA script: composite Minecraft or not, block GTA's fire/aim (mouse plays Minecraft),
/// and the Minecraft height offset. Both switches turn themselves off if the script stops calling.
FB_API void FB_SetFusion(int composite, int block_mouse, float yoff)
{
	compositor::try_register(g_module);
	compositor::set_fusion(g_saOk && composite != 0, std::isfinite(yoff) ? yoff : 0.0f);
	g_blockMouse = g_saOk && block_mouse != 0;
	g_blockBeat = GetTickCount();
}

/// FSR 1.0 for Minecraft's picture, from the app through the GTA script: on (0/1) and RCAS sharpness (stops, 0..2).
FB_API void FB_SetFsr(int on, float sharpness)
{
	compositor::set_fsr(on != 0, sharpness);
}

/// out[16]: sa version ok, reshade registered, fresh Minecraft frame, backbuffer w, h, uploads, pad hook,
/// hud hook, effect found, Minecraft frame w, h, early (before HUD) renders.
FB_API int FB_GetStatus(int *out)
{
	if (out == nullptr)
		return 0;
	int c[16] = {};
	compositor::status(c);
	for (int i = 0; i < 16; ++i)
		out[i] = 0;
	out[0] = g_saOk ? 1 : 0;
	out[1] = c[0];
	out[2] = c[1];
	out[3] = c[2];
	out[4] = c[3];
	out[5] = c[4];
	out[6] = g_padHook ? 1 : 0;
	out[7] = g_hudHook ? 1 : 0;
	out[8] = c[5];
	out[9] = c[6];
	out[10] = c[7];
	out[11] = c[8];
	return 1;
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID reserved)
{
	switch (reason)
	{
	case DLL_PROCESS_ATTACH:
		g_module = module;
		DisableThreadLibraryCalls(module);
		InitializeCriticalSection(&g_logLock);
		g_saOk = sa::is_10us();
		logf("FusionBridgeSA %d.%d.%d carregado", kVersion / 1000, kVersion / 100 % 10, kVersion % 100);
		if (!g_saOk)
		{
			logf("gta_sa.exe nao e a versao 1.0 US: fusao visual desligada (nenhum endereco do jogo sera usado)");
			break;
		}
		g_padHook = sa::hook_update_pads(&after_update_pads);
		g_hudHook = sa::hook_render2d(&before_hud);
		compositor::set_hud_hook(g_hudHook);
		logf("GTA SA 1.0 US ok; bloqueio do mouse: %s; efeito antes do HUD: %s", g_padHook ? "sim" : "NAO (gancho nao encontrado)",
			g_hudHook ? "sim" : "NAO (o Minecraft aparece por cima do HUD)");
		logf("ReShade: %s", compositor::try_register(module) ? "registrado" : "ainda nao carregou (registra quando o jogo comecar)");
		watchdog::start(module, &log_line);
		logf("vigia de travamento ligado (se o GTA ficar 8 s sem desenhar, anota aqui onde ele parou)");
		break;
	case DLL_PROCESS_DETACH:
		// reserved != nullptr: the process is exiting (the module is pinned, so that's the only way here)
		watchdog::stop();
		compositor::unregister(module, reserved != nullptr);
		if (g_log)
			fclose(g_log);
		g_log = nullptr;
		break;
	}
	return TRUE;
}
