#!/usr/bin/env python3
"""FusionBridge PC 0.6.5 - hub + fusion engine (+ optional HTTP API) for Windows (and any OS with Python 3.8+).

One file, standard library only. It:
  * runs the bridge hub on 127.0.0.1:28765 (JSON-lines, protocol v2) that GTA SA (MoonLoader)
    and Minecraft Java (Fabric mod) connect to;
  * is driven by the native app (fb_app.py, FusionBridge.exe) through Controller - no browser;
  * run directly ("python fusionbridge.py") it is a headless server with the same Controller behind an HTTP API
    on 127.0.0.1:28766 (token per run) - used by the tests and for development, it never opens a browser;
  * routes events between the two games and keeps snapshots/diagnostics;
  * runs the fusion engine (fusion_engine.py): links to the Minecraft passthrough mod on 127.0.0.1:25599
    and drives Minecraft from GTA's camera, so Minecraft is drawn *inside* GTA SA.

Run:  FusionBridge.exe (the app), or headless:  python fusionbridge.py
"""
import collections, html, json, os, secrets, socket, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

VERSION = "0.6.5"
HUB_PORT = 28765
UI_PORT = 28766
HERE = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(HERE, "web")
sys.path.insert(0, HERE)
from fusion_engine import FusionEngine, mc_command_for  # noqa: E402

MAX_CLIENTS = 16
OUT_CAP = 128 * 1024
IN_CAP = 64 * 1024
STATE_TYPES = {"player_state", "camera_state", "world_state", "entity_state", "state"}

_log_ring = collections.deque(maxlen=600)


def settings_path():
    """Where the fusion options are saved: the user's profile on Windows (the app folder may be read-only)."""
    if os.name == "nt" and os.environ.get("LOCALAPPDATA"):
        d = os.path.join(os.environ["LOCALAPPDATA"], "FusionBridge")
        try:
            os.makedirs(d, exist_ok=True)
            return os.path.join(d, "fusionbridge_settings.json")
        except OSError:
            pass
    return os.path.join(HERE, "fusionbridge_settings.json")


def log(msg):
    line = time.strftime("%H:%M:%S ") + msg
    _log_ring.append(line)
    print(line, flush=True)


# ====================================================================== hub
class Client:
    __slots__ = ("sock", "name", "role", "side", "ver", "ident", "inbuf", "outbuf",
                 "since", "last_rx", "rx", "tx", "dropped", "bad", "state", "quiet")

    def __init__(self, sock):
        self.sock = sock
        self.name = self.role = self.side = self.ver = ""
        self.ident = False
        self.inbuf, self.outbuf = bytearray(), bytearray()
        self.since = self.last_rx = time.monotonic()
        self.rx = self.tx = self.dropped = self.bad = 0
        self.state = None
        self.quiet = False      # already said it went silent

    def queue(self, line):
        data = (line if line.endswith("\n") else line + "\n").encode("utf-8", "replace")
        if len(self.outbuf) + len(data) > OUT_CAP:
            self.dropped += 1
            return
        self.outbuf += data


class Hub:
    def __init__(self):
        import selectors
        self.sel = selectors.DefaultSelector()
        self.selectors = selectors
        self.clients = {}
        self.cfg = {"mode": "eco", "host": "gta", "secondary": "minecraft",
                    "dlss": False, "framegen": False}
        self.snaps = {}
        self.diags = {}
        self.events = collections.deque(maxlen=60)
        self.cmd_q = collections.deque()
        self.want = True          # bridge on/off
        self.listen = None
        self.pub = {}
        self.lock = threading.Lock()
        self.next_flush = 0.0
        self.next_hk = 0.0
        self.log = log
        self.engine = FusionEngine(self, settings_path=settings_path())
        self._refresh_pub()

    # ---------------------------------------------------------------- helpers
    def hz(self):
        return 20 if self.cfg.get("mode") in ("live", "visual") else 5

    def config_line(self):
        c = {"type": "fusion_config", "protocol": 2, "state_hz": self.hz()}
        c.update({k: self.cfg[k] for k in ("mode", "host", "secondary", "dlss", "framegen")})
        return json.dumps(c, separators=(",", ":"))

    def roster_line(self):
        cl = [{"name": c.name, "role": c.role, "side": c.side} for c in self.clients.values() if c.ident]
        return json.dumps({"type": "roster", "hub": "FusionBridge-PC", "version": VERSION, "clients": cl},
                          separators=(",", ":"))

    def broadcast(self, line, except_c=None):
        for c in self.clients.values():
            if c.ident and c is not except_c:
                c.queue(line)

    @staticmethod
    def matches(to, name):
        return name.startswith(to[:-1]) if to.endswith("*") else to == name

    def add_event(self, frm, text):
        self.events.append({"wall": time.time(), "from": frm, "text": text})

    def route(self, src_name, obj, raw):
        if "from" not in obj:
            obj["from"] = src_name
            raw = json.dumps(obj, separators=(",", ":"))
        to = obj.get("to")
        t = obj.get("type")
        if t in ("event", "command_result"):
            txt = (obj.get("event") or obj.get("action") or t)
            detail = obj.get("detail")
            self.add_event(obj.get("from", src_name), txt + ((": " + str(detail)) if detail else ""))
        for c in self.clients.values():
            if c.name == src_name or not c.ident:
                continue
            if isinstance(to, str) and to and not self.matches(to, c.name):
                continue
            c.queue(raw)

    def close(self, c, why):
        try:
            self.sel.unregister(c.sock)
        except Exception:
            pass
        try:
            c.sock.close()
        except Exception:
            pass
        for k, v in list(self.clients.items()):
            if v is c:
                del self.clients[k]
        if c.ident:
            log("[Hub] %s saiu (%s)" % (c.name, why))
            self.broadcast(self.roster_line())
            if c.name.startswith("gta"):
                # GTA gone with Minecraft's inventory open: let go of anything still held in Minecraft's window
                self.engine.mcwin.release_all(time.monotonic())

    # ---------------------------------------------------------------- protocol
    def handle_line(self, c, line):
        line = line.strip()
        if not line:
            return
        c.rx += 1
        c.last_rx = time.monotonic()
        if c.quiet:
            c.quiet = False
            log("[Hub] %s voltou a responder" % c.name)
        try:
            obj = json.loads(line)
            if not isinstance(obj, dict):
                raise ValueError
        except Exception:
            c.bad += 1
            return
        t = obj.get("type") or obj.get("op")
        if not isinstance(t, str) or not t:
            c.bad += 1
            return
        if t == "hello":
            name = str(obj.get("client") or obj.get("source") or "anon").lower()
            c.name = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in name)[:31] or "anon"
            c.role, c.side = str(obj.get("role", ""))[:23], str(obj.get("side", ""))[:15]
            c.ver, c.ident = str(obj.get("version", "?"))[:15], True
            log("[Hub] %s conectou (v%s)" % (c.name, c.ver))
            c.queue(json.dumps({"type": "hello_ack", "server": "FusionBridge", "version": VERSION,
                                "protocol": 2, "you": c.name}))
            c.queue(self.config_line())
            now = time.time()
            for nm, s in self.snaps.items():
                if nm != c.name:
                    c.queue('{"type":"snapshot","of":%s,"age_ms":%d,"state":%s}'
                            % (json.dumps(nm), int((now - s["t"]) * 1000), s["line"]))
            for nm, dl in self.diags.items():
                if nm != c.name:
                    c.queue(dl)
            self.broadcast(self.roster_line())
            return
        if t == "ping":
            c.queue(json.dumps({"type": "pong", "server": "FusionBridge", "t": int(time.time() * 1000)}))
            return
        if t == "bye":
            self.close(c, "bye")
            return
        if not c.ident:
            c.bad += 1
            return
        if t.startswith("fusion_") and c.name == "gta":
            # the GTA script's fusion stream (camera every frame, ground, input) goes to the engine only
            if self.engine.on_gta(c, t, obj):
                return
        if t in STATE_TYPES:
            c.state = line[:2048]
            self.snaps[c.name] = {"t": time.time(), "line": line[:2048]}
            self.route(c.name, obj, line)
            return
        if t == "diag":
            obj.setdefault("from", c.name)
            prev = self.diags.get(c.name)
            if prev and len(line) < 900 and len(prev) > 900:
                try:
                    full = json.loads(prev); full["update"] = obj
                    self.diags[c.name] = json.dumps(full, separators=(",", ":"))
                except Exception:
                    self.diags[c.name] = json.dumps(obj, separators=(",", ":"))
            else:
                self.diags[c.name] = json.dumps(obj, separators=(",", ":"))
        self.route(c.name, obj, line)

    def on_read(self, c):
        try:
            data = c.sock.recv(65536)
        except (BlockingIOError, InterruptedError):
            return
        except OSError as e:
            self.close(c, "erro de leitura: %s" % e)
            return
        if not data:
            self.close(c, "fechou")
            return
        c.inbuf += data
        while True:
            i = c.inbuf.find(b"\n")
            if i < 0:
                break
            ln = bytes(c.inbuf[:i]).decode("utf-8", "replace")
            del c.inbuf[:i + 1]
            self.handle_line(c, ln)
            if c.sock.fileno() < 0:
                return
        if len(c.inbuf) > IN_CAP:
            c.bad += 1
            c.inbuf.clear()

    def flush(self, c):
        if not c.outbuf:
            return
        try:
            n = c.sock.send(c.outbuf)
            del c.outbuf[:n]
            c.tx += 1
        except (BlockingIOError, InterruptedError):
            pass
        except OSError as e:
            self.close(c, "erro de escrita: %s" % e)

    # ---------------------------------------------------------------- control (from HTTP thread)
    def submit(self, line):
        self.cmd_q.append(line)

    def set_cfg(self, **kw):
        changed = False
        for k, v in kw.items():
            if k in self.cfg and v is not None:
                self.cfg[k] = v
                changed = True
        if self.cfg["mode"] not in ("eco", "live", "visual"):
            self.cfg["mode"] = "eco"
        if changed:
            self.cmd_q.append(self.config_line())
        return changed

    # ---------------------------------------------------------------- listen socket
    def open_listen(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if os.name == "nt":
            # Windows' SO_REUSEADDR would let a second program bind the same port; this keeps it ours alone
            s.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", -5), 1)
        else:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", HUB_PORT))
            s.listen(16)
            s.setblocking(False)
            self.sel.register(s, self.selectors.EVENT_READ, "listen")
            self.listen = s
            log("[Hub] ouvindo em 127.0.0.1:%d" % HUB_PORT)
            return True
        except OSError as e:
            s.close()
            log("[Hub] nao consegui abrir a porta %d: %s" % (HUB_PORT, e))
            return False

    def close_listen(self):
        if self.listen:
            try:
                self.sel.unregister(self.listen)
            except Exception:
                pass
            self.listen.close()
            self.listen = None

    # ---------------------------------------------------------------- public status
    def _refresh_pub(self):
        now = time.monotonic()
        wall = time.time()
        clients = [{"name": c.name, "side": c.side, "role": c.role,
                    "secs": int(now - c.since), "rx": c.rx, "tx": c.tx, "dropped": c.dropped}
                   for c in self.clients.values() if c.ident]
        snaps = [{"of": nm, "age_s": int(wall - s["t"]), "state": s["line"]} for nm, s in self.snaps.items()]
        diags = [{"of": nm, "age_s": 0, "diag": dl} for nm, dl in self.diags.items()]
        events = [{"age_s": int(wall - e["wall"]), "from": e["from"], "text": e["text"]}
                  for e in reversed(self.events)]
        mode = "hub" if (self.want and self.listen) else ("off" if not self.want else "retry")
        self.pub = {"version": VERSION, "hub": {"mode": mode, "port": HUB_PORT, "want": self.want,
                                                "clients": clients, "snapshots": snaps, "diags": diags,
                                                "events": events}, "cfg": dict(self.cfg),
                    "fusion": self.engine.pub}

    # ---------------------------------------------------------------- main loop
    def run(self):
        if self.want:
            self.open_listen()
        errors, streak = {}, 0
        while True:
            try:
                self.step()
                streak = 0
            except Exception as e:
                # one bad message or a failing OS call must never stop the bridge: log it (rarely) and go on; if it
                # keeps failing, drop the connections (the games reconnect by themselves) to clear whatever is stuck
                key = ("%s: %s" % (type(e).__name__, e))[:200]
                n = errors[key] = errors.get(key, 0) + 1
                if n <= 3 or n % 1000 == 0:
                    log("[Hub] erro interno, a ponte continua: %s%s" % (key, " (%d vezes)" % n if n > 1 else ""))
                streak += 1
                if streak == 20:
                    log("[Hub] o erro se repete: reconectando os jogos")
                    for c in list(self.clients.values()):
                        try:
                            self.close(c, "recuperando de um erro")
                        except Exception:
                            pass
                time.sleep(0.05)

    def step(self):
        """One turn of the loop: sockets, panel commands, the fusion engine, housekeeping."""
        # reconcile bridge on/off
        if self.want and not self.listen:
            self.open_listen()
        elif not self.want and self.listen:
            for c in list(self.clients.values()):
                self.close(c, "bridge desligado")
            self.close_listen()

        for key, mask in self.sel.select(0.05):
            if key.data == "mclink":
                self.engine.on_readable(self.sel)
                continue
            if key.data == "listen":
                while True:
                    try:
                        s, _ = self.listen.accept()
                    except (BlockingIOError, InterruptedError):
                        break
                    except OSError:
                        break
                    if len(self.clients) >= MAX_CLIENTS:
                        s.close(); continue
                    s.setblocking(False)
                    s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    c = Client(s)
                    self.clients[s.fileno()] = c
                    self.sel.register(s, self.selectors.EVENT_READ, c)
                continue
            c = key.data
            if mask & self.selectors.EVENT_READ:
                self.on_read(c)

        # drain panel commands
        while self.cmd_q:
            line = self.cmd_q.popleft()
            try:
                obj = json.loads(line)
            except Exception:
                continue
            obj.setdefault("from", "panel")
            self.route("panel", obj, json.dumps(obj, separators=(",", ":")))

        now = time.monotonic()
        self.engine.tick(self.sel, self.selectors, now)
        if now >= self.next_flush:
            self.next_flush = now + 1.0 / max(self.hz(), 5)
            for c in list(self.clients.values()):
                self.flush(c)
        if now >= self.next_hk:
            self.next_hk = now + 1.0
            for c in list(self.clients.values()):
                if now - c.last_rx > (60 if c.ident else 15):
                    self.close(c, "timeout")
                elif c.ident and not c.quiet and now - c.last_rx > 15:
                    # a game sends at least a ping every 5 s: silence means paused (no focus, menu) or frozen
                    c.quiet = True
                    log("[Hub] %s sem responder ha 15 s (jogo pausado, minimizado ou travado)" % c.name)
        for c in list(self.clients.values()):
            if c.outbuf and c.sock.fileno() >= 0:
                self.flush(c)
        self._refresh_pub()


# ====================================================================== Controller (app + HTTP API)
ALLOW_MC = {"wither", "tnt", "tnt_rain", "creeper", "charged_creeper", "lightning",
            "boom", "heal", "clear", "day", "freeze", "unfreeze", "status"}
ALLOW_GTA = {"block", "boom", "boom_rain", "heal", "shake", "hud", "diag", "rules"}
GTA_NUMS = ("on", "tnt", "wither", "lightning", "creeper", "model")
KITS = {
    "tnt": ["give @p minecraft:tnt 64", "give @p minecraft:flint_and_steel 1"],
    "build": ["give @p minecraft:grass_block 64", "give @p minecraft:stone_bricks 64",
              "give @p minecraft:oak_planks 64", "give @p minecraft:glass 64"],
    "portal": ["give @p minecraft:obsidian 14", "give @p minecraft:flint_and_steel 1"],
    "creeper": ["give @p minecraft:creeper_spawn_egg 16"],
    "pearls": ["give @p minecraft:ender_pearl 16"],
}


class Controller:
    """Everything the panel can do, in one place: the native app calls it directly, the HTTP API wraps it.
    Methods are safe to call from any thread (they queue work for the hub thread) and return
    {"ok": bool, "error": str?, ...}."""

    def __init__(self, hub):
        self.hub = hub
        self._cmd_id = 1000
        self._lock = threading.Lock()

    def _next_id(self):
        with self._lock:
            self._cmd_id += 1
            return self._cmd_id

    # ---------------------------------------------------------------- reading
    def status(self, with_log=False):
        hub = self.hub
        out = dict(hub.pub)
        out["cfg"] = dict(hub.cfg)                 # live, so toggles show at once
        out["hub"] = dict(out.get("hub", {}))
        out["hub"]["want"] = hub.want
        if with_log:
            out["log"] = list(_log_ring)
        return out

    @staticmethod
    def log_lines():
        return list(_log_ring)

    # ---------------------------------------------------------------- bridge + config
    def set_bridge(self, on):
        self.hub.want = bool(on)
        log("[Hub] bridge %s pelo painel" % ("ligado" if self.hub.want else "desligado"))
        return {"ok": True}

    def set_cfg(self, **kw):
        self.hub.set_cfg(**kw)
        return {"ok": True}

    # ---------------------------------------------------------------- chaos
    def mc_action(self, action, at="player"):
        hub = self.hub
        if action not in ALLOW_MC:
            return {"ok": False, "error": "acao invalida"}
        if at not in ("player", "spawn"):
            at = "player"
        has_mod = any(c.ident and c.name.startswith("minecraft") for c in list(hub.clients.values()))
        if not has_mod and hub.engine.mc_open():
            # no FusionBridgeMC: the passthrough mod runs the same commands (as the server, at the player)
            cmds = mc_command_for(action) or []
            hub.engine.submit(lambda: hub.engine.mc_commands(cmds))
            hub.add_event("panel", "%s -> Minecraft (passthrough)" % action)
            return {"ok": True, "via": "passthrough"}
        hub.submit(json.dumps({"type": "command", "to": "minecraft*", "action": action,
                               "at": at, "id": self._next_id()}, separators=(",", ":")))
        return {"ok": True}

    def gta_action(self, action, **nums):
        if action not in ALLOW_GTA:
            return {"ok": False, "error": "acao invalida"}
        msg = {"type": "command", "to": "gta", "action": action, "id": self._next_id()}
        for k in GTA_NUMS:
            if k in nums and nums[k] is not None:
                try:
                    msg[k] = int(nums[k])
                except (TypeError, ValueError):
                    pass
        self.hub.submit(json.dumps(msg, separators=(",", ":")))
        return {"ok": True}

    # ---------------------------------------------------------------- visual fusion
    def fusion(self, op, v="", key=""):
        eng = self.hub.engine
        if op == "on":
            on = v in ("1", 1, True)
            eng.submit(lambda: eng.set_on(on))
        elif op == "relevel":
            eng.submit(lambda: eng.relevel("painel"))
        elif op == "mouse" and v in ("mc", "gta"):
            eng.submit(lambda: eng.set_mouse(v))
        elif op == "opt":
            if key not in eng.opts:
                return {"ok": False, "error": "opcao invalida"}
            try:
                val = int(v)
            except (TypeError, ValueError):
                return {"ok": False, "error": "valor invalido"}
            eng.submit(lambda: eng.set_opts(**{key: val}))
        elif op == "give":
            if v not in KITS or not eng.mc_open():
                return {"ok": False, "error": "Minecraft (passthrough) nao conectado"}
            cmds = KITS[v]
            eng.submit(lambda: eng.mc_commands(cmds))
        else:
            return {"ok": False, "error": "operacao invalida"}
        return {"ok": True}

    def send_line(self, line):
        try:
            o = json.loads(line)
            assert isinstance(o, dict) and o.get("type")
        except Exception:
            return {"ok": False, "error": "linha invalida"}
        self.hub.submit(line)
        return {"ok": True}


def start_hub():
    """Starts the hub (and its fusion engine) on a background thread; returns (hub, controller)."""
    hub = Hub()
    threading.Thread(target=hub.run, name="FusionBridge-Hub", daemon=True).start()
    return hub, Controller(hub)


# ====================================================================== HTTP API (headless server mode)
class Panel(BaseHTTPRequestHandler):
    ctl = None
    token = ""

    def log_message(self, *a):
        pass

    def _send(self, code, ctype, body):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def _json(self, obj, code=200):
        self._send(code, "application/json; charset=utf-8", json.dumps(obj, separators=(",", ":")))

    def _result(self, r):
        self._json(r, 200 if r.get("ok") else 400)

    def _file(self, name, ctype):
        try:
            with open(os.path.join(WEB, name), "rb") as f:
                self._send(200, ctype, f.read())
        except OSError:
            self._send(404, "text/plain", "nao encontrado")

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        path = u.path
        one = lambda k, d="": (q.get(k) or [d])[0]
        if one("k") != self.token:
            self._send(403, "text/plain", "token invalido")
            return
        ctl = self.ctl
        if path == "/" or path == "/index.html":
            self._file("index.html", "text/html; charset=utf-8")
        elif path == "/hud":
            self._file("hud.html", "text/html; charset=utf-8")
        elif path == "/api/status":
            self._json(ctl.status(with_log=one("log") == "1"))
        elif path == "/api/log":
            self._json(ctl.log_lines())
        elif path == "/api/hub":
            self._result(ctl.set_bridge(one("on", "1") == "1"))
        elif path == "/api/cfg":
            kw = {k: q[k][0] for k in ("mode", "host", "secondary") if k in q}
            kw.update({k: q[k][0] == "1" for k in ("dlss", "framegen") if k in q})
            self._result(ctl.set_cfg(**kw))
        elif path == "/api/mc":
            self._result(ctl.mc_action(one("action"), one("at", "player")))
        elif path == "/api/gta":
            self._result(ctl.gta_action(one("action"), **{k: q[k][0] for k in GTA_NUMS if k in q}))
        elif path == "/api/fusion":
            self._result(ctl.fusion(one("op"), one("v"), one("key")))   # "key", not "k": that is the token
        elif path == "/api/send":
            self._result(ctl.send_line(one("line")))
        else:
            self._send(404, "text/plain", "nao encontrado")


def main():
    hub, ctl = start_hub()
    Panel.ctl = ctl
    Panel.token = secrets.token_urlsafe(16)
    httpd = ThreadingHTTPServer(("127.0.0.1", UI_PORT), Panel)
    log("[FusionBridge] modo servidor: API em http://127.0.0.1:%d/?k=%s (o app FusionBridge.exe nao precisa disso)"
        % (UI_PORT, Panel.token))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        log("[FusionBridge] encerrado")


if __name__ == "__main__":
    main()
