// Validates a ReShade FX file the way ReShade 6.8 does for Direct3D 9: preprocess (same built-in macros), parse, and
// generate shader-model-3 HLSL. Prints errors/warnings; writes the HLSL next to argv[3] if given. Exit 1 on error.
#include "effect_preprocessor.hpp"
#include "effect_parser.hpp"
#include "effect_codegen.hpp"
#include <cstdio>
#include <fstream>
#include <memory>

int main(int argc, char **argv)
{
	if (argc < 3) { std::fprintf(stderr, "usage: fxcheck file.fx include_dir [out.hlsl] [W H]\n"); return 2; }
	const char *w = argc > 5 ? argv[4] : "3440", *h = argc > 5 ? argv[5] : "1440";
	reshadefx::preprocessor pp;
	pp.add_include_path(argv[2]);
	pp.add_macro_definition("__RESHADE__", "60800");
	pp.add_macro_definition("__RESHADE_PERMUTATION__", "0");
	pp.add_macro_definition("__RESHADE_PERFORMANCE_MODE__", "0");
	pp.add_macro_definition("__VENDOR__", "4318");
	pp.add_macro_definition("__DEVICE__", "0");
	pp.add_macro_definition("__RENDERER__", "36864"); // 0x9000 = D3D9
	pp.add_macro_definition("__APPLICATION__", "0");
	pp.add_macro_definition("BUFFER_WIDTH", w);
	pp.add_macro_definition("BUFFER_HEIGHT", h);
	pp.add_macro_definition("BUFFER_RCP_WIDTH", "(1.0 / BUFFER_WIDTH)");
	pp.add_macro_definition("BUFFER_RCP_HEIGHT", "(1.0 / BUFFER_HEIGHT)");
	pp.add_macro_definition("BUFFER_COLOR_SPACE", "1");
	pp.add_macro_definition("BUFFER_COLOR_FORMAT", "0");
	pp.add_macro_definition("BUFFER_COLOR_BIT_DEPTH", "8");
	pp.add_macro_definition("RESHADE_DEPTH_INPUT_IS_REVERSED", "0");
	pp.add_macro_definition("RESHADE_DEPTH_INPUT_IS_UPSIDE_DOWN", "0");
	pp.add_macro_definition("RESHADE_DEPTH_INPUT_IS_LOGARITHMIC", "0");
	pp.add_macro_definition("RESHADE_DEPTH_LINEARIZATION_FAR_PLANE", "1000");
	pp.append_string(
		"#define tex2Doffset(s, coords, offset) tex2D(s, coords, offset)\n"
		"#define tex2Dlodoffset(s, coords, offset) tex2Dlod(s, coords, offset)\n");
	const bool pre = pp.append_file(argv[1]);
	std::string errors = pp.errors();
	std::unique_ptr<reshadefx::codegen> cg(reshadefx::create_codegen_hlsl(30, false, false));
	reshadefx::parser parser;
	const bool ok = parser.parse(pp.output(), cg.get()) && pre;
	errors += parser.errors();
	std::fputs(errors.c_str(), stdout);
	if (ok && argc > 3)
	{
		std::ofstream(argv[3]) << cg->finalize_code();
		const auto &m = cg->module();
		std::printf("techniques: %zu, entry points: %zu, uniforms: %zu, textures: %zu\n", m.techniques.size(), m.entry_points.size(), m.uniforms.size(), m.textures.size());
		std::ofstream ep(std::string(argv[3]) + ".entries");
		for (const auto &e : m.entry_points)
			ep << (e.second == reshadefx::shader_type::vertex ? "vs_3_0 " : "ps_3_0 ") << e.first << "\n";
	}
	std::puts(ok ? "FX OK" : "FX FAILED");
	return ok ? 0 : 1;
}
