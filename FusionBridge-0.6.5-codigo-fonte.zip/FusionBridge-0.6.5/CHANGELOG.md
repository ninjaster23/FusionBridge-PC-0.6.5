# Changelog - FusionBridge PC

## 0.6.5 - SkyCraft (Minecraft no Skyrim), Minecraft automático e a interface nova de volta

**Interface**
- **A interface nova (feita na 0.6.1) voltou e recebeu tudo da 0.6.2 a 0.6.4.** Barra lateral com **Ponte, Caos, Controles, Instalar, Mods fusion, Desempenho, Segurança, Diagnóstico e Log**, fontes próprias (Jersey 15 e IBM Plex Mono, SIL OFL), botões e cartões no estilo de blocos, e a **logo do F verde na ponte ao pôr do sol** na janela, na barra de tarefas e no atalho, que o app oferece criar na primeira vez. O `FusionBridge.exe` continua com o ícone do Python: mudar o arquivo quebraria a assinatura que o Controle inteligente confere.
- A página **Desempenho** junta o ritmo e o peso da fusão, o **FSR 1.0** da imagem do Minecraft, **DLSS** e **Frame Generation** explicados sem enganação (com o Lossless Scaling achado e aberto pelo app) e, por último, o **Upscale em qualquer jogo** (Magpie).
- **Resident Doom removido do app.** Ele era só uma referência de ideias e nunca devia ter entrado: saíram a pasta `fusion-mods/resident-doom`, os mods fusion do Doom e do Resident Evil 1 (não aparecem mais no seletor de Host/Secundário), o cartão e o `fb_resdoom.py`. Parte do código dele foi adaptada de um decomp do Resident Evil 1 (engenharia reversa do executável da Capcom), de origem legal incerta. Quem usou o **Preparar** na 0.6.4 pode apagar `%LOCALAPPDATA%\FusionBridge\ResidentDoom`.

**Novo: SkyCraft (Minecraft dentro do Skyrim), de chasmlol, MIT**
- Cartão na página **Mods fusion** e mods fusion `skycraft-skyrim.json` (Host) e `skycraft-minecraft.json` (Secundário): o Skyrim aparece no seletor da Ponte com mod fusion, e o Minecraft faz par com o mod certo de cada lado (o da fusão GTA ou o do SkyCraft).
- O app acha o Skyrim (Steam, registro), lê a versão do `SkyrimSE.exe` e só aceita o runtime da Anniversary Edition (1.6/1.7). A 1.5.97, o VR e o do Xbox/Game Pass são recusados com o motivo. Também confere se o **SKSE64** (`skse64_<versão>.dll`) e a **Address Library** (`versionlib-<versão>.bin`) são os da mesma versão.
- **Instalar SkyCraft:** baixa o SkyCraft 0.1.2 oficial do GitHub (SHA-256 fixo, o mesmo do kit Oliverall) e instala junto o SKSE e a Address Library que você escolheu: o arquivo baixado (`.zip`/`.7z`, aberto pelo tar do próprio Windows) ou os arquivos de dentro. Da Address Library entra só o `.bin` da sua versão.
  - **Nunca sobrescreve um arquivo diferente.** Um SKSE de outra versão pode ser trocado com backup, e o Remover devolve.
  - Faz **backup dos saves** antes e grava o registro de cada arquivo antes de copiar, para uma instalação interrompida ser desfeita.
- **Minecraft do SkyCraft:** o app desempacota o Prism do SkyCraft do mesmo jeito que o `SkyCraft.dll`: mesma pasta, mesmo `bundle.stamp`, mesma limpeza dos jars e o `LowMemWarning` desligado. Assim dá para **entrar na conta Microsoft antes de abrir o Skyrim**, sem a janela do Prism por cima do jogo.
- **Jogar** abre o Skyrim pelo `skse64_loader.exe` e, no Skyrim da Steam, abre a Steam antes (minimizada) e espera por ela.
- O cartão também:
  - mostra o que o `SkyCraft.log` e o `latest.log` do Minecraft dizem, em palavras simples;
  - liga e desliga as opções do `SkyCraft.ini` sem perder os comentários;
  - avisa dos mods de câmera que brigam com o SkyCraft, da falta do Alternate Start, do Controle inteligente e do Mod Organizer 2/Vortex;
  - mostra as teclas que continuam do Skyrim.
- **Remover** tira só o que o app colocou, e só se não mudou. A conta e o mundo do SkyCraft (`%LOCALAPPDATA%\SkyCraft`) ficam.

**Novo: Minecraft automático na fusão do GTA (estabilidade aprendida com o SkyCraft)**
- Um **Prism Launcher 11.1.1 portátil** (GPL-3.0; o zip oficial do GitHub, SHA-256 fixo) com a instância **FusionBridge**: Minecraft 26.3, Fabric Loader 0.19.5, LWJGL 3.4.3 e os mods da fusão. O Prism baixa o Minecraft e o Java sozinho, então **o Minecraft Launcher, o instalador do Fabric e o perfil do launcher não são mais necessários**, e as versões sempre batem. Tudo fica em `%LOCALAPPDATA%\FusionBridge\Prism`.
- **Abre o Minecraft sozinho quando o GTA abre**, e nunca um segundo: nem com um Minecraft já ligado, nem com o Prism ainda abrindo um.
- **Fecha o Minecraft quando o GTA fecha**, mas só o que o app abriu. É o mesmo pedido do botão X, então ele salva o mundo antes.
- Opção de deixar a **janela do Minecraft fora da tela, sem minimizar**: minimizado, o Minecraft cai para poucos quadros por segundo e a fusão fica sem imagem nova. Ainda não foi testada numa placa de vídeo real; se a imagem sumir, é só desligar.
- Faixa **Minecraft automático** na Ponte (o que falta, **Abrir o Minecraft**) e cartão em **Instalar** (opções, **Entrar na conta**, **Remover o Prism**, que guarda o mundo antes). O modo antigo (Minecraft Launcher oficial) continua: escolha no cartão do Minecraft em Instalar. Uma instalação da 0.6.4 segue no modo antigo até você usar Remover e Instalar de novo.

**Estabilidade e compatibilidade**
- **Backup dos saves do GTA** (`Documents\GTA San Andreas User Files`) antes de instalar, em `%LOCALAPPDATA%\FusionBridge\backups`.
- Mods fusion: novos campos `installed_when_any` (instalado quando qualquer um dos arquivos existe) e caminhos `{localappdata}/…`, sempre recusando `..` e caminhos absolutos.
- Fechar o app espera também a instalação do SkyCraft e do Prism terminarem, para nunca deixar nada pela metade.

**Licença**
- O código do FusionBridge passa a ter licença **MIT** (`LICENSE`). `THIRD-PARTY-NOTICES.md` traz os textos completos das licenças de terceiros: o `passthrough` e o compositor/efeito adaptados dele (MIT), o FSR 1.0 da AMD dentro do `FusionBridgeSA.fx` (MIT), a API de add-ons do ReShade (BSD-3) e as fontes (OFL). O cabeçalho do `FusionBridgeSA.fx` agora traz os avisos MIT completos, e o zip só do mod do GTA leva os avisos junto.

**Pesquisa de mods parecidos**
- Publicados e com licença aberta, só o SkyCraft roda um jogo de verdade dentro de outro. O Minecraft no Elden Ring (Tobyn Jacobs) é só vídeo, sem download nem licença. O mashup de MW2 com Skate 3 e Minecraft (do autor do SkyCraft) é uma recriação em Rust que precisa de arquivos do Xbox 360. Para Cyberpunk e GTA 5 não há nada publicado. Esses ficaram de fora.

**Sem mudança**
- O mod do GTA (`FusionBridgeSA.asi` 0.6.3, script 0.2.4) é o mesmo da 0.6.4, e no `FusionBridgeSA.fx` só mudaram os comentários de licença: não precisa reinstalar no GTA.

## 0.6.4 - upscale FSR 1.0 em qualquer jogo

**Novo**
- **Upscale em qualquer jogo**, primeiro cartão da aba **Desempenho**: FSR 1.0 da AMD (EASU + RCAS) sobre a janela de qualquer jogo do PC, não só da fusão (DirectX 9 a 12, OpenGL, Vulkan, emuladores). Usa o Magpie 0.12.1 (Blinue, GPL-3.0). **Baixar e preparar** baixa o zip oficial do GitHub, confere o SHA-256 (o mesmo do bucket Extras do Scoop), extrai com verificação de caminhos para `%LOCALAPPDATA%\FusionBridge\Magpie` em modo portátil e grava a configuração inicial com o FSR como modo padrão e o idioma em português. Uma configuração que o jogador já tem nunca é sobrescrita, nem numa reinstalação. **Abrir upscaler (FSR)** abre o Magpie; no jogo, **Alt+Shift+A** amplia e **Alt+Shift+D** mostra a barra dele. Também há **Abrir pasta** e **Remover**. O cartão explica como usar, o que não funciona (tela cheia exclusiva, jogo como administrador, anti-cheat) e avisa quando o Controle inteligente de aplicativo está ligado, porque o Magpie não tem assinatura digital. O app não muda essa configuração.
- O cartão explica por que FSR 2/3 e DLSS não existem "em qualquer jogo": eles precisam dos vetores de movimento, da profundidade e do jitter que só o próprio jogo fornece.

**Sem mudança**
- O mod do GTA (`FusionBridgeSA.asi` 0.6.3, `FusionBridgeSA.fx`, script 0.2.4) é o mesmo da 0.6.3: não precisa reinstalar.

## 0.6.3 - FSR 1.0 de verdade, aba Desempenho, DLSS e Frame Generation sem enganação

**Novo**
- **FSR 1.0 (AMD FidelityFX Super Resolution 1.0) na imagem do Minecraft dentro do GTA:** o efeito `FusionBridgeSA.fx` ganhou três passes. **EASU** amplia, respeitando as bordas, o mundo do Minecraft e o HUD/inventário dele até a resolução do GTA. **RCAS** dá a nitidez adaptativa, com a redução de ruído da AMD. Funciona em qualquer placa (NVIDIA, AMD, Intel). Os modos da AMD (Nativo, Ultra qualidade 1,3×, Qualidade 1,5×, Equilibrado 1,7×, Desempenho 2×) fazem o Minecraft renderizar menor, o que alivia a placa. A nitidez tem três níveis. O efeito foi conferido com o próprio compilador de efeitos do ReShade 6.8 (Direct3D 9, shader model 3). `FusionBridgeSA.asi` 0.6.3 (`FB_SetFsr`) e script do GTA 0.2.4.
- **Aba Desempenho**, no mesmo estilo das outras: peso da fusão (raio do chão, resolução máxima do Minecraft), FSR 1.0, DLSS e Frame Generation. Mostra a placa de vídeo do PC e os tamanhos reais do Minecraft e do GTA.
- **DLSS e Frame Generation honestos:** as caixinhas "DLSS / upscaling" e "Frame Generation" do topo, que só guardavam a escolha, saíram. A aba explica por que o DLSS não existe nestes jogos (Direct3D 9 e OpenGL) e o que funciona de verdade: Lossless Scaling (o app acha e abre), Smooth Motion e NIS da NVIDIA, RSR e AFMF da AMD, Magpie. O app não instala nada nem mexe nas configurações do driver.

**Corrigido**
- As opções da fusão são gravadas por inteiro (arquivo temporário e troca), então uma queda no meio não deixa o arquivo pela metade. Valores fora do limite (editados à mão) são corrigidos ao abrir.

## 0.6.2 - o GTA não trava mais, inventário do Minecraft dentro do GTA

**Novo**
- **Inventário do Minecraft dentro do GTA (script do GTA 0.2.3):** com a fusão ligada, **I** abre o inventário e o GTA mostra o cursor sobre a imagem do Minecraft (o CJ e a câmera param). A posição do cursor, os cliques (esquerdo, direito, do meio), Shift, 1–9 (trocar com a barra), Q (soltar o item) e a rodinha vão para a janela do Minecraft pelo app, como mensagens de mouse e teclado do Windows: o inventário funciona ali mesmo, sem trocar de janela. **I** ou **E** fecha. Ao fechar, ao entrar num carro, ao desligar a fusão ou se o GTA cair, tudo que estava apertado é solto e o mouse volta para o GTA.
- *(Removido na 0.6.5.)* **Resident Doom (Resident Evil 1 × Doom), de Drelvak, como mod fusion:** só os arquivos que fazem o mod funcionar (`fusion-mods/resident-doom/`, GPL-3.0), os descritores do Doom (Host) e do RE1 (Secundário) e um cartão na aba **Instalação**. O app acha o Doom e o RE1 instalados, confere o `DOOM.WAD` (Doom 1 registrado) e os 53 arquivos do RE1 que o mod usa, copia tudo com o GZDoom para `%LOCALAPPDATA%\FusionBridge\ResidentDoom` (**Preparar**) e abre o `play.py` do próprio mod (**Jogar**). Se o mod for atualizado, o jogo é montado de novo sozinho.

**Estabilidade**
- **O app não perde mais a ponte por um erro:** cada volta do servidor do meio (hub) roda protegida; um erro inesperado vai para o Log e a ponte continua. Se ele se repetir sem parar, os jogos são reconectados.
- **O script do GTA também:** cada quadro do laço principal roda protegido; um erro vai para o `moonloader.log` e o script continua (antes ele parava, e o CJ podia ficar invisível).
- **GTA travando ("Não foi possível restaurar gta_sa.exe", imagem esbranquiçada) — script do GTA 0.2.2 e ASI 0.6.2:** o script pedia ao Windows uma conexão "sem bloqueio" com o código `FIONBIO` (0x8004667E), que o LuaJIT convertia para 0x80000000 (número grande demais para um inteiro de 32 bits com sinal). O Windows recusava, a conexão continuava bloqueante e o primeiro `recv` parava a linha do próprio jogo até o app derrubar a conexão (60 s): o "gta saiu (timeout)" seguido de reconexão e novo travamento do log. Agora o valor chega certo, uma conexão que não fica sem bloqueio nunca é usada, cada leitura passa antes por `select`, o envio parcial é guardado e as linhas são cortadas de uma vez só. A primeira tentativa de correção (tela cheia exclusiva / janela sem bordas) foi um diagnóstico errado: o GTA já rodava em janela e não houve nenhum reset do Direct3D. Ela foi retirada, e o `FusionBridgeSA.ini` não é mais usado.
- **Vigia de travamento no `FusionBridgeSA.asi`:** se o jogo ficar 8 s sem completar um quadro, o ASI anota no `FusionBridgeSA.log` onde a linha do jogo está (módulo e posição, e a pilha). O script anota no `moonloader.log` quando conecta, quando a fusão liga e desliga, e os erros que antes eram engolidos. O app avisa no Log quando um jogo fica 15 s sem responder.
- **Menos engasgos com a fusão ligada:** o modelo dos blocos invisíveis é carregado em segundo plano e fica carregado entre um "nivelar chão" e outro (antes cada nivelamento, que pode ser automático a cada 1,5 s, parava o jogo com `loadAllModelsNow`); o app manda ao GTA só os 120 blocos mais perto do CJ, do mais perto para o mais longe, e o script cria as paredes nessa ordem (antes as 150 paredes podiam ir para os blocos mais longe); colunas de chão sem colisão (água) não são testadas de novo a cada quadro; a imagem do Minecraft vai para a placa sem esperar a GPU terminar o quadro anterior (textura dinâmica com DISCARD) e sem um bloco de estado do Direct3D extra por quadro.
- **ASI mais seguro:** as texturas do Minecraft são desligadas do ReShade antes de serem liberadas (antes ele podia usar texturas já liberadas depois de um reset), e ao fechar o jogo o ASI não chama mais o ReShade, que já foi descarregado. O log mostra a versão certa (antes "6.0.1").
- **Remover depois de atualizar o mod à mão:** se o `FusionBridgeSA.asi`, o `FusionBridgeGTA.lua` ou o `FusionBridgeSA.fx` foram trocados (pelo zip só do mod do GTA, por exemplo), o Remover guarda o arquivo de lado com outro nome, que o jogo não carrega, em vez de deixar a instalação "presa".
- **Script do GTA:** a conexão com o app é feita em segundo plano (com o app fechado, cada tentativa não segura mais o jogo); o sinal de vida vai também durante cenas, menus e com o CJ morto ou preso; os corações subiram para o alto da tela (cobriam as legendas). O `libFusionBridgeGTA.so` é o mod de Android: o Windows não usa.

## 0.6.1 - app próprio, sem navegador, e compatível com o Controle inteligente de aplicativo

**Novo**
- **`FusionBridge.exe` com janela própria:** Fusão, Caos, Instalação, Segurança, Diagnóstico e Log dentro do app, com o mesmo visual do painel. O servidor (hub + motor de fusão) roda dentro do app. **Nada abre no navegador.** HUD de corações flutuante virou uma janelinha nativa sempre visível.
- **Sem Python instalado, sem `.bat/.cmd/.ps1`:** o `FusionBridge.exe` é o Python oficial (python.org, assinado pela Python Software Foundation, sem alteração) e o código do app são arquivos `.py`. Todo código nativo do pacote é assinado pela PSF ou pela Microsoft.
- **Instalar/Remover dentro do app** (porta do INSTALAR/REMOVER em Python, mesmo registro): escolher o gta_sa.exe pela janela do Windows, checagens com bolinhas (versão 1.0 US lida do próprio arquivo, MoonLoader, Fabric, d3d9.dll de outro mod, GTA aberto), opção de substituir d3d9.dll/ReShade com backup, "Reabrir como administrador" quando a pasta é protegida, "Atalho na Área de Trabalho" (e no menu Iniciar) com o ícone do app.
- **Host e Secundário escolhidos com o mouse:** clique no cartão Host ou Secundário e o app mostra os jogos instalados no PC (Steam, Epic Games, GOG, Ubisoft Connect, Rockstar, EA app, Battle.net, Riot, app Xbox, Minecraft Java, GTA SA clássico, ou "Outro jogo…" pelo .exe). Clicando num jogo, aparece à direita se ele **tem mod fusion ou não** para funcionar naquele lado, se o mod já está instalado e se faz par com o jogo do outro lado. Busca digitando, setas, Enter e Esc. A escolha fica salva em `%LOCALAPPDATA%\FusionBridge\jogos.json`; escolher um GTA SA 1.0 como Host já preenche a pasta da aba Instalação.
- **Mods fusion (`fusion-mods\`):** cada jogo suportado é um arquivo `.json` de descrição (só dados, nada é executado). Os do GTA SA (Host) e do Minecraft Java (Secundário) vêm junto. Um arquivo novo colocado em `fusion-mods\` ou em `%LOCALAPPDATA%\FusionBridge\fusion-mods\` é reconhecido **na hora, com o app aberto**. Formato em `fusion-mods\COMO-ADICIONAR-MOD.md`.
- **Aba Segurança:** estado do Controle inteligente, assinatura de cada arquivo do app e do GTA (verificada pelo Windows) e "Procurar bloqueios do Windows" no log CodeIntegrity. `SEGURANCA-WINDOWS.md` explica o que o app resolve e o limite dos mods do GTA.
- **Ícone do FusionBridge** (bloco de grama com pôr do sol).

- **Teclas fundidas:** quando a fusão começa, o app manda ao GTA o mapa de teclas dos dois jogos. A pé, com o mouse no Minecraft: Q/E (e a rodinha) trocam o item do Minecraft e a arma do GTA juntos, I abre e fecha o inventário do Minecraft, Z solta o item, X troca de mão; 1–9 e os botões do mouse continuam como antes. O GTA avisa na tela quais teclas ficaram fundidas. A tabela fica na aba Fusão e dá para desligar em Controles.
- **Pronto para o GitHub:** `README.md` com a instalação passo a passo, `.gitignore` (o runtime do Python não vai para o repositório) e `tools/make_zips.py`, que gera o zip para jogar e o zip do código-fonte.
- **Código-fonte do mod do Minecraft** (`src/minecraft/FusionBridgeMC/`, projeto Gradle sem Loom). Só existia o `.jar` 0.2.0; o código foi reconstruído a partir dele e compila para o mesmo bytecode, classe por classe.
- **Códigos-fonte antigos do lado Android** em `src/android/`: o núcleo nativo do GTA SA Android 0.1.0 e o FusionBridgeMC 0.1.3 (histórico; o PC não usa).

**Corrigido**
- No Windows a porta 28765 agora é exclusiva do FusionBridge (antes outro programa podia abrir a mesma porta).
- Só uma cópia do app abre por vez (a segunda traz a janela da primeira para a frente).
- As opções da fusão ficam em `%LOCALAPPDATA%\FusionBridge` (a pasta do app pode ser só leitura).
- "Reabrir como administrador" fechava o app sem abrir de novo: o Python oficial lê a linha de comando antes do app e recusava `--elevated`. Agora as opções do app vão como `-X fb=elevated` / `-X fb=server`.
- Os downloads do Instalar usam o WinHTTP do Windows, como o instalador da 0.6.0 fazia pelo PowerShell: o Windows confere o certificado do site (e busca sozinho um certificado raiz que falte num Windows recém-instalado) e usa o proxy do sistema. O download pelo Python ficou como segunda tentativa; o SHA-256 é conferido do mesmo jeito.
- Instalar de novo depois de um Remover (ou de uma instalação que falhou) era recusado por causa da pasta isolada do Minecraft: agora ela é reaproveitada, com o mundo que estiver lá.
- Instalar/Remover conferem que o GTA, o Minecraft e o Minecraft Launcher estão fechados (o launcher regrava a lista de perfis ao fechar). Um arquivo em uso não interrompe mais o Remover no meio: o resto sai, os backups voltam, e o Remover pode ser usado de novo.
- O `ReShade.ini` que o próprio ReShade regrava não deixa mais a instalação "presa": o Remover guarda a configuração ao lado e devolve o `ReShade.ini` do outro mod.
- Registro da instalação gravado de forma atômica; um registro danificado é guardado de lado em vez de travar o Instalar e o Remover. A reversão de uma instalação que falha também desfaz um arquivo gravado pela metade e as pastas que ela criou.
- "Reabrir como administrador" numa conta comum usava as pastas do administrador que digitou a senha; agora a cópia elevada recebe as pastas do usuário. Uma segunda cópia do app não abre mais enquanto uma cópia de administrador está aberta.
- Fechar o app durante Instalar/Remover espera terminar (a reversão não fica pela metade). A pasta do GTA escolhida à mão é lembrada.
- Aba Segurança: eventos só de avaliação (3034/3076) aparecem como "seria bloqueado", não como bloqueado.
- A janela cabe na tela em notebooks 1366x768 e com escala de 125%; a lista de jogos não trava com jogos em disco de rede; a busca do seletor seleciona o primeiro resultado; o painel da direita rola.
- Lista de jogos: pastas do app Xbox escolhidas pelo jogador, bibliotecas Steam com [ ] no caminho, dois GTA SA clássicos, jogos do Rockstar Launcher só no desinstalador; um registro estranho de um jogo não esconde os outros.
- Mods fusion: um arquivo malformado (por exemplo, com aninhamento absurdo) é recusado sem derrubar o app; um mod que cita o outro em "partners" já faz par; com dois mods para o mesmo jogo, vale o que faz par.
- O app ignora pacotes de outra instalação de Python do usuário (`%APPDATA%\Python\Python313`), que o Python 3.13 ainda colocava no caminho.

**Removido**
- `FusionBridge.bat`, `INSTALAR.cmd`, `REMOVER.cmd`, `instalar.ps1`, `remover.ps1` (viraram botões no app). Para desenvolvimento, `FusionBridge.exe -X fb=server` ou `python app/fusionbridge.py` sobem só o hub com a API HTTP (usada pelos testes).

**Testes**
- App de verdade no Wine (janela, cliques chegando nos jogos, seletor de jogos, mod fusion novo reconhecido com o app aberto, instância única, fechar libera a porta, `-X fb=server` e `-X fb=elevated`): 18. Jogos instalados + mods fusion: 44. Instalar/Remover: 46. Motor + hub: 53 + 23. Lua: 58 (com as teclas fundidas) + 28. Câmera: 20.000.

## 0.6.0 - fusão visual: o Minecraft dentro do GTA San Andreas

O FusionBridge virou o **servidor de fusão** no meio dos dois jogos, no esquema do kit "Minecraft no GTA V" (Minecraft Java + GTA V Legacy), adaptado para o GTA SA.

**Novo**
- **Motor de fusão** (`fusion_engine.py`, dentro do hub): liga no mod passthrough do Minecraft (WebSocket 127.0.0.1:25599) e converte câmera, chão e entrada do GTA para o Minecraft; leva explosões, pérolas e blocos do Minecraft de volta para o GTA no ponto exato; nivela o chão (F8/automático, inclusive no Monte Chiliad); ajusta a janela do Minecraft à imagem do GTA; mostra os frames do Minecraft (memória compartilhada) no painel; opções salvas em `fusionbridge_settings.json`.
- **FusionBridgeSA.asi** (novo, C++ 32-bit): add-on do ReShade 6.8 para Direct3D 9 que desenha o Minecraft dentro do GTA pela profundidade, com a câmera exata do RenderWare; bloqueia o tiro/mira do CJ enquanto o mouse joga o Minecraft; aplica o efeito antes do HUD do GTA. Endereços só da 1.0 US, conferidos antes do uso (se não bater, desliga sozinho).
- **FusionBridgeSA.fx**: o efeito do kit do GTA V (MIT) adaptado ao Direct3D 9 do GTA SA (profundidade normal, aspecto 4:3 esticado, regras de MRT e de shader model 3).
- **FusionBridgeGTA.lua 0.2.0**: câmera e CJ todo frame, sondagem do chão, mouse/1–9/rodinha para o Minecraft, Steve no lugar do CJ (CJ invisível a pé, à prova de explosão e fogo), explosões/teleporte/paredes vindas do Minecraft, teclas F6/F7/F8. Tudo da 0.1.0 continua.
- **Painel:** aba **Fusão** com o estado de cada peça (Minecraft, frames, script, ASI, ReShade, efeito, ganchos, chão), liga/desliga, mouse, opções, raio do chão, resolução do Minecraft e kits de itens. "Caos no Minecraft" também funciona só com o mod passthrough.
- **INSTALAR/REMOVER** no estilo do kit: ReShade 32-bit como `d3d9.dll`, ASI, efeito, script, perfil isolado do Minecraft com passthrough + Fabric API + FusionBridgeMC, tudo registrado e com backups.

**Testes**
- Motor + hub: 50 testes de ponta a ponta (Minecraft e GTA falsos); hub 0.5.0: 23.
- Script do GTA: 45 testes da fusão + 28 da 0.5.0 (LuaJIT).
- Matemática da câmera: 20.000 câmeras aleatórias. ASI compilado e conferido. Shader compilado para Direct3D 9 pelo ReShade e pelo d3dcompiler da Microsoft.

## 0.5.0 (primeira versão para Windows)

Porte do FusionBridge para o PC, fundindo **Minecraft Java** e **GTA: San Andreas**.

**Novo**
- **Hub + painel em Python puro** (`fusionbridge.py`): sobe a ponte em `127.0.0.1:28765`, serve o painel web com token por sessão em `127.0.0.1:28766` e abre o navegador. Sem instalar bibliotecas — só o Python.
- **Launcher de 1 clique** (`FusionBridge.bat`): acha o Python e, se faltar, manda instalar.
- **Módulo do GTA SA como script MoonLoader** (`FusionBridgeGTA.lua`): arrasta-e-solta na pasta `moonloader`, sem compilar nem reempacotar. Conexão TCP direto pelo Windows (LuaJIT FFI + ws2_32), sem biblioteca Lua extra. Sem endereço de memória fixo: só comandos (opcodes) oficiais do MoonLoader.
  - Botões: Bloco, Explosão, Chuva de explosões, Curar CJ, Tremer câmera.
  - Fusão automática Minecraft → GTA (TNT, Wither, raio, creeper), cada regra com interruptor.
  - Corações do Minecraft (sem fome) desenhados no jogo com a vida do CJ.
- **Mod do Minecraft Java:** o mesmo `FusionBridgeMC-0.2.0.jar` (Fabric) das versões anteriores.
- **Painel PC:** Caos do Minecraft + Caos do GTA, fusão automática, HUD flutuante, modos Eco/Ao vivo/Visual, liga/desliga da ponte, feed de eventos, diagnóstico das conexões e do módulo do GTA.
- **DLSS e Frame Generation no menu de config** (para a RTX 5070 Ti): guardam a escolha e mostram o passo a passo do Nvidia Smooth Motion / Lossless Scaling, deixando claro que o app não injeta DLSS no jogo.

**Testes**
- Hub + painel: 23 testes de ponta a ponta (Python).
- Lógica do script do GTA: 28 testes em LuaJIT com os comandos do jogo dublados.
- UI renderizada sem erros de JavaScript (Playwright).

**Em relação ao Android (0.4.3)**
- O protocolo é o mesmo (v2, JSON-lines), então o mod do Minecraft e o painel são reaproveitados.
- No PC não há Termux, Shizuku, overlay de sistema nem reempacotar APK: a instalação do GTA é só copiar um arquivo.
