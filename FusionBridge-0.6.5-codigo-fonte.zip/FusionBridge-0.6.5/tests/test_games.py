"""Tests for fb_games: finding installed games (fake launcher records in a temp folder) and the fusion mods
(loading, refusing bad files, picking up a new file while running, the sentence for each side).
usage: python3 -I tests/test_games.py"""
import json, os, shutil, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "app"))
import fb_games as G  # noqa: E402

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(detail)[:400]), flush=True)


class FakeEnv:
    def __init__(self, root):
        self.root = root
        self.environ = {"APPDATA": os.path.join(root, "Roaming"), "ProgramData": os.path.join(root, "ProgramData"),
                        "ProgramFiles(x86)": os.path.join(root, "PF86"), "ProgramFiles": os.path.join(root, "PF")}
        self.reg = {}
        self.drives = [os.path.join(root, "D")]

    def key(self, hive, regpath, **values):
        self.reg[(hive, regpath)] = {k.lower(): v for k, v in values.items()}

    def values(self, hive, path, view64=False):           # the registry ignores case, and keeps it
        return dict(next((v for (h, p), v in self.reg.items() if h == hive and p.lower() == path.lower()), {}))

    def subkeys(self, hive, path, view64=False):
        pre = path.lower() + "\\"
        return sorted({p[len(pre):].split("\\")[0] for h, p in self.reg if h == hive and p.lower().startswith(pre)})

    def fixed_drives(self):
        return self.drives


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def acf(appid, name, installdir, flags="4"):
    return ('"AppState"\n{\n\t"appid"\t\t"%s"\n\t"Universe"\t\t"1"\n\t"name"\t\t"%s"\n\t"StateFlags"\t\t"%s"\n'
            '\t"installdir"\t\t"%s"\n}\n' % (appid, name, flags, installdir))


def build_pc(root):
    env = FakeEnv(root)
    steam = os.path.join(root, "Steam")
    lib2 = os.path.join(root, "D", "SteamLibrary")
    env.key("HKCU", r"Software\Valve\Steam", SteamPath=steam.replace("\\", "/"))
    write(os.path.join(steam, "steamapps", "libraryfolders.vdf"),
          '"libraryfolders"\n{\n\t"0"\n\t{\n\t\t"path"\t\t"%s"\n\t}\n\t"1"\n\t{\n\t\t"path"\t\t"%s"\n\t\t"apps"\n\t\t{\n'
          '\t\t\t"620"\t\t"1"\n\t\t}\n\t}\n}\n' % (steam.replace("\\", "\\\\"), lib2.replace("\\", "\\\\")))
    write(os.path.join(steam, "steamapps", "appmanifest_12120.acf"), acf(12120, "Grand Theft Auto: San Andreas", "GTA San Andreas"))
    write(os.path.join(steam, "steamapps", "common", "GTA San Andreas", "gta-sa.exe"), "x")
    write(os.path.join(steam, "steamapps", "appmanifest_228980.acf"), acf(228980, "Steamworks Common Redistributables", "Steamworks Shared"))
    os.makedirs(os.path.join(steam, "steamapps", "common", "Steamworks Shared"))
    write(os.path.join(steam, "steamapps", "appmanifest_99.acf"), acf(99, "Half Downloaded", "Half", flags="1026"))
    os.makedirs(os.path.join(steam, "steamapps", "common", "Half"))
    write(os.path.join(steam, "steamapps", "appmanifest_7.acf"), acf(7, "Uninstalled Folder Gone", "Gone"))
    write(os.path.join(lib2, "steamapps", "appmanifest_620.acf"), acf(620, "Portal 2", "Portal 2"))
    os.makedirs(os.path.join(lib2, "steamapps", "common", "Portal 2"))
    # Epic: a game, a DLC of it and an unfinished install
    man = os.path.join(root, "ProgramData", "Epic", "EpicGamesLauncher", "Data", "Manifests")
    fort = os.path.join(root, "Epic", "Fortnite")
    os.makedirs(fort)
    write(os.path.join(man, "A.item"), json.dumps({"DisplayName": "Fortnite", "InstallLocation": fort, "AppName": "Fortnite",
                                                   "MainGameAppName": "Fortnite", "AppCategories": ["public", "games"]}))
    write(os.path.join(man, "B.item"), json.dumps({"DisplayName": "Fortnite DLC", "InstallLocation": fort, "AppName": "FnDLC",
                                                   "MainGameAppName": "Fortnite"}))
    write(os.path.join(man, "C.item"), json.dumps({"DisplayName": "Broken", "InstallLocation": fort, "AppName": "X",
                                                   "bIsIncompleteInstall": True}))
    write(os.path.join(man, "D.item"), "{not json")
    # GOG with a DLC, Ubisoft, Rockstar (launcher skipped), EA through its uninstall entry
    gog = os.path.join(root, "GOG", "Witcher 3")
    os.makedirs(gog)
    env.key("HKLM", r"SOFTWARE\WOW6432Node\GOG.com\Games\1207664663", gameName="The Witcher 3", path=gog, gameID="1207664663")
    env.key("HKLM", r"SOFTWARE\WOW6432Node\GOG.com\Games\1", gameName="W3 DLC", path=gog, dependsOn="1207664663")
    ubi = os.path.join(root, "Ubi", "Far Cry 5")
    os.makedirs(ubi)
    env.key("HKLM", r"SOFTWARE\WOW6432Node\Ubisoft\Launcher\Installs\5", InstallDir=ubi + "/")
    gta5 = os.path.join(root, "R", "GTAV")
    os.makedirs(gta5)
    env.key("HKLM", r"SOFTWARE\WOW6432Node\Rockstar Games\Grand Theft Auto V", InstallFolder=gta5)
    env.key("HKLM", r"SOFTWARE\WOW6432Node\Rockstar Games\Launcher", InstallFolder=gta5)
    fifa = os.path.join(root, "EA", "FC 26")
    os.makedirs(fifa)
    un = r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    env.key("HKLM", un + r"\{fc26}", DisplayName="EA SPORTS FC 26", Publisher="Electronic Arts", InstallLocation=fifa)
    env.key("HKLM", un + r"\EAapp", DisplayName="EA app", Publisher="Electronic Arts", InstallLocation=fifa)
    env.key("HKLM", un + r"\word", DisplayName="Word", Publisher="Microsoft", InstallLocation=fifa)
    # Xbox app + Minecraft Java (the .minecraft folder)
    os.makedirs(os.path.join(root, "D", "XboxGames", "Forza Horizon 5", "Content"))
    os.makedirs(os.path.join(root, "D", "XboxGames", "Minecraft Launcher", "Content"))
    os.makedirs(os.path.join(root, "D", "Jogos Xbox", "Halo Infinite", "Content"))     # a folder picked in the Xbox app
    with open(os.path.join(root, "D", ".GamingRoot"), "wb") as f:
        f.write(b"RGBX" + (1).to_bytes(4, "little") + "\\Jogos Xbox".encode("utf-16-le") + b"\0\0")
    os.makedirs(os.path.join(root, "Roaming", ".minecraft"))
    # the classic GTA SA (1.0) somewhere else
    classic = os.path.join(root, "Games", "GTA San Andreas")
    write(os.path.join(classic, "gta_sa.exe"), "x")
    return env, classic


def main():
    tmp = tempfile.mkdtemp(prefix="fb-games-")
    try:
        env, classic = build_pc(tmp)
        games, errors = G.scan(env, extra=[{"key": "manual:x", "name": "Meu Jogo", "path": os.path.join(tmp, "Mine"), "ids": {}}],
                               gta_sa_dirs=[classic, None])
        names = [g["name"] for g in games]
        by = {g["name"]: g for g in games}
        check("no scanner failed", not errors, errors)
        check("Steam: games from both libraries", "Grand Theft Auto: San Andreas" in by and "Portal 2" in by, names)
        check("Steam: tools, unfinished installs and missing folders are left out",
              not any(n in names for n in ("Steamworks Common Redistributables", "Half Downloaded", "Uninstalled Folder Gone")), names)
        check("Steam: AppID kept", by.get("Portal 2", {}).get("ids", {}).get("steam") == "620", by.get("Portal 2"))
        check("Epic: the game, not its DLC nor a broken install", "Fortnite" in by and "Fortnite DLC" not in names and "Broken" not in names, names)
        check("GOG: the game, not the DLC", "The Witcher 3" in by and "W3 DLC" not in names, names)
        check("Ubisoft: named after its folder", "Far Cry 5" in by, names)
        check("Rockstar: the game, not the launcher", "Grand Theft Auto V" in by and "Launcher" not in names, names)
        check("EA app: the game from its uninstall entry, not the EA app itself nor other publishers",
              "EA SPORTS FC 26" in by and "EA app" not in names and "Word" not in names, names)
        check("Xbox app games", "Forza Horizon 5" in by, names)
        check("Xbox app games in the folder picked in the app (.GamingRoot)", "Halo Infinite" in by, names)
        check("Minecraft Java found once (the .minecraft folder), the Xbox launcher folder merged into it",
              names.count("Minecraft: Java Edition") == 1 and "Minecraft Launcher" not in names, names)
        check("classic GTA SA found by gta_sa.exe", any(g["source"] == "classic" for g in games), names)
        check("a game added by hand is listed", by.get("Meu Jogo", {}).get("source") == "manual", names)
        check("sorted by name", names == sorted(names, key=G.norm_name), names)

        # ---- fusion mods
        app_mods = os.path.join(ROOT, "fusion-mods")
        user_mods = os.path.join(tmp, "user-mods")
        os.makedirs(user_mods)
        logs = []
        reg = G.ModRegistry([app_mods, user_mods], log=logs.append)
        reg.refresh()
        ids = sorted(m.id for m in reg.mods)
        BUNDLED = ["fusionbridge-gta-sa", "fusionbridge-minecraft-java", "skycraft-minecraft", "skycraft-skyrim"]
        check("the bundled fusion mods load (GTA SA + Minecraft, SkyCraft's Skyrim + Minecraft)",
              ids == BUNDLED and not reg.problems, (ids, reg.problems))
        steam_sa, classic_sa = by["Grand Theft Auto: San Andreas"], next(g for g in games if g["source"] == "classic")
        mc = by["Minecraft: Java Edition"]
        v = G.verdict(steam_sa, "host", reg)
        check("Steam GTA SA as Host: has a fusion mod", v["state"] == "ok" and v["mod"].id == "fusionbridge-gta-sa", v)
        v = G.verdict(classic_sa, "host", reg, other=mc)
        check("classic GTA SA (gta_sa.exe) as Host, Minecraft on the other side: pairs",
              v["state"] == "ok" and any("Faz a fusão com" in t for _, t in v["lines"]), v["lines"])
        check("... and says the mod is not installed yet", any(st == "wait" and "não instalado" in t for st, t in v["lines"]), v["lines"])
        write(os.path.join(classic, "FusionBridgeSA.asi"), "x")
        write(os.path.join(classic, "moonloader", "FusionBridgeGTA.lua"), "x")
        v = G.verdict(classic_sa, "host", reg)
        check("... and installed once its files are there", any(st == "ok" and "instalado" in t for st, t in v["lines"]), v["lines"])
        v = G.verdict(mc, "host", reg)
        check("Minecraft as Host: has a mod, but for the other side", v["state"] == "wait" and v["mod"] is None, v)
        v = G.verdict(mc, "secondary", reg, fb_data=os.path.join(tmp, "FB"))
        check("Minecraft as Secundário: ok, mod not installed", v["state"] == "ok" and any("não instalado" in t for _, t in v["lines"]), v["lines"])
        v = G.verdict(by["Portal 2"], "host", reg)
        check("a game without a fusion mod says so", v["state"] == "bad" and v["title"] == "Não tem mod fusion para este jogo", v)
        # SkyCraft: Skyrim as Host pairs with SkyCraft's own Minecraft side; GTA SA keeps FusionBridge's
        sky = os.path.join(tmp, "Skyrim Special Edition")
        write(os.path.join(sky, "SkyrimSE.exe"), "x")
        skyg = {"key": "steam:489830", "name": "The Elder Scrolls V: Skyrim Special Edition", "path": sky,
                "ids": {"steam": "489830"}}
        local = os.path.join(tmp, "LOCAL")
        fbd = os.path.join(local, "FusionBridge")
        v = G.verdict(skyg, "host", reg, other=mc, fb_data=fbd)
        check("Skyrim SE as Host: SkyCraft, and it pairs with Minecraft", v["state"] == "ok" and v["mod"].id == "skycraft-skyrim"
              and any("Faz a fusão com" in t for _, t in v["lines"]), v["lines"])
        check("... not installed until SkyCraft.dll is in Data/SKSE/Plugins", any("não instalado" in t for _, t in v["lines"]), v["lines"])
        hits = []
        v = G.verdict(skyg, "host", reg, other=mc, fb_data=fbd, checks={"skyrim_skycraft": lambda g: (hits.append(g) or ("ok", "pronto"))})
        check("... and the app's SkyCraft check runs for it", hits and ("ok", "pronto") in v["lines"], v["lines"])
        byname = dict(skyg, key="manual:sky", ids={}, name="Skyrim")
        check("a Skyrim found only by SkyrimSE.exe (added by hand) is recognized", G.verdict(byname, "host", reg)["state"] == "ok")
        v = G.verdict(mc, "secondary", reg, other=skyg, fb_data=fbd)
        check("Minecraft next to Skyrim uses SkyCraft's Minecraft side", v["mod"] is not None and v["mod"].id == "skycraft-minecraft", v)
        check("... not installed until SkyCraft's Prism is unpacked", any("não instalado" in t for _, t in v["lines"]), v["lines"])
        write(os.path.join(local, "SkyCraft", "Prism", "prismlauncher.exe"), "x")
        v = G.verdict(mc, "secondary", reg, other=skyg, fb_data=fbd)
        check("... installed once %LOCALAPPDATA%\\SkyCraft\\Prism is there ({localappdata} path)",
              any(st == "ok" and "instalado" in t for st, t in v["lines"]), v["lines"])
        v = G.verdict(mc, "secondary", reg, other=steam_sa, fb_data=fbd)
        check("Minecraft next to GTA SA still uses FusionBridge's own mod", v["mod"].id == "fusionbridge-minecraft-java", v)
        check("... not installed yet", any("não instalado" in t for _, t in v["lines"]), v["lines"])
        write(os.path.join(fbd, "Prism", "instances", "FusionBridge", ".minecraft", "mods", "FusionBridgeMC-0.2.0.jar"), "x")
        v = G.verdict(mc, "secondary", reg, other=steam_sa, fb_data=fbd)
        check("... installed when it is in the automatic Minecraft (Prism) instead of the launcher folder (installed_when_any)",
              any(st == "ok" and "instalado" in t for st, t in v["lines"]), v["lines"])
        for bad_path in ("{localappdata}/../Windows/x", "{localappdata}/C:/x"):
            try:
                G.FusionMod({"fusion_mod": 1, "id": "x", "roles": ["host"], "game": {"steam": [1]},
                             "installed_when_any": [bad_path]}, "x.json")
                ok = False
            except ValueError:
                ok = True
            check("installed_when_any refuses %s" % bad_path, ok)
        defsa = {"key": "default:gta-sa", "name": "GTA: San Andreas", "path": "", "ids": {"special": "gta-sa"}}
        check("the default Host card (GTA SA) matches its mod", G.verdict(defsa, "host", reg)["state"] == "ok")
        de = {"key": "steam:1546990", "name": "Grand Theft Auto: San Andreas – The Definitive Edition", "path": "", "ids": {"steam": "1546990"}}
        check("the Definitive Edition is not taken for the classic GTA SA", G.verdict(de, "host", reg)["state"] == "bad")

        # a mod that names Minecraft's mod as its partner pairs with it (the example in COMO-ADICIONAR-MOD.md)
        write(os.path.join(user_mods, "meu.json"), json.dumps({
            "fusion_mod": 1, "id": "meu-jogo-fusion", "name": "Fusion para Meu Jogo", "roles": ["host"],
            "game": {"steam": [620]}, "partners": ["fusionbridge-minecraft-java"]}))
        reg.refresh()
        v = G.verdict(by["Portal 2"], "host", reg, other=mc)
        check("a mod listing Minecraft's mod as partner pairs with it", any(st == "ok" and "Faz a fusão" in t for st, t in v["lines"]),
              v["lines"])
        # two Host mods for the same game: the one that pairs with the other side is picked
        write(os.path.join(user_mods, "meu2.json"), json.dumps({
            "fusion_mod": 1, "id": "aaa-outro", "name": "Outro", "roles": ["host"], "game": {"steam": [620]},
            "partners": ["nada"]}))
        reg.refresh()
        v = G.verdict(by["Portal 2"], "host", reg, other=mc)
        check("with two mods for one game, the one that pairs is used", v["mod"].id == "meu-jogo-fusion", v["mod"].id)
        os.remove(os.path.join(user_mods, "meu.json"))
        os.remove(os.path.join(user_mods, "meu2.json"))
        reg.refresh()

        # a new mod file shows up while running - no restart
        check("nothing changed: refresh() says so", reg.refresh() is False)
        write(os.path.join(user_mods, "portal.json"), json.dumps({
            "fusion_mod": 1, "id": "portal-fusion", "name": "Portal Fusion", "version": "0.1", "roles": ["host", "secondary"],
            "game": {"steam": [620]}, "partners": [], "installed_when": ["portal2/fusion.dll"]}))
        changed = reg.refresh()
        v = G.verdict(by["Portal 2"], "host", reg)
        check("a new fusion mod file is picked up at once", changed and v["state"] == "ok" and v["mod"].id == "portal-fusion", v)
        check("... and it was logged", any("recarregados" in l for l in logs), logs)
        v = G.verdict(by["Portal 2"], "host", reg, other=mc)
        check("... but not with a mod that lists other partners (Minecraft's only pairs with GTA SA)",
              any(st == "wait" and "não faz par" in t for st, t in v["lines"]), v["lines"])
        write(os.path.join(user_mods, "fortnite.json"), json.dumps({
            "fusion_mod": 1, "id": "fortnite-fusion", "name": "Fortnite Fusion", "roles": ["secondary"], "game": {"epic": ["Fortnite"]}}))
        reg.refresh()
        v = G.verdict(by["Portal 2"], "host", reg, other=by["Fortnite"])
        check("two mods without partner lists pair with each other", any(st == "ok" and "Faz a fusão com Fortnite" in t for st, t in v["lines"]),
              v["lines"])
        os.remove(os.path.join(user_mods, "fortnite.json"))
        os.remove(os.path.join(user_mods, "portal.json"))
        reg.refresh()
        check("... and goes away when the file is removed", G.verdict(by["Portal 2"], "host", reg)["state"] == "bad")
        # the player's folder overrides a bundled mod with the same id
        write(os.path.join(user_mods, "gta.json"), json.dumps({
            "fusion_mod": 1, "id": "fusionbridge-gta-sa", "name": "GTA SA nova", "roles": ["host"], "game": {"names": ["GTA San Andreas"]}}))
        reg.refresh()
        check("same id in the player's folder wins", reg.by_id("fusionbridge-gta-sa").name == "GTA SA nova")
        os.remove(os.path.join(user_mods, "gta.json"))
        # bad files are refused with a reason, the rest still load
        bad = {"a-notjson.json": "{nope", "b-noflag.json": json.dumps({"id": "x", "roles": ["host"], "game": {"names": ["x"]}}),
               "c-role.json": json.dumps({"fusion_mod": 1, "id": "c", "roles": ["boss"], "game": {"names": ["x"]}}),
               "d-path.json": json.dumps({"fusion_mod": 1, "id": "d", "roles": ["host"], "game": {"names": ["x"]},
                                          "installed_when": ["../../Windows/System32/x.dll"]}),
               "e-abs.json": json.dumps({"fusion_mod": 1, "id": "e", "roles": ["host"], "game": {"files": ["C:\\\\Windows\\\\notepad.exe"]}}),
               "f-id.json": json.dumps({"fusion_mod": 1, "id": "Bad Id!", "roles": ["host"], "game": {"names": ["x"]}}),
               "g-nogame.json": json.dumps({"fusion_mod": 1, "id": "g", "roles": ["host"], "game": {}}),
               "h-big.json": json.dumps({"fusion_mod": 1, "id": "h", "roles": ["host"], "game": {"names": ["x"]}, "pad": "x" * 70000}),
               "j-deep.json": "[" * 5000 + "]" * 5000}
        for n, t in bad.items():
            write(os.path.join(user_mods, n), t)
        with open(os.path.join(user_mods, "i-latin1.json"), "wb") as f:
            f.write(b'{"fusion_mod": 1, "id": "i", "roles": ["host"], "game": {"names": ["Jogo \xe9"]}}')
        reg.refresh()
        refused = sorted(n for n, _ in reg.problems)
        check("bad mod files are refused, each with a reason", refused == sorted(list(bad) + ["i-latin1.json"]), reg.problems)
        check("... and the good ones still load", sorted(m.id for m in reg.mods) == BUNDLED,
              [m.id for m in reg.mods])
        check("... and a path outside the game folder is never used", not any(m.id in ("d", "e") for m in reg.mods))

        # what the player chose survives a restart; a game added by hand
        cpath = os.path.join(tmp, "FB", "jogos.json")
        ch = G.Choices(cpath)
        ch.set("host", by["Portal 2"])
        exe = os.path.join(tmp, "Games", "Meu Jogo", "bin", "MeuJogo.exe")
        write(exe, "x")
        g = ch.add_custom(exe)
        ch2 = G.Choices(cpath)
        check("the chosen Host is kept", ch2.host and ch2.host["name"] == "Portal 2", ch2.host)
        check("a game added by hand is kept, named after its folder (not 'bin')",
              ch2.custom and ch2.custom[0]["name"] == "Meu Jogo" and ch2.custom[0]["path"] == os.path.dirname(exe), ch2.custom)
        write(cpath, "{broken")
        ch3 = G.Choices(cpath)
        check("a broken jogos.json just starts empty", ch3.host is None and ch3.custom == [])
        for bad_json in ('{"custom": {"x": 1}}', '{"custom": 5}', "[" * 5000 + "]" * 5000):
            write(cpath, bad_json)
            ch4 = G.Choices(cpath)
            check("jogos.json with a wrong shape (%s...) starts empty" % bad_json[:12], ch4.custom == [] and ch4.host is None)
        check("norm_name drops marks and accents", G.norm_name("Pokémon™: Edição (R)") == "pokemon edicao")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    bad = [n for n, ok in results if not ok]
    print("\n%d/%d passaram" % (len(results) - len(bad), len(results)))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
