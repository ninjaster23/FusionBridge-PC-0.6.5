// Ponto de entrada no servidor dedicado (Fabric).
package org.fusionbridge.mc;

import net.fabricmc.api.DedicatedServerModInitializer;

public final class FusionBridgeServer implements DedicatedServerModInitializer {
    public void onInitializeServer() {
        FusionCore.start(FusionCore.Side.SERVER);
    }
}
