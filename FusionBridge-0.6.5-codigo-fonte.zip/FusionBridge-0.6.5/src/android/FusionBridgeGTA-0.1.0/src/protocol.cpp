#include "protocol.h"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>

namespace fbgta {
namespace {

std::string escape_json(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 8);
    for (char c : s) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default: out += c; break;
        }
    }
    return out;
}

bool find_key(const std::string& s, const char* key, std::size_t& p) {
    std::string needle = "\"" + std::string(key) + "\"";
    p = s.find(needle);
    if (p == std::string::npos) return false;
    p = s.find(':', p + needle.size());
    if (p == std::string::npos) return false;
    ++p;
    while (p < s.size() && std::isspace(static_cast<unsigned char>(s[p]))) ++p;
    return p < s.size();
}

bool get_string(const std::string& s, const char* key, std::string& out) {
    std::size_t p;
    if (!find_key(s, key, p) || s[p] != '"') return false;
    ++p;
    out.clear();
    while (p < s.size()) {
        char c = s[p++];
        if (c == '"') return true;
        if (c == '\\' && p < s.size()) {
            char e = s[p++];
            switch (e) {
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case '\\': out += '\\'; break;
                case '"': out += '"'; break;
                default: out += e; break;
            }
        } else {
            out += c;
        }
    }
    return false;
}

bool get_number(const std::string& s, const char* key, double& out) {
    std::size_t p;
    if (!find_key(s, key, p)) return false;
    const char* begin = s.c_str() + p;
    char* end = nullptr;
    out = std::strtod(begin, &end);
    return end != begin;
}

bool get_i64(const std::string& s, const char* key, std::int64_t& out) {
    double d = 0.0;
    if (!get_number(s, key, d)) return false;
    out = static_cast<std::int64_t>(d);
    return true;
}

float fnum(const std::string& s, const char* key, float fallback = 0.0f) {
    double d;
    return get_number(s, key, d) ? static_cast<float>(d) : fallback;
}

} // namespace

bool parse_event_line(const std::string& line, Event& out) {
    out = Event{};

    std::string type;
    if (!get_string(line, "type", type)) {
        // Backward compatibility with protocol v1 drafts using "op":"event".
        std::string op;
        if (!get_string(line, "op", op) || op != "event") return false;
        type = "event";
    }
    if (type != "event" && type != "fusion_event") return false;

    std::string event;
    if (!get_string(line, "event", event)) get_string(line, "kind", event);
    if (event.empty()) return false;

    out.x = fnum(line, "x", fnum(line, "px", 0.0f));
    out.y = fnum(line, "y", fnum(line, "py", 0.0f));
    out.z = fnum(line, "z", fnum(line, "pz", 0.0f));
    out.radius = fnum(line, "radius", 7.0f);
    out.damage = fnum(line, "damage", 100.0f);
    out.amount = fnum(line, "amount", 0.0f);
    get_i64(line, "id", out.id);
    get_string(line, "entity", out.kind);
    if (out.kind.empty()) get_string(line, "entity_type", out.kind);
    if (out.kind.empty()) get_string(line, "kind_name", out.kind);
    get_string(line, "block", out.block_id);
    if (out.block_id.empty()) get_string(line, "block_id", out.block_id);

    if (event == "tnt" || event == "tnt_explosion") out.type = Event::Type::TntExplosion;
    else if (event == "explosion") out.type = Event::Type::Explosion;
    else if (event == "entity_spawn" || event == "creeper" || event == "wither" || event == "wither_spawn") {
        out.type = Event::Type::EntitySpawn;
        if (out.kind.empty()) out.kind = (event == "creeper") ? "minecraft:creeper" : "minecraft:wither";
    }
    else if (event == "entity_move") out.type = Event::Type::EntityMove;
    else if (event == "entity_remove") out.type = Event::Type::EntityRemove;
    else if (event == "block_place") out.type = Event::Type::BlockPlace;
    else if (event == "block_break") out.type = Event::Type::BlockBreak;
    else if (event == "heal") out.type = Event::Type::Heal;
    else return false;

    return true;
}

std::string make_hello() {
    return "{\"type\":\"hello\",\"client\":\"gta\",\"version\":\"0.1.0\",\"protocol\":1,\"capabilities\":[\"minecraft_delta_events\",\"snapshot_eco\",\"headless_live\"]}";
}

std::string make_ping() {
    return "{\"type\":\"ping\",\"client\":\"gta\",\"protocol\":1}";
}

std::string make_player_state(float x, float y, float z, float yaw, float health,
                              int in_vehicle, float vehicle_health) {
    char buf[512];
    std::snprintf(buf, sizeof(buf),
        "{\"type\":\"player_state\",\"client\":\"gta\",\"protocol\":1,"
        "\"position\":{\"x\":%.3f,\"y\":%.3f,\"z\":%.3f},"
        "\"yaw\":%.3f,\"health\":%.3f,\"in_car\":%s,\"car_health\":%.3f}",
        x, y, z, yaw, health, in_vehicle ? "true" : "false", vehicle_health);
    return std::string(buf);
}

} // namespace fbgta
