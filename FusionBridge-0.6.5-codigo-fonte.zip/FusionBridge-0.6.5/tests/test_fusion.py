"""End-to-end test of the fusion engine (fusion_engine.py inside fusionbridge.py).

A fake Minecraft passthrough mod (a WebSocket server on 127.0.0.1:25599, like the real mod's HostLink) and
a fake GTA SA script (TCP JSON-lines client) talk through the real hub process.
usage: python3 -I test_fusion.py [path to fusionbridge.py]
"""
import base64, hashlib, json, math, os, re, socket, struct, subprocess, sys, threading, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
FB = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "app", "fusionbridge.py"))
sys.path.insert(0, os.path.dirname(FB))
import fusion_engine as fe  # noqa: E402

HUB = ("127.0.0.1", 28765)
UI = 28766
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(detail)[:400]), flush=True)


def close(a, b, eps=1e-3):
    return abs(a - b) <= eps


# ---------------------------------------------------------------- fake Minecraft (passthrough HostLink)
class FakeMC:
    def __init__(self, port=25599):
        self.ls = socket.socket()
        self.ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.ls.bind(("127.0.0.1", port))
        self.ls.listen(4)
        self.conn = None
        self.msgs = []
        self.lock = threading.Lock()
        self.handshakes = 0
        threading.Thread(target=self.loop, daemon=True).start()

    def loop(self):
        while True:
            try:
                c, _ = self.ls.accept()
            except OSError:
                return
            threading.Thread(target=self.serve, args=(c,), daemon=True).start()

    def serve(self, c):
        try:
            self._serve(c)
        except (OSError, AssertionError, ValueError, IndexError):
            pass                     # the hub went away (end of test)

    def _serve(self, c):
        buf = b""
        while b"\r\n\r\n" not in buf:
            d = c.recv(4096)
            if not d:
                return
            buf += d
        head, buf = buf.split(b"\r\n\r\n", 1)
        key = [l.split(b":", 1)[1].strip() for l in head.split(b"\r\n") if l.lower().startswith(b"sec-websocket-key")][0]
        acc = base64.b64encode(hashlib.sha1(key + b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").digest())
        c.sendall(b"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                  b"Sec-WebSocket-Accept: " + acc + b"\r\n\r\n")
        self.conn = c
        self.handshakes += 1
        self.send({"t": "hello", "v": 1, "shm": "Local\\MCPassthroughFrame", "pid": 4242})
        while True:
            while len(buf) < 2:
                d = c.recv(65536)
                if not d:
                    return
                buf += d
            b0, b1 = buf[0], buf[1]
            n, pos = b1 & 0x7F, 2
            need = 2
            if n == 126:
                need = 4
            elif n == 127:
                need = 10
            while len(buf) < need + 4:
                d = c.recv(65536)
                if not d:
                    return
                buf += d
            if n == 126:
                n = struct.unpack(">H", buf[2:4])[0]; pos = 4
            elif n == 127:
                n = struct.unpack(">Q", buf[2:10])[0]; pos = 10
            assert b1 & 0x80, "client frames must be masked"
            mask = buf[pos:pos + 4]; pos += 4
            while len(buf) < pos + n:
                d = c.recv(65536)
                if not d:
                    return
                buf += d
            payload = bytes(x ^ mask[i % 4] for i, x in enumerate(buf[pos:pos + n]))
            buf = buf[pos + n:]
            if (b0 & 0x0F) == 1:
                with self.lock:
                    self.msgs.append(json.loads(payload.decode()))

    def send(self, obj):
        data = json.dumps(obj).encode()
        n = len(data)
        head = bytes([0x81, n]) if n < 126 else bytes([0x81, 126]) + struct.pack(">H", n)
        self.conn.sendall(head + data)        # server frames are not masked

    def take(self, t=None):
        with self.lock:
            if t is None:
                out, self.msgs = self.msgs, []
                return out
            out = [m for m in self.msgs if m.get("t") == t]
            self.msgs = [m for m in self.msgs if m.get("t") != t]
            return out

    def wait(self, t, timeout=3.0, pred=None):
        end = time.time() + timeout
        while time.time() < end:
            with self.lock:
                for i, m in enumerate(self.msgs):
                    if m.get("t") == t and (pred is None or pred(m)):
                        return self.msgs.pop(i)
            time.sleep(0.03)
        return None

    def drop(self):
        try:
            self.conn.shutdown(socket.SHUT_RDWR)
            self.conn.close()
        except OSError:
            pass


# ---------------------------------------------------------------- fake GTA script
class GTA:
    def __init__(self):
        self.s = socket.create_connection(HUB, timeout=3)
        self.s.settimeout(0.2)
        self.buf = b""
        self.q = []
        self.send({"type": "hello", "client": "gta", "side": "game", "role": "host", "version": "0.2.0"})
        assert self.expect("hello_ack")

    def send(self, o):
        self.s.sendall((json.dumps(o) + "\n").encode())

    def pump(self, t):
        end = time.time() + t
        while time.time() < end:
            try:
                d = self.s.recv(65536)
                if not d:
                    break
                self.buf += d
            except socket.timeout:
                pass
            while b"\n" in self.buf:
                ln, self.buf = self.buf.split(b"\n", 1)
                if ln.strip():
                    self.q.append(json.loads(ln))

    def expect(self, typ, timeout=3.0, pred=None):
        end = time.time() + timeout
        while True:
            for i, m in enumerate(self.q):
                if m.get("type") == typ and (not pred or pred(m)):
                    return self.q.pop(i)
            if time.time() >= end:
                return None
            self.pump(0.1)


def http(path, tok):
    sep = "&" if "?" in path else "?"
    with urllib.request.urlopen("http://127.0.0.1:%d%s%sk=%s" % (UI, path, sep, tok), timeout=3) as r:
        return json.loads(r.read().decode())


def unit_tests():
    check("wrap180", close(fe.wrap180(270), -90) and close(fe.wrap180(-190), 170) and close(fe.wrap180(180), 180))
    check("angles: GTA north -> MC yaw 180", fe.angles_to_mc(0, 10, 0) == (180.0, -10, 0))
    check("angles: GTA west(90) -> MC yaw 90", close(fe.angles_to_mc(90, 0, 0)[0], 90))
    check("coords roundtrip", all(close(a, b) for a, b in zip(fe.mc_to_gta(*fe.gta_to_mc(12.5, -40.25, 7.0, 0.3), 0.3),
                                                              (12.5, -40.25, 7.0))))
    f, sh = fe.level_offset(12.3)
    check("level 12.3 -> frac -0.3, shift 0", close(f, -0.3) and sh == 0, (f, sh))
    f, sh = fe.level_offset(527.6)
    check("level Chiliad -> shift keeps MC y in range", 0 < 527.6 + f + sh < 320, (f, sh))
    check("ground column", fe.ground_column(5, -7, 12.3, -0.3) == [5, -7, 10, 11], fe.ground_column(5, -7, 12.3, -0.3))
    check("explosion kinds", (fe.explosion_kind(4, "tnt"), fe.explosion_kind(3, "creeper"),
                              fe.explosion_kind(1, "fireball"), fe.explosion_kind(6, "end_crystal")) == (2, 0, 1, 7))
    check("view 4:3 projection at 1080p", fe.mc_view_size(1920, 1080, 4 / 3.0) == (1440, 1080))
    w, h = fe.mc_view_size(3840, 2160, 16 / 9.0)
    check("view capped to ~1080p pixels", w * h <= fe.MAX_MC_PIXELS * 1.01 and close(w / h, 16 / 9, 0.01), (w, h))
    # FSR 1.0 modes: Minecraft renders at GTA's size / factor (and FSR brings it back up inside GTA)
    w, h = fe.mc_view_size(2560, 1440, 16 / 9.0, 4000000, 150)
    check("FSR Qualidade (1.5x): 2560x1440 GTA -> Minecraft 1707x960", (w, h) == (1707, 960), (w, h))
    w, h = fe.mc_view_size(3440, 1440, 3440 / 1440.0, fe.MAX_MC_PIXELS, 200)
    check("FSR Desempenho (2x) at 21:9 -> 1720x720", (w, h) == (1720, 720), (w, h))
    check("FSR Nativo = old behaviour", fe.mc_view_size(1920, 1080, 4 / 3.0, fe.MAX_MC_PIXELS, 100) == (1440, 1080))
    eng = fe.FusionEngine.__new__(fe.FusionEngine)
    check("unknown FSR factor falls back to the default", eng._valid("fsr_scale", 123) == 100 and eng._valid("fsr_scale", 170) == 170)
    check("options from a hand-edited file are clamped", eng._valid("radius", 9999) == 64 and eng._valid("fsr_sharp", -5) == 0)
    import tempfile
    with tempfile.TemporaryDirectory() as t:
        sp = os.path.join(t, "s.json")
        with open(sp, "w") as f:
            json.dump({"opts": {"radius": 500, "fsr_scale": 999, "fsr": False, "fsr_sharp": 50}}, f)
        e2 = fe.FusionEngine.__new__(fe.FusionEngine)
        e2.opts, e2.settings_path, e2.mouse = dict(fe.DEFAULT_OPTS), sp, "mc"
        e2._load()
        check("settings load: clamped and validated", e2.opts["radius"] == 64 and e2.opts["fsr_scale"] == 100
              and e2.opts["fsr"] is False and e2.opts["fsr_sharp"] == 50, e2.opts)
        e2._save()
        check("settings saved whole (no .tmp left)", json.load(open(sp))["opts"]["fsr_sharp"] == 50 and not os.path.exists(sp + ".tmp"))
    check("mc command tnt", fe.mc_command_for("tnt") == ["execute at @p run summon minecraft:tnt ~ ~3 ~"])
    check("mc command unknown -> None", fe.mc_command_for("rm -rf") is None)


class FakeWindows:
    """Stands in for user32 (McWindow's api): one GLFW window of 1000x500 for pid 4242."""

    def __init__(self):
        self.posted, self.finds, self.alive_ = [], 0, True

    def find(self, pid):
        self.finds += 1
        return 77 if pid == 4242 else None

    def alive(self, hwnd):
        return self.alive_

    def client_size(self, hwnd):
        return 1000, 500

    def to_screen(self, hwnd, x, y):
        return x + 100, y + 50

    def scancode(self, vk):
        return {0x10: 0x2A, 0x32: 0x03, 0x51: 0x10}.get(vk, 0)

    def post(self, hwnd, msg, wp, lp):
        self.posted.append((hwnd, msg, wp, lp))
        return True


def inventory_tests():
    api = FakeWindows()
    w = fe.McWindow(api)
    check("McWindow: no Minecraft pid yet -> nothing posted", not w.pointer(0.5, 0.5, 0.0) and not api.posted)
    w.set_pid(4242)
    check("cursor -> WM_MOUSEMOVE at the same fraction of Minecraft's window", w.pointer(0.5, 1.0, 1.0)
          and api.posted == [(77, 0x200, 0, (499 << 16) | 500)], api.posted)
    api.posted.clear()
    w.pointer(0.25, 0.25, 1.0, button=0, down=True)
    check("left button down -> move + WM_LBUTTONDOWN with MK_LBUTTON",
          api.posted == [(77, 0x200, 1, (125 << 16) | 250), (77, 0x201, 1, (125 << 16) | 250)], api.posted)
    api.posted.clear()
    w.pointer(0.25, 0.25, 1.0, button=0, down=False)
    check("left button up -> WM_LBUTTONUP, nothing held", api.posted[-1] == (77, 0x202, 0, (125 << 16) | 250) and w.buttons == 0)
    api.posted.clear()
    w.pointer(0.25, 0.25, 1.0, wheel=-1)
    check("wheel -> WM_MOUSEWHEEL, delta -120 in the high word, screen coordinates",
          api.posted[-1] == (77, 0x20A, ((-120) & 0xFFFF) << 16, ((125 + 50) << 16) | (250 + 100)), api.posted)
    api.posted.clear()
    check("Shift down -> WM_KEYDOWN with the scan code", w.key(0x10, True, 1.0) and api.posted[-1] == (77, 0x100, 0x10, 1 | (0x2A << 16)))
    check("keys outside the inventory set are refused", not w.key(0x1B, True, 1.0) and not w.key(0x41, True, 1.0))
    w.pointer(0.5, 0.5, 1.0, button=1, down=True)
    api.posted.clear()
    w.release_all(1.0)
    msgs = [m[1] for m in api.posted]
    check("release_all lets go of the right button and Shift", 0x205 in msgs and 0x101 in msgs and w.buttons == 0
          and not w.keys_down, msgs)
    up = [m for m in api.posted if m[1] == 0x101][0]
    check("... key up flags (bits 30, 31) set", up[3] & (3 << 30) == (3 << 30))
    api.alive_ = False
    api.posted.clear()
    n = api.finds
    w.pointer(0.5, 0.5, 1.2)
    check("window gone: looked up again at most once a second", api.finds == n)
    w.pointer(0.5, 0.5, 3.0)
    check("... then found again", api.finds == n + 1)
    # the engine: only while the fusion is on and Minecraft is linked
    eng = fe.FusionEngine.__new__(fe.FusionEngine)
    eng.mcwin, eng.on, eng.mc_hello = fe.McWindow(api), True, {"pid": 4242}
    api.alive_ = True
    eng.mc_open = lambda: True
    api.posted.clear()
    eng.on_gta(None, "fusion_pointer", {"type": "fusion_pointer", "x": 2.0, "y": -1, "b": 0, "down": 1})
    check("engine: fusion_pointer clamps to the window and clicks", api.posted[-1][1] == 0x201
          and api.posted[-1][3] == (0 << 16) | 999, api.posted)
    eng.on_gta(None, "fusion_pointer", {"type": "fusion_pointer", "vk": 0x51, "down": 1})
    check("engine: inventory key Q goes through", api.posted[-1][1] == 0x100 and api.posted[-1][2] == 0x51)
    api.posted.clear()
    eng.on_gta(None, "fusion_pointer", {"type": "fusion_pointer", "release": 1})
    check("engine: release lets go of the held button and key", {m[1] for m in api.posted} >= {0x202, 0x101})
    eng.on = False
    api.posted.clear()
    eng.on_gta(None, "fusion_pointer", {"type": "fusion_pointer", "x": 0.5, "y": 0.5, "b": 0, "down": 1})
    check("engine: fusion off -> nothing reaches Minecraft", not any(m[1] == 0x201 for m in api.posted))


def main():
    unit_tests()
    inventory_tests()
    mc = FakeMC()
    settings = os.path.join(os.path.dirname(FB), "fusionbridge_settings.json")
    if os.path.exists(settings):
        os.remove(settings)
    proc = subprocess.Popen([sys.executable, "-I", FB, "--no-browser"], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, bufsize=1)
    tok = None
    end = time.time() + 8
    lines = []
    while time.time() < end and tok is None:
        ln = proc.stdout.readline()
        lines.append(ln)
        m = re.search(r"\?k=(\S+)", ln)
        if m:
            tok = m.group(1)
    try:
        check("hub started", tok is not None, "".join(lines))
        t0 = time.time()
        while mc.handshakes == 0 and time.time() - t0 < 5:
            time.sleep(0.05)
        check("hub opened the WebSocket to the Minecraft mod", mc.handshakes == 1)
        time.sleep(0.3)
        st = http("/api/status", tok)
        check("status shows the Minecraft link open", st.get("fusion", {}).get("mc", {}).get("state") == "open",
              st.get("fusion"))
        check("status has the mod's hello", st["fusion"]["mc"]["hello"].get("pid") == 4242, st["fusion"]["mc"])

        g = GTA()
        g.send({"type": "fusion_hello"})
        s = g.expect("fusion_state", pred=lambda m: m.get("mc") == 1)
        check("GTA gets fusion_state with Minecraft linked", s is not None and s["on"] == 1 and s["mouse"] == "mc", s)
        ks = (s or {}).get("keys") or []
        check("... with the fused keys (Q/E items, I inventory, Z drop, X swap)",
              ks[:4] == [1, 1, 2, 2] and {81: 7, 69: 8, 73: 3, 90: 4, 88: 5} == dict(zip(ks[4::2], ks[5::2])), ks)

        g.send({"type": "fusion_view", "w": 1920, "h": 1080, "aspect": 4 / 3.0})
        v = mc.wait("view")
        check("Minecraft window sized to GTA's projection", v is not None and (v["w"], v["h"]) == (1440, 1080), v)

        cam = {"type": "fusion_cam", "f": 7, "c": [100.0, 200.0, 15.0], "r": [90.0, -10.0, 0.0], "fov": 55.0,
               "p": [101.0, 203.0, 13.3], "h": 45.0, "veh": 0, "pg": 12.3}
        g.send(cam)
        check("first camera levels: Minecraft gets clear", mc.wait("clear") is not None)
        check("... and blocksync", mc.wait("blocksync") is not None)
        check("... GTA gets fusion_ground_reset", g.expect("fusion_ground_reset") is not None)
        hud = mc.wait("hud")
        check("on foot: Minecraft HUD shown", hud is not None and hud["hidden"] is False, hud)
        c = mc.wait("cam")
        ok = (c is not None and close(c["p"][0], 100) and close(c["p"][1], 14.7) and close(c["p"][2], -200)
              and close(c["r"][0], 90) and close(c["r"][1], 10) and close(c["fov"], 55)
              and close(c["pl"][0], 101) and close(c["pl"][1], 13.3 - 1.0 - 0.3) and close(c["pl"][2], -203)
              and close(c["h"], 135) and c["fp"] is False)
        check("camera converted GTA -> Minecraft", ok, c)

        g.send({"type": "fusion_ground", "g": [[100, -201, 12.3], [101, -201, 13.1]]})
        gr = mc.wait("ground")
        check("ground -> barrier columns", gr is not None and gr["c"] == [100, -201, 10, 11, 101, -201, 11, 12], gr)

        g.send({"type": "fusion_input", "k": "attack", "down": True})
        g.send({"type": "fusion_input", "slot": 4})
        g.send({"type": "fusion_input", "scroll": -3})
        k = mc.wait("key")
        check("mouse click -> Minecraft attack", k is not None and k["k"] == "attack" and k["down"] is True, k)
        sl = mc.wait("slot")
        check("number key -> hotbar slot", sl is not None and sl["n"] == 4, sl)
        sc = mc.wait("scroll")
        check("wheel -> scroll", sc is not None and sc["d"] == -1, sc)
        g.send({"type": "fusion_input", "k": "quit_game"})
        time.sleep(0.2)
        check("unknown key is not forwarded", not mc.take("key"))

        mc.send({"t": "explosion", "pos": [100.0, 14.7, -200.0], "r": 4.0, "src": "tnt"})
        b = g.expect("fusion_boom")
        check("Minecraft TNT -> GTA explosion, same spot", b is not None and close(b["x"], 100) and close(b["y"], 200)
              and close(b["z"], 15.0) and b["kind"] == 2, b)
        mc.send({"t": "pteleport", "pos": [50.0, 20.7, -60.0]})
        tp = g.expect("fusion_teleport")
        check("ender pearl -> CJ teleport", tp is not None and close(tp["x"], 50) and close(tp["y"], 60)
              and close(tp["z"], 22.0), tp)
        mc.send({"t": "blocks", "set": [100, 15, -200], "clear": []})
        pr = g.expect("fusion_props", pred=lambda m: "set" in m)
        check("Minecraft block -> GTA wall prop", pr is not None and pr["set"] == [100.5, 199.5, 15.3], pr)
        many = []
        for i in range(1000):
            many += [100 + i, 15, -200]
        mc.send({"t": "blocks", "set": many, "clear": []})
        pr = g.expect("fusion_props", pred=lambda m: "set" in m)
        xs = pr["set"][0::3] if pr else []
        check("a big blocksync reaches GTA capped: the nearest 120 blocks, nearest first", pr is not None
              and len(pr["set"]) == 360 and pr["set"][:3] == [100.5, 199.5, 15.3] and xs == sorted(xs) and max(xs) == 219.5,
              pr and (len(pr["set"]), xs[:3], xs[-3:]))

        r = http("/api/mc?action=tnt", tok)
        cm = mc.wait("cmd")
        check("panel TNT goes through the passthrough mod", r.get("via") == "passthrough" and cm is not None
              and cm["c"] == "execute at @p run summon minecraft:tnt ~ ~3 ~", (r, cm))
        r = http("/api/fusion?op=give&v=portal", tok)
        gv = [mc.wait("cmd"), mc.wait("cmd")]
        check("panel kit 'portal' gives obsidian", r.get("ok") and gv[0] and "obsidian" in gv[0]["c"], (r, gv))

        g.send({"type": "fusion_key", "k": "relevel"})
        check("F8: re-level waits for the next camera", mc.wait("clear", timeout=1.0) is None)  # waits for the next camera
        g.send(dict(cam, pg=12.6))
        cl = mc.wait("clear")
        check("re-level happens with the next camera", cl is not None)
        c = mc.wait("cam")
        check("new offset applied (12.6 -> +0.4)", c is not None and close(c["p"][1], 15.4), c)

        http("/api/fusion?op=mouse&v=gta", tok)
        s = g.expect("fusion_state", pred=lambda m: m.get("mouse") == "gta")
        check("panel mouse -> GTA", s is not None, s)
        http("/api/fusion?op=opt&key=keys_fused&v=0", tok)
        s = g.expect("fusion_state", pred=lambda m: m.get("keys") == [1, 1, 2, 2])
        check("panel option: fused keys off -> only the mouse buttons", s is not None, s)
        http("/api/fusion?op=opt&key=keys_fused&v=1", tok)
        s = g.expect("fusion_state", pred=lambda m: len(m.get("keys") or []) == 14)
        check("... and on again", s is not None, s)
        http("/api/fusion?op=opt&key=hide_cj&v=0", tok)
        s = g.expect("fusion_state", pred=lambda m: m.get("hide_cj") == 0)
        check("panel option hide_cj off", s is not None, s)
        mc.take()
        g.send(dict(cam, pg=12.6))
        c = mc.wait("cam")
        check("CJ shown -> Minecraft first person (no Steve)", c is not None and c["fp"] is True, c)

        g.send(dict(cam, veh=1, pg=12.6))
        hud = mc.wait("hud")
        check("in a car: Minecraft HUD hidden", hud is not None and hud["hidden"] is True, hud)

        http("/api/fusion?op=on&v=0", tok)
        s = g.expect("fusion_state", pred=lambda m: m.get("on") == 0)
        check("panel turns the fusion off", s is not None, s)
        mc.take()
        g.send(cam)
        time.sleep(0.3)
        check("fusion off: no camera forwarded", not mc.take("cam"))
        g.send({"type": "fusion_key", "k": "toggle"})
        s = g.expect("fusion_state", pred=lambda m: m.get("on") == 1)
        check("F7 turns it back on", s is not None, s)
        mc.take()
        g.send(dict(cam, pg=12.6))            # turning it on re-levels with the next camera
        check("turned back on: ground re-leveled", mc.wait("clear") is not None)
        time.sleep(0.4)                       # the panel status refreshes 4x/s

        st = http("/api/status", tok)
        fu = st["fusion"]
        check("status: booms/teleports counted", fu["booms"] == 1 and fu["teleports"] == 1, fu)
        check("status: level + ground counted", fu["level"]["have"] and fu["level"]["ground_cols"] == 2, fu["level"])
        check("settings saved", os.path.exists(settings) and json.load(open(settings))["mouse"] == "gta")

        mc.drop()
        s = g.expect("fusion_state", pred=lambda m: m.get("mc") == 0, timeout=4)
        check("Minecraft closed: GTA told (mc=0)", s is not None, s)
        t0 = time.time()
        while mc.handshakes < 2 and time.time() - t0 < 6:
            time.sleep(0.05)
        check("hub reconnects to Minecraft", mc.handshakes == 2)
        s = g.expect("fusion_state", pred=lambda m: m.get("mc") == 1, timeout=4)
        check("... and GTA is told again (mc=1)", s is not None, s)
    finally:
        proc.terminate()
        try:
            proc.wait(3)
        except Exception:
            proc.kill()
        if os.path.exists(settings):
            os.remove(settings)
    bad = [n for n, ok in results if not ok]
    print("\n%d/%d passaram" % (len(results) - len(bad), len(results)))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
