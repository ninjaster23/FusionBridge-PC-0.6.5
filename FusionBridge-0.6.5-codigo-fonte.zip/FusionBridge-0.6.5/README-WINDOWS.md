# FusionBridge PC 0.6.5 (Windows)

Ponte ao vivo entre **Minecraft Java** e **GTA: San Andreas** no PC. Na 0.5.0 os jogos trocavam eventos (TNT vira explosão perto do CJ, corações no HUD). Na **0.6.0 o FusionBridge virou o servidor de fusão**: o Minecraft é desenhado **dentro** do GTA SA, como no kit "Minecraft no GTA V". Na **0.6.1 ele virou um app de Windows**: o `FusionBridge.exe` abre uma janela própria com tudo dentro (sem navegador), roda o servidor dentro dele e é aceito pelo Controle inteligente de aplicativo (`SEGURANCA-WINDOWS.md`). Na **0.6.5** ele ganhou o **Minecraft automático** (um Prism portátil que abre e fecha o Minecraft junto com o GTA, como o SkyCraft faz no Skyrim) e a página **Mods fusion**, que instala e abre o **SkyCraft** (Minecraft dentro do Skyrim). Para instalar e jogar, leia o **`COMECE-AQUI.md`**.

## Como a fusão funciona

```
GTA San Andreas (1.0 US)                         FusionBridge.exe (app + hub)              Minecraft Java 26.3 + Fabric
  FusionBridgeGTA.lua 0.2.4 (MoonLoader)            hub 127.0.0.1:28765                       mod passthrough 0.1.0 (MIT)
    fusion_cam (todo frame)      ------------>      fusion_engine.py  ---- WebSocket ---->    HostLink 127.0.0.1:25599
    fusion_ground / fusion_input ------------>        GTA -> Minecraft:   cam, ground,           (câmera, barreiras,
    fusion_boom/teleport/props   <------------        key, slot, scroll,  view, hud, cmd         teclas, comandos)
                                                      Minecraft -> GTA:   explosion,          <-- explosion, pteleport,
  FusionBridgeSA.asi (ReShade 6.8 add-on, D3D9)       pteleport, blocks                           blocks
    FusionBridgeSA.fx  <------------- memória compartilhada "Local\MCPassthroughFrame" ---------  FrameExporter (cor + profundidade + HUD)
  FusionBridgeMC 0.2.0 (opcional, o mesmo de antes) --> hub (Caos, player_state)
```

- **Coordenadas:** 1 metro do GTA = 1 bloco. GTA (x, y, z) → Minecraft (x, z + yoff, −y). Yaw do Minecraft = 180 − heading do GTA, pitch = −pitch. `yoff` põe o chão debaixo do CJ exatamente na borda de um bloco (F8 ou automático) e, no alto do Monte Chiliad, desloca blocos inteiros para caber na altura do Minecraft.
- **Câmera:** o script do GTA lê a câmera que o jogo realmente desenha (RenderWare, pelo ASI: posição, direção, roll, FOV vertical, near/far e o aspecto da projeção, que é 4:3 esticado sem widescreen fix) e manda todo frame. O motor converte e manda ao Minecraft, que redimensiona a janela para a imagem do GTA.
- **Chão:** o script sonda o chão do GTA em espiral ao redor do CJ (`getGroundZFor3dCoord`, 96 por frame, raio 40) e o motor transforma em colunas de barreira no Minecraft.
- **Imagem:** o Minecraft copia cor + profundidade do mundo e, separado, mão + HUD para a memória compartilhada. O `FusionBridgeSA.asi` (add-on do ReShade) sobe o frame mais novo para texturas e o `FusionBridgeSA.fx` desenha o Minecraft onde ele está mais perto que o buffer de profundidade do GTA, reprojetando da pose em que o Minecraft desenhou para a câmera atual do GTA (esconde o atraso), com luz, cor e névoa do GTA. O efeito é aplicado **antes do HUD do GTA** (o radar fica por cima).
- **Mouse:** a pé, os cliques, a rodinha e 1–9 vão para o Minecraft, e o ASI zera o tiro/mira do CJ naquele frame. F6 devolve o mouse ao GTA; no carro ele é sempre do GTA.

## O que vem no pacote

| Arquivo | O que é |
|---|---|
| `FusionBridge.exe` | o app. É o `pythonw.exe` oficial (assinado pela Python Software Foundation), sem alteração |
| `FusionBridge._pth`, `python313.dll`, `python3.dll`, `vcruntime140*.dll`, `runtime\` | o Python oficial que roda o app (tudo assinado pela PSF/Microsoft) |
| `app\fb_app.py`, `app\fb_winui.py` | as telas e o kit de interface nativa Win32 (sem navegador, sem tkinter) |
| `app\fusionbridge.py`, `app\fusion_engine.py` | o hub e o motor de fusão (rodam dentro do app) |
| `app\fb_installer.py` | Instalar/Remover e as checagens de segurança do Windows |
| `app\fb_games.py` | os jogos instalados (registros dos launchers, só leitura) e os mods fusion |
| `app\fb_prism.py` | o Minecraft automático: Prism Launcher portátil (baixado do GitHub oficial), a instância FusionBridge e o que abre/fecha junto com o GTA |
| `app\fb_skycraft.py` | o SkyCraft (Minecraft dentro do Skyrim): versão do Skyrim, SKSE, Address Library, instalar/remover com registro, preparar o Minecraft dele, jogar, logs |
| `app\fb_upscale.py`, `app\fb_perf.py`, `app\fb_art.py` | o Upscale em qualquer jogo (Magpie), as placas de vídeo e a logo desenhada em código |
| `fusion-mods\` | um `.json` por mod fusion (GTA SA, Minecraft Java, SkyCraft no Skyrim e no Minecraft) e `COMO-ADICIONAR-MOD.md` |
| `app\sitecustomize.py` | o ponto de partida: o Python oficial importa e abre a janela |
| `moonloader/FusionBridgeGTA.lua` | o módulo do GTA SA (MoonLoader), 0.2.4 |
| `gta/FusionBridgeSA.asi`, `gta/shaders/FusionBridgeSA.fx` | o compositor (ReShade add-on, 32-bit) e o efeito |
| `mod/passthrough-0.1.0.jar` (+ licença MIT), `mod/FusionBridgeMC-0.2.0.jar` | os mods do Minecraft |
| `src/asi/` | código do ASI (C++), `build.sh` (MinGW) e teste da matemática da câmera |
| `tools/build_app.py` | monta o `FusionBridge.exe` + `runtime\` a partir do pacote oficial do Python |
| `tests/`, `tools/` | testes e verificação do shader |

## Modo servidor (testes)

`FusionBridge.exe -X fb=server` (ou `python app/fusionbridge.py`) sobe só o hub, sem janela, para os testes automáticos. Ele nunca abre o navegador.

## O que foi testado aqui e o que não foi

Testado (Linux, sem o jogo):
- **O app de verdade** (`FusionBridge.exe` com o runtime assinado) no **Wine**, numa tela virtual: abre a janela; o hub de dentro dele conecta no Minecraft falso e no GTA falso; cliques na janela chegam no jogo certo (fusão liga/desliga, mouse, TNT no Minecraft, explosão no GTA); o seletor de jogos (clique no cartão Host, escolha na lista, Enter/Esc) e um mod fusion novo reconhecido com o app aberto; uma segunda cópia do app fecha sozinha; fechar a janela encerra o app e libera a porta; `-X fb=server` e `-X fb=elevated` abrem certo (20 testes, com capturas de tela, incluindo um Skyrim falso na página Mods fusion).
- **Jogos instalados e mods fusion:** 56 testes com registros falsos de Steam (duas bibliotecas), Epic, GOG, Ubisoft, Rockstar, EA app, app Xbox e Minecraft; arquivos de mod inválidos recusados com o motivo; mod novo e mod removido percebidos sem reiniciar; a frase de cada lado e o par Host/Secundário; o Skyrim com o SkyCraft e o Minecraft fazendo par com o mod certo de cada lado.
- **Assinaturas:** todos os `.exe/.dll/.pyd` do pacote têm assinatura da Python Software Foundation ou da Microsoft (osslsigncode); a verificação do próprio Windows (WinVerifyTrust, rodando no Wine) dá "assinado" para o `FusionBridge.exe`.
- **Instalar/Remover dentro do app:** 61 testes em pastas falsas do GTA e do Minecraft: arquivos e backups, conflito com d3d9.dll de outro mod, reversão completa no meio de uma falha, pasta protegida (pede administrador), download com SHA-256 errado, arquivo colocado à mão, remoção de uma instalação feita pela 0.6.0, registro adulterado apontando para fora da pasta do jogo; o modo do Minecraft automático (sem o Minecraft Launcher) e o backup dos saves do GTA.
- **SkyCraft:** 64 testes com um Skyrim, um SKSE e uma Address Library falsos: versão lida do `SkyrimSE.exe`, SKSE/Address Library de outra versão recusados, instalação sem sobrescrever nada, backup dos saves, troca de um SKSE antigo com backup e devolução no Remover, `SkyCraft.ini` mudando sem perder os comentários, o Minecraft do SkyCraft desempacotado com o mesmo `bundle.stamp` do SkyCraft.dll, Jogar pelo `skse64_loader.exe` abrindo a Steam antes, 1.5.97 e Game Pass recusados, zip com caminho `../` recusado.
- **Minecraft automático:** 32 testes: o Prism desempacotado e a instância FusionBridge (Minecraft 26.3, Fabric 0.19.5), as configurações do jogador mantidas, abrir só depois da conta Microsoft, abrir com o GTA uma vez só, nunca um segundo, fechar só o que o app abriu, janela fora da tela e de volta, e o Remover guardando o mundo.
- **Motor de fusão + hub:** 76 testes de ponta a ponta; hub 0.5.0: 23.
- **Script do GTA:** 109 testes da fusão (com as teclas fundidas e o inventário) + 28 da 0.5.0 (LuaJIT). Matemática da câmera do ASI: 20.000 câmeras.
- **ASI e shader:** compilam (MinGW / compilador do ReShade + d3dcompiler da Microsoft para Direct3D 9).

Não testado (precisa do seu PC):
- O app no Windows de verdade (testei no Wine), e com o Controle inteligente ligado.
- A lista de jogos com os launchers de verdade (testei com registros falsos no formato deles).
- Tudo dentro do GTA SA real: o ASI com o ReShade e o MoonLoader, o alinhamento das imagens, os ganchos.
- Os downloads do Instalar (ReShade, Fabric API, shaders): as fontes e os SHA-256 são os mesmos do kit, mas este ambiente não alcança esses sites. Os zips do Prism 11.1.1 e do SkyCraft 0.1.2 foram baixados aqui do GitHub oficial e os SHA-256 conferem com os fixados no app.
- O SkyCraft e o Minecraft automático com o Skyrim, o Prism e o Minecraft de verdade (a conta Microsoft, os downloads do Prism, a janela fora da tela numa placa de vídeo real).

Se algo falhar, as páginas Ponte, Segurança e Log, o `FusionBridgeSA.log` e o `ReShade.log` na pasta do GTA (e, no SkyCraft, o `SkyCraft.log`) dizem em que peça parou.
