// Camera conventions shared by the ASI and its native unit test (no Windows, no game).
//
// GTA SA world: x east, y north, z up (right-handed). The RenderWare camera frame gives the view direction
// ("at") and the camera's up vector. GTA heading: 0 = north, 90 = west (counter-clockwise from above).
// Minecraft: GTA (x, y, z) -> Minecraft (x, z + yoff, -y). Minecraft's camera rotation is
// rotationYXZ(pi - yaw, -pitch, roll) with the camera looking down -z (FusionBridge mod / passthrough mod).
#pragma once
#include <cmath>

namespace fbmath
{
	constexpr float kPi = 3.14159265358979f;
	constexpr float kDeg = 180.0f / kPi;

	inline float wrap180(float a)
	{
		a = std::fmod(a, 360.0f);
		if (a > 180.0f)
			a -= 360.0f;
		if (a <= -180.0f)
			a += 360.0f;
		return a;
	}

	struct Angles
	{
		float heading, pitch, roll; // GTA convention, degrees
	};

	/// GTA heading/pitch/roll from the camera's forward and up vectors (GTA world space).
	/// Roll is positive when the camera's up vector leans to the left, which is Minecraft's roll sign.
	inline Angles angles_from_vectors(const float f_in[3], const float u_in[3], float fallback_heading = 0.0f)
	{
		float f[3] = {f_in[0], f_in[1], f_in[2]};
		const float fl = std::sqrt(f[0] * f[0] + f[1] * f[1] + f[2] * f[2]);
		if (fl > 1e-6f)
			for (float &c : f)
				c /= fl;
		Angles a;
		const float horiz = std::sqrt(f[0] * f[0] + f[1] * f[1]);
		a.heading = horiz > 1e-5f ? std::atan2(-f[0], f[1]) * kDeg : fallback_heading;
		a.pitch = std::asin(f[2] < -1.0f ? -1.0f : (f[2] > 1.0f ? 1.0f : f[2])) * kDeg;
		a.roll = 0.0f;
		if (horiz > 1e-5f)
		{
			// the camera's right and up with no roll: right = f x Z, up0 = right x f
			const float r0[3] = {f[1] / horiz, -f[0] / horiz, 0.0f};
			const float u0[3] = {r0[1] * f[2] - r0[2] * f[1], r0[2] * f[0] - r0[0] * f[2], r0[0] * f[1] - r0[1] * f[0]};
			const float ur = u_in[0] * r0[0] + u_in[1] * r0[1] + u_in[2] * r0[2];
			const float uu = u_in[0] * u0[0] + u_in[1] * u0[1] + u_in[2] * u0[2];
			if (std::fabs(ur) + std::fabs(uu) > 1e-6f)
				a.roll = std::atan2(-ur, uu) * kDeg;
		}
		return a;
	}

	struct McPose
	{
		float yaw, pitch, roll, fov;
		double x, y, z;
	};

	inline McPose mc_pose(const float pos[3], const Angles &a, float vfov, float yoff)
	{
		McPose p;
		p.yaw = wrap180(180.0f - a.heading);
		p.pitch = -a.pitch;
		p.roll = a.roll;
		p.fov = vfov;
		p.x = pos[0];
		p.y = double(pos[2]) + yoff;
		p.z = -double(pos[1]);
		return p;
	}

	/// Camera-to-world rotation the way Minecraft builds it: Ry(pi - yaw) * Rx(-pitch) * Rz(roll).
	inline void mc_camera_rotation(float yaw, float pitch, float roll, float m[3][3])
	{
		const float a = kPi - yaw / kDeg, b = -pitch / kDeg, c = roll / kDeg;
		const float ca = std::cos(a), sa = std::sin(a), cb = std::cos(b), sb = std::sin(b), cc = std::cos(c), sc = std::sin(c);
		const float ry[3][3] = {{ca, 0, sa}, {0, 1, 0}, {-sa, 0, ca}};
		const float rx[3][3] = {{1, 0, 0}, {0, cb, -sb}, {0, sb, cb}};
		const float rz[3][3] = {{cc, -sc, 0}, {sc, cc, 0}, {0, 0, 1}};
		float t[3][3] = {};
		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j)
				for (int k = 0; k < 3; ++k)
					t[i][j] += ry[i][k] * rx[k][j];
		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j)
			{
				m[i][j] = 0;
				for (int k = 0; k < 3; ++k)
					m[i][j] += t[i][k] * rz[k][j];
			}
	}

	/// Rows of R_mc^T * R_host: turns a ray in the host camera's space into Minecraft's camera space.
	inline void warp_matrix(const McPose &host, const McPose &mc, float out[3][3])
	{
		float rh[3][3], rm[3][3];
		mc_camera_rotation(host.yaw, host.pitch, host.roll, rh);
		mc_camera_rotation(mc.yaw, mc.pitch, mc.roll, rm);
		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j)
			{
				out[i][j] = 0;
				for (int k = 0; k < 3; ++k)
					out[i][j] += rm[k][i] * rh[k][j];
			}
	}

	/// Minecraft's camera position relative to the host's, in Minecraft's camera space: T = R_mc^T (host - mc).
	inline void warp_translation(const McPose &host, const McPose &mc, float t[3])
	{
		float rm[3][3];
		mc_camera_rotation(mc.yaw, mc.pitch, mc.roll, rm);
		const float d[3] = {float(host.x - mc.x), float(host.y - mc.y), float(host.z - mc.z)};
		for (int i = 0; i < 3; ++i)
			t[i] = rm[0][i] * d[0] + rm[1][i] * d[1] + rm[2][i] * d[2];
	}
}
