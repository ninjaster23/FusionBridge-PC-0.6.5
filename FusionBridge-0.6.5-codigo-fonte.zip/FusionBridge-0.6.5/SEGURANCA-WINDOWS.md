# FusionBridge 0.6.5 e a segurança do Windows

## O que estava dando problema

O Controle inteligente de aplicativo (Smart App Control) do Windows 11 deixa um programa rodar só quando:
- ele tem uma **assinatura digital de um editor reconhecido**; ou
- a nuvem da Microsoft já conhece aquele arquivo e confia nele.

Além disso, ele **bloqueia, sem opção de liberar**, arquivos baixados da internet com certas extensões, entre elas `.bat`, `.cmd`, `.ps1` e `.lnk`, quando você tenta abri-los.

A versão 0.6.0 dependia justamente de `FusionBridge.bat`, `INSTALAR.cmd`, `REMOVER.cmd` e de scripts PowerShell. Sob o Controle inteligente, o PowerShell sem assinatura roda em "modo de linguagem restrito", e nesse modo o instalador antigo quebra.

## O que a 0.6.5 faz

- **`FusionBridge.exe` é o executável oficial do Python** (`pythonw.exe` do pacote oficial da python.org), **sem nenhum byte alterado**, só com outro nome. Ele é assinado pela **Python Software Foundation**, um editor reconhecido pela Microsoft. Renomear não muda a assinatura, porque ela vale para o conteúdo do arquivo e não para o nome.
- Todo o código nativo que vem no pacote é assinado pela **Python Software Foundation** ou pela **Microsoft**: `python313.dll`, `python3.dll`, `vcruntime140.dll`, `vcruntime140_1.dll` e tudo em `runtime\` (`*.pyd`, `libffi`, `libssl`, `libcrypto`).
- O código do FusionBridge são arquivos `.py` (em `app\`) executados por esse Python. A Microsoft só verifica scripts em hosts preparados para isso (PowerShell, VBScript/JScript, mshta), e o Python não é um deles. O que ele carrega de código nativo continua sendo verificado, e é tudo assinado.
- **Não há mais `.bat`, `.cmd`, `.ps1` nem `.lnk` no pacote.** Instalar, Remover e o atalho viraram botões dentro do app. O atalho criado pelo app é feito no seu PC, então não carrega a marca de "baixado da internet".
- **Nada abre no navegador e não há servidor exposto.** A ponte escuta só em `127.0.0.1` (o próprio PC). No Windows, a porta fica exclusiva do FusionBridge.
- **A lista de jogos e os mods fusion não executam nada.** Para mostrar os jogos instalados, o app só lê os registros dos launchers (Steam, Epic, GOG etc.). Um mod fusion em `fusion-mods\` é um `.json` de descrição: o app lê os campos e recusa caminhos fora da pasta do jogo. Por isso adicionar mods fusion não muda nada para o Controle inteligente.

Você pode conferir as assinaturas:
- no Windows, clique com o botão direito no `FusionBridge.exe` → Propriedades → Assinaturas Digitais → "Python Software Foundation";
- ou na página **Segurança** do app, que mostra cada arquivo verificado pelo próprio Windows (WinVerifyTrust).

Como é o Python, o Gerenciador de Tarefas mostra "Python" na descrição do processo e o `FusionBridge.exe` tem o ícone do Python. Mudar o ícone exigiria alterar o arquivo, e aí a assinatura deixaria de valer. A janela, a barra de tarefas e o atalho usam o ícone do FusionBridge.

## O Upscale em qualquer jogo (Magpie)

O cartão **Upscale em qualquer jogo** (página Desempenho) baixa o **Magpie** 0.12.1, um programa de terceiros de código aberto (GPL-3.0, github.com/Blinue/Magpie), e confere o SHA-256 do zip oficial antes de extrair. O `Magpie.exe` **não tem assinatura digital**. Por isso, com o Controle inteligente de aplicativo **ligado**, o Windows pode bloquear o Magpie quando você clicar em **Abrir upscaler**. O app avisa quando é o caso e não muda essa configuração. O Magpie fica só em `%LOCALAPPDATA%\FusionBridge\Magpie`, e o botão **Remover** do cartão apaga a pasta.

## O Minecraft automático (Prism) e o SkyCraft

- O **Minecraft automático** baixa o **Prism Launcher 11.1.1** portátil (GPL-3.0, github.com/PrismLauncher/PrismLauncher) e confere o SHA-256 do zip oficial antes de extrair em `%LOCALAPPDATA%\FusionBridge\Prism`. O Prism abre o Minecraft com o Java que ele mesmo baixa. Nem o `prismlauncher.exe` nem esse Java são do pacote assinado do FusionBridge: com o Controle inteligente **ligado**, o Windows pode bloquear o Prism. O app não muda essa configuração, e **Remover o Prism** apaga a pasta (o mundo da fusão vai para os backups antes). O login da Microsoft é feito na janela do próprio Prism: o FusionBridge nunca vê a sua senha.
- O **SkyCraft** (MIT, github.com/chasmlol/SkyCraft) é baixado do GitHub oficial com SHA-256 conferido. Ele, o **SKSE64** e a **Address Library** que você escolhe são DLLs e programas sem assinatura reconhecida que entram no Skyrim. Com o Controle inteligente **ligado**, o Windows pode bloqueá-los (o cartão avisa). O app instala sem sobrescrever nada, guarda um registro de cada arquivo (SHA-256) e o **Remover** tira só o que ele colocou.
- O app não injeta nada nos jogos: ele copia arquivos, abre programas (`skse64_loader.exe`, `prismlauncher.exe`) e, no modo automático, pede para a janela do Minecraft fechar (a mesma mensagem do botão X) ou muda a posição dela.

## O limite que o app não consegue resolver: os mods do GTA

Para a fusão aparecer no jogo, o GTA carrega estas DLLs:
- `MoonLoader.asi` e o carregador de ASI;
- `d3d9.dll` (ReShade);
- `FusionBridgeSA.asi`.

O Controle inteligente avalia toda DLL que um programa carrega. Uma DLL **sem assinatura reconhecida** e pouco conhecida pela nuvem da Microsoft **é bloqueada quando o controle está LIGADO**:
- se for o `d3d9.dll` (ReShade) ou o carregador de ASI (`vorbisFile.dll`/`dinput8.dll`), que o `gta_sa.exe` carrega para abrir, **o GTA nem abre**;
- se for um `.asi` (MoonLoader, `FusionBridgeSA.asi`), o jogo abre sem aquele mod.

Isso vale para praticamente todo mod de GTA SA, e não dá para contornar de dentro do app.

Na página **Segurança**:
- **Estado** mostra se o Controle inteligente está Ligado, Em avaliação ou Desligado. Em avaliação, nada é bloqueado; o Windows só observa.
- **Arquivos do GTA** mostra quais estão assinados.
- **Procurar bloqueios do Windows** lê o log do Windows (CodeIntegrity) e lista o que foi bloqueado no GTA (eventos 3033/3077, em vermelho) e o que *seria* bloqueado com o controle em avaliação (eventos 3034/3076, em amarelo: esses arquivos carregaram). O mesmo log fica no Visualizador de Eventos: *Logs de Aplicativos e Serviços → Microsoft → Windows → CodeIntegrity → Operational*.

Se os mods do GTA forem bloqueados, a Microsoft documenta só dois caminhos:
1. **Os arquivos serem assinados** com um certificado reconhecido. Um certificado autoassinado não serve. Isso depende de quem fez cada mod. Para o `FusionBridgeSA.asi`, seria preciso um certificado de assinatura de código pago, que este projeto não tem. O Microsoft Artifact Signing (antigo Azure Trusted Signing) só atende pessoas físicas nos EUA e no Canadá e empresas de alguns países, e o Brasil não está entre eles. Daqui, o caminho é um certificado OV de uma autoridade reconhecida pela Microsoft, com a chave num token ou HSM.
2. **Desligar o Controle inteligente** em *Segurança do Windows → Controle de aplicativos e do navegador → Configurações do Controle inteligente de aplicativo*. No Windows 11 atualizado (atualização de abril de 2026, KB5083769, liberada aos poucos), dá para ligar de novo depois sem reinstalar o Windows. Sem essa atualização, desligar é definitivo. A decisão é sua; o FusionBridge nunca muda essa configuração.

O Antivírus/SmartScreen do Windows continuam funcionando normalmente com o FusionBridge.

## Para desenvolvedores

- `tools/build_app.py` monta o `FusionBridge.exe` e o `runtime\` a partir do pacote oficial `python` 3.13.16 do nuget.org (SHA-256 fixo). Ele copia os arquivos sem alterar e cria o `FusionBridge._pth`, que aponta para `runtime\` e `app\` e liga o `site`; o `app\sitecustomize.py` abre a janela.
- O app não usa tkinter (o runtime oficial não traz Tcl/Tk): a interface é Win32 puro via ctypes (`app\fb_winui.py`).
- O Python lê a linha de comando antes do app e encerra quando vê uma opção que não conhece. Por isso as opções do app são `-X fb=server` (só o hub, para testes) e `-X fb=elevated` (usada pelo "Reabrir como administrador").
- Com `._pth`, o Python 3.13 ainda acrescenta a pasta de pacotes do usuário (`%APPDATA%\Python\Python313\site-packages`; CPython gh-120037, corrigido só na 3.15). O `sitecustomize.py` limita o caminho de módulos à pasta do FusionBridge antes de abrir o app, e o atalho e o "Reabrir como administrador" passam `-s`, que desliga essa pasta.
